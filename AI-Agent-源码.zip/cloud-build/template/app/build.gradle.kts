/**
 * 云端打包模板 —— 单页 WebView 壳工程。
 *
 * 所有随构建变化的信息都从 Gradle 属性读入（由云构建服务用 -P 注入），
 * 因此同一份模板可以反复复用，不需要为每次构建生成新的工程文件。
 */
plugins {
    id("com.android.application")
}

fun prop(name: String, fallback: String): String =
    (project.findProperty(name) as String?)?.takeIf { it.isNotBlank() } ?: fallback

val appPackage = prop("appPackage", "com.example.webshell")
val appLabel = prop("appLabel", "Web App")
// 屏幕方向由构建请求传入；unspecified 表示交给系统（跟随传感器）
val appOrientation = prop("appOrientation", "unspecified")

android {
    namespace = appPackage
    compileSdk = 36

    defaultConfig {
        applicationId = appPackage
        minSdk = prop("appMinSdk", "24").toIntOrNull()?.coerceIn(21, 35) ?: 24
        targetSdk = 36
        versionCode = prop("appVersionCode", "1").toIntOrNull() ?: 1
        versionName = prop("appVersionName", "1.0")
        resValue("string", "app_name", appLabel)
        manifestPlaceholders["appOrientation"] = appOrientation
    }

    // 壳工程不引入任何 AndroidX 依赖，R8/资源压缩关闭以换取构建速度
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
