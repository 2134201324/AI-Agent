# AI Agent 助手 · 项目交接与上下文说明（v1.8.4）

> ⚠ **已过时，仅作历史参考**。当前版本为 **1.12.0（versionCode 29）**，
> 唯一权威交接文档是 `/workspace/AI-Agent-项目交接文档.txt`。
> 本文件（v1.8.4 时期：versionCode 15、112 个单测、无 REA / 无云打包）中的
> 版本号、测试数、功能清单、工具数量均已大幅过期，**有冲突时一律以该 txt 为准**。
> 保留本文件只是为了追溯 v1.8.4 当时的设计决策。

> 用途：本文件是「AI Agent 助手」Android 项目的完整交接说明。开启新对话时，把本文件提供给助手，即可在无需回顾历史对话的前提下继续开发。

---

## 一、项目概况

- **产品形态**：原生 Android 应用，名为「AI Agent 助手」（包名 `com.example.nativedemo`）
- **技术栈**：Kotlin + Jetpack Compose（非 WebView / 非混合开发）
- **当前版本**：**1.8.4（versionCode 15）**
- **SDK 配置**：compileSdk 36 / targetSdk 36 / minSdk 24
- **构建插件**：AGP 8.13.0、Kotlin 2.0.21、Compose BOM 2024.12.01，需 JDK 21
- **发布构建**：开启 R8 混淆与资源压缩，产物约 1.7 MB
- **测试现状**：**112 个单元测试全部通过**（12 个测试文件）
- **工程目录**：工作区内 `native-compose-demo/`

---

## 二、功能全景（截至 v1.8.4）

### 1. 对话与模型接入

- OpenAI 兼容协议的流式对话，支持工具调用（function calling）
- 内置服务商预设一键填充：阿里云百炼、OpenAI、DeepSeek、Kimi、智谱 GLM、硅基流动、DeepSeek 网页桥接、自定义
- **按 Key 拉取模型清单**：一键获取该密钥在服务端真正可用的模型并点选
- **API Key 安全存储**：Android Keystore AES-256-GCM 加密，明文永不落盘；每个模型档案使用独立加密别名

### 2. 多模型编排

- 主模型拆解任务 → 多个子模型并行生成 → 主模型整合与纠错
- 用户拥有最高权限：主模型、子模型均可自由指定；子模型之间只能做一次性询问，不能互相干预
- 模型档案系统：每个档案 = 地址 + 模型名 + 独立 Key + 角色（仅主模型 / 仅子模型 / 两者皆可）

### 3. 网页桥接（DSH）专项能力

- 「DeepSeek 网页桥接」预设 + 就地使用指引
- **免 API Key**：本地 / 局域网端点自动放行（详见第四节）
- **局域网自动发现**：自动扫出电脑上运行的桥接服务
- **一键全自动配置**：扫描 → 填入 → 选模型 → 保存 → 验证，一次点击完成

### 4. Agent 工具系统

- 可插拔工具注册表，用户可逐项开关
- 内置工具：网页抓取、文件读取 / 写入 / 创建 / 编辑 / 删除 / 列表、命令执行
- SAF 目录授权（用户自选可访问目录），带命令黑名单防护

### 5. 命令终端

- 内置类似 Termux 的命令行终端，与 `run_command` 工具共用同一引擎

### 6. 界面与阅读体验

- 深度外观自定义：主题模式、字体缩放、界面密度、气泡圆角、自定义背景图、逐色槽配色
- **智能图文适配**：按背景明暗自动调整文字层级，保证可读性
- **长代码折叠**：助手消息中的代码块默认折叠为摘要卡，按需展开，不铺满屏幕
- **流式滚动跟随**：生成过程中可自由向上翻阅，滑回底部自动恢复跟随

---

## 三、版本演进（近期）

- **v1.8.0（vc 11）**：多模型编排上线——主模型拆任务、子模型并行、主模型整合；模型档案与多 Key 体系
- **v1.8.1（vc 12）**：修复流式输出时无法查看最新消息的问题（改为底部锚点 + 跟随态机）
- **v1.8.2（vc 13）**：DSH 网页桥接预设与指引；模型连接页支持在多个档案间选用；长代码块折叠收集
- **v1.8.3（vc 14）**：按 Key 拉取模型清单（`GET /models`，容错解析）；局域网桥接自动发现
- **v1.8.4（vc 15）**：网页桥接免 Key；一键全自动配置；连接失败自动拉取模型清单救援

---

## 四、本轮对话确立的核心机制（重要）

### 1. 网页桥接为什么曾经需要 Key，以及现在的解法

- **根因**：OpenAI 兼容协议规定客户端在 `Authorization` 头携带 Bearer 令牌，几乎所有客户端都硬编码该头；早期代码又加了一道「Key 为空则拒绝发送」的闸门。但 DSH 这类桥接工具转发的是浏览器网页登录态，**根本不校验令牌**。
- **解法**：识别「本地 / 局域网端点」，这类地址不要求用户填 Key，由程序自动补占位令牌以保证请求头存在。
- **判定范围**：`127.0.0.1`、`localhost`、`::1`、`10.x`、`192.168.x`、`172.16–31.x`、`169.254.x`（热点直连）、`*.local`、`host.docker.internal`。
- **云服务不受影响**：非本地端点仍然必须填写真实 Key。

### 2. 模型清单拉取

- 调用 `GET {baseUrl}/models`，兼容三种响应形态：标准 `data[]`、`models[]`、裸数组
- 仅接受字符串型 id（数字等一律忽略），避免把普通 JSON 接口误判为模型服务
- Base URL 漏写版本层（如只填 `http://host:8000`）时自动回退尝试 `/v1/models`
- 界面上选中模型即自动保存，避免「选了但没保存、聊天仍用旧模型名」的死循环

### 3. 局域网桥接自动发现

- 由本机 IPv4 推导 `/24` 网段，并发探测 8000 / 8001 / 8080 端口的 `/v1/models` 与 `/models`
- 判定为命中：能解析出模型清单；或返回 401/403（像个需要 Key 的 API）
- 带实时进度、可取消、20 秒硬超时保底；单次探测超时 600ms、不重试

### 4. 一键全自动配置

扫描局域网 → 优先选择「无需 Key 就能列出模型」的桥接 → 填入 Base URL → 自动占位 Key → 智能选模型（`deepseek-chat` 优先）→ 写入配置 → 自动发起连接测试。

### 5. 连接失败救援

测试连接失败时自动静默拉取该服务的可用模型清单，成功即弹出可点选列表。这直接解决了「地址对、模型名错」导致的 HTTP 400 死循环。

---

## 五、关键文件索引

### 网络与模型层

- `data/llm/LlmClient.kt`：OpenAI 兼容客户端，支持非流式、流式（SSE + 工具调用分片归并）、连通性诊断、模型清单拉取
- `data/llm/LlmDtos.kt`：协议数据模型与模型清单容错解析
- `data/llm/LlmError.kt`：分类异常（鉴权 / 限流 / 服务端 / 协议违规等）与用户可读提示
- `data/llm/LlmPreset.kt`：服务商预设（含「是否需要用户自备 Key」标记）
- `data/llm/LocalBridge.kt`：本地端点判定、占位令牌、模型优选
- `data/llm/BridgeDiscovery.kt`：局域网并发扫描与网段推导

### Agent 层

- `data/agent/AgentEngine.kt`：Agent 主循环（请求 → 工具 → 回灌 → 再请求）
- `data/agent/Orchestrator.kt`：多模型编排引擎
- `data/agent/ConversationSanitizer.kt`：会话历史清理（防历史中毒导致 400）

### 设置与持久化

- `data/settings/SettingsRepository.kt`：设置总仓库（DataStore + Flow）
- `data/settings/SecureStore.kt`：Keystore 加密存储（多别名）
- `data/settings/ModelProfile.kt`：模型档案模型与编解码

### 界面

- `ui/chat/ChatScreen.kt` / `ChatViewModel.kt`：对话页与消息渲染
- `ui/chat/MessageSegments.kt` / `CodeBlockCard.kt`：消息分段与代码折叠
- `ui/settings/SettingsScreen.kt`：设置主页 + 模型连接页 + 局域网自动发现
- `ui/settings/OrchestrationPage.kt`：多模型编排页与档案管理
- `ui/terminal/`：内置命令终端

---

## 六、构建与交付流程

```bash
# 1. 环境（JDK 21 + Android SDK；路径因机器而异，可用 `which java` / `ls /opt` 复核）
export JAVA_HOME=<JDK 21 安装路径>

# 2. 跑测试 + 打包 release
cd native-compose-demo
./gradlew testDebugUnitTest assembleRelease

# 3. 取出未签名产物并签名
cp app/build/outputs/apk/release/app-release-unsigned.apk /workspace/AI-Agent-vX.Y.Z.apk
<android-sdk>/build-tools/36.0.0/apksigner sign \
  --ks <用户主目录>/.android/debug.keystore --ks-key-alias androiddebugkey \
  --ks-pass pass:android --key-pass pass:android /workspace/AI-Agent-vX.Y.Z.apk

# 4. 复验版本号与签名
<android-sdk>/build-tools/36.0.0/aapt2 dump badging /workspace/AI-Agent-vX.Y.Z.apk | grep package
<android-sdk>/build-tools/36.0.0/apksigner verify /workspace/AI-Agent-vX.Y.Z.apk
```

- **版本号推进规则**：每次交付必须递增 `versionCode` 并更新 `versionName`，可在 `app/build.gradle.kts` 中修改，并在注释里写明本次改了什么
- **调试密钥**位于用户主目录的 `.android/debug.keystore`（沙盒默认密钥）。正式发布请替换为自己的 keystore，密钥文件不随源码分发
- 沙盒内 Gradle 开启了构建缓存，清理构建目录后重建也可快速完成

---

## 七、已知边界与注意事项

1. **移动数据无法直连局域网桥接**：手机走流量时与电脑不在同一可达网段，这是网络事实而非程序缺陷。必须手机与电脑连同一 WiFi；远程使用需在电脑侧部署内网穿透（cloudflared / frp / ngrok）后手动填写公网地址。
2. **明文 HTTP 已放行**：应用已配置网络安全策略允许 `http://` 自建服务地址（本地推理服务 / 桥接工具常见形态），`https` 仍走系统证书校验。
3. **API Key 不落盘明文**：全部经 Android Keystore 加密，换机恢复后需重新填写。
4. **工作区 `.codebuddy` 目录不可删除**：它是项目数据目录，不是缓存。
5. **会话产物面板**：客户端「产物」面板记录的是历史交付台账，删除沙盒文件不会同步移除该面板条目，需在面板内用「批量操作」自行清理。

---

## 八、如何继续开发（新对话使用说明）

开启新对话时，建议按以下方式提供上下文：

- **一句话开场**：继续「AI Agent 助手」Android 项目；工程在工作区 `native-compose-demo/`；当前版本 v1.8.4；先查阅资料库中的《AI Agent 助手 · 项目交接与上下文说明》了解全貌。
- **本次要做什么**：直接描述需求（新增功能 / 修 bug / 调整界面）。
- **交付约定**（项目一贯做法）：
  1. 改动后必须跑通全部单元测试；
  2. 交付物是可安装的已签名 APK；
  3. 版本号必须递增；
  4. 回答与文档使用中文；
  5. 涉及网络行为的功能，需要说明其边界与失败原因，不做无依据的承诺。

**当前已完成状态**：v1.8.4 已构建、签名、验证通过（112 个测试全绿），成品为 `AI-Agent-v1.8.4.apk`，随附完整工程源码与配置打包件。
