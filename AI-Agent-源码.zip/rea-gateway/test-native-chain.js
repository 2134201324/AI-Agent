#!/usr/bin/env node
/**
 * 经网关验证 REA native 分析链路：open_binary → binary_overview → procedure_pseudo_code。
 * 用法：node test-native-chain.js [so 文件路径]
 */
'use strict';
const fs = require('fs');

const BASE = process.env.BASE || 'http://localhost:8080';
const TOKEN = process.env.REA_GATEWAY_TOKEN || '8aa553c8af1806f8953815330a0736cd';
const SO = process.argv[2] || '/workspace/rea-uploads/1791977198608_libpath.so';

async function mcp(method, params) {
  const res = await fetch(`${BASE}/mcp`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params })
  });
  const json = await res.json();
  if (json.error) throw new Error(`${method} 失败: ${JSON.stringify(json.error)}`);
  return json.result;
}

function textOf(result) {
  const items = (result && result.content) || [];
  return items.filter((i) => i && typeof i.text === 'string').map((i) => i.text).join('\n');
}

(async () => {
  const size = fs.statSync(SO).size;
  console.log(`[1/3] open_binary: ${SO} (${(size / 1024).toFixed(1)} KB)`);
  const open = await mcp('tools/call', {
    name: 'open_binary',
    arguments: { path: SO, format: 'executable' }
  });
  const openText = textOf(open);
  console.log(openText.slice(0, 400));
  const m = openText.match(/session[_ ]?id["'\s:]+([A-Za-z0-9\-_]+)/i) || openText.match(/"id"\s*:\s*"([^"]+)"/);
  const sessionId = m && m[1];
  if (!sessionId) throw new Error('未从 open_binary 结果中解析到 session id');
  console.log(`\n→ session id = ${sessionId}`);

  console.log(`\n[2/3] binary_overview (session ${sessionId})`);
  const ov = await mcp('tools/call', { name: 'binary_overview', arguments: { session_id: sessionId } });
  const ovText = textOf(ov);
  console.log(ovText.slice(0, 700));

  console.log(`\n[3/3] procedure_pseudo_code: JNI_OnLoad`);
  const pc = await mcp('tools/call', {
    name: 'procedure_pseudo_code',
    arguments: { session_id: sessionId, name: 'JNI_OnLoad' }
  });
  console.log(textOf(pc).slice(0, 500));

  console.log('\n✓ Ghidra native 链路验证通过');
})().catch((e) => { console.error('✗', e.message); process.exit(1); });
