/**
 * REA 网关 —— 把本机的 REA（MCP stdio server）包装成带鉴权的 HTTP MCP 服务，
 * 并同进程承载「云构建」能力（见 build-service.js）。
 *
 * 架构：
 *   App (Kotlin MCP client)
 *     → HTTPS 本服务（/mcp，JSON-RPC 2.0 over HTTP POST）
 *       → REA stdio 子进程（rea mcp，newline-delimited JSON-RPC）
 *         → Ghidra / Apktool 等引擎
 *
 *   App (云打包页)
 *     → HTTPS 本服务（/build*）
 *       → 沙盒内 JDK + Android SDK + Gradle（见 build-service.js）
 *
 * 端点：
 *   GET  /health                 健康检查（无需鉴权）
 *   POST /mcp                    MCP JSON-RPC：initialize / tools/list / tools/call
 *   POST /upload                 上传文件到服务器（multipart 或原始字节 + X-Filename）
 *   GET  /build/capabilities     云构建工具链自检
 *   POST /build                  提交云构建任务
 *   GET  /build/:id              查询任务（?since=N 增量取日志）
 *   GET  /build/:id/apk          下载签名后的 APK
 *   GET  /builds                 历史任务
 *   DEL  /build/:id              删除任务
 *
 * 环境变量：
 *   PORT                监听端口（默认 8080；云端发布时由平台注入）
 *   REA_GATEWAY_TOKEN   Bearer 令牌（可选，默认用内置固定值，App 侧按此配置）
 *                       鉴权通道：Authorization: Bearer <t> / X-Auth-Token: <t> / ?token=<t>
 *                       （公网代理可能剥 Authorization，故保留三种通道）
 *   REA_BIN             rea 可执行文件路径
 *   REA_UPLOAD_DIR      上传目录
 *   CLOUD_BUILD_ROOT    云构建数据目录（模板 / 任务 / 签名密钥库）
 *
 * 纯 Node 内置模块，无 npm 依赖。
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const buildService = require('./build-service');

const PORT = Number(process.env.PORT || 8080);
// 部署令牌：本地/CI 可用 REA_GATEWAY_TOKEN 覆盖；云端发布脚本只注入 PORT，
// 因此这里必须有固定兜底值，否则线上实例每次随机令牌，App 侧无法配置。
const TOKEN = process.env.REA_GATEWAY_TOKEN || '8aa553c8af1806f8953815330a0736cd';
const REA_BIN = process.env.REA_BIN || '/root/.nvm/versions/node/v22.23.3/bin/rea';
const REA_ARGS = (process.env.REA_ARGS || 'mcp').split(' ');
const UPLOAD_DIR = process.env.REA_UPLOAD_DIR || '/workspace/rea-uploads';
const MAX_UPLOAD_BYTES = 96 * 1024 * 1024;
/** 单个 MCP 响应的字节上限：REA 的清单/会话输出动辄 90K–230K 字符，直接回给手机会炸上下文。 */
const MAX_RESULT_BYTES = 180 * 1024;
/** REA 工具调用超时（Ghidra headless 分析可能要几十秒）。 */
const CALL_TIMEOUT_MS = Number(process.env.REA_CALL_TIMEOUT_MS || 300000);
const PROTOCOL_VERSION = '2025-03-26';

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ── REA stdio 客户端 ────────────────────────────────────────────────────

class ReaStdio {
  constructor() {
    this.proc = null;
    this.buf = '';
    this.pending = new Map();
    this.nextId = 1;
    this.ready = false;
    this.startPromise = null;
    this.stopping = false;
    /** 串行队列：REA 是单会话进程，并发调用会互相踩会话状态。 */
    this.chain = Promise.resolve();
  }

  /** 拉起 REA 并完成 MCP 握手；进程退出后自动重置，下次请求重新拉起。 */
  ensureStarted() {
    if (this.startPromise) return this.startPromise;
    this.startPromise = (async () => {
      await this._spawn();
      const init = await this._sendRequest('initialize', {
        protocolVersion: PROTOCOL_VERSION,
        capabilities: {},
        clientInfo: { name: 'rea-gateway', version: '1.0.0' }
      });
      // 双方协议版本协商：REA 可能不支持我们给的版本，以它的为准
      if (init && typeof init.protocolVersion === 'string') {
        this.serverProtocolVersion = init.protocolVersion;
      }
      this._send({ jsonrpc: '2.0', method: 'notifications/initialized' });
      this.ready = true;
    })();
    // 失败（超时/秒退）时清掉，允许下次重试
    this.startPromise.catch(() => { this.startPromise = null; });
    return this.startPromise;
  }

  _spawn() {
    return new Promise((resolve, reject) => {
      const proc = spawn(REA_BIN, REA_ARGS, {
        // Ghidra headless 需要显式安装目录与 JDK 21。REA 在桌面环境通常由用户 shell
        // 提供这些变量；网关是独立服务进程，必须自带兜底注入，否则 native 类工具
        // 一律报 provider_unavailable（GHIDRA_INSTALL_DIR is not set）。
        env: {
          ...process.env,
          GHIDRA_INSTALL_DIR: process.env.GHIDRA_INSTALL_DIR || '/opt/ghidra',
          JAVA_HOME: process.env.JAVA_HOME || '/usr/lib/jvm/java-21-openjdk-amd64',
          PATH: `${process.env.JAVA_HOME || '/usr/lib/jvm/java-21-openjdk-amd64'}/bin:${process.env.PATH || ''}`,
          NODE_OPTIONS: '--max-old-space-size=3072'
        },
        stdio: ['pipe', 'pipe', 'pipe']
      });
      this.proc = proc;
      let stderr = '';
      let spawned = false;
      proc.stderr.on('data', (d) => {
        stderr += d.toString();
        if (stderr.length > 8000) stderr = stderr.slice(-8000);
      });
      proc.stdout.on('data', (d) => this._onData(d));
      proc.on('exit', (code) => {
        this.proc = null;
        this.ready = false;
        this.startPromise = null;
        for (const [, p] of this.pending) {
          p.reject(new Error(`REA 进程退出（code=${code}）${stderr ? '：' + stderr.slice(-400) : ''}`));
        }
        this.pending.clear();
        if (!spawned) reject(new Error(`REA 启动即退出（code=${code}）：${stderr.slice(-400) || '无 stderr'}`));
      });
      proc.on('error', (e) => {
        if (!spawned) reject(new Error(`无法启动 REA（${REA_BIN}）：${e.message}`));
      });
      // spawn 成功（进程活着）即算启动完成；握手由调用方继续
      setTimeout(() => {
        if (this.proc === proc && !this.stopping) { spawned = true; resolve(); }
      }, 300);
    });
  }

  _onData(chunk) {
    this.buf += chunk.toString();
    let idx;
    while ((idx = this.buf.indexOf('\n')) >= 0) {
      const line = this.buf.slice(0, idx).trim();
      this.buf = this.buf.slice(idx + 1);
      if (!line) continue;
      let msg;
      try { msg = JSON.parse(line); } catch { continue; }
      this._onMessage(msg);
    }
  }

  _onMessage(msg) {
    if (msg.method && msg.id !== undefined) {
      // REA 反向发来的请求（极少见）：回应一个空能力，避免它干等
      this._send({
        jsonrpc: '2.0', id: msg.id,
        result: { protocolVersion: this.serverProtocolVersion || PROTOCOL_VERSION, capabilities: {}, serverInfo: { name: 'rea-gateway', version: '1.0.0' } }
      });
      return;
    }
    if (msg.id !== undefined && this.pending.has(msg.id)) {
      const p = this.pending.get(msg.id);
      this.pending.delete(msg.id);
      if (msg.error) p.reject(new Error(msg.error.message || 'REA 返回错误'));
      else p.resolve(msg.result);
    }
    // 其余一律是通知，忽略
  }

  _send(obj) {
    if (!this.proc || !this.proc.stdin.writable) throw new Error('REA 进程不可写');
    this.proc.stdin.write(JSON.stringify(obj) + '\n');
  }

  _sendRequest(method, params) {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`REA 调用超时（${CALL_TIMEOUT_MS / 1000}s）：${method}`));
      }, CALL_TIMEOUT_MS);
      this.pending.set(id, {
        resolve: (v) => { clearTimeout(timer); resolve(v); },
        reject: (e) => { clearTimeout(timer); reject(e); }
      });
      this._send({ jsonrpc: '2.0', id, method, params: params || {} });
    });
  }

  /** 排队发请求，保证 REA 单会话不被并发打乱。 */
  request(method, params) {
    const run = this.chain.then(() => this._request(method, params));
    this.chain = run.catch(() => {});
    return run;
  }

  async _request(method, params) {
    await this.ensureStarted();
    return this._sendRequest(method, params);
  }
}

const rea = new ReaStdio();

// ── 输出裁剪 ────────────────────────────────────────────────────────────

function truncateResult(result) {
  if (!result || typeof result !== 'object') return result;
  const json = JSON.stringify(result);
  if (json.length <= MAX_RESULT_BYTES) return result;
  // 保留结构，只裁 content 里的超长文本
  const clipped = JSON.parse(json);
  if (Array.isArray(clipped.content)) {
    let budget = Math.floor(MAX_RESULT_BYTES * 0.6);
    for (const item of clipped.content) {
      if (item && typeof item.text === 'string' && item.text.length > budget) {
        item.text = item.text.slice(0, budget) +
          `\n…［网关截断］原文 ${item.text.length} 字符，仅保留前 ${budget} 字符。` +
          `需要完整数据时可缩小查询范围（如指定单个函数/单段地址）后重试。`;
        budget = 0;
      } else if (item && typeof item.text === 'string') {
        budget -= item.text.length;
      }
    }
  }
  return clipped;
}

// ── HTTP 层 ─────────────────────────────────────────────────────────────

function jsonRes(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type, X-Filename'
  });
  res.end(body);
}

function authorized(req, url) {
  // 公网反向代理可能剥掉 Authorization 头（实测 workbuddy 发布代理即如此），
  // 因此同时接受自定义头与查询参数两种备用通道；本机直连仍可用标准 Bearer。
  const h = req.headers['authorization'] || '';
  if (h === `Bearer ${TOKEN}`) return true;
  const custom = req.headers['x-auth-token'] || req.headers['x-rea-token'] || '';
  if (custom === TOKEN) return true;
  if (url && url.searchParams.get('token') === TOKEN) return true;
  return false;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_UPLOAD_BYTES) { reject(new Error('请求体超过 96MB 上限')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

/** 处理一个 MCP JSON-RPC 请求（可能一次多个，批处理）。 */
async function handleMcp(payload) {
  const isBatch = Array.isArray(payload);
  const messages = isBatch ? payload : [payload];
  const out = [];
  for (const msg of messages) {
    if (!msg || msg.jsonrpc !== '2.0' || typeof msg.method !== 'string') {
      if (msg && msg.id !== undefined) out.push({ jsonrpc: '2.0', id: msg.id, error: { code: -32600, message: 'Invalid Request' } });
      continue;
    }
    const respond = (result) => out.push({ jsonrpc: '2.0', id: msg.id, result });
    const fail = (code, message) => out.push({ jsonrpc: '2.0', id: msg.id, error: { code, message } });

    try {
      switch (msg.method) {
        case 'initialize':
          respond({
            protocolVersion: rea.serverProtocolVersion || PROTOCOL_VERSION,
            capabilities: { tools: {} },
            serverInfo: { name: 'rea-gateway', version: '1.0.0' },
            instructions: 'REA 逆向引擎网关。分析流程：先用 rea_upload 上传目标文件（或对服务器已有路径），再 open_binary，然后按需调用清单/反编译/字符串/交叉引用类工具。'
          });
          break;
        case 'ping':
          respond({});
          break;
        case 'tools/list': {
          const r = await rea.request('tools/list', msg.params || {});
          respond(r);
          break;
        }
        case 'tools/call': {
          const r = await rea.request('tools/call', msg.params || {});
          respond(truncateResult(r));
          break;
        }
        default:
          if (msg.id === undefined) break; // 通知：静默接受
          fail(-32601, `Method not found: ${msg.method}`);
      }
    } catch (e) {
      fail(-32603, e.message || String(e));
    }
  }
  return isBatch ? out : out[0];
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (req.method === 'OPTIONS') { jsonRes(res, 204, {}); return; }

    if (req.method === 'GET' && url.pathname === '/health') {
      jsonRes(res, 200, { ok: true, service: 'rea-gateway', rea: rea.proc ? 'up' : 'starting' });
      return;
    }

    if (!authorized(req, url)) {
      jsonRes(res, 401, { error: '未授权：需要 Authorization: Bearer <token>、X-Auth-Token: <token> 或 ?token=<token>' });
      return;
    }

    // 云构建（/build*）：与 REA 同进程、同令牌，请求体上限由 readBody 统一把关
    if (await buildService.handle(req, res, url, readBody)) return;

    if (req.method === 'POST' && url.pathname === '/mcp') {
      const body = await readBody(req);
      let payload;
      try { payload = JSON.parse(body.toString('utf8')); }
      catch { jsonRes(res, 400, { jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } }); return; }
      const result = await handleMcp(payload);
      jsonRes(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/upload') {
      const body = await readBody(req);
      const raw = decodeURIComponent(req.headers['x-filename'] || '');
      const name = path.basename(raw || `upload_${Date.now()}.bin`).replace(/[^\w.\-\u4e00-\u9fff]/g, '_');
      if (!name || name === '.' || name === '..') { jsonRes(res, 400, { error: '非法文件名' }); return; }
      const target = path.join(UPLOAD_DIR, `${Date.now()}_${name}`);
      fs.writeFileSync(target, body);
      jsonRes(res, 200, { ok: true, path: target, bytes: body.length });
      return;
    }

    jsonRes(res, 404, { error: 'Not found' });
  } catch (e) {
    jsonRes(res, 500, { error: e.message || String(e) });
  }
});

server.listen(PORT, () => {
  console.log(`[rea-gateway] listening on :${PORT}`);
  console.log(`[rea-gateway] token = ${TOKEN}`);
  console.log(`[rea-gateway] REA  = ${REA_BIN} ${REA_ARGS.join(' ')}`);
  // 预热：启动即拉起 REA 并完成握手，首个请求不必等 60s
  rea.ensureStarted().then(
    () => console.log('[rea-gateway] REA 握手完成'),
    (e) => console.error('[rea-gateway] REA 握手失败：', e.message)
  );
});
