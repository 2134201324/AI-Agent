/**
 * 云构建服务 —— 把「网页工程」编译成可安装的 APK。
 *
 * 定位：与 REA 网关同进程、同域名、同令牌的第二个能力面。App 把工程描述
 * （应用名/包名/版本/图标/网页文件）POST 上来，服务端在沙盒里驱动
 * JDK + Android SDK + Gradle 产出 APK 并签名，App 轮询进度、下载安装。
 *
 * 端点：
 *   GET    /build/capabilities  工具链自检（App 用「测试连接」调用）
 *   POST   /build               提交构建任务，立即返回 { id }
 *   GET    /build/:id           查询任务（?since=N 只取新增日志，便于增量刷新）
 *   GET    /build/:id/apk       下载签名后的 APK
 *   GET    /builds              历史任务列表
 *   DELETE /build/:id           删除任务及其产物
 *
 * 关键工程决策：
 * 1. **串行队列**：Gradle 守护进程内存占用高，且共用依赖缓存，并发构建会互相
 *    抢锁、拖慢彼此，所以一次只跑一个任务。
 * 2. **每任务独立工作区**：把模板整份拷进任务目录再构建，任务之间零共享。
 *    代价是冷启动，实测仍然只要 9 秒（依赖都在 Gradle 缓存里）。
 * 3. **强制 --offline**：本机 DNS 把 dl.google.com 解析到不可路由的 IPv6，
 *    Gradle 一旦尝试访问 google() 仓库就会阻塞到超时才失败。模板零三方依赖，
 *    全部依赖早已在缓存中，离线构建既正确又稳定。
 *
 * 纯 Node 内置模块，无 npm 依赖。
 */
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const { spawn } = require('child_process');

const ROOT = process.env.CLOUD_BUILD_ROOT || '/workspace/cloud-build';
const TEMPLATE = path.join(ROOT, 'template');
const JOBS_DIR = path.join(ROOT, 'jobs');
const KS_DIR = path.join(ROOT, 'keystore');
const KEYSTORE = path.join(KS_DIR, 'cloudbuild.jks');
const KS_PASS = process.env.CLOUD_BUILD_KS_PASS || 'cloudbuild';
const KS_ALIAS = 'cloudbuild';

const JAVA_HOME = process.env.JAVA_HOME || '/usr/lib/jvm/java-21-openjdk-amd64';
const ANDROID_HOME = process.env.ANDROID_HOME || '/opt/android-sdk';
const BUILD_TOOLS =
  process.env.CLOUD_BUILD_TOOLS || path.join(ANDROID_HOME, 'build-tools', '36.0.0');
const APKSIGNER = path.join(BUILD_TOOLS, 'apksigner');
const ZIPALIGN = path.join(BUILD_TOOLS, 'zipalign');
const AAPT2 = path.join(BUILD_TOOLS, 'aapt2');
const KEYTOOL = path.join(JAVA_HOME, 'bin', 'keytool');

const BUILD_TIMEOUT_MS = Number(process.env.CLOUD_BUILD_TIMEOUT_MS || 10 * 60 * 1000);
const MAX_FILES = 300;
const MAX_FILE_BYTES = 8 * 1024 * 1024;
const MAX_TOTAL_BYTES = 24 * 1024 * 1024;
const MAX_BINARY_BYTES = 16 * 1024 * 1024;
const MAX_ICON_BYTES = 2 * 1024 * 1024;
const MAX_LOGS = 800;
const KEEP_JOBS = Number(process.env.CLOUD_BUILD_KEEP || 20);

fs.mkdirSync(JOBS_DIR, { recursive: true });

// ── 构建产物签名用的密钥库（首次启动自动生成，之后复用）────────────────

function ensureKeystore() {
  if (fs.existsSync(KEYSTORE)) return { ok: true, created: false };
  fs.mkdirSync(KS_DIR, { recursive: true });
  const r = require('child_process').spawnSync(
    KEYTOOL,
    [
      '-genkeypair', '-v',
      '-keystore', KEYSTORE,
      '-alias', KS_ALIAS,
      '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10950',
      '-storepass', KS_PASS, '-keypass', KS_PASS,
      '-dname', 'CN=Cloud Build, OU=Web To Apk, O=AI Agent, L=NA, ST=NA, C=CN'
    ],
    { encoding: 'utf8' }
  );
  if (r.status !== 0) {
    throw new Error(`生成签名密钥库失败：${(r.stderr || r.stdout || '').slice(-400)}`);
  }
  return { ok: true, created: true };
}

// ── 任务模型 ────────────────────────────────────────────────────────────

/** @type {Map<string, any>} */
const jobs = new Map();
/** 待执行队列（串行，见文件头说明） */
const queue = [];
let running = false;

function newJob(request) {
  const id = crypto.randomBytes(8).toString('hex');
  return {
    id,
    state: 'QUEUED', // QUEUED | RUNNING | SUCCEEDED | FAILED
    createdAt: Date.now(),
    startedAt: null,
    finishedAt: null,
    request,
    logs: [],
    apk: null, // { path, bytes, sha256, packageId, versionName, versionCode, label }
    error: null
  };
}

function log(job, level, message) {
  job.logs.push({ t: Date.now(), level, message: String(message).slice(0, 2000) });
  if (job.logs.length > MAX_LOGS) job.logs.splice(0, job.logs.length - MAX_LOGS);
}

function persist(job) {
  try {
    const dir = path.join(JOBS_DIR, job.id);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(
      path.join(dir, 'job.json'),
      JSON.stringify({ ...job, apk: job.apk ? { ...job.apk, path: undefined } : null })
    );
  } catch {
    /* 落盘失败不影响构建 */
  }
}

/** 对外的任务视图（不暴露服务器绝对路径）。 */
function publicJob(job, sinceLog = 0) {
  const from = Math.max(0, Number(sinceLog) || 0);
  return {
    id: job.id,
    state: job.state,
    createdAt: job.createdAt,
    startedAt: job.startedAt,
    finishedAt: job.finishedAt,
    request: {
      appName: job.request.appName,
      packageId: job.request.packageId,
      versionName: job.request.versionName,
      versionCode: job.request.versionCode
    },
    logTotal: job.logs.length,
    logs: job.logs.slice(from),
    apk: job.apk
      ? {
          bytes: job.apk.bytes,
          sha256: job.apk.sha256,
          packageId: job.apk.packageId,
          versionName: job.apk.versionName,
          versionCode: job.apk.versionCode,
          label: job.apk.label,
          downloadPath: `/build/${job.id}/apk`
        }
      : null,
    error: job.error
  };
}

/**
 * 解析提交上来的请求体，透明支持三种形态：
 *   1. 裸 JSON —— 本机直连、curl 调试时最方便
 *   2. `{payload: base64(JSON)}`
 *   3. `{payload: base64(gzip(JSON))}` —— App 用的就是这种
 *
 * 为什么要有信封：公网的 WAF 会拦截请求体里出现的 `<script>`、`onclick=`、
 * `document.getElementById` 这类 XSS 特征（实测直接 403 + WAF 拦截页），
 * 而网页工程必然包含 JS —— 裸 JSON 发出去，任何真实工程都打不了包。
 * 压缩后 base64 的内容对 WAF 是随机字节，既不触发规则，体积还更小。
 */
function decodeRequestBody(raw) {
  let parsed;
  try {
    parsed = JSON.parse(raw.toString('utf8'));
  } catch (e) {
    throw new Error(`请求体不是合法 JSON：${e.message}`);
  }
  if (!parsed || typeof parsed !== 'object' || typeof parsed.payload !== 'string') {
    return parsed;
  }

  let buf;
  try {
    buf = Buffer.from(parsed.payload, 'base64');
  } catch {
    throw new Error('payload 不是合法的 base64');
  }
  // gzip 魔数；没有它说明对方只做了 base64
  if (buf.length > 2 && buf[0] === 0x1f && buf[1] === 0x8b) {
    try {
      buf = zlib.gunzipSync(buf);
    } catch (e) {
      throw new Error(`payload 解压失败：${e.message}`);
    }
  }
  try {
    return JSON.parse(buf.toString('utf8'));
  } catch (e) {
    throw new Error(`payload 解包后不是合法 JSON：${e.message}`);
  }
}

// ── 请求校验 ────────────────────────────────────────────────────────────

const PKG_RE = /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/;
const ORIENTATIONS = new Set(['unspecified', 'portrait', 'landscape', 'sensor', 'sensorPortrait', 'sensorLandscape']);

/** 把 webFiles 的相对路径规整为安全路径；非法返回 null。 */
function safeRelPath(raw) {
  if (typeof raw !== 'string' || !raw.trim()) return null;
  const p = raw.replace(/\\/g, '/').trim();
  if (p.startsWith('/') || /^[a-zA-Z]:/.test(p)) return null;
  const parts = p.split('/').filter((s) => s && s !== '.');
  if (!parts.length) return null;
  if (parts.some((s) => s === '..')) return null;
  // 文件名里禁止出现控制字符与 Android 资源非法字符
  if (parts.some((s) => /[\u0000-\u001f<>:"|?*]/.test(s))) return null;
  return parts.join('/');
}

function validateRequest(body) {
  if (!body || typeof body !== 'object') return { error: '请求体必须是 JSON 对象' };

  const appName = String(body.appName || '').trim();
  if (!appName) return { error: 'appName 不能为空' };
  if (appName.length > 60) return { error: 'appName 过长（上限 60 字符）' };

  const packageId = String(body.packageId || '').trim();
  if (!PKG_RE.test(packageId)) {
    return { error: 'packageId 非法，应形如 com.example.app（至少两段、仅字母数字下划线）' };
  }
  if (packageId.length > 120) return { error: 'packageId 过长' };

  const versionName = String(body.versionName || '1.0').trim() || '1.0';
  if (versionName.length > 40) return { error: 'versionName 过长' };
  const versionCode = Number.parseInt(body.versionCode, 10);
  if (!Number.isFinite(versionCode) || versionCode < 1 || versionCode > 2100000000) {
    return { error: 'versionCode 必须是 1..2100000000 的整数' };
  }

  const rawFiles = body.webFiles;
  if (!rawFiles || typeof rawFiles !== 'object' || Array.isArray(rawFiles)) {
    return { error: 'webFiles 必须是「路径 → 内容」的对象' };
  }
  const entries = Object.entries(rawFiles);
  if (!entries.length) return { error: 'webFiles 不能为空，至少要有一个 index.html' };

  const webFiles = {};
  let total = 0;
  for (const [rawPath, rawContent] of entries) {
    if (Object.keys(webFiles).length >= MAX_FILES) {
      return { error: `文件数量超过上限（${MAX_FILES}）` };
    }
    const rel = safeRelPath(rawPath);
    if (!rel) return { error: `文件路径非法：${String(rawPath).slice(0, 80)}` };
    const content = typeof rawContent === 'string' ? rawContent : '';
    const bytes = Buffer.byteLength(content, 'utf8');
    if (bytes > MAX_FILE_BYTES) return { error: `文件过大：${rel}` };
    total += bytes;
    if (total > MAX_TOTAL_BYTES) return { error: `工程总大小超过上限（${MAX_TOTAL_BYTES / 1024 / 1024}MB）` };
    webFiles[rel] = content;
  }

  // 二进制资源（图片/字体等）。网页工程里这些几乎必然存在，而 JSON 装不下原始
  // 字节，所以约定用 base64 传，服务端解码后按原样写进 assets。
  const binaryFiles = {};
  let binaryTotal = 0;
  const rawBinary = body.binaryFiles;
  if (rawBinary != null) {
    if (typeof rawBinary !== 'object' || Array.isArray(rawBinary)) {
      return { error: 'binaryFiles 必须是「路径 → base64」的对象' };
    }
    for (const [rawPath, rawB64] of Object.entries(rawBinary)) {
      if (Object.keys(webFiles).length + Object.keys(binaryFiles).length >= MAX_FILES) {
        return { error: `文件数量超过上限（${MAX_FILES}）` };
      }
      const rel = safeRelPath(rawPath);
      if (!rel) return { error: `二进制文件路径非法：${String(rawPath).slice(0, 80)}` };
      const b64 = String(rawB64 || '').replace(/^data:[^;]+;base64,/, '');
      let buf;
      try {
        buf = Buffer.from(b64, 'base64');
      } catch {
        return { error: `二进制文件不是合法 base64：${rel}` };
      }
      if (!buf.length) return { error: `二进制文件内容为空：${rel}` };
      if (buf.length > MAX_FILE_BYTES) return { error: `二进制文件过大：${rel}` };
      binaryTotal += buf.length;
      if (binaryTotal > MAX_BINARY_BYTES) {
        return { error: `二进制资源总量超过上限（${MAX_BINARY_BYTES / 1024 / 1024}MB）` };
      }
      binaryFiles[rel] = buf;
    }
  }

  // 入口文件是壳启动时加载的固定路径，缺失会让打包出来的应用白屏
  if (!Object.prototype.hasOwnProperty.call(webFiles, 'index.html')) {
    return { error: '缺少入口文件 index.html（它会被壳加载为首页）' };
  }

  let iconBuffer = null;
  if (body.iconBase64) {
    const b64 = String(body.iconBase64).replace(/^data:[^;]+;base64,/, '');
    try {
      iconBuffer = Buffer.from(b64, 'base64');
    } catch {
      return { error: 'iconBase64 不是合法的 base64' };
    }
    if (!iconBuffer.length || iconBuffer.length > MAX_ICON_BYTES) {
      return { error: `图标大小非法（上限 ${MAX_ICON_BYTES / 1024 / 1024}MB）` };
    }
  }

  const extras = (body.extras && typeof body.extras === 'object') ? body.extras : {};
  const orientation = ORIENTATIONS.has(String(extras.orientation)) ? String(extras.orientation) : 'unspecified';
  const minSdk = Number.parseInt(extras.minSdk, 10);

  return {
    request: {
      appName,
      packageId,
      versionName,
      versionCode,
      webFiles,
      binaryFiles,
      iconBuffer,
      orientation,
      minSdk: Number.isFinite(minSdk) ? Math.min(Math.max(minSdk, 21), 35) : 24
    }
  };
}

// ── 图片类型嗅探（决定图标落盘扩展名）──────────────────────────────────

function sniffImage(buf) {
  if (buf.length > 8 && buf[0] === 0x89 && buf.toString('latin1', 1, 4) === 'PNG') return 'png';
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.length > 12 && buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') return 'webp';
  return null;
}

// ── 构建执行 ────────────────────────────────────────────────────────────

function copyTemplate(dest) {
  fs.cpSync(TEMPLATE, dest, {
    recursive: true,
    filter: (src) => {
      const base = path.basename(src);
      // 不带构建缓存：每个任务都是干净工作区，避免产物串味
      return base !== 'build' && base !== '.gradle' && base !== 'local.properties';
    }
  });
}

/**
 * 图标预检。
 *
 * 背景：aapt2 遇到损坏的图片不会好好报错，而是直接段错误退出（退出码 139），
 * Gradle 侧只能看到一句 "Aapt2 Daemon #0: Unexpected error during compile"，
 * 用户拿不到任何可操作的信息。这里用 aapt2 单文件编译提前探一次：
 * 通过就继续，不通过就抛出「图标有问题」这种能照着改的错误。
 */
function validateIcon(iconPath) {
  const probe = path.join(path.dirname(iconPath), `.probe-${Date.now()}.zip`);
  const r = require('child_process').spawnSync(AAPT2, ['compile', '-o', probe, iconPath], {
    encoding: 'utf8',
    env: { ...process.env, JAVA_HOME, PATH: `${JAVA_HOME}/bin:${process.env.PATH || ''}` }
  });
  try { fs.rmSync(probe, { force: true }); } catch { /* ignore */ }
  if (r.status !== 0) {
    throw new Error(
      '图标文件无法被 aapt2 解析（可能已损坏或不是有效的图片）：' +
        `退出码 ${r.status ?? 'signal:' + r.signal}。请重新导出为 PNG/JPEG/WebP 后再试。`
    );
  }
}

function materializeFiles(projDir, request) {
  const assetsDir = path.join(projDir, 'app', 'src', 'main', 'assets');
  fs.rmSync(assetsDir, { recursive: true, force: true });
  fs.mkdirSync(assetsDir, { recursive: true });

  for (const [rel, content] of Object.entries(request.webFiles)) {
    const target = path.join(assetsDir, rel);
    const resolved = path.resolve(target);
    if (!resolved.startsWith(path.resolve(assetsDir) + path.sep)) {
      throw new Error(`文件路径越界：${rel}`);
    }
    fs.mkdirSync(path.dirname(resolved), { recursive: true });
    fs.writeFileSync(resolved, content, 'utf8');
  }

  for (const [rel, buf] of Object.entries(request.binaryFiles || {})) {
    const resolved = path.resolve(path.join(assetsDir, rel));
    if (!resolved.startsWith(path.resolve(assetsDir) + path.sep)) {
      throw new Error(`文件路径越界：${rel}`);
    }
    fs.mkdirSync(path.dirname(resolved), { recursive: true });
    fs.writeFileSync(resolved, buf);
  }

  if (request.iconBuffer) {
    const ext = sniffImage(request.iconBuffer);
    if (!ext) throw new Error('图标不是可识别的 PNG / JPEG / WebP 图片');
    const drawableDir = path.join(projDir, 'app', 'src', 'main', 'res', 'drawable');
    fs.mkdirSync(drawableDir, { recursive: true });
    // 先清掉模板默认图标，否则同名不同扩展会出现资源重复
    for (const f of fs.readdirSync(drawableDir)) {
      if (f.startsWith('ic_launcher.')) fs.rmSync(path.join(drawableDir, f), { force: true });
    }
    const iconPath = path.join(drawableDir, `ic_launcher.${ext}`);
    fs.writeFileSync(iconPath, request.iconBuffer);
    validateIcon(iconPath);
  }

  // local.properties 指向 SDK，模板里没有（它被 copyTemplate 过滤掉了）
  fs.writeFileSync(path.join(projDir, 'local.properties'), `sdk.dir=${ANDROID_HOME}\n`);
}

function runGradle(job, projDir, request) {
  return new Promise((resolve, reject) => {
    const args = [
      'assembleRelease',
      '--offline',            // 见文件头：本机到 google() 仓库不通，且依赖已全部缓存
      '--console=plain',
      '--no-build-cache',
      '-PappPackage=' + request.packageId,
      '-PappLabel=' + request.appName,
      '-PappVersionCode=' + request.versionCode,
      '-PappVersionName=' + request.versionName,
      '-PappOrientation=' + request.orientation,
      '-PappMinSdk=' + request.minSdk
    ];

    log(job, 'INFO', `开始编译：${request.packageId} v${request.versionName}（${request.versionCode}）`);
    log(job, 'INFO', `工程文件 ${Object.keys(request.webFiles).length} 个，目标 minSdk=${request.minSdk}`);

    const proc = spawn(path.join(projDir, 'gradlew'), args, {
      cwd: projDir,
      env: {
        ...process.env,
        JAVA_HOME,
        PATH: `${JAVA_HOME}/bin:${process.env.PATH || ''}`,
        ANDROID_HOME,
        ANDROID_SDK_ROOT: ANDROID_HOME,
        // 守护进程内存收敛，并让它空闲即退，避免长期占着沙盒内存
        GRADLE_OPTS: '-Dorg.gradle.daemon.idletimeout=120000',
        TERM: 'dumb'
      },
      stdio: ['ignore', 'pipe', 'pipe']
    });

    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      log(job, 'ERROR', `构建超时（${BUILD_TIMEOUT_MS / 1000}s），已终止`);
      try { proc.kill('SIGKILL'); } catch { /* ignore */ }
      reject(new Error('构建超时'));
    }, BUILD_TIMEOUT_MS);

    const onChunk = (buf) => {
      for (const raw of buf.toString().split('\n')) {
        const line = raw.trimEnd();
        if (!line) continue;
        const level = /^(FAILURE|e: |error:)/i.test(line.trim()) ? 'ERROR'
          : /warning|deprecat|^w: /i.test(line) ? 'WARN'
          : 'INFO';
        log(job, level, line);
      }
    };
    proc.stdout.on('data', onChunk);
    proc.stderr.on('data', onChunk);

    proc.on('error', (e) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(new Error(`无法启动构建进程：${e.message}`));
    });

    proc.on('close', (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (code === 0) resolve();
      else reject(new Error(`Gradle 构建失败（退出码 ${code}）`));
    });
  });
}

/** zipalign + apksigner，产出可直接安装的 APK。 */
function signApk(job, projDir, outPath) {
  const unsigned = path.join(projDir, 'app', 'build', 'outputs', 'apk', 'release', 'app-release-unsigned.apk');
  if (!fs.existsSync(unsigned)) {
    throw new Error('构建成功但对不上产物路径，未找到 app-release-unsigned.apk');
  }
  const aligned = `${outPath}.aligned`;

  const za = require('child_process').spawnSync(ZIPALIGN, ['-f', '-p', '4', unsigned, aligned], {
    encoding: 'utf8'
  });
  if (za.status !== 0) throw new Error(`zipalign 失败：${(za.stderr || za.stdout || '').slice(-300)}`);

  const sg = require('child_process').spawnSync(
    APKSIGNER,
    [
      'sign',
      '--ks', KEYSTORE,
      '--ks-pass', `pass:${KS_PASS}`,
      '--key-pass', `pass:${KS_PASS}`,
      '--ks-key-alias', KS_ALIAS,
      '--v2-signing-enabled', 'true',
      '--v3-signing-enabled', 'true',
      aligned
    ],
    { encoding: 'utf8', env: { ...process.env, JAVA_HOME, PATH: `${JAVA_HOME}/bin:${process.env.PATH || ''}` } }
  );
  if (sg.status !== 0) throw new Error(`apksigner 签名失败：${(sg.stderr || sg.stdout || '').slice(-300)}`);

  fs.renameSync(aligned, outPath);

  const vf = require('child_process').spawnSync(APKSIGNER, ['verify', '--print-certs', outPath], { encoding: 'utf8' });
  if (vf.status !== 0) throw new Error(`签名校验未通过：${(vf.stderr || '').slice(-300)}`);
  log(job, 'INFO', '签名完成（APK Signature Scheme v2 + v3）');
}

/** 读回产物实际元数据，避免「App 显示的值」与「包里的值」不一致。 */
function inspectApk(outPath) {
  const r = require('child_process').spawnSync(AAPT2, ['dump', 'badging', outPath], { encoding: 'utf8' });
  const text = r.stdout || '';
  const pkg = /package: name='([^']+)' versionCode='([^']*)' versionName='([^']*)'/.exec(text);
  const label = /application-label:'([^']*)'/.exec(text);
  return {
    packageId: pkg ? pkg[1] : null,
    versionCode: pkg ? Number(pkg[2]) : null,
    versionName: pkg ? pkg[3] : null,
    label: label ? label[1] : null
  };
}

async function execute(job) {
  job.state = 'RUNNING';
  job.startedAt = Date.now();
  persist(job);

  const jobDir = path.join(JOBS_DIR, job.id);
  const projDir = path.join(jobDir, 'proj');
  try {
    fs.mkdirSync(jobDir, { recursive: true });
    copyTemplate(projDir);
    materializeFiles(projDir, job.request);

    await runGradle(job, projDir, job.request);

    const outPath = path.join(jobDir, 'app.apk');
    signApk(job, projDir, outPath);

    const stat = fs.statSync(outPath);
    const sha256 = crypto.createHash('sha256').update(fs.readFileSync(outPath)).digest('hex');
    const meta = inspectApk(outPath);

    job.apk = {
      path: outPath,
      bytes: stat.size,
      sha256,
      packageId: meta.packageId || job.request.packageId,
      versionName: meta.versionName || job.request.versionName,
      versionCode: meta.versionCode || job.request.versionCode,
      label: meta.label || job.request.appName
    };
    job.state = 'SUCCEEDED';
    job.finishedAt = Date.now();
    log(
      job,
      'INFO',
      `构建成功：${(stat.size / 1024).toFixed(1)} KB，用时 ${((job.finishedAt - job.startedAt) / 1000).toFixed(1)}s`
    );
  } catch (e) {
    job.state = 'FAILED';
    job.finishedAt = Date.now();
    job.error = e.message || String(e);
    log(job, 'ERROR', job.error);
  } finally {
    // 工程目录随任务保留会迅速吃掉磁盘；产物已拷出，构建目录可以丢
    try { fs.rmSync(projDir, { recursive: true, force: true }); } catch { /* ignore */ }
    persist(job);
    pruneJobs();
  }
}

function pruneJobs() {
  const finished = [...jobs.values()]
    .filter((j) => j.state === 'SUCCEEDED' || j.state === 'FAILED')
    .sort((a, b) => (b.finishedAt || 0) - (a.finishedAt || 0));
  for (const stale of finished.slice(KEEP_JOBS)) {
    jobs.delete(stale.id);
    try { fs.rmSync(path.join(JOBS_DIR, stale.id), { recursive: true, force: true }); } catch { /* ignore */ }
  }
}

async function pump() {
  if (running) return;
  const next = queue.shift();
  if (!next) return;
  running = true;
  try {
    await execute(next);
  } finally {
    running = false;
    // 队列里还有任务就接着跑
    if (queue.length) setImmediate(pump);
  }
}

function enqueue(job) {
  jobs.set(job.id, job);
  queue.push(job);
  persist(job);
  setImmediate(pump);
  return job;
}

// ── HTTP 路由 ───────────────────────────────────────────────────────────

function sendJson(res, code, obj) {
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type, X-Auth-Token, X-Rea-Token'
  });
  res.end(JSON.stringify(obj));
}

/**
 * 处理 /build* 路由。命中返回 true（并已写出响应），否则返回 false 交给调用方。
 * 鉴权已在调用方完成 —— 这里假定请求可信。
 */
async function handle(req, res, url, readBody) {
  const { pathname } = url;
  if (!pathname.startsWith('/build')) return false;

  if (req.method === 'GET' && pathname === '/build/capabilities') {
    let toolchain;
    try {
      const ks = ensureKeystore();
      toolchain = {
        template: fs.existsSync(path.join(TEMPLATE, 'app', 'build.gradle.kts')),
        java: fs.existsSync(path.join(JAVA_HOME, 'bin', 'java')),
        androidSdk: fs.existsSync(path.join(ANDROID_HOME, 'platforms')),
        buildTools: fs.existsSync(APKSIGNER),
        keystore: ks.ok,
        keystoreCreated: ks.created,
        offline: true
      };
    } catch (e) {
      return sendJson(res, 500, { ok: false, error: e.message }), true;
    }
    const ready = Object.values(toolchain).every((v) => v === true || v === false) &&
      toolchain.template && toolchain.java && toolchain.androidSdk && toolchain.buildTools && toolchain.keystore;
    return sendJson(res, 200, {
      ok: ready,
      service: 'cloud-build',
      toolchain,
      busy: running,
      queued: queue.length,
      limits: {
        maxFiles: MAX_FILES,
        maxFileBytes: MAX_FILE_BYTES,
        maxTotalBytes: MAX_TOTAL_BYTES,
        maxIconBytes: MAX_ICON_BYTES
      }
    }), true;
  }

  if (req.method === 'GET' && pathname === '/builds') {
    const list = [...jobs.values()]
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 50)
      .map((j) => publicJob(j, j.logs.length));
    return sendJson(res, 200, { ok: true, jobs: list }), true;
  }

  const statusMatch = /^\/build\/([0-9a-f]{8,32})$/.exec(pathname);
  if (req.method === 'GET' && statusMatch) {
    const job = jobs.get(statusMatch[1]);
    if (!job) return sendJson(res, 404, { ok: false, error: '任务不存在或已被清理' }), true;
    const since = url.searchParams.get('since');
    return sendJson(res, 200, { ok: true, job: publicJob(job, since == null ? 0 : Number(since)) }), true;
  }

  const apkMatch = /^\/build\/([0-9a-f]{8,32})\/apk$/.exec(pathname);
  if (req.method === 'GET' && apkMatch) {
    const job = jobs.get(apkMatch[1]);
    if (!job || !job.apk || !fs.existsSync(job.apk.path)) {
      return sendJson(res, 404, { ok: false, error: '产物不存在' }), true;
    }
    const buf = fs.readFileSync(job.apk.path);
    const filename = `${job.apk.packageId}-${job.apk.versionName}.apk`;
    res.writeHead(200, {
      'Content-Type': 'application/vnd.android.package-archive',
      'Content-Length': buf.length,
      'Content-Disposition': `attachment; filename="${filename}"`,
      'X-Apk-Sha256': job.apk.sha256,
      'Access-Control-Allow-Origin': '*'
    });
    res.end(buf);
    return true;
  }

  const delMatch = /^\/build\/([0-9a-f]{8,32})$/.exec(pathname);
  if (req.method === 'DELETE' && delMatch) {
    const job = jobs.get(delMatch[1]);
    if (!job) return sendJson(res, 404, { ok: false, error: '任务不存在' }), true;
    if (job.state === 'RUNNING' || job.state === 'QUEUED') {
      return sendJson(res, 409, { ok: false, error: '任务正在执行，无法删除' }), true;
    }
    jobs.delete(job.id);
    try { fs.rmSync(path.join(JOBS_DIR, job.id), { recursive: true, force: true }); } catch { /* ignore */ }
    return sendJson(res, 200, { ok: true }), true;
  }

  if (req.method === 'POST' && pathname === '/build') {
    let body;
    try {
      const raw = await readBody(req);
      body = decodeRequestBody(raw);
    } catch (e) {
      return sendJson(res, 400, { ok: false, error: `请求体解析失败：${e.message}` }), true;
    }
    const { error, request } = validateRequest(body);
    if (error) return sendJson(res, 400, { ok: false, error }), true;

    // 构建必须在签名密钥库就绪后才有意义，这里提前生成，避免任务跑到最后才失败
    try {
      ensureKeystore();
    } catch (e) {
      return sendJson(res, 500, { ok: false, error: e.message }), true;
    }

    const job = enqueue(newJob(request));
    return sendJson(res, 202, {
      ok: true,
      id: job.id,
      state: job.state,
      queued: queue.length - 1,
      statusPath: `/build/${job.id}`,
      apkPath: `/build/${job.id}/apk`
    }), true;
  }

  return sendJson(res, 404, { ok: false, error: '未知的构建端点' }), true;
}

module.exports = { handle, ensureKeystore };
