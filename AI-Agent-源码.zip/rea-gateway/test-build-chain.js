#!/usr/bin/env node
/**
 * 云构建链路端到端测试：提交工程 → 轮询状态 → 下载 APK → 校验产物。
 *
 * 用法：
 *   node test-build-chain.js [baseUrl] [token]
 * 默认 http://127.0.0.1:3999 与 testtoken（本地自测用）。
 */
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const BASE = process.argv[2] || 'http://127.0.0.1:3999';
const TOKEN = process.argv[3] || 'testtoken';
const OUT = process.argv[4] || '/tmp/cloudbuild-out.apk';

const HEADERS = {
  'Content-Type': 'application/json',
  'X-Auth-Token': TOKEN,
  Authorization: `Bearer ${TOKEN}`
};

/** 一个真实的网页小应用，用来验证 assets 确实被打进包里 */
const WEB_FILES = {
  'index.html': `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>云打包自测</title>
<style>
  body{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;
       font-family:system-ui,sans-serif;background:linear-gradient(160deg,#1b2a4a,#0b1220);color:#e8eaed}
  .card{text-align:center;padding:28px 32px;border-radius:18px;background:rgba(255,255,255,.06)}
  h1{font-size:22px;margin:0 0 10px}
  p{margin:0;color:#9aa0a6;font-size:13px}
  button{margin-top:16px;padding:10px 18px;border:0;border-radius:10px;background:#3b6fd4;color:#fff;font-size:14px}
</style></head>
<body><div class="card">
  <h1>云打包成功</h1>
  <p id="msg">这个页面来自服务器编译出的 APK</p>
  <button onclick="document.getElementById('msg').textContent='JS 正常工作 '+new Date().toLocaleTimeString()">点我</button>
</div></body></html>`,
  'sub/style.css': 'body{background:#000}',
  'sub/app.js': 'console.log("cloud build ok");'
};

/**
 * 就地生成一张合法的 PNG 图标。
 *
 * 不内嵌 base64 大字符串的原因：手写的 base64 一旦有半个字节不对就是坏图，
 * 而 aapt2 遇到坏图会直接段错误，排查成本很高。这里用 zlib 现编一张，
 * 结构可控、肉眼可读。
 */
function makeIconPng(size, rgba) {
  const zlib = require('zlib');
  const crc32 = zlib.crc32 || (() => {
    let table = null;
    return (buf) => {
      if (!table) {
        table = new Int32Array(256);
        for (let n = 0; n < 256; n++) {
          let c = n;
          for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
          table[n] = c;
        }
      }
      let c = 0 ^ -1;
      for (const b of buf) c = (c >>> 8) ^ table[(c ^ b) & 0xff];
      return (c ^ -1) >>> 0;
    };
  })();

  const chunk = (type, data) => {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const body = Buffer.concat([Buffer.from(type, 'latin1'), data]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(body));
    return Buffer.concat([len, body, crc]);
  };

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8;   // bit depth
  ihdr[9] = 6;   // color type: RGBA
  // 10..12 保持 0：deflate 压缩、自适应滤波、非隔行

  const raw = Buffer.alloc((size * 4 + 1) * size);
  for (let y = 0; y < size; y++) {
    const rowStart = y * (size * 4 + 1);
    raw[rowStart] = 0; // 每行滤波类型 None
    for (let x = 0; x < size; x++) {
      const o = rowStart + 1 + x * 4;
      // 中间画个圆点，外圈是纯色底，方便一眼看出图标生效
      const dx = x - size / 2;
      const dy = y - size / 2;
      const inside = dx * dx + dy * dy < (size * 0.28) * (size * 0.28);
      raw[o] = inside ? 255 : rgba[0];
      raw[o + 1] = inside ? 255 : rgba[1];
      raw[o + 2] = inside ? 255 : rgba[2];
      raw[o + 3] = 255;
    }
  }

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0))
  ]);
}

const ICON_PNG_BASE64 = makeIconPng(96, [59, 111, 212]).toString('base64');

/** 工程里的二进制资源：用来验证「二进制走独立通道」而不是被当文本写坏 */
const LOGO_PNG = makeIconPng(64, [24, 160, 120]);
const BINARY_FILES = { 'img/logo.png': LOGO_PNG.toString('base64') };

/**
 * 与 App 完全一致的传输编码：gzip + base64 信封。
 *
 * 这不是测试的权宜之计，而是协议的一部分：公网 WAF 会按 XSS 规则扫请求体，
 * 裸 JSON 里出现 <script> / onclick= 会被直接 403，而网页工程必然带 JS。
 */
function encodeEnvelope(obj) {
  const zlib = require('zlib');
  const gz = zlib.gzipSync(Buffer.from(JSON.stringify(obj), 'utf8'));
  return JSON.stringify({ encoding: 'gzip+base64', payload: gz.toString('base64') });
}

async function main() {
  const suffix = Date.now().toString(36).slice(-5);
  const payload = {
    appName: '云打包自测',
    packageId: `com.cloudbuild.selftest${suffix}`,
    versionName: '1.0.0',
    versionCode: 1,
    webFiles: WEB_FILES,
    binaryFiles: BINARY_FILES,
    iconBase64: ICON_PNG_BASE64,
    extras: { minSdk: 24, orientation: 'unspecified' }
  };

  console.log(`[1/4] 提交构建：${BASE}`);
  let r = await fetch(`${BASE}/build`, {
    method: 'POST',
    headers: HEADERS,
    body: encodeEnvelope(payload)
  });
  const raw = await r.text();
  let created;
  try {
    created = JSON.parse(raw);
  } catch {
    // 公网链路上「非 JSON 响应」几乎都是网关/代理的中间层错误页，
    // 把状态码和正文开头打出来，否则只能看到一句 JSON 解析失败
    throw new Error(`提交失败 HTTP ${r.status}，响应不是 JSON：${raw.slice(0, 300)}`);
  }
  if (!r.ok || !created.ok) throw new Error(`提交失败 HTTP ${r.status}：${JSON.stringify(created)}`);
  const id = created.id;
  console.log(`      任务 id=${id}，前面排队 ${created.queued} 个`);

  console.log('[2/4] 轮询状态');
  const deadline = Date.now() + 8 * 60 * 1000;
  let since = 0;
  let job = null;
  while (Date.now() < deadline) {
    await new Promise((res) => setTimeout(res, 1500));
    const sr = await fetch(`${BASE}/build/${id}?since=${since}`, { headers: HEADERS });
    const sj = await sr.json();
    if (!sr.ok || !sj.ok) throw new Error(`查询失败 HTTP ${sr.status}：${JSON.stringify(sj)}`);
    job = sj.job;
    since = job.logTotal;
    for (const line of job.logs) console.log(`      [${line.level}] ${line.message}`);
    if (job.state === 'SUCCEEDED' || job.state === 'FAILED') break;
    console.log(`      …状态 ${job.state}`);
  }
  if (!job) throw new Error('轮询超时');
  if (job.state !== 'SUCCEEDED') throw new Error(`构建未成功：${job.state} / ${job.error}`);

  console.log('[3/4] 下载 APK');
  const dr = await fetch(`${BASE}/build/${id}/apk`, { headers: HEADERS });
  if (!dr.ok) throw new Error(`下载失败 HTTP ${dr.status}`);
  const buf = Buffer.from(await dr.arrayBuffer());
  fs.writeFileSync(OUT, buf);
  const sha = crypto.createHash('sha256').update(buf).digest('hex');
  console.log(`      写入 ${OUT}，${buf.length} 字节`);
  console.log(`      服务端 sha256=${job.apk.sha256}`);
  console.log(`      本地   sha256=${sha}`);
  if (sha !== job.apk.sha256) throw new Error('下载内容与服务端校验和不一致');

  console.log('[4/4] 校验产物');
  const BT = '/opt/android-sdk/build-tools/36.0.0';
  const env = { ...process.env, JAVA_HOME: process.env.JAVA_HOME || '/usr/lib/jvm/java-21-openjdk-amd64' };
  const badging = spawnSync(`${BT}/aapt2`, ['dump', 'badging', OUT], { encoding: 'utf8' });
  const pkgLine = (badging.stdout || '').split('\n').filter((l) => /^package:|^application-label:|^launchable-activity:/.test(l));
  pkgLine.forEach((l) => console.log('      ' + l.trim()));
  const verify = spawnSync(`${BT}/apksigner`, ['verify', '--print-certs', OUT], { encoding: 'utf8', env });
  console.log(`      签名校验：${verify.status === 0 ? '通过' : '失败'}`);
  if (verify.status !== 0) throw new Error('签名校验失败：' + verify.stderr);
  const dex = spawnSync('unzip', ['-l', OUT], { encoding: 'utf8' });
  const entries = (dex.stdout || '').split('\n').filter((l) => /assets\/|classes\.dex|resources\.arsc|res\//.test(l));
  console.log('      关键条目：');
  entries.forEach((l) => console.log('        ' + l.trim()));

  // 二进制资源必须字节级一致：按文本通道发过去会被写坏，这一步专门盯它
  const dir = fs.mkdtempSync('/tmp/cloudbuild-verify-');
  spawnSync('unzip', ['-o', '-q', OUT, 'assets/img/logo.png', '-d', dir], { encoding: 'utf8' });
  const extracted = path.join(dir, 'assets/img/logo.png');
  if (!fs.existsSync(extracted)) throw new Error('二进制资源 assets/img/logo.png 未被打进包里');
  const got = fs.readFileSync(extracted);
  if (!got.equals(LOGO_PNG)) {
    throw new Error(`二进制资源内容不一致：期望 ${LOGO_PNG.length} 字节，实际 ${got.length} 字节`);
  }
  console.log(`      二进制资源校验通过：assets/img/logo.png ${got.length} 字节，字节级一致`);
  fs.rmSync(dir, { recursive: true, force: true });

  console.log('\n✅ 云构建链路全通');
}

main().catch((e) => {
  console.error('\n❌ ' + e.message);
  process.exit(1);
});
