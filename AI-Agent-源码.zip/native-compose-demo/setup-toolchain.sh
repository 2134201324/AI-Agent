#!/usr/bin/env bash
# ============================================================================
#  一键配置「逆向分析」+「Android 打包」两套能力（幂等，可反复执行）
#
#  用法：  bash native-compose-demo/setup-toolchain.sh
#
#  为什么需要它：沙盒镜像本身不含这两套工具链，只有在装过一次的沙盒里才存在。
#  新会话如果落在全新沙盒，就会「看起来什么都没有」——本脚本把两套能力装回来。
#
#  安装内容与落点：
#    JDK 21        → /usr/lib/jvm/java-21-openjdk-amd64（apt）
#    Android SDK   → /opt/android-sdk（cmdline-tools / platform-tools /
#                    platforms;android-36 / build-tools;36.0.0）
#    Ghidra 12.1.4 → /opt/ghidra（反编译引擎）
#    JADX 1.5.6    → /opt/jadx（APK / Java 反编译）
#    apktool 3.0.3 → /opt/apktool（APK 资源解码）
#    Node 22.23.3  → /root/.nvm/versions/node/v22.23.3（nvm）
#    REA 6.4.0     → npm 全局包 + MCP 注册 + 技能软链
# ============================================================================

JAVA_HOME_21=/usr/lib/jvm/java-21-openjdk-amd64
ANDROID_SDK=/opt/android-sdk
BT_VERSION=36.0.0
NODE_VERSION=22.23.3
# 注意：nvm 的目录名带 v 前缀（/root/.nvm/versions/node/v22.23.3）
NODE_DIR=/root/.nvm/versions/node/v$NODE_VERSION

FAILED=0
log()  { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }
ok()   { printf '  \033[32m✓\033[0m %s\n' "$1"; }
skip() { printf '  \033[2m·\033[0m %s\n' "$1"; }
bad()  { printf '  \033[31m✗\033[0m %s\n' "$1"; FAILED=$((FAILED+1)); }

# 下载：断点续传 + 慢速自动重试。
# 沙盒到 GitHub 的带宽可能只有 0.1~0.5 MB/s，Ghidra 有 570MB，
# 所以必须允许「慢」和「中断后续传」，不能设短的硬超时。
dl() {
    curl -fL --retry 6 --retry-delay 5 --retry-all-errors \
         --connect-timeout 30 --speed-limit 1024 --speed-time 180 \
         -C - -o "$1" "$2"
}

echo "=============================================="
echo "  工具链配置脚本    $(date '+%Y-%m-%d %H:%M:%S')"
echo "=============================================="

# ── 1. JDK 21 ───────────────────────────────────────────────────────────────
log "1/6  JDK 21"
if [ -x "$JAVA_HOME_21/bin/java" ]; then
    skip "JDK 21 已存在（$JAVA_HOME_21）"
else
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq && apt-get install -y -qq openjdk-21-jdk-headless \
        && ok "已安装 JDK 21" || bad "JDK 21 安装失败"
fi
if [ -x "$JAVA_HOME_21/bin/java" ]; then
    # 让默认 java 也指向 21（沙盒镜像默认是 20，会让构建失败）
    if [ -d /root/.sdkman/candidates/java ]; then
        ln -sfn "$JAVA_HOME_21" /root/.sdkman/candidates/java/current
        ok "默认 java 已指向 JDK 21"
    fi
fi

# ── 2. Android SDK ──────────────────────────────────────────────────────────
log "2/6  Android SDK"
export JAVA_HOME="$JAVA_HOME_21"
SDKMANAGER="$ANDROID_SDK/cmdline-tools/latest/bin/sdkmanager"
if [ -x "$SDKMANAGER" ]; then
    skip "cmdline-tools 已存在"
else
    mkdir -p "$ANDROID_SDK/cmdline-tools"
    if dl /tmp/clt.zip "https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip"; then
        rm -rf /tmp/clt && mkdir -p /tmp/clt && unzip -q /tmp/clt.zip -d /tmp/clt
        rm -rf "$ANDROID_SDK/cmdline-tools/latest"
        mv /tmp/clt/cmdline-tools "$ANDROID_SDK/cmdline-tools/latest"
        ok "cmdline-tools 已安装"
    else
        bad "cmdline-tools 下载失败"
    fi
fi

if [ -x "$SDKMANAGER" ]; then
    mkdir -p "$ANDROID_SDK/licenses"
    for f in android-sdk-license android-sdk-preview-license android-googletv-license \
             android-googlexr-license android-sdk-arm-dbt-license google-gdk-license \
             microxr-sysimage-license mips-android-sysimage-license; do
        printf '\n24333f8a63b6825ea9c5514f83c2829b004d1fee\n84831b9409646a918e30573bab4c9c91346d8abd\n' \
            > "$ANDROID_SDK/licenses/$f"
    done
    yes 2>/dev/null | "$SDKMANAGER" --sdk_root="$ANDROID_SDK" --licenses >/dev/null 2>&1
    "$SDKMANAGER" --sdk_root="$ANDROID_SDK" \
        "platform-tools" "platforms;android-36" "build-tools;$BT_VERSION" 2>&1 \
        | tail -3
    if [ -x "$ANDROID_SDK/build-tools/$BT_VERSION/aapt2" ]; then
        ok "platform-tools / android-36 / build-tools $BT_VERSION 就绪"
    else
        bad "SDK 组件安装不完整"
    fi
fi

# ── 3. 逆向分析引擎 ─────────────────────────────────────────────────────────
log "3/6  Ghidra / JADX / apktool"

if [ -d /opt/ghidra/Ghidra ]; then
    skip "Ghidra 已存在（/opt/ghidra）"
else
    GHIDRA_URL="https://github.com/NationalSecurityAgency/ghidra/releases/download/Ghidra_12.1.4_build/ghidra_12.1.4_PUBLIC_20260921.zip"
    if [ -f /tmp/ghidra.zip ] && unzip -tq /tmp/ghidra.zip >/dev/null 2>&1; then
        ok "使用已就绪的 /tmp/ghidra.zip"
    else
        echo "      下载中（约 570MB，视带宽可能需要 10~30 分钟；中断后重跑本脚本会断点续传）"
        dl /tmp/ghidra.zip "$GHIDRA_URL" || bad "Ghidra 下载未完成（重新执行本脚本会继续下载）"
    fi
    if unzip -tq /tmp/ghidra.zip >/dev/null 2>&1; then
        rm -rf /tmp/gh && mkdir -p /tmp/gh && unzip -q /tmp/ghidra.zip -d /tmp/gh
        src=$(find /tmp/gh -maxdepth 1 -type d -name 'ghidra_*' | head -1)
        rm -rf /opt/ghidra
        if [ -n "$src" ]; then mv "$src" /opt/ghidra && ok "Ghidra 已安装"; else bad "Ghidra 解压结构异常"; fi
        rm -rf /tmp/gh
    fi
fi

if [ -x /opt/jadx/bin/jadx ]; then
    skip "JADX 已存在（/opt/jadx）"
else
    if dl /tmp/jadx.zip "https://github.com/skylot/jadx/releases/download/v1.5.6/jadx-1.5.6.zip"; then
        rm -rf /opt/jadx && mkdir -p /opt/jadx && unzip -q /tmp/jadx.zip -d /opt/jadx
        chmod +x /opt/jadx/bin/* 2>/dev/null
        ok "JADX 已安装"
    else
        bad "JADX 下载失败"
    fi
fi

if [ -f /opt/apktool/apktool_3.0.3.jar ]; then
    skip "apktool 已存在（/opt/apktool）"
else
    mkdir -p /opt/apktool
    if dl /opt/apktool/apktool_3.0.3.jar "https://github.com/iBotPeaches/Apktool/releases/download/v3.0.3/apktool_3.0.3.jar"; then
        ok "apktool 已安装"
    else
        bad "apktool 下载失败"
    fi
fi
printf '#!/bin/bash\nexec java -jar /opt/apktool/apktool_3.0.3.jar "$@"\n' > /usr/local/bin/apktool
chmod +x /usr/local/bin/apktool

# ── 4. Node + REA ───────────────────────────────────────────────────────────
log "4/6  Node $NODE_VERSION + REA"
export NVM_DIR=/root/.nvm
if [ ! -s "$NVM_DIR/nvm.sh" ]; then
    curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash >/dev/null 2>&1
fi
if [ -s "$NVM_DIR/nvm.sh" ]; then
    # shellcheck disable=SC1091
    . "$NVM_DIR/nvm.sh" >/dev/null 2>&1
    if [ -x "$NODE_DIR/bin/node" ]; then
        skip "Node $NODE_VERSION 已存在"
    else
        nvm install "$NODE_VERSION" >/dev/null 2>&1 && ok "Node $NODE_VERSION 已安装" || bad "Node 安装失败"
    fi
else
    bad "nvm 不可用"
fi

if [ -x "$NODE_DIR/bin/rea" ]; then
    skip "REA 已安装（$("$NODE_DIR/bin/rea" --version 2>/dev/null | head -1)）"
else
    "$NODE_DIR/bin/npm" i -g rea-agents@6.4.0 >/dev/null 2>&1 \
        && ok "rea-agents 已安装" || bad "rea-agents 安装失败"
fi

# ── 5. 环境变量、MCP 注册、快捷入口 ─────────────────────────────────────────
log "5/6  环境变量 / MCP 注册 / 快捷入口"

cat > /etc/profile.d/rea-tools.sh <<'EOS'
# 逆向分析与 Android 打包工具链配置
export GHIDRA_INSTALL_DIR=/opt/ghidra
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
case ":$PATH:" in *":$JAVA_HOME/bin:"*) ;; *) export PATH="$JAVA_HOME/bin:$PATH" ;; esac
export PATH="/opt/jadx/bin:/opt/apktool:$PATH"
export ANDROID_HOME=/opt/android-sdk
export ANDROID_SDK_ROOT=/opt/android-sdk
case ":$PATH:" in
  *":$ANDROID_HOME/platform-tools:"*) ;;
  *) export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH" ;;
esac
export NVM_DIR=/root/.nvm
[ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh" >/dev/null 2>&1 && nvm use 22.23.3 >/dev/null 2>&1
EOS
ok "已写入 /etc/profile.d/rea-tools.sh（登录 shell 生效）"

# 助手的命令行是非登录 shell，读不到上面的变量 —— 所以再建一层按名可调的入口
for pair in "aapt2:$ANDROID_SDK/build-tools/$BT_VERSION/aapt2" \
            "apksigner:$ANDROID_SDK/build-tools/$BT_VERSION/apksigner" \
            "zipalign:$ANDROID_SDK/build-tools/$BT_VERSION/zipalign" \
            "adb:$ANDROID_SDK/platform-tools/adb" \
            "jadx:/opt/jadx/bin/jadx"; do
    name="${pair%%:*}"; target="${pair##*:}"
    [ -x "$target" ] && ln -sfn "$target" "/usr/local/bin/$name"
done
ok "已建快捷入口：aapt2 / apksigner / zipalign / adb / jadx / apktool"

if [ -x "$NODE_DIR/bin/rea" ]; then
    if grep -q '"rea"' /root/.codebuddy/.mcp.json 2>/dev/null; then
        skip "MCP 已注册 rea 服务"
    else
        "$NODE_DIR/bin/rea" setup --yes --all-detected >/dev/null 2>&1 \
            && ok "已执行 rea setup（注册 MCP + 安装技能）" || bad "rea setup 失败"
    fi
fi

# ── 6. 校验 ─────────────────────────────────────────────────────────────────
log "6/6  校验"
export GHIDRA_INSTALL_DIR=/opt/ghidra
export PATH="$NODE_DIR/bin:$JAVA_HOME_21/bin:/opt/jadx/bin:/opt/apktool:$PATH"

if [ -x "$NODE_DIR/bin/rea" ]; then
    if "$NODE_DIR/bin/rea" doctor 2>/dev/null | grep -q "^healthy: true"; then
        ok "rea doctor：healthy"
    else
        "$NODE_DIR/bin/rea" doctor 2>/dev/null | grep -E "^(healthy|environment_healthy)" | sed 's/^/    /'
    fi
fi

echo
if [ -f "$ANDROID_SDK/build-tools/$BT_VERSION/aapt2" ]; then ok "aapt2 就绪"; else bad "aapt2 缺失"; fi
if [ -f /root/.android/debug.keystore ]; then
    ok "签名密钥存在"
else
    mkdir -p /root/.android
    keytool -genkeypair -v -keystore /root/.android/debug.keystore \
        -alias androiddebugkey -storepass android -keypass android \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -dname "CN=Android Debug,O=Android,C=US" >/dev/null 2>&1 \
        && ok "已生成调试签名密钥" || bad "签名密钥生成失败"
fi

echo
echo "=============================================="
if [ "$FAILED" -eq 0 ]; then
    printf ' \033[32m配置完成：全部就绪\033[0m\n'
else
    printf ' \033[31m配置结束：%d 项失败\033[0m（详见上面 ✗ 行，可重跑本脚本补齐）\n' "$FAILED"
fi
echo "=============================================="
echo
echo "下一步："
echo "  1) 体检：bash native-compose-demo/check-env.sh"
echo "  2) 构建：cd native-compose-demo && ./gradlew testDebugUnitTest assembleRelease"
echo
echo "注意：REA 的逆向工具是「延迟加载」的 MCP 工具，不在助手的直接工具表里；"
echo "      必须先用工具检索（ToolSearch）按关键词查找，再用 DeferExecuteTool 调用。"
