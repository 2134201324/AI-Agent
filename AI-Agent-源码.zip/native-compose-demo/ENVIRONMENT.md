# 本工程的环境与能力清单（AGENT 必读）

> ⚠ **权威版本**：`/workspace/AI-Agent-项目交接文档.txt`（第 1.4 / 1.5 节）。
> 该文件是唯一权威交接文档，新会话优先全文阅读它；本文件是其中环境小节的详细展开，
> 内容以该 txt 为准，两处冲突时听 txt 的。

> **给新会话的助手**：本工程运行在一个预装了逆向分析、Android 打包等工具链的沙盒里。
> 你的工具列表里**看不到**这些能力（尤其是逆向分析工具），它们是**延迟加载**的——
> 这不是环境缺失。动手前请先执行：

```bash
bash native-compose-demo/check-env.sh
```

自检脚本会逐项报告能力是否可用（✓/✗）以及缺失时的修复方向。

---

## 零、三个「看起来像缺失、其实都在」的陷阱（务必先读）

上一轮新会话的助手就踩了前两个，得出「JDK 只有 20、Android SDK 完全缺失、构建工具缺失」的
**误判结论**。真实原因是：完整工具链的配置写在校验性的 profile 脚本（`/etc/profile.d/rea-tools.sh`）
里，而助手的命令行是**非登录 shell，读不到那些变量**。

### 1. 默认 `java` 可能是 20，而工程需要 21

- 机器上同时存在 JDK 20（SDKMAN 默认）与 JDK 21（`/usr/lib/jvm/java-21-openjdk-amd64`）
- **已固化进工程**：`native-compose-demo/gradle.properties` 里设了
  `org.gradle.java.home=/usr/lib/jvm/java-21-openjdk-amd64`，
  所以 `./gradlew` 一定用 JDK 21 —— **不需要手动 export**，直接构建即可
- 若自检报「默认 java 低于 21」：`ln -sfn /usr/lib/jvm/java-21-openjdk-amd64 /root/.sdkman/candidates/java/current`
- 排查方式：`./gradlew --version` 看 `Daemon JVM` 一行，出现 `from org.gradle.java.home` 即正常

### 2. `ANDROID_HOME` 为空 ≠ Android SDK 缺失

- SDK 实际在 `/opt/android-sdk`，由工程内 `local.properties` 的 `sdk.dir=/opt/android-sdk` 指定
- **Gradle 构建不看 `ANDROID_HOME`**，所以变量为空完全不影响打包
- 构建工具已建好快捷入口，任意 shell 都能按名直接调用：
  `aapt2` / `apksigner` / `zipalign` / `adb` / `jadx` / `apktool`
- 只有当你要用 `sdkmanager` 装新组件时，才需要显式 `export ANDROID_HOME=/opt/android-sdk`

### 3. 个别环境变量只在「登录 shell」里存在

`GHIDRA_INSTALL_DIR`、`JAVA_HOME`、`ANDROID_HOME`、`PATH` 扩展都写在
`/etc/profile.d/rea-tools.sh` 里 —— 助手的非登录 shell 读不到。判断工具是否可用，
**以绝对路径或「按名调用是否成功」为准，不要以变量是否为空为准**。

---

## 一、第二个坑：逆向工具是「延迟加载」的

沙盒里注册了 REA（Reverse Engineering Assistant）MCP 服务，提供 **170 个**逆向分析工具
（Ghidra 反编译、APK 解析、Mach-O / PE 分析、JS 运行时追踪、固件提取等）。

它们**不会出现在你的直接工具表里**，而是被标记为 deferred。日志中的原话：

```
[MCP][toolFilter] server=rea tool=mcp__rea__analyze_function → FILTERED OUT (deferred)
```

**正确用法：先检索，再调用。**

1. 用工具检索（ToolSearch）按关键词查找，例如：
   - `tool_names: ["mcp__rea__binary_overview"]`
   - `queries: ["反编译 apk", "decompile", "binary analysis"]`
2. 检索结果会给出该工具的完整参数签名；
3. 再用延迟工具执行（DeferExecuteTool）按签名调用。

**不要**因为直接工具表里没有 `mcp__rea__*` 就断言"没有逆向能力"。

同理，下表中所有「技能」需要通过 Skill 工具按名称加载，不要在没试过的情况下说不可用。

---

## 二、能力清单

### 1. 逆向分析（REA）

- MCP 服务名：`rea`，版本 6.4.0，通过 stdio 启动
- 启动命令：`/root/.nvm/versions/node/v22.23.3/bin/rea mcp`
- 配置文件：`/root/.codebuddy/.mcp.json`（`mcpServers.rea` 段）
- 技能入口：`reverse-engineer-anything`（软链 → `/root/.agents/skills/reverse-engineer-anything`）
- 依赖：
  - Ghidra：`/opt/ghidra`（环境变量 `GHIDRA_INSTALL_DIR`）
  - JADX：`/opt/jadx/bin`（APK / Java 反编译）
  - apktool：`/opt/apktool`（APK 资源解码）
  - JDK 21：`/usr/lib/jvm/java-21-openjdk-amd64`
- 常用工具举例：`binary_overview`、`analyze_function`、`procedure_pseudo_code`、`list_strings`、
  `open_binary`、`decode_android_resources`、`decompile_jeb_item`、`inspect_plist`、`capture_web_screenshot`

### 2. Android 打包与交付

- JDK：`/usr/lib/jvm/java-21-openjdk-amd64`（必须用 21）
- Android SDK：`/opt/android-sdk`（工程内 `local.properties` 的 `sdk.dir`）
- 构建工具：`/opt/android-sdk/build-tools/36.0.0/`（`apksigner`、`aapt2`）
- 调试密钥：用户主目录下 `.android/debug.keystore`（别名 `androiddebugkey`，口令 `android`）
- 工程：`native-compose-demo/`（Kotlin + Jetpack Compose，AGP 8.13.0 / Kotlin 2.0.21）

**标准交付流程：**

```bash
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
cd native-compose-demo
./gradlew testDebugUnitTest assembleRelease

cp app/build/outputs/apk/release/app-release-unsigned.apk /workspace/AI-Agent-vX.Y.Z.apk
/opt/android-sdk/build-tools/36.0.0/apksigner sign \
  --ks /root/.android/debug.keystore --ks-key-alias androiddebugkey \
  --ks-pass pass:android --key-pass pass:android /workspace/AI-Agent-vX.Y.Z.apk

# 复验版本号与签名
/opt/android-sdk/build-tools/36.0.0/aapt2 dump badging /workspace/AI-Agent-vX.Y.Z.apk | grep package
/opt/android-sdk/build-tools/36.0.0/apksigner verify /workspace/AI-Agent-vX.Y.Z.apk
```

- 版本号在 `app/build.gradle.kts` 内，**每次交付必须递增 `versionCode` 并更新 `versionName`**
- 交付前必须跑通全部单元测试（当前 112 个用例）
- 沙盒开启了 Gradle 构建缓存（缓存目录在 `~/.gradle`，工作区之外），清理 `app/build` 后重建依然很快

### 3. 发布为在线应用

- 技能：`发布为应用`（目录 `/root/.codebuddy/skills/sites`），可用于把静态页 / Node / Python / Go 服务发布成公开链接

### 4. 应用自身的 APK 逆向工具集（v1.9.0 起内置）

**这是 App 的功能，不是沙盒环境的能力** —— 也就是说，装了这个 APK 的手机，其 AI
助手可以直接分析设备上的其它 APK，**不需要 Termux、不需要 jadx/apktool**。

实现方式：`app/src/main/java/com/example/nativedemo/tools/apk/` 下的纯 Kotlin
二进制解析与改包引擎（除签名用 Google 官方 apksig 外零外部依赖），共注册 **15 个工具**：

| 工具 | 用途 |
|---|---|
| `apk_info` | 总览：包名/版本/SDK/权限/导出组件/签名/加固特征 —— **分析第一步** |
| `apk_manifest` | 把二进制 `AndroidManifest.xml` 解码成可读 XML |
| `apk_list` | 列出包内条目（过滤、按大小或名字排序） |
| `apk_read` | 读条目：AXML 自动解码、dex/arsc 给概览、二进制给 hex 文件头 |
| `apk_dex` | 代码结构：统计 / 类列表 / 方法列表 / 字符串池 |
| `apk_resources` | 资源表查询（按类型或关键字，含资源 id） |
| `apk_search` | 跨 DEX 字符串池 / 资源 / manifest / assets 搜索关键字 |
| `apk_signature` | 签名方案 v1/v2/v3 + 证书指纹、有效期、是否调试证书 |
| `apk_extract` | 把包内文件提取到已授权目录（写操作，UI 会二次确认） |
| `apk_replace` | **替换包内文件并重建签名**（换图 / 改配置一步到位）← 改包主力 |
| `apk_unpack` | 完整解包到目录（二进制 XML 自动解码） |
| `apk_pack` | 从目录重新打包并签名 |
| `apk_sign` | 仅重新签名，可传入自己的 keystore |
| `file_write_binary` | 写二进制文件（base64 或复制已有文件） |
| `image_convert` | 图片缩放 / 转格式（准备要替换进 APK 的图） |

改包链路的坑同样写在源码注释里，**动手前务必读**：
- `ApkZipWriter`：对齐是**硬性**的（`resources.arsc` 未对齐 → Android 11+ 拒装；
  `.so` 需按页对齐），所以没用 `ZipOutputStream` 而是自己拼字节；
- `SelfSignedCert`：UTCTime 只能表示 1950–2049，超范围会被解读成上个世纪，
  证书直接"早已过期"（已加硬上限）；
- `RepackEngine`：重建必须剔除旧签名，否则 apksig 拒绝签。

测试都用**真实样本**兜住：`ApkParsersTest`（解析）、`RepackSignTest`（自签 → 重建 →
apksig 签名 → 校验通过，端到端四步全绿）。样本 `app/src/test/resources/sample.apk`
是用 SDK 的 aapt2 + d8 + apksigner 真造出来的，不是手工拼的字节。

测试样本 `app/src/test/resources/sample.apk` 是用 SDK 的 aapt2 + d8 + apksigner
真造出来的（含二进制 AXML、resources.arsc、classes.dex、v1 签名），不是手工拼的字节。

### 5. 其他常用技能

`library`（资料库读写）、`markitdown`（文档转 Markdown）、`workbuddy-docx` / `workbuddy-pptx` / `workbuddy-sheetagent`
（Office 三件套）、`pdf`、`pptx`、`docx`、`xlsx`、`agent-browser` / `playwright-cli`（浏览器自动化）、
`multi-search-engine`、`impeccable` / `frontend-design`（前端设计）

---

## 三、项目资源位置

- 工程源码：`native-compose-demo/`
- 当前成品：`/workspace/AI-Agent-v1.9.2.apk`（versionCode 21）
- 完整打包件：`/workspace/AI-Agent-v1.8.4-full-package.zip`
- 项目交接文档（含架构、机制、版本演进、边界说明）：
  资料库《AI Agent 助手 · 项目交接与上下文说明（v1.8.4）》
  https://www.workbuddy.cn/space/d/2yFnT52NYBafDR5FnQCSlT
- 项目数据目录：`/workspace/.codebuddy`（**不可删除**，非缓存）

---

## 四、能力缺失时的修复方向

若自检报 ✗，按此顺序排查：

1. **REA MCP 未注册** → 检查 `/root/.codebuddy/.mcp.json` 是否含 `mcpServers.rea`；
   缺失则重新执行 `rea setup`（写入 MCP 配置并安装技能软链）。
2. **rea 命令不存在** → 重新安装：`npm i -g rea-agents`（Node 用 v22.23.3），然后 `rea setup`。
3. **Ghidra / JADX / apktool 缺失** → 沙盒镜像变更导致，需要重装到 `/opt/ghidra`、`/opt/jadx`、`/opt/apktool`。
4. **Android SDK 缺失** → 重装到 `/opt/android-sdk`，并确认 `build-tools/36.0.0` 存在。
5. **技能目录为空** → 说明当前会话落在了一个干净沙盒（与工作区未绑定）。
   `reverse-engineer-anything` 是**装在沙盒里**的，不会跟随账号；需在新沙盒重跑一次 `rea setup`。

---

## 五、约定

- 回复与文档一律使用**简体中文**
- 交付物是**可安装的已签名 APK**，版本号递增
- 涉及网络能力的功能要说明真实边界，不做无依据承诺
- 不擅自删除 `/workspace/.codebuddy` 与工程配置文件
