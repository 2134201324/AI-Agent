# ── kotlinx.serialization ─────────────────────────────────────────────
# 序列化依赖生成的 serializer 与 Companion，R8 默认会裁掉它们
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**

-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}

-keep,includedescriptorclasses class com.example.nativedemo.**$$serializer { *; }
-keepclassmembers class com.example.nativedemo.** {
    *** Companion;
}
-keepclasseswithmembers class com.example.nativedemo.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# ── OkHttp / okio ─────────────────────────────────────────────────────
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# ── 其它 ──────────────────────────────────────────────────────────────
-dontwarn org.jetbrains.annotations.**
