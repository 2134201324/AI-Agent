package com.example.nativedemo.tools.net

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 搜索解析的离线测试。
 *
 * 样本都取自**真实抓到的结果页**（2026-10 实际请求 cn.bing.com / so.com 的返回），
 * 只裁掉了与解析无关的样式表和脚本噪音。这样测的是"真能解析出现在线上的页面"，
 * 而不是"能解析我编出来的理想 HTML"。
 *
 * 为什么值得为这几段正则写测试：搜索引擎改版是常态，而解析一旦失效，
 * 表现是"web_search 静默返回 0 条结果" —— 模型只会以为网上没这东西。
 * 有测试兜着，改版时至少能在构建阶段就发现。
 */
class SerpParserTest {

    // ── Bing ────────────────────────────────────────────────────────────

    /** 结构与线上一致：<li class="b_algo"> → .b_algoheader 里 a>h2，摘要另在 .b_caption 的 p 里。 */
    private val bingHtml = """
        <html><body><ol id="b_results">
        <li class="b_algo" data-id iid=SERP.5255>
        <div class="b_algoheader">
        <a href="https://developer.android.google.cn/develop/ui/compose/tutorial?hl=zh-cn" h="ID=SERP,5094.2">
        <h2>Android <strong>Compose</strong> 教程 | Jetpack <strong>Compose</strong></h2>
        </a></div>
        <div class="b_caption"><p class="b_lineclamp3">Jetpack Compose 是用于构建原生 Android 界面的新工具包。</p></div>
        </li>
        <li class="b_algo" data-id iid=SERP.5256>
        <div class="b_algoheader">
        <a href="https://example.com/compose-guide" h="ID=SERP,5095.2">
        <h2>一篇讲 Compose 自定义组件的文章</h2>
        </a></div>
        <div class="b_caption"><p class="b_lineclamp3">从布局到绘制，讲清楚 Compose 的渲染流程。</p></div>
        </li>
        </ol></body></html>
    """.trimIndent()

    @Test
    fun `Bing 解析出标题 链接与摘要`() {
        val hits = SerpParser.parse(SearchEngine.BING, bingHtml, limit = 10)

        assertEquals(2, hits.size)
        assertEquals("Android Compose 教程 | Jetpack Compose", hits[0].title)
        assertEquals(
            "https://developer.android.google.cn/develop/ui/compose/tutorial?hl=zh-cn",
            hits[0].url
        )
        assertTrue(hits[0].snippet.startsWith("Jetpack Compose 是用于构建原生"))
        assertEquals("一篇讲 Compose 自定义组件的文章", hits[1].title)
    }

    @Test
    fun `Bing 标题里的高亮标签被剥掉`() {
        val hits = SerpParser.parse(SearchEngine.BING, bingHtml, limit = 10)
        assertFalse(hits[0].title.contains("<strong>"))
        assertFalse(hits[0].title.contains("<"))
    }

    // ── 360 搜索 ────────────────────────────────────────────────────────

    /**
     * 360 的坑：结果锚点的 href 是站内跳转（m.so.com/jump?u=…），
     * 真实地址在容器的 data-url 属性上。若把它当普通锚点解析，
     * 拿到的一律是 so.com 跳转链接 —— 本用例专门守住这一点。
     */
    private val so360Html = """
        <html><body><div class="result">
        <div class="g-card res-list sumext-tpl-image" data-url="https://cloud.tencent.com/developer/article/2579069" data-cat="mso-image">
        <a class=alink href="https://m.so.com/jump?u=https%3A%2F%2Fcloud.tencent.com%2Fdeveloper%2Farticle%2F2579069&amp;m=0d8fed&amp;from=m.so.com" data-md='{"b":"title"}'>
        <h3 class="res-title"> 前端开发者的 <em>Kotlin</em> 之旅:<em>Compose</em> 自定义组件开发实战 </h3>
        </a>
        <a class=alink href="https://m.so.com/jump?u=x&amp;from=m.so.com" data-md='{"b":"brief"}'>
        <div class="res-con"><div class="con hasImg" data-md='{"b":"summary"}'>这篇文章讲述如何用 Compose 写自定义组件。</div></div>
        </a>
        </div></div></body></html>
    """.trimIndent()

    @Test
    fun `360 用 data-url 里的真实地址 而不是站内跳转链接`() {
        val hits = SerpParser.parse(SearchEngine.SO360, so360Html, limit = 10)

        assertEquals(1, hits.size)
        assertEquals("https://cloud.tencent.com/developer/article/2579069", hits[0].url)
        assertFalse("不应带出跳转链接", hits[0].url.contains("so.com"))
        assertTrue(hits[0].title.contains("前端开发者的"))
        assertTrue(hits[0].title.contains("自定义组件开发实战"))
    }

    // ── DuckDuckGo ──────────────────────────────────────────────────────

    @Test
    fun `DuckDuckGo 的跳转包壳被还原成真实网址`() {
        val html = """
            <html><body>
            <a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fkotlinlang.org%2Fdocs%2F&amp;rut=abc">Kotlin 官方文档</a>
            <a class="result__snippet" href="//duckduckgo.com/l/?uddg=x">Kotlin 是一门现代编程语言。</a>
            </body></html>
        """.trimIndent()

        val hits = SerpParser.parse(SearchEngine.DUCKDUCKGO, html, limit = 10)

        assertEquals(1, hits.size)
        assertEquals("https://kotlinlang.org/docs/", hits[0].url)
        assertEquals("Kotlin 官方文档", hits[0].title)
        assertTrue(hits[0].snippet.contains("现代编程语言"))
    }

    // ── 通用兜底 ────────────────────────────────────────────────────────

    /**
     * 引擎改版后专属规则失效时，通用锚点解析至少还能捞出东西。
     * 这里用一个"不认识的结构"，验证兜底确实会接管。
     */
    @Test
    fun `专属规则失效时通用兜底仍能捞出长文本锚点`() {
        val unknown = """
            <html><body>
            <div class="some-new-layout-2027">
              <a href="https://example.org/very-useful-article">这是一篇足够长的文章标题用来通过过滤</a>
              <a href="https://example.org/short">更多</a>
            </div>
            </body></html>
        """.trimIndent()

        val hits = SerpParser.parse(SearchEngine.BING, unknown, limit = 10)

        assertEquals(1, hits.size)
        assertEquals("https://example.org/very-useful-article", hits[0].url)
    }

    @Test
    fun `指向搜索引擎自身的链接不会被当成结果`() {
        val html = """
            <html><body>
            <a href="https://www.bing.com/search?q=more">搜索结果翻页与导航链接一个</a>
            <a href="https://example.com/real-result">这是一条真正的外部结果链接</a>
            </body></html>
        """.trimIndent()

        val hits = SerpParser.parse(SearchEngine.BING, html, limit = 10)
        assertEquals(1, hits.size)
        assertEquals("https://example.com/real-result", hits[0].url)
    }

    @Test
    fun `重复网址会被去重`() {
        val html = """
            <html><body>
            <a href="https://example.com/a">第一条相同链接的结果标题</a>
            <a href="https://example.com/a">第二条相同链接的结果标题</a>
            </body></html>
        """.trimIndent()

        val hits = SerpParser.parse(SearchEngine.BING, html, limit = 10)
        assertEquals(1, hits.size)
    }

    @Test
    fun `结果数量受 limit 限制`() {
        val html = (1..20).joinToString("\n") { index ->
            """<a href="https://example.com/$index">第 $index 条足够长的结果标题文本</a>"""
        }
        val hits = SerpParser.parse(SearchEngine.BING, html, limit = 3)
        assertEquals(3, hits.size)
    }

    // ── 文本清洗 ────────────────────────────────────────────────────────

    @Test
    fun `实体解码覆盖常见与数字形式`() {
        assertEquals("a & b", SerpParser.decodeEntities("a &amp; b"))
        assertEquals("it's", SerpParser.decodeEntities("it&#39;s"))
        assertEquals("x < y > z", SerpParser.decodeEntities("x &lt; y &gt; z"))
        assertEquals("省略…", SerpParser.decodeEntities("省略&hellip;"))
        assertEquals("中文字符", SerpParser.decodeEntities("&#x4e2d;&#x6587;&#x5b57;&#x7b26;"))
        assertEquals("AB", SerpParser.decodeEntities("&#65;&#66;"))
        assertEquals("不换行 空格", SerpParser.decodeEntities("不换行&nbsp;空格"))
    }

    @Test
    fun `cleanHtml 会剥掉脚本与样式`() {
        val cleaned = SerpParser.cleanHtml(
            "<style>.a{color:red}</style>正文<script>var x=1;</script>结束"
        )
        assertTrue(cleaned.contains("正文"))
        assertTrue(cleaned.contains("结束"))
        assertFalse(cleaned.contains("color:red"))
        assertFalse(cleaned.contains("var x"))
    }

    // ── 字符集 ──────────────────────────────────────────────────────────

    @Test
    fun `字符集优先取 HTTP 头`() {
        assertEquals(
            "GB18030",
            SerpParser.detectCharset(ByteArray(0), "text/html; charset=gbk")
        )
        assertEquals(
            "UTF-8",
            SerpParser.detectCharset(ByteArray(0), "text/html; charset=utf-8")
        )
    }

    @Test
    fun `HTTP 头没有 charset 时回落到页面 meta`() {
        val bytes = """<html><head><meta charset="gb2312"></head></html>"""
            .toByteArray(Charsets.ISO_8859_1)
        assertEquals("GB18030", SerpParser.detectCharset(bytes, "text/html"))
    }

    @Test
    fun `两处都没有时默认 UTF-8`() {
        val bytes = "<html><body>纯文本</body></html>".toByteArray(Charsets.UTF_8)
        assertEquals("UTF-8", SerpParser.detectCharset(bytes, null))
    }

    // ── 引擎枚举 ────────────────────────────────────────────────────────

    @Test
    fun `引擎 id 解析大小写不敏感且未知返回 null`() {
        assertEquals(SearchEngine.BING, SearchEngine.fromId("BING"))
        assertEquals(SearchEngine.SO360, SearchEngine.fromId(" 360 "))
        assertEquals(SearchEngine.DUCKDUCKGO, SearchEngine.fromId("duckduckgo"))
        assertEquals(null, SearchEngine.fromId("google"))
        assertEquals(null, SearchEngine.fromId(null))
    }

    @Test
    fun `默认引擎顺序以 Bing 打头`() {
        assertEquals(SearchEngine.BING, SearchEngine.DEFAULT_ORDER.first())
        assertTrue(SearchEngine.DEFAULT_ORDER.size >= 3)
    }
}
