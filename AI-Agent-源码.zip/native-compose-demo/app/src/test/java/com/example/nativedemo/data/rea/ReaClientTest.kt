package com.example.nativedemo.data.rea

import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

import com.example.nativedemo.tools.rea.ReaRunTool

/**
 * REA 网关客户端的协议层测试。
 *
 * 用 MockWebServer 假扮网关：这里守住的都是"线上最难查"的问题 ——
 * 鉴权头有没有发、协议字段对不对、错误怎么映射、超长怎么截。
 */
class ReaClientTest {

    private lateinit var server: MockWebServer
    private lateinit var client: ReaClient

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
        client = ReaClient(baseUrl = server.url("/").toString(), token = "test-token")
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    @Test
    fun `initialize 发送协议字段并解析服务端信息`() = runBlocking {
        server.enqueue(
            MockResponse().setBody(
                """{"jsonrpc":"2.0","id":1,"result":{"protocolVersion":"2025-03-26",
                   "serverInfo":{"name":"rea-gateway","version":"1.0.0"}}}"""
            )
        )
        val info = client.initialize()
        assertEquals("rea-gateway", info.name)
        assertEquals("1.0.0", info.version)

        val sent = server.takeRequest()
        assertEquals("/mcp", sent.path)
        val body = sent.body.readUtf8()
        assertTrue("应带 protocolVersion", body.contains("\"protocolVersion\":\"2025-03-26\""))
        assertTrue("应带 clientInfo", body.contains("\"clientInfo\""))
        assertTrue("应带 capabilities", body.contains("\"capabilities\""))
    }

    @Test
    fun `每个请求都双发鉴权头`() = runBlocking {
        server.enqueue(MockResponse().setBody("""{"jsonrpc":"2.0","id":1,"result":{}}"""))
        client.initialize()
        val sent = server.takeRequest()
        // 公网代理会剥 Authorization，自定义头是主力；本机直连两种都认
        assertEquals("test-token", sent.getHeader("X-Auth-Token"))
        assertEquals("Bearer test-token", sent.getHeader("Authorization"))
    }

    @Test
    fun `tools list 解析工具清单`() = runBlocking {
        server.enqueue(
            MockResponse().setBody(
                """{"jsonrpc":"2.0","id":2,"result":{"tools":[
                     {"name":"open_binary","description":"打开二进制","inputSchema":{"type":"object"}},
                     {"name":"binary_overview","description":"总览"}
                   ]}}"""
            )
        )
        val tools = client.listTools()
        assertEquals(2, tools.size)
        assertEquals("open_binary", tools[0].name)
        assertEquals("打开二进制", tools[0].description)
    }

    @Test
    fun `tools call 拼接多个 content 文本`() = runBlocking {
        server.enqueue(
            MockResponse().setBody(
                """{"jsonrpc":"2.0","id":3,"result":{"content":[
                     {"type":"text","text":"第一段"},
                     {"type":"image","data":"xxx"},
                     {"type":"text","text":"第二段"}
                   ]}}"""
            )
        )
        val result = client.callTool("binary_overview", buildJsonObject {})
        assertEquals("第一段\n第二段", result.text)
        assertFalse(result.isError)
    }

    @Test
    fun `tools call 透传 isError`() = runBlocking {
        server.enqueue(
            MockResponse().setBody(
                """{"jsonrpc":"2.0","id":4,"result":{"isError":true,
                   "content":[{"type":"text","text":"provider_unavailable"}]}}"""
            )
        )
        val result = client.callTool("binary_overview", buildJsonObject {})
        assertTrue(result.isError)
        assertEquals("provider_unavailable", result.text)
    }

    @Test
    fun `HTTP 401 映射为 ReaException`() {
        server.enqueue(MockResponse().setResponseCode(401).setBody("未授权"))
        val error = runCatching {
            runBlocking { client.initialize() }
        }.exceptionOrNull()
        assertTrue("应是 ReaException，实际 ${error?.javaClass}", error is ReaException)
        assertTrue(error!!.message!!.contains("401"))
    }

    @Test
    fun `JSON-RPC error 映射为 ReaException`() {
        server.enqueue(
            MockResponse().setBody(
                """{"jsonrpc":"2.0","id":1,"error":{"code":-32603,"message":"REA 进程退出"}}"""
            )
        )
        val error = runCatching {
            runBlocking { client.initialize() }
        }.exceptionOrNull()
        assertTrue(error is ReaException)
        assertTrue(error!!.message!!.contains("REA 进程退出"))
    }

    @Test
    fun `非 JSON 响应映射为 ReaException`() {
        server.enqueue(MockResponse().setBody("<html>502 Bad Gateway</html>"))
        val error = runCatching {
            runBlocking { client.initialize() }
        }.exceptionOrNull()
        assertTrue(error is ReaException)
        assertTrue(error!!.message!!.contains("解析失败"))
    }

    @Test
    fun `超长结果头尾保留式截断`() {
        val longText = "头".repeat(2000) + "中".repeat(100_000) + "尾".repeat(2000)
        val clipped = client.clip(longText)
        assertTrue("截断后应更短", clipped.length < longText.length)
        assertTrue("应保留原文开头", clipped.startsWith("头".repeat(100)))
        assertTrue("应保留原文结尾", clipped.endsWith("尾".repeat(100)))
        assertTrue("应有截断标记", clipped.contains("本地截断"))
        assertTrue("标记应带原文字符数", clipped.contains("104000"))
    }

    @Test
    fun `短原样返回不截断`() {
        val text = "x".repeat(100)
        assertEquals(text, client.clip(text))
    }

    @Test
    fun `upload 返回服务器路径并带文件名头`() = runBlocking {
        server.enqueue(
            MockResponse().setBody("""{"ok":true,"path":"/workspace/rea-uploads/123_app.apk","bytes":1024}""")
        )
        val path = client.upload(ByteArray(16) { 1 }, "app.apk")
        assertEquals("/workspace/rea-uploads/123_app.apk", path)

        val sent = server.takeRequest()
        assertEquals("/upload", sent.path)
        assertEquals("app.apk", sent.getHeader("X-Filename"))
        assertEquals("test-token", sent.getHeader("X-Auth-Token"))
        assertEquals(16, sent.bodySize)
    }

    @Test
    fun `upload 失败时抛 ReaException`() {
        server.enqueue(MockResponse().setResponseCode(413).setBody("too large"))
        val error = runCatching {
            runBlocking { client.upload(ByteArray(8), "big.apk") }
        }.exceptionOrNull()
        assertTrue(error is ReaException)
        assertTrue(error!!.message!!.contains("413"))
    }

    @Test
    fun `基地址末尾斜杠归一化`() = runBlocking {
        // 带尾斜杠的地址不应产生双斜杠路径
        val slashedClient = ReaClient(baseUrl = server.url("/").toString().trimEnd('/') + "/", token = "t")
        server.enqueue(MockResponse().setBody("""{"jsonrpc":"2.0","id":1,"result":{}}"""))
        slashedClient.initialize()
        val sent = server.takeRequest()
        assertEquals("/mcp", sent.path)
    }

    @Test
    fun `空 content 返回空文本`() = runBlocking {
        server.enqueue(MockResponse().setBody("""{"jsonrpc":"2.0","id":1,"result":{"content":[]}}"""))
        val result = client.callTool("list_strings", buildJsonObject {})
        assertEquals("", result.text)
        assertFalse(result.isError)
    }

    @Test
    fun `缺失的 serverInfo 不影响握手成功`() = runBlocking {
        server.enqueue(MockResponse().setBody("""{"jsonrpc":"2.0","id":1,"result":{"protocolVersion":"2025-03-26"}}"""))
        val info = client.initialize()
        assertEquals("", info.name)
        assertEquals("", info.version)
    }

    @Test
    fun `callTool 原样传递参数`() = runBlocking {
        server.enqueue(MockResponse().setBody("""{"jsonrpc":"2.0","id":1,"result":{"content":[{"type":"text","text":"ok"}]}}"""))
        val args = buildJsonObject {
            put("procedure", "JNI_OnLoad")
            put("mode", "regex")
        }
        client.callTool("search_procedures", args)
        val sent = server.takeRequest()
        val body = sent.body.readUtf8()
        assertTrue(body.contains("\"name\":\"search_procedures\""))
        assertTrue(body.contains("\"procedure\":\"JNI_OnLoad\""))
        assertTrue(body.contains("\"mode\":\"regex\""))
    }
}

/** rea_run 的 arguments 解析（模型手写 JSON，容错要宽）。 */
class ReaRunArgsTest {

    @Test
    fun `空与缺省返回空对象`() {
        assertEquals(0, ReaRunTool.parseArguments(null)!!.size)
        assertEquals(0, ReaRunTool.parseArguments("")!!.size)
        assertEquals(0, ReaRunTool.parseArguments("   ")!!.size)
        assertEquals(0, ReaRunTool.parseArguments("{}")!!.size)
    }

    @Test
    fun `合法 JSON 对象解析出字段`() {
        val args = ReaRunTool.parseArguments("""{"pattern":"JNI_OnLoad","mode":"regex"}""")!!
        assertEquals("JNI_OnLoad", args["pattern"]?.toString()?.trim('"'))
        assertEquals("regex", args["mode"]?.toString()?.trim('"'))
    }

    @Test
    fun `带多余空白与换行也能解析`() {
        val args = ReaRunTool.parseArguments("""
            {
              "addresses": ["0x1000", "0x2000"]
            }
        """.trimIndent())!!
        assertEquals(1, args.size)
    }

    @Test
    fun `非法 JSON 返回 null`() {
        assertNull(ReaRunTool.parseArguments("{pattern: JNI_OnLoad"))
        assertNull(ReaRunTool.parseArguments("[1,2,3]"))
        assertNull(ReaRunTool.parseArguments("\"just a string\""))
    }
}
