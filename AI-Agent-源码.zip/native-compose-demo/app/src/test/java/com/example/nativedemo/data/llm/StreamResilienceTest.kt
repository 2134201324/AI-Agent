package com.example.nativedemo.data.llm

import kotlinx.coroutines.runBlocking
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.SocketPolicy
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * 「思考强度大导致中断」相关的流式行为测试。
 *
 * 覆盖三件事：
 * 1. 推理模型的思考内容（reasoning_content / reasoning）被正确解析并上抛，
 *    且**不混进正文**（混进去会导致下一轮回灌历史被服务端 400 拒绝）；
 * 2. 流在半途被掐断时，**已经收到的内容不丢**，且被标记为 incomplete，
 *    上层据此自动续写；
 * 3. 连接根本没建立起来时才抛异常 —— 不能把真错误吞成一段空白。
 */
class StreamResilienceTest {

    private lateinit var server: MockWebServer

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    private fun sse(body: String) = MockResponse()
        .setResponseCode(200)
        .setHeader("Content-Type", "text/event-stream")
        .setBody(body)

    private fun baseUrl() = server.url("/v1").toString().trimEnd('/')

    private fun reasoningStream(reasoningField: String) = buildString {
        append("data: {\"choices\":[{\"index\":0,\"delta\":{\"$reasoningField\":\"让我先想\"}}]}\n\n")
        append("data: {\"choices\":[{\"index\":0,\"delta\":{\"$reasoningField\":\"一下…\"}}]}\n\n")
        append("data: {\"choices\":[{\"index\":0,\"delta\":{\"content\":\"答案是 42\"}}]}\n\n")
        append("data: {\"choices\":[{\"index\":0,\"delta\":{},\"finish_reason\":\"stop\"}]}\n\n")
        append("data: [DONE]\n\n")
    }

    private fun stream(
        onText: (String) -> Unit = {},
        onReasoning: (String) -> Unit = {}
    ): ChatResponse = runBlocking {
        LlmClient().chatStream(
            baseUrl = baseUrl(),
            apiKey = "",
            request = ChatRequest(model = "deepseek-reasoner", messages = listOf(ChatMessage.user("q"))),
            onTextDelta = { piece -> onText(piece) },
            onReasoningDelta = { piece -> onReasoning(piece) }
        )
    }

    @Test
    fun `思考内容被解析并上抛，且不混进正文`() {
        server.enqueue(sse(reasoningStream("reasoning_content")))

        val thinking = StringBuilder()
        val text = StringBuilder()
        val response = stream(onText = { text.append(it) }, onReasoning = { thinking.append(it) })

        assertEquals("让我先想一下…", thinking.toString())
        assertEquals("答案是 42", text.toString())
        assertEquals("答案是 42", response.firstMessage?.textContent)
        // 思考内容绝不能出现在正文里
        assertFalse(response.firstMessage?.textContent.orEmpty().contains("让我先想"))
        // 正常收到 finish_reason 的流不应被标记为不完整
        assertFalse(response.incomplete)
    }

    @Test
    fun `网关使用 reasoning 字段时同样能收到`() {
        server.enqueue(sse(reasoningStream("reasoning")))

        val thinking = StringBuilder()
        stream(onReasoning = { thinking.append(it) })

        assertEquals("让我先想一下…", thinking.toString())
    }

    @Test
    fun `流被半途掐断时不丢内容，并标记为 incomplete`() {
        val full = "已经生成的前半段以及第二段还没写完就断了"
        server.enqueue(
            sse(
                buildString {
                    append("data: {\"choices\":[{\"index\":0,\"delta\":{\"content\":\"已经生成的前半段\"}}]}\n\n")
                    append("data: {\"choices\":[{\"index\":0,\"delta\":{\"content\":\"以及第二段\"}}]}\n\n")
                    append("data: {\"choices\":[{\"index\":0,\"delta\":{\"content\":\"还没写完就断了\"}}]}\n\n")
                }
            ).setSocketPolicy(SocketPolicy.DISCONNECT_DURING_RESPONSE_BODY)
        )

        val response = stream()

        // 关键不变量：收到的内容保住了（是完整文本的前缀），且被标记为不完整
        val got = response.firstMessage?.textContent.orEmpty()
        assertTrue("断流后必须保留已收到的内容，实际为空", got.isNotEmpty())
        assertTrue("保留下来的内容应是完整文本的前缀：$got", full.startsWith(got))
        assertTrue("断流后必须标记 incomplete", response.incomplete)
    }

    @Test
    fun `连接建立失败时才抛异常`() {
        server.enqueue(MockResponse().setSocketPolicy(SocketPolicy.DISCONNECT_AT_START))

        val error = runCatching { stream() }.exceptionOrNull()

        assertTrue(
            "连接失败应抛出可读错误，实际：$error",
            error is LlmException
        )
    }

    @Test
    fun `限流与鉴权错误照旧抛出，不被吞成不完整响应`() {
        server.enqueue(
            MockResponse().setResponseCode(401)
                .setBody("""{"error":{"message":"invalid api key"}}""")
        )

        val error = runCatching { stream() }.exceptionOrNull()

        assertTrue("401 应抛鉴权异常，实际：$error", error is LlmException.Auth)
    }
}
