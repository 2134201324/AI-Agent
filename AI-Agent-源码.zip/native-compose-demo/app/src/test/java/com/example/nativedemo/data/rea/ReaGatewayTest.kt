package com.example.nativedemo.data.rea

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * [ReaGateway] 构造契约的回归测试。
 *
 * 背景（v1.10.0 的真实崩溃）：`AppContainer` 里注册表构造时会读取 reaGateway，
 * 而 reaGateway 当时写成 `by lazy { ReaGateway(settingsRepository) }` —— 这次读取
 * 等于立刻强制执行 lazy 初始化体，但那一刻 settingsRepository 尚未赋值（它声明在
 * 注册表之后，因为仓库反过来要读注册表拿默认启用集），于是把 null 传进了非空参数，
 * 应用一启动就 NPE 崩溃。
 *
 * 修复方式：门面改为持有「取仓库的方式」（lambda），把访问推迟到工具真正被调用的
 * 时刻。这两条用例把该契约锁住 —— 任何人若把仓库访问搬回构造期，测试立即变红。
 */
class ReaGatewayTest {

    @Test
    fun `构造期绝不访问设置仓库`() {
        var accessed = false
        // provider 一旦被调用就报错：构造期本不该有任何访问
        val gateway = ReaGateway(settingsProvider = {
            accessed = true
            throw IllegalStateException("构造期不应访问设置仓库")
        })

        assertFalse("ReaGateway 构造时就碰了 settingsRepository —— 依赖环会再次崩", accessed)

        // 读取只依赖常量的属性同样不应触发访问
        assertTrue(gateway.missingReason.contains("REA 逆向引擎尚未配置"))
        assertFalse(accessed)
    }

    @Test
    fun `调用时才通过 provider 取仓库`() {
        var calls = 0
        val gateway = ReaGateway(settingsProvider = {
            calls++
            throw IllegalStateException("测试用桩：只验证访问时机")
        })

        runCatching { kotlinx.coroutines.runBlocking { gateway.client() } }

        assertTrue("client() 必须经 provider 实时取仓库（配置变更即时生效）", calls >= 1)
    }
}
