package com.example.nativedemo.data.agent

import com.example.nativedemo.data.llm.ChatMessage
import com.example.nativedemo.data.llm.FunctionCall
import com.example.nativedemo.data.llm.ToolCall
import kotlinx.serialization.json.JsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 净化逻辑的正确性直接决定「中毒会话能不能恢复」——
 * 错了不会报错，只会继续 400，所以必须有测试兜住。
 */
class ConversationSanitizerTest {

    private fun assistantWith(vararg calls: Pair<String, String>): ChatMessage = ChatMessage(
        role = "assistant",
        content = null,
        toolCalls = calls.map { (id, args) ->
            ToolCall(id = id, function = FunctionCall(name = "file_edit", arguments = args))
        }
    )

    private fun toolReply(id: String) = ChatMessage.tool(id, """{"ok":true}""")

    private val goodArgs = """{"path":"readme.md","old_text":"甲"}"""

    /** 线上那条真实错误：参数在生成中途被截断，字符串没有闭合。 */
    private val truncatedArgs =
        """{"path": "code_game/提示词修改文档.txt", "old_text": "lon 改我上面文件 WebGL 体系游戏""" +
            """（类我的世界）。适配目标唯一且明确：\n 低配 Windows 7 + IE11（系统自带浏览器）。\n\n# 硬性要求：IE11 A"""

    @Test
    fun cleanHistoryIsUntouched() {
        val history = listOf(
            ChatMessage.system("sys"),
            ChatMessage.user("改一下 readme"),
            assistantWith("call_1" to goodArgs),
            toolReply("call_1"),
            ChatMessage.assistant("改好了")
        )
        val report = ConversationSanitizer.analyze(history)

        assertFalse("合法历史不应被改动", report.changed)
        assertEquals(history, report.messages)
    }

    @Test
    fun truncatedArgumentsAreRejectedAndPurged() {
        val history = listOf(
            ChatMessage.user("改一下文档"),
            assistantWith("call_bad" to truncatedArgs),
            toolReply("call_bad"),
            ChatMessage.user("继续")
        )
        val report = ConversationSanitizer.analyze(history)

        assertTrue("必须识别出这条坏记录", report.changed)
        assertEquals(1, report.droppedToolCalls)
        // 关键的 assistant 调用与它的 tool 响应都必须消失，否则下一轮依旧 400
        assertTrue(
            "历史中不应再出现 arguments 非法的 tool_call",
            report.messages.none { msg ->
                msg.toolCalls?.any { !ConversationSanitizer.isValidArguments(it.function.arguments) } == true
            }
        )
        assertTrue(
            "配对失败的 tool 响应也应被清掉",
            report.messages.none { it.role == "tool" && it.toolCallId == "call_bad" }
        )
        // 用户消息不该被误删
        assertEquals(2, report.messages.count { it.role == "user" })
    }

    @Test
    fun validCallsSurviveWhenSiblingIsBroken() {
        val history = listOf(
            ChatMessage.user("同时做两件事"),
            assistantWith("call_ok" to goodArgs, "call_bad" to truncatedArgs),
            toolReply("call_ok"),
            toolReply("call_bad")
        )
        val report = ConversationSanitizer.analyze(history)

        val assistant = report.messages.first { it.toolCalls != null }
        assertEquals(listOf("call_ok"), assistant.toolCalls!!.map { it.id })
        assertEquals(1, report.droppedToolCalls)
    }

    @Test
    fun callWithoutToolResponseIsDropped() {
        // 用户点「停止」会留下这种：助手发了调用，但响应没写进历史
        val history = listOf(
            ChatMessage.user("开始"),
            assistantWith("call_1" to goodArgs)
        )
        val report = ConversationSanitizer.analyze(history)

        assertTrue(report.changed)
        assertTrue(
            "没有响应的 tool_call 会让协议不成立，必须剔除",
            report.messages.none { it.toolCalls != null }
        )
    }

    @Test
    fun orphanToolMessageIsDropped() {
        val history = listOf(
            ChatMessage.user("你好"),
            toolReply("call_ghost")
        )
        val report = ConversationSanitizer.analyze(history)

        assertTrue(report.changed)
        assertTrue(report.messages.none { it.role == "tool" })
    }

    @Test
    fun assistantDegradesToTextWhenAllCallsDropped() {
        val history = listOf(
            ChatMessage.user("改一下"),
            ChatMessage(
                role = "assistant",
                content = JsonPrimitive("我来修改这个文件。"),
                toolCalls = listOf(
                    ToolCall(id = "c1", function = FunctionCall("file_edit", truncatedArgs))
                )
            ),
            toolReply("c1")
        )
        val report = ConversationSanitizer.analyze(history)

        val assistant = report.messages.first { it.role == "assistant" }
        assertEquals("我来修改这个文件。", assistant.textContent)
        assertEquals(null, assistant.toolCalls)
        assertEquals(1, report.droppedMessages) // 被降级，原消息计入丢弃
    }

    @Test
    fun argumentsValidationRules() {
        assertTrue(ConversationSanitizer.isValidArguments("""{"a":1}"""))
        assertTrue(ConversationSanitizer.isValidArguments("{}"))

        assertFalse("空参数不是合法 JSON", ConversationSanitizer.isValidArguments(""))
        assertFalse(ConversationSanitizer.isValidArguments("   "))
        assertFalse("数组不是对象", ConversationSanitizer.isValidArguments("""["a"]"""))
        assertFalse(ConversationSanitizer.isValidArguments("""{"a":"""))
        assertFalse(ConversationSanitizer.isValidArguments("not json at all"))
        assertFalse(ConversationSanitizer.isValidArguments(null))
    }
}
