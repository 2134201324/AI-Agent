package com.example.nativedemo.data.agent

import com.example.nativedemo.data.llm.LlmException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 「长思考被中途打断」时自动救助逻辑的判定测试。
 *
 * 这两条判定直接决定用户会不会看到「答到一半突然停住」：
 * - [shouldAutoContinue]：要不要自动续写；
 * - [isMaxTokensRejectedError]：服务商拒绝输出上限时要不要去掉该参数重试。
 */
class AgentContinuationPolicyTest {

    @Test
    fun `服务端回 length 时应当续写`() {
        assertTrue(
            shouldAutoContinue(incomplete = false, finishReason = "length", continuations = 0)
        )
    }

    @Test
    fun `流被掐断时应当续写`() {
        assertTrue(
            shouldAutoContinue(incomplete = true, finishReason = null, continuations = 0)
        )
        // 即使服务端已经回了 finish_reason，只要标记为不完整（半途断流）也要救
        assertTrue(
            shouldAutoContinue(incomplete = true, finishReason = "stop", continuations = 1)
        )
    }

    @Test
    fun `正常结束不续写`() {
        assertFalse(
            shouldAutoContinue(incomplete = false, finishReason = "stop", continuations = 0)
        )
        assertFalse(
            shouldAutoContinue(incomplete = false, finishReason = "tool_calls", continuations = 0)
        )
        // 有些服务端不回 finish_reason，也不该凭空续写
        assertFalse(
            shouldAutoContinue(incomplete = false, finishReason = null, continuations = 0)
        )
    }

    @Test
    fun `续写次数到达上限后不再续写`() {
        val max = AgentEngine.MAX_CONTINUATIONS
        assertTrue(shouldAutoContinue(true, null, continuations = max - 1))
        assertFalse("到达上限必须停，否则会无限烧 token", shouldAutoContinue(true, null, max))
        assertFalse(shouldAutoContinue(false, "length", continuations = max + 5))
    }

    @Test
    fun `识别服务商拒绝输出上限的各种措辞`() {
        val cases = listOf(
            """{"error":{"message":"max_tokens is too large"}}""",
            """{"error":{"message":"Invalid max tokens: 32768"}}""",
            """{"error":{"message":"max_output_tokens must be <= 8192"}}""",
            """{"error":{"message":"This model's maximum context length is 8192 tokens"}}""",
            """{"error":{"message":"requested length exceeds the maximum"}}"""
        )
        cases.forEach { raw ->
            assertTrue(
                "应被识别为「上限被拒」：$raw",
                isMaxTokensRejectedError(LlmException.BadRequest(400, "err", serverRaw = raw))
            )
        }
    }

    @Test
    fun `与输出上限无关的 400 不该被误判`() {
        val unrelated = listOf(
            """{"error":{"message":"model not found"}}""",
            """{"error":{"message":"invalid api key"}}""",
            """{"error":{"message":"tools is not supported"}}""",
            """{"error":{"message":"function.arguments is not valid json"}}"""
        )
        unrelated.forEach { raw ->
            assertFalse(
                "不应被识别为上限问题：$raw",
                isMaxTokensRejectedError(LlmException.BadRequest(400, "err", serverRaw = raw))
            )
        }
    }

    @Test
    fun `默认输出上限已提到 8192`() {
        // 4096 对推理模型不够：思考 token 与回答 token 共用这份预算
        assertEquals(8192, DEFAULT_MAX_OUTPUT_TOKENS)
        assertEquals(DEFAULT_MAX_OUTPUT_TOKENS, AgentEngine.MAX_TOKENS)
    }
}
