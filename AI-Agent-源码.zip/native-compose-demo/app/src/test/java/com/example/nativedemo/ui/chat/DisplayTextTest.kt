package com.example.nativedemo.ui.chat

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * 展示用换行规整的测试。
 *
 * 用户实测反馈：带工具调用的长任务里，正文之间会出现大片空白。
 * 成因是模型在工具调用前后吐的一串换行被原样渲染。这里锁住「压掉多余换行、
 * 但保留段落分隔」这条边界 —— 压得太狠会把大段文字糊成一坨，也是问题。
 */
class DisplayTextTest {

    @Test
    fun `连续大量换行压成一个空行`() {
        assertEquals("第一段\n\n第二段", normalizeDisplayText("第一段\n\n\n\n\n\n第二段"))
    }

    @Test
    fun `一个空行代表段落分隔_必须保留`() {
        assertEquals("第一段\n\n第二段", normalizeDisplayText("第一段\n\n第二段"))
    }

    @Test
    fun `单个换行不动`() {
        assertEquals("第一行\n第二行", normalizeDisplayText("第一行\n第二行"))
    }

    @Test
    fun `首尾空行去掉`() {
        assertEquals("正文", normalizeDisplayText("\n\n\n正文\n\n\n"))
        assertEquals("- a\n- b", normalizeDisplayText("\n- a\n- b\n\n"))
    }

    @Test
    fun `纯空白文本会变成空串`() {
        // 变成空串后，上层会跳过渲染 —— 这正是「不要留一大片空行」想要的效果
        assertEquals("", normalizeDisplayText("\n\n\n\n\n"))
        assertEquals("", normalizeDisplayText(""))
    }

    @Test
    fun `段落中间的长换行也压掉`() {
        assertEquals(
            "- `a.xml`（616B）\n- `b.xml`（344B）\n\n先读这几个文件：",
            normalizeDisplayText("- `a.xml`（616B）\n- `b.xml`（344B）\n\n\n\n\n先读这几个文件：")
        )
    }

    @Test
    fun `代码块内容不受影响`() {
        // 规整只作用在正文段上；代码段走另一条渲染路径，缩进与空行都要原样保留。
        // 注意围栏前那个换行按解析规则会留在代码内容里（lineCount 自己会 trim），
        // 所以这里比较 trimEnd 后的结果。
        val code = "fun main() {\n\n\n    println(1)\n}"
        val segments = parseMessageSegments("说明：\n\n```kotlin\n$code\n```")
        val codeSegment = segments.filterIsInstance<MsgSegment.Code>().single()
        assertEquals(code, codeSegment.code.trimEnd('\n'))
    }
}
