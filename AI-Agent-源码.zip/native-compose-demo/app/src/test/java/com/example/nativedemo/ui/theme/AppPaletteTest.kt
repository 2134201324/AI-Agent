package com.example.nativedemo.ui.theme

import com.example.nativedemo.data.settings.AppBrand
import com.example.nativedemo.data.settings.BackdropStats
import com.example.nativedemo.data.settings.BackdropStatsCodec
import com.example.nativedemo.data.settings.ColorSlot
import com.example.nativedemo.data.settings.ColorSlotCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 调色板分层测试：主题预设 → 智能适配 → 手动覆盖，三层优先级不能乱。
 *
 * 顺序错了的后果很具体：用户手动把备注小字调亮，智能层却把它盖回去 ——
 * 「我改的颜色为什么不管用」。
 */
class AppPaletteTest {

    @Test
    fun `slots keep two roughly balanced columns`() {
        // 只要求均衡，不要求严格相等：槽位总数是奇数时不可能对半分，
        // 而「哪一列多一个」远不如「两列不会一长一短」重要。
        val left = ColorSlot.entries.count { it.column == 0 }
        val right = ColorSlot.entries.count { it.column == 1 }
        assertTrue("两列数量相差 ${kotlin.math.abs(left - right)}，布局会明显失衡", kotlin.math.abs(left - right) <= 1)
        assertEquals(ColorSlot.entries.size, left + right)
    }

    @Test
    fun `内层卡片 分割线 用户气泡都能被覆盖`() {
        // 回归守卫：这三个槽位原本不存在，导致工具卡、思考卡、模型档案卡这些
        // 「卡片里的卡片」怎么调色都不变，用户只能看到一半的自定义生效。
        val base = AppPalette.of(AppBrand.BLUE, dark = true)
        val overridden = base.withOverrides(
            mapOf(
                ColorSlot.CHIP_BG to 0xFF010203L,
                ColorSlot.LINE_COLOR to 0xFF040506L,
                ColorSlot.USER_BUBBLE to 0xFF070809L
            )
        )

        assertEquals(androidx.compose.ui.graphics.Color(0xFF010203), overridden.chipBg)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF040506), overridden.lineColor)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF070809), overridden.userBubble)

        // 反向取值同样要通，否则设置页读回颜色会显示成预设值
        assertEquals(androidx.compose.ui.graphics.Color(0xFF010203), overridden.valueOf(ColorSlot.CHIP_BG))
        assertEquals(androidx.compose.ui.graphics.Color(0xFF040506), overridden.valueOf(ColorSlot.LINE_COLOR))
        assertEquals(androidx.compose.ui.graphics.Color(0xFF070809), overridden.valueOf(ColorSlot.USER_BUBBLE))

        // 覆盖这三个不该顺带改动别的
        assertEquals(base.cardBg, overridden.cardBg)
        assertEquals(base.fg, overridden.fg)
    }

    @Test
    fun `muted and faint slots map to palette fields`() {
        val base = AppPalette.of(AppBrand.BLUE, dark = true)
        val overridden = base.withOverrides(
            mapOf(
                ColorSlot.MUTED to 0xFF112233L,
                ColorSlot.FAINT to 0xFF445566L
            )
        )
        assertEquals(androidx.compose.ui.graphics.Color(0xFF112233), overridden.muted)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF445566), overridden.faint)
        // 反向取值也要通
        assertEquals(androidx.compose.ui.graphics.Color(0xFF112233), overridden.valueOf(ColorSlot.MUTED))
        assertEquals(androidx.compose.ui.graphics.Color(0xFF445566), overridden.valueOf(ColorSlot.FAINT))
        // 其他槽位不受影响
        assertEquals(base.fg, overridden.fg)
        assertEquals(base.bg, overridden.bg)
    }

    @Test
    fun `smart text only touches the three text slots`() {
        val base = AppPalette.of(AppBrand.BLUE, dark = true)
        val smart = base.withSmartText(BackdropStats(0.05f, 0.4f))

        assertNotEquals(base.fg, smart.fg)
        assertNotEquals(base.muted, smart.muted)
        assertNotEquals(base.faint, smart.faint)
        // 背景类槽位一个都不动 —— 它们各有背景色兜底
        assertEquals(base.bg, smart.bg)
        assertEquals(base.cardBg, smart.cardBg)
        assertEquals(base.chipBg, smart.chipBg)
        assertEquals(base.inputBg, smart.inputBg)
        assertEquals(base.fieldBg, smart.fieldBg)
        assertEquals(base.lineColor, smart.lineColor)
        assertEquals(base.userBubble, smart.userBubble)
        assertEquals(base.accent, smart.accent)
        assertEquals(base.topBarBg, smart.topBarBg)
        assertEquals(base.topBarFg, smart.topBarFg)
        assertEquals(base.inputBarBg, smart.inputBarBg)
        assertEquals(base.inputBarFg, smart.inputBarFg)
        assertEquals(base.overlayBg, smart.overlayBg)
        assertEquals(base.drawerBg, smart.drawerBg)
        assertEquals(base.bannerBg, smart.bannerBg)
    }

    @Test
    fun `null stats is a no-op`() {
        val base = AppPalette.of(AppBrand.TEAL, dark = false)
        assertEquals(base, base.withSmartText(null))
    }

    @Test
    fun `manual override beats smart layer`() {
        val base = AppPalette.of(AppBrand.BLUE, dark = true)
        val smart = base.withSmartText(BackdropStats(0.05f, 0.4f))
        val final = smart.withOverrides(
            mapOf(
                ColorSlot.TEXT to 0xFF123456L,
                ColorSlot.FAINT to 0xFF654321L
            )
        )
        // 手动改过的槽位以用户为准
        assertEquals(androidx.compose.ui.graphics.Color(0xFF123456), final.fg)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF654321), final.faint)
        // 没改的 muted 保持智能推导值
        assertEquals(smart.muted, final.muted)
    }

    @Test
    fun `smart layer survives theme switch but overrides do not freeze it`() {
        // 换品牌色 / 深浅模式后，智能层仍在（它跟着新预设重算），
        // 手动覆盖也仍在（它只冻结自己那一个槽位）
        val dark = AppPalette.of(AppBrand.BLUE, dark = true)
            .withSmartText(BackdropStats(0.05f, 0.4f))
        val light = AppPalette.of(AppBrand.BLUE, dark = false)
            .withSmartText(BackdropStats(0.05f, 0.4f))
        // 同一品牌色，但深浅两套预设的背景不同
        assertEquals(dark.accent, light.accent)
        assertNotEquals(dark.bg, light.bg)
        // 同一份统计在深浅两套预设下推导出同样的文字色（智能层只看背景图）
        assertEquals(dark.fg, light.fg)
    }

    @Test
    fun `palette apply composes layers in order`() {
        val stats = BackdropStats(0.05f, 0.4f)
        Palette.apply(AppBrand.BLUE, dark = true, emptyMap(), stats)
        val smartOnly = Palette.current
        assertNotEquals(AppPalette.of(AppBrand.BLUE, dark = true).fg, smartOnly.fg)

        Palette.apply(
            brand = AppBrand.BLUE,
            dark = true,
            overrides = mapOf(ColorSlot.TEXT to 0xFF123456L),
            smartStats = stats
        )
        assertEquals(androidx.compose.ui.graphics.Color(0xFF123456), Palette.current.fg)
        // 还原全局状态，避免影响同一进程里的其他测试
        Palette.apply(AppBrand.BLUE, dark = true)
    }

    @Test
    fun `slot codec round trips new slots`() {
        val entries = setOf(
            ColorSlotCodec.encode(ColorSlot.MUTED, 0xFF112233L),
            ColorSlotCodec.encode(ColorSlot.FAINT, 0xFF445566L)
        )
        val decoded = ColorSlotCodec.decodeAll(entries)
        assertEquals(2, decoded.size)
        assertEquals(0xFF112233L, decoded[ColorSlot.MUTED])
        assertEquals(0xFF445566L, decoded[ColorSlot.FAINT])
    }

    @Test
    fun `background style gates stats behind the switch`() {
        val stats = BackdropStats(0.3f, 0.4f)
        val on = com.example.nativedemo.data.settings.BackgroundStyle(
            uri = "/x/bg.jpg",
            smartContrast = true,
            stats = stats
        )
        val off = on.copy(smartContrast = false)
        assertTrue(on.effectiveStats == stats)
        assertTrue(off.effectiveStats == null)
        assertTrue(
            com.example.nativedemo.data.settings.BackgroundStyle()
                .effectiveStats == null
        )
    }

    @Test
    fun `backdrop stats codec rejects malformed input`() {
        assertEquals(null, BackdropStatsCodec.decode("0.5|"))
        assertEquals(null, BackdropStatsCodec.decode("x|y"))
        val decoded = BackdropStatsCodec.decode("1.5|-0.2")
        assertEquals(1f, decoded!!.luminance, 1e-6f)
        assertEquals(0f, decoded.busyness, 1e-6f)
    }
}
