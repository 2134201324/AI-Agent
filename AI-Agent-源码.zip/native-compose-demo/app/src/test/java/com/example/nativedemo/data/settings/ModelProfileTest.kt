package com.example.nativedemo.data.settings

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 模型档案（多 Key / 多模型编排的基本单位）测试。
 *
 * 重点钉住两件事：
 * 1. **升级不丢配置** —— 旧版单模型配置必须原样收编成档案，Key 密文直接搬用；
 * 2. **坏数据不致命** —— 解码时去重、剔空 id、补标签，设置页不能因为一条脏记录崩掉。
 */
class ModelProfileTest {

    // ── 旧配置迁移 ────────────────────────────────────────────────────

    @Test
    fun `legacy config is adopted as the default profile`() {
        val profiles = migrateLegacyProfiles(
            existingJson = null,
            legacyBaseUrl = "https://api.deepseek.com/v1",
            legacyModel = "deepseek-chat",
            legacyKeyCipher = "cipher-text"
        )
        assertEquals(1, profiles.size)
        val profile = profiles[0]
        assertEquals(ModelProfile.LEGACY_DEFAULT_ID, profile.id)
        assertEquals("默认模型", profile.label)
        assertEquals("https://api.deepseek.com/v1", profile.baseUrl)
        assertEquals("deepseek-chat", profile.model)
        // Key 密文原样搬用：它的别名就是旧默认别名，不需要重新加密
        assertEquals("cipher-text", profile.keyCipher)
        assertTrue(profile.enabled)
        assertEquals(ProfileRole.BOTH, profile.role)
        assertTrue(profile.hasKey)
    }

    @Test
    fun `stored profiles win over legacy migration`() {
        val stored = ModelProfileCodec.encodeProfiles(
            listOf(
                ModelProfile(id = "x", label = "主力", baseUrl = "https://a.com/v1", model = "m1"),
                ModelProfile(id = "y", label = "备用", baseUrl = "https://b.com/v1", model = "m2")
            )
        )
        val profiles = migrateLegacyProfiles(
            existingJson = stored,
            legacyBaseUrl = "https://legacy.com/v1",
            legacyModel = "legacy-model",
            legacyKeyCipher = "cipher"
        )
        assertEquals(2, profiles.size)
        assertEquals("x", profiles[0].id)
        assertEquals("y", profiles[1].id)
    }

    @Test
    fun `blank legacy config yields no profiles`() {
        assertTrue(
            migrateLegacyProfiles(null, legacyBaseUrl = "", legacyModel = "", legacyKeyCipher = null)
                .isEmpty()
        )
    }

    @Test
    fun `blank legacy model falls back to base url`() {
        val profiles = migrateLegacyProfiles(
            existingJson = null,
            legacyBaseUrl = "https://api.example.com/v1",
            legacyModel = "",
            legacyKeyCipher = null
        )
        assertEquals("https://api.example.com/v1", profiles[0].model)
        assertFalse(profiles[0].hasKey)
    }

    // ── 编解码 ────────────────────────────────────────────────────────

    @Test
    fun `codec round trip preserves everything`() {
        val original = listOf(
            ModelProfile(
                id = "p1",
                label = "主力模型",
                baseUrl = "https://api.openai.com/v1",
                model = "gpt-4o-mini",
                role = ProfileRole.ORCHESTRATOR,
                enabled = true,
                keyCipher = "abc",
                toolsSupported = true,
                createdAt = 12345L
            ),
            ModelProfile(
                id = "p2",
                label = "备用模型",
                baseUrl = "https://api.deepseek.com/v1",
                model = "deepseek-chat",
                role = ProfileRole.SUB,
                enabled = false,
                keyCipher = null,
                toolsSupported = false
            )
        )
        val decoded = ModelProfileCodec.decodeProfiles(ModelProfileCodec.encodeProfiles(original))
        assertEquals(original, decoded)
    }

    @Test
    fun `codec tolerates garbage input`() {
        assertTrue(ModelProfileCodec.decodeProfiles(null).isEmpty())
        assertTrue(ModelProfileCodec.decodeProfiles("").isEmpty())
        assertTrue(ModelProfileCodec.decodeProfiles("not json at all").isEmpty())
        assertTrue(ModelProfileCodec.decodeProfiles("{}").isEmpty())
    }

    @Test
    fun `codec sanitizes blank ids duplicates and labels`() {
        val dirty = """
            [
              {"id":"","label":"","baseUrl":"https://a.com/v1","model":"m1"},
              {"id":"dup","label":"第一个","baseUrl":"https://a.com/v1","model":"m1"},
              {"id":"dup","label":"第二个","baseUrl":"https://b.com/v1","model":"m2"},
              {"id":"keep","label":"  ","baseUrl":"https://c.com/v1","model":"m3"}
            ]
        """.trimIndent()
        val decoded = ModelProfileCodec.decodeProfiles(dirty)
        assertEquals(2, decoded.size)
        // 空 id 被剔除
        assertEquals("dup", decoded[0].id)
        // 同 id 去重，保留第一个
        assertEquals("第一个", decoded[0].label)
        // 空标签用模型名补
        assertEquals("keep", decoded[1].id)
        assertEquals("m3", decoded[1].label)
    }

    // ── 角色与可用性判定 ──────────────────────────────────────────────

    @Test
    fun `role decides orchestrator and sub eligibility`() {
        val both = ModelProfile(id = "1", label = "L", baseUrl = "u", model = "m", keyCipher = "k")
        val orchOnly = both.copy(id = "2", role = ProfileRole.ORCHESTRATOR)
        val subOnly = both.copy(id = "3", role = ProfileRole.SUB)
        val noKey = both.copy(id = "4", keyCipher = null)
        val disabled = both.copy(id = "5", enabled = false)

        assertTrue(both.canOrchestrate && both.canSub)
        assertTrue(orchOnly.canOrchestrate)
        assertFalse(orchOnly.canSub)
        assertEquals("角色为仅主模型", orchOnly.subUnavailableReason())
        assertNull(orchOnly.orchestratorUnavailableReason())

        assertTrue(subOnly.canSub)
        assertFalse(subOnly.canOrchestrate)
        assertEquals("角色为仅子模型", subOnly.orchestratorUnavailableReason())
        assertNull(subOnly.subUnavailableReason())

        assertFalse(noKey.canOrchestrate && noKey.canSub)
        assertEquals("未填写 API Key", noKey.orchestratorUnavailableReason())

        assertFalse(disabled.canOrchestrate && disabled.canSub)
        assertEquals("已停用", disabled.orchestratorUnavailableReason())
    }

    @Test
    fun `profile role parse falls back to both`() {
        assertEquals(ProfileRole.BOTH, ProfileRole.parse(null))
        assertEquals(ProfileRole.BOTH, ProfileRole.parse("不存在的值"))
        assertEquals(ProfileRole.SUB, ProfileRole.parse("SUB"))
        assertEquals(ProfileRole.ORCHESTRATOR, ProfileRole.parse("ORCHESTRATOR"))
    }
}
