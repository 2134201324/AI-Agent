package com.example.nativedemo.data.settings

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * 工具启用集的升级补齐规则。
 *
 * 这段逻辑的特点是"只在升级的那一瞬间起作用"，平时怎么点开关都测不到它，
 * 一旦写错又表现为"新功能没生效"或"开关自己弹回去" —— 只能靠这里守住。
 */
class ToolEnableResolverTest {

    private val v192Tools = setOf("web_fetch", "file_read", "file_write", "run_command")

    /** 1.9.3/1.9.4 新增：web_search 与 mt_open 默认开、mt_script 默认关。 */
    private val v193Tools = v192Tools + setOf("web_search", "mt_open", "mt_script")

    private val defaultEnabled = setOf("web_fetch", "file_read", "file_write", "web_search", "mt_open")

    @Test
    fun `从未设置过开关时返回 null 表示全默认`() {
        val resolved = computeEnabledTools(
            stored = null,
            known = emptySet(),
            allToolNames = v193Tools,
            defaultEnabled = defaultEnabled
        )
        assertNull(resolved)
    }

    @Test
    fun `没有新工具时原样返回存储值`() {
        val stored = setOf("web_fetch", "file_read")
        val resolved = computeEnabledTools(
            stored = stored,
            known = v193Tools,
            allToolNames = v193Tools,
            defaultEnabled = defaultEnabled
        )
        assertEquals(stored, resolved)
    }

    @Test
    fun `升级后新增的默认启用工具会自动补进来`() {
        // 老用户在 1.9.2 只开过 web_fetch
        val stored = setOf("web_fetch")
        val resolved = computeEnabledTools(
            stored = stored,
            known = v192Tools,
            allToolNames = v193Tools,
            defaultEnabled = defaultEnabled
        )
        assertEquals(setOf("web_fetch", "web_search", "mt_open"), resolved)
    }

    @Test
    fun `新增但默认关闭的工具不会被自动打开`() {
        val resolved = computeEnabledTools(
            stored = setOf("web_fetch"),
            known = v192Tools,
            allToolNames = v193Tools,
            defaultEnabled = defaultEnabled
        )
        // mt_script 危险，必须由用户显式打开
        assertEquals(false, resolved?.contains("mt_script"))
    }

    @Test
    fun `用户主动关掉的工具不会被补回来`() {
        // 用户在 1.9.2 时特意关掉了 run_command（它不在 stored 里，但在 known 里）
        val stored = setOf("web_fetch", "file_read", "file_write")
        val resolved = computeEnabledTools(
            stored = stored,
            known = v192Tools,
            allToolNames = v193Tools,
            defaultEnabled = defaultEnabled
        )
        assertEquals(false, resolved?.contains("run_command"))
    }

    @Test
    fun `补齐只发生一次 记录已知后再次计算结果不变`() {
        val stored = setOf("web_fetch")

        // 第一次：用户还没见过新工具，补上
        val first = computeEnabledTools(
            stored = stored,
            known = v192Tools,
            allToolNames = v193Tools,
            defaultEnabled = defaultEnabled
        )
        // 调用方（markToolsSeen）会把 first 落盘、并把全部工具名并入 known
        val second = computeEnabledTools(
            stored = first,
            known = v193Tools,
            allToolNames = v193Tools,
            defaultEnabled = defaultEnabled
        )

        assertEquals(first, second)
    }

    /**
     * 反例回归：只更新 known、不落盘启用集，补齐结果就会在下一次读取时消失。
     * 这条用例把"必须落盘"这个约束固化成断言 —— 以后若有人简化掉落盘那一步，这里会红。
     */
    @Test
    fun `若补齐结果不落盘 第二次读取会丢掉新工具`() {
        val stored = setOf("web_fetch")

        val resolved = computeEnabledTools(
            stored = stored,
            known = v192Tools,
            allToolNames = v193Tools,
            defaultEnabled = defaultEnabled
        )
        assertEquals(true, resolved?.contains("web_search"))

        // 模拟"忘了落盘"：stored 仍是旧的，但 known 已更新为全部工具
        val wrong = computeEnabledTools(
            stored = stored,
            known = v193Tools,
            allToolNames = v193Tools,
            defaultEnabled = defaultEnabled
        )
        assertEquals(false, wrong?.contains("web_search"))
    }
}
