package com.example.nativedemo.data.agent

import com.example.nativedemo.data.llm.ChatMessage
import com.example.nativedemo.data.llm.FunctionCall
import com.example.nativedemo.data.llm.LlmException
import com.example.nativedemo.data.llm.ToolCall
import com.example.nativedemo.data.llm.looksLikeRichContentRejected
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 回归测试：曾经让「聊几次之后整个会话就废掉」的那条链路。
 *
 * 现场证据（用户截图中的真实报文）：
 * ```
 * {"success":false,"error":{"issues":[{"code":"invalid_union","unionErrors":[
 *   {"issues":[{"code":"invalid_type","expected":"string","received":"array",
 *    "path":["messages",13,"content"],"message":"Expected string, received array"}]}],
 *   "name":"ZodError"}]}}
 * ```
 * 即：服务端只接受字符串 content，而历史里那条带图片的消息是数组 —— 且它会
 * 一直留在历史里，导致该会话此后每轮都 400。
 */
class RequestPayloadGuardTest {

    private fun imageUrlPart(url: String = "data:image/jpeg;base64,AAAA") = buildJsonObject {
        put("type", "image_url")
        putJsonObject("image_url") { put("url", url) }
    }

    private fun textPart(text: String) = buildJsonObject {
        put("type", "text")
        put("text", text)
    }

    private fun richUser(text: String, withImage: Boolean = true): ChatMessage {
        val parts = mutableListOf<JsonElement>()
        if (text.isNotEmpty()) parts += textPart(text)
        if (withImage) parts += imageUrlPart()
        return ChatMessage(role = "user", content = JsonArray(parts))
    }

    private fun badRequest(raw: String) = LlmException.BadRequest(400, raw, raw)

    // ── toPlainText：把任何形态压成字符串 ─────────────────────────────

    @Test
    fun `字符串内容原样返回`() {
        assertEquals("你好", JsonPrimitive("你好").toPlainText())
    }

    @Test
    fun `文本与图片混排时文本保留、图片变成占位符`() {
        val element = JsonArray(listOf(textPart("修改这张图"), imageUrlPart()))
        val text = element.toPlainText()
        assertTrue(text!!.contains("修改这张图"))
        assertTrue(text, text.contains(IMAGE_PLACEHOLDER))
    }

    @Test
    fun `纯图片没有文字时也给占位符而不是空串`() {
        // 早先的实现（asTextOrNull）对图片分片返回空串，模型和用户都不知道
        // 这里原本有一张图 —— 那既丢信息又难排查
        assertEquals(IMAGE_PLACEHOLDER, JsonArray(listOf(imageUrlPart())).toPlainText())
    }

    @Test
    fun `单个图片分片对象同样能压平`() {
        assertEquals(IMAGE_PLACEHOLDER, imageUrlPart().toPlainText())
    }

    @Test
    fun `null 与空数组安全返回`() {
        assertNull((null as JsonElement?).toPlainText())
        assertNull(JsonArray(emptyList()).toPlainText())
    }

    // ── prepare：历史压平、本轮保留 ──────────────────────────────────

    @Test
    fun `历史里的多模态消息被压平而本轮保留`() {
        val history = listOf(
            richUser("上次那张图"),            // 元凶：留在历史里，每轮都要回灌
            ChatMessage.assistant("好的"),
            richUser("这一次的图")
        )

        val report = RequestPayloadGuard.prepare(history, keepLastUserRich = true)

        assertEquals(1, report.flattened)
        assertEquals(1, report.richKept)
        assertTrue(report.changed)

        // 旧的那条已变成字符串，且图片留下了可见占位
        val flattened = report.messages[0]
        assertFalse(flattened.hasRichContent)
        assertTrue(flattened.textContent!!.contains("上次那张图"))
        assertTrue(flattened.textContent!!.contains(IMAGE_PLACEHOLDER))

        // 本轮那条仍是数组 —— 模型应该看到用户刚发的图
        assertTrue(report.messages[2].hasRichContent)
    }

    @Test
    fun `关闭富文本后连本轮也一并压平`() {
        val history = listOf(richUser("旧图"), ChatMessage.assistant("好"), richUser("新图"))

        val report = RequestPayloadGuard.prepare(history, keepLastUserRich = false)

        assertEquals(2, report.flattened)
        assertEquals(0, report.richKept)
        assertFalse(report.messages.any { it.hasRichContent })
    }

    @Test
    fun `纯文本会话不做任何改动`() {
        val plain = listOf(ChatMessage.user("你好"), ChatMessage.assistant("在的"))

        val report = RequestPayloadGuard.prepare(plain, keepLastUserRich = true)

        assertFalse(report.changed)
        assertEquals(0, report.richKept)
        assertEquals(plain, report.messages)
    }

    // ── 400 识别：要认得出，也不能误伤 ───────────────────────────────

    @Test
    fun `Zod 报的 content 类型错误能被识别`() {
        val raw = """{"success":false,"error":{"issues":[{"code":"invalid_union",""" +
            """"unionErrors":[{"issues":[{"code":"invalid_type","expected":"string",""" +
            """"received":"array","path":["messages",13,"content"],""" +
            """"message":"Expected string, received array"}]}],"name":"ZodError"}]}}"""

        assertTrue(looksLikeRichContentRejected(raw))
        assertTrue(isRichContentRejectedError(badRequest(raw)))
    }

    @Test
    fun `其它方言的同类错误同样识别`() {
        // Pydantic / FastAPI：字段位置在 loc 里，措辞是另一套
        assertTrue(
            looksLikeRichContentRejected(
                """{"detail":[{"type":"string_type","loc":["body","messages",13,"content"],""" +
                    """"msg":"Input should be a valid string"}]}"""
            )
        )
        // 通用网关的两种语序
        assertTrue(looksLikeRichContentRejected("messages[2].content: content must be a string"))
        assertTrue(looksLikeRichContentRejected("messages.2.content: string expected"))
    }

    @Test
    fun `普通 400 不被误判`() {
        assertFalse(looksLikeRichContentRejected("""{"error":{"message":"model not exist"}}"""))
        assertFalse(isRichContentRejectedError(badRequest("""{"error":{"message":"Invalid API key"}}""")))
    }

    @Test
    fun `工具不支持的错误不被误判成 content 问题`() {
        // 报文里出现了 "content"（在 content_encoding 这个无关字段里），
        // 但整句话说的是 tools 不被支持 —— 必须走「工具降级」那条自愈路径
        val raw = """{"error":{"message":"tools is not supported by this model",""" +
            """"content_encoding":"gzip"}}"""

        assertFalse(looksLikeRichContentRejected(raw))
        assertTrue(isToolsUnsupportedError(badRequest(raw)))
    }

    // ── 历史裁剪 ─────────────────────────────────────────────────────

    @Test
    fun `未超阈值不裁剪`() {
        val messages = (1..10).map { ChatMessage.user("m$it") }

        val report = ConversationSanitizer.prune(messages, maxMessages = 20)

        assertFalse(report.changed)
        assertEquals(10, report.messages.size)
    }

    @Test
    fun `超阈值时从 user 边界裁掉最早的部分`() {
        // 关键：落点必须避开 assistant(tool_calls) + tool 这一对，
        // 切开它们同样是协议违规，会引出新的 400
        val messages = listOf(
            ChatMessage.user("u1"),
            ChatMessage(
                role = "assistant",
                content = JsonPrimitive("a1"),
                toolCalls = listOf(ToolCall(id = "c1", function = FunctionCall("probe", "{}")))
            ),
            ChatMessage.tool("c1", "r1"),
            ChatMessage.assistant("a2"),
            ChatMessage.user("u2"),
            ChatMessage.assistant("a3")
        )

        val report = ConversationSanitizer.prune(messages, maxMessages = 3)

        assertTrue(report.changed)
        assertEquals(4, report.dropped)
        assertEquals(2, report.messages.size)
        // 裁完之后的第一条是新会话的起点（user 消息）
        assertEquals("u2", report.messages.first().textContent)
        assertEquals("user", report.messages.first().role)
    }
}
