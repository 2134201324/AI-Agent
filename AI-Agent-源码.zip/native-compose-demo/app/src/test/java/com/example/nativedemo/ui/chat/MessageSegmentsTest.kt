package com.example.nativedemo.ui.chat

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 消息分段（代码块折叠）的纯 JVM 测试。
 *
 * 钉住两类行为：围栏配对（含流式未闭合）与语言标注解析 —— 分错一段，
 * 用户看到的就不是「折叠的代码」而是一屏幕乱码或消失的代码。
 */
class MessageSegmentsTest {

    @Test
    fun `plain text is a single segment`() {
        val segments = parseMessageSegments("你好，这是一段普通回复。")
        assertEquals(1, segments.size)
        assertTrue(segments[0] is MsgSegment.Text)
        assertEquals("你好，这是一段普通回复。", (segments[0] as MsgSegment.Text).text)
    }

    @Test
    fun `empty text yields no segments`() {
        assertTrue(parseMessageSegments("").isEmpty())
    }

    @Test
    fun `single closed code block with language`() {
        val text = "看这段代码：\n```kotlin\nfun main() {\n    println(1)\n}\n```\n就完成了。"
        val segments = parseMessageSegments(text)
        assertEquals(3, segments.size)

        assertTrue(segments[0] is MsgSegment.Text)
        val code = segments[1] as MsgSegment.Code
        assertEquals("kotlin", code.lang)
        assertTrue(code.closed)
        assertEquals("fun main() {\n    println(1)\n}\n", code.code)
        // 围栏之后的内容归为文本
        assertTrue(segments[2] is MsgSegment.Text)
    }

    @Test
    fun `code block without language`() {
        val segments = parseMessageSegments("```\nplain code\n```")
        assertEquals(1, segments.size)
        val code = segments[0] as MsgSegment.Code
        assertEquals("", code.lang)
        assertEquals("plain code\n", code.code)
    }

    @Test
    fun `streaming code block is not closed`() {
        // 流式生成到一半：开围栏有，闭围栏还没来
        val segments = parseMessageSegments("好的：\n```python\nprint(")
        assertEquals(2, segments.size)
        val code = segments[1] as MsgSegment.Code
        assertEquals("python", code.lang)
        assertFalse(code.closed)
        assertEquals("print(", code.code)
    }

    @Test
    fun `multiple code blocks alternate with text`() {
        val text = "第一段\n```js\nlet a = 1\n```\n中间说明\n```js\nlet b = 2\n```\n收尾"
        val segments = parseMessageSegments(text)
        assertEquals(5, segments.size)
        assertTrue(segments[0] is MsgSegment.Text)
        assertTrue(segments[1] is MsgSegment.Code)
        assertTrue(segments[2] is MsgSegment.Text)
        assertTrue(segments[3] is MsgSegment.Code)
        assertTrue(segments[4] is MsgSegment.Text)
        assertTrue((segments[1] as MsgSegment.Code).closed)
        assertTrue((segments[3] as MsgSegment.Code).closed)
    }

    @Test
    fun `text between two fences only is code`() {
        // 整个消息就是一个代码块，没有外围文字
        val segments = parseMessageSegments("```sql\nSELECT 1;\n```")
        assertEquals(1, segments.size)
        assertTrue(segments[0] is MsgSegment.Code)
    }

    @Test
    fun `unclosed fence at very start`() {
        val segments = parseMessageSegments("```kotlin\nval x =")
        assertEquals(1, segments.size)
        val code = segments[0] as MsgSegment.Code
        assertFalse(code.closed)
        assertEquals("val x =", code.code)
    }

    @Test
    fun `empty code block counts zero lines`() {
        val code = MsgSegment.Code("", "", closed = true)
        assertEquals(0, code.lineCount)
    }

    @Test
    fun `line count ignores trailing newline`() {
        assertEquals(1, MsgSegment.Code("", "a", true).lineCount)
        assertEquals(3, MsgSegment.Code("", "a\nb\nc", true).lineCount)
        // 围栏里的代码几乎都以换行结尾；那一行不算内容，否则 2 行脚本会被标成 3 行
        assertEquals(3, MsgSegment.Code("", "a\nb\nc\n", true).lineCount)
        assertEquals(0, MsgSegment.Code("", "", true).lineCount)
        assertEquals(0, MsgSegment.Code("", "\n\n", true).lineCount)
    }

    @Test
    fun `empty text segments between fences are dropped`() {
        // 两个代码块紧邻，中间的文本段为空，不应产生空 Text
        val segments = parseMessageSegments("```\na\n```\n```\nb\n```")
        assertEquals(2, segments.size)
        assertTrue(segments.all { it is MsgSegment.Code })
    }

    // ── 折叠摘要（历史消息收起后显示的内容）────────────────────────

    @Test
    fun `摘要把代码块压成占位而不复制正文`() {
        val text = "下面是一段脚本：\n```kotlin\nval a = 1\nval b = 2\n```\n跑一下试试。"
        val digest = digestMessage(text)

        assertTrue(digest.preview.contains("下面是一段脚本"))
        assertTrue(digest.preview.contains("［代码 2 行］"))
        // 代码正文不能被抄进摘要 —— 那正是折叠想避免的
        assertFalse(digest.preview.contains("val a = 1"))
        assertEquals(1, digest.codeBlocks)
        assertEquals(2, digest.codeLines)
    }

    @Test
    fun `短消息不折叠`() {
        assertFalse(digestMessage("好的，已经完成了。").worthCollapsing)
    }

    @Test
    fun `长文本会触发折叠`() {
        assertTrue(digestMessage("这是一段很长的说明。".repeat(80)).worthCollapsing)
    }

    @Test
    fun `大段代码即使文字很少也会折叠`() {
        val code = (1..40).joinToString("\n") { "line$it" }
        val digest = digestMessage("```\n$code\n```")
        assertTrue("40 行代码应当触发折叠", digest.worthCollapsing)
    }

    @Test
    fun `摘要把换行与多余空白压成单行`() {
        assertEquals("第一行 第二行 第三行", digestMessage("第一行\n\n\n第二行   第三行").preview)
    }

    @Test
    fun `摘要超长时截断并加省略号`() {
        val digest = digestMessage("啊".repeat(500), maxPreview = 50)
        assertEquals(51, digest.preview.length)
        assertTrue(digest.preview.endsWith("…"))
    }

    @Test
    fun `空消息也能安全生成摘要`() {
        val digest = digestMessage("")
        assertTrue(digest.preview.isEmpty())
        assertFalse(digest.worthCollapsing)
    }
}
