package com.example.nativedemo.tools.apk

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * APK 逆向解析器的端到端测试。
 *
 * 测试样本 `src/test/resources/sample.apk` 是**真实构建出来的包**（用 aapt2 + d8 +
 * apksigner 生成，见工程脚本），里面的 `AndroidManifest.xml` 是真正的二进制 AXML、
 * `classes.dex` 是真正的 Dalvik 字节码。用真样本而不是手工拼的字节，才能验证
 * 「aapt 实际产出的格式」被正确解析 —— 手拼的字节只能验证解析器符合我自己的想象。
 *
 * 样本里刻意埋了几个便于断言的钩子：
 * - 包名 `cc.sample.target`、versionCode 42、versionName 9.9.9
 * - 权限 READ_PHONE_STATE、`debuggable=true`、`usesCleartextTraffic=true`
 * - 导出组件 MainActivity、非导出 SyncService
 * - 字符串资源 `app_name` / `secret_endpoint`（值里带一个假域名）
 * - DEX 里的方法 `greet`、`collectDeviceInfo` 与常量 `https://api.sample.internal/v2`
 */
class ApkParsersTest {

    private val sampleBytes: ByteArray by lazy {
        javaClass.classLoader!!.getResourceAsStream("sample.apk")?.use(InputStream::readBytes)
            ?: error("测试样本 sample.apk 缺失（应在 src/test/resources 下）")
    }

    private val entries: Map<String, ByteArray> by lazy {
        val result = mutableMapOf<String, ByteArray>()
        ZipInputStream(sampleBytes.inputStream()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory) result[entry.name] = zip.readBytes()
            }
        }
        result
    }

    // ── 二进制 XML ─────────────────────────────────────────────────────

    @Test
    fun `二进制 manifest 能被解码出结构与关键属性`() {
        val document = AxmlParser.decode(entries.getValue("AndroidManifest.xml"))
        val root = document.root
        assertNotNull("应当解析出根元素", root)
        assertEquals("manifest", root!!.name)
        assertEquals("cc.sample.target", root.attr("package"))

        // 系统属性按资源 id 匹配：名字反查表在 JVM 环境下不完整，
        // 而 id 是文件里真实存在的，这条链路必须可靠
        assertEquals("42", root.attrById(0x0101021b, "versionCode"))
        assertEquals("9.9.9", root.attrById(0x0101021c, "versionName"))
    }

    @Test
    fun `序列化出的 XML 可读且带命名空间声明`() {
        val xml = AxmlParser.toXml(AxmlParser.decode(entries.getValue("AndroidManifest.xml")))

        assertTrue(xml, xml.contains("xmlns:android=\"http://schemas.android.com/apk/res/android\""))
        // 属性名被正确反查（否则会是 android:attr/0x0101021b）
        assertTrue(xml, xml.contains("android:versionCode=\"42\""))
        assertTrue(xml, xml.contains("android:versionName=\"9.9.9\""))
        assertTrue(xml, xml.contains("cc.sample.target"))
        assertTrue(xml, xml.contains("android.permission.READ_PHONE_STATE"))
        assertTrue(xml, xml.contains("android:exported=\"true\""))
    }

    @Test
    fun `uses-sdk 与 application 的属性可读`() {
        val root = AxmlParser.decode(entries.getValue("AndroidManifest.xml")).root!!
        val sdk = root.childrenNamed("uses-sdk").single()
        assertEquals("21", sdk.attrById(0x0101020c, "minSdkVersion"))
        assertEquals("30", sdk.attrById(0x01010270, "targetSdkVersion"))

        val application = root.childrenNamed("application").single()
        // 布尔属性是类型化的，必须靠 Res_value 解析而不是原始字符串
        assertEquals("true", application.attrById(0x0101000f, "debuggable"))
        assertEquals("true", application.attrById(0x010104ec, "usesCleartextTraffic"))
        // label 是对资源表的引用
        assertTrue(application.attrById(0x01010001, "label")!!.startsWith("@"))
    }

    @Test
    fun `组件与 intent-filter 被完整解析`() {
        val root = AxmlParser.decode(entries.getValue("AndroidManifest.xml")).root!!
        val application = root.childrenNamed("application").single()

        val activities = application.childrenNamed("activity")
        assertEquals(1, activities.size)
        assertEquals(".MainActivity", activities[0].attrById(0x01010003, "name"))

        val filter = activities[0].childrenNamed("intent-filter").single()
        val actions = filter.childrenNamed("action").map { it.attrById(0x01010003, "name") }
        assertTrue(actions.contains("android.intent.action.MAIN"))

        assertEquals(1, application.childrenNamed("service").size)
    }

    // ── DEX ────────────────────────────────────────────────────────────

    @Test
    fun `dex 解析出类 方法数与字符串池`() {
        val dex = DexParser.parse(entries.getValue("classes.dex"))

        val sample = dex.classes.firstOrNull { it.name == "cc.sample.Sample" }
        assertNotNull("应当能识别出 cc.sample.Sample", sample)
        assertTrue("类至少应含构造器与两个方法", sample!!.methodCount >= 3)

        val methods = dex.methodsOf(sample.index)
        val names = methods.map { it.name }
        assertTrue(names.toString(), names.contains("greet"))
        assertTrue(names.toString(), names.contains("collectDeviceInfo"))
        // 构造器在 DEX 里叫 <init>
        assertTrue(methods.any { it.isConstructor })
    }

    @Test
    fun `dex 字符串池可搜索且包含内联常量`() {
        val dex = DexParser.parse(entries.getValue("classes.dex"))
        val hits = dex.searchStrings("api.sample.internal", 20)
        assertTrue("应当搜到内联的 URL 常量：$hits", hits.any { it.contains("api.sample.internal") })

        // 子串匹配应当忽略大小写
        assertTrue(dex.searchStrings("API.SAMPLE.INTERNAL", 20).isNotEmpty())
        // 不存在的关键字返回空而不是抛错
        assertTrue(dex.searchStrings("绝不存在的关键字zzz", 20).isEmpty())
    }

    @Test
    fun `类名描述符被还原成可读形式`() {
        assertEquals("com.example.Foo", DexParser.descriptorToReadable("Lcom/example/Foo;"))
        assertEquals("int", DexParser.descriptorToReadable("I"))
        assertEquals("java.lang.String[]", DexParser.descriptorToReadable("[Ljava/lang/String;"))
        assertEquals("int[][]", DexParser.descriptorToReadable("[[I"))
    }

    @Test
    fun `非 dex 数据被拒绝而不是解析出垃圾`() {
        val error = runCatching { DexParser.parse("这不是 dex".toByteArray()) }.exceptionOrNull()
        assertTrue(error is ResParseException)
    }

    // ── 资源表 ─────────────────────────────────────────────────────────

    @Test
    fun `资源表解析出字符串资源及其值`() {
        val table = ResourceTableParser.parse(entries.getValue("resources.arsc"))

        assertEquals(listOf("cc.sample.target"), table.packages)

        val strings = table.entries.filter { it.typeName == "string" }
        assertTrue(strings.any { it.entryName == "app_name" && it.value == "SampleTarget" })
        assertTrue(
            strings.any {
                it.entryName == "secret_endpoint" && it.value.contains("evil.example.com")
            }
        )
        // 资源 id 应当落在 0x7f 包段
        assertTrue(table.entries.all { it.resIdHex.startsWith("0x7f") })
    }

    // ── 签名 ───────────────────────────────────────────────────────────

    @Test
    fun `检测到 v1 签名方案`() {
        val temp = File.createTempFile("sample", ".apk")
        try {
            temp.writeBytes(sampleBytes)
            val schemes = ApkSignatureInspector.detectSchemes(temp)
            assertTrue("样本用 apksigner 签过，v1 应当存在", schemes.v1)
            assertTrue(schemes.any)
        } finally {
            temp.delete()
        }
    }

    @Test
    fun `未签名的包不会误报有签名`() {
        val stripped = File.createTempFile("stripped", ".apk")
        try {
            // 把 META-INF 去掉，模拟一个未签名的包
            val out = java.io.ByteArrayOutputStream()
            java.util.zip.ZipOutputStream(out).use { zip ->
                entries.filterKeys { !it.startsWith("META-INF/") }.forEach { (name, bytes) ->
                    zip.putNextEntry(java.util.zip.ZipEntry(name))
                    zip.write(bytes)
                    zip.closeEntry()
                }
            }
            stripped.writeBytes(out.toByteArray())
            val schemes = ApkSignatureInspector.detectSchemes(stripped)
            assertTrue("不应检测到 v1", !schemes.v1)
        } finally {
            stripped.delete()
        }
    }
}
