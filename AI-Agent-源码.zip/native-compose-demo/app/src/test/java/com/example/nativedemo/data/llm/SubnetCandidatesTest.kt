package com.example.nativedemo.data.llm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * subnetCandidates 的推导规则测试。
 *
 * 扫描的候选集完全由它决定：漏掉该扫的地址 = 发现不了服务，
 * 扫到不该扫的（自身 / 广播）= 浪费一轮探测。
 */
class SubnetCandidatesTest {

    @Test
    fun `常规 WiFi 地址推出整段候选`() {
        val candidates = subnetCandidates("192.168.1.105")
        assertEquals(253, candidates.size)
        assertTrue(candidates.contains("192.168.1.1"))
        assertTrue(candidates.contains("192.168.1.254"))
        assertTrue(candidates.contains("192.168.1.42"))
    }

    @Test
    fun `排除自身与网段广播地址`() {
        val candidates = subnetCandidates("10.0.0.7")
        assertFalse(candidates.contains("10.0.0.7"))
        assertFalse(candidates.contains("10.0.0.0"))
        assertFalse(candidates.contains("10.0.0.255"))
        // 253 = 1..254 去掉自身
        assertEquals(253, candidates.size)
    }

    @Test
    fun `移动数据的运营商内网地址同样按 24 处理`() {
        val candidates = subnetCandidates("10.132.45.201")
        assertTrue(candidates.contains("10.132.45.1"))
        assertTrue(candidates.contains("10.132.45.254"))
        assertFalse(candidates.contains("10.132.45.201"))
    }

    @Test
    fun `空地址与非法地址返回空列表`() {
        assertTrue(subnetCandidates(null).isEmpty())
        assertTrue(subnetCandidates("").isEmpty())
        assertTrue(subnetCandidates("   ").isEmpty())
        assertTrue(subnetCandidates("192.168.1").isEmpty())
        assertTrue(subnetCandidates("192.168.1.999").isEmpty())
        assertTrue(subnetCandidates("abc.def.ghi.jkl").isEmpty())
        assertTrue(subnetCandidates("::1").isEmpty())
    }

    @Test
    fun `自身就是 1 或 254 时边界仍正确`() {
        val atOne = subnetCandidates("192.168.0.1")
        assertFalse(atOne.contains("192.168.0.1"))
        assertTrue(atOne.contains("192.168.0.2"))
        assertEquals(253, atOne.size)

        val atMax = subnetCandidates("192.168.0.254")
        assertFalse(atMax.contains("192.168.0.254"))
        assertTrue(atMax.contains("192.168.0.253"))
        assertEquals(253, atMax.size)
    }
}
