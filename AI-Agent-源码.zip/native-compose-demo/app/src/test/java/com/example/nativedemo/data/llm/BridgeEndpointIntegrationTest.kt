package com.example.nativedemo.data.llm

import kotlinx.coroutines.runBlocking
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * 「网页桥接版无需 API Key」的端到端验证。
 *
 * 用 MockWebServer 模拟 DSH 一类桥接服务：**完全不校验鉴权**，只转发网页会话。
 * 然后让真正的 [LlmClient] 去访问它 —— 验证用户不填任何 Key 时，
 * 模型清单、对话、流式对话三条链路全部能通。
 *
 * 这类问题纯函数测试看不出来：坑在 HTTP 头、URL 拼接与协议解析上。
 */
class BridgeEndpointIntegrationTest {

    private lateinit var server: MockWebServer

    private val modelsJson =
        """{"object":"list","data":[{"id":"deepseek-chat"},{"id":"deepseek-reasoner"}]}"""

    private val chatJson =
        """{"id":"c1","model":"deepseek-chat","choices":[{"index":0,""" +
            """"message":{"role":"assistant","content":"pong"},"finish_reason":"stop"}]}"""

    /** 流式分片：模拟 token 逐段下发 */
    private val sseBody = buildString {
        append("data: {\"id\":\"c1\",\"model\":\"deepseek-chat\",\"choices\":[{\"index\":0,")
        append("\"delta\":{\"content\":\"po\"}}]}\n\n")
        append("data: {\"id\":\"c1\",\"choices\":[{\"index\":0,")
        append("\"delta\":{\"content\":\"ng\"},\"finish_reason\":\"stop\"}]}\n\n")
        append("data: [DONE]\n\n")
    }

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    private fun jsonResponse(body: String) = MockResponse()
        .setResponseCode(200)
        .setHeader("Content-Type", "application/json")
        .setBody(body)

    /** 带版本层的 Base URL（模拟用户按预设填的 http://host:8000/v1）。 */
    private fun baseUrl() = server.url("/v1").toString().trimEnd('/')

    /** 漏写版本层的 Base URL（http://host:8000）。 */
    private fun rootUrl() = server.url("/").toString().trimEnd('/')

    @Test
    fun `不填 Key 也能列出模型`() {
        server.enqueue(jsonResponse(modelsJson))
        runBlocking {
            val models = LlmClient().listModels(baseUrl(), apiKey = "")
            assertEquals(listOf("deepseek-chat", "deepseek-reasoner"), models)
        }
        val request = server.takeRequest()
        assertEquals("/v1/models", request.path)
        assertEquals("Bearer $LOCAL_BRIDGE_PLACEHOLDER_KEY", request.getHeader("Authorization"))
    }

    @Test
    fun `不填 Key 也能对话`() {
        server.enqueue(jsonResponse(chatJson))
        runBlocking {
            val response = LlmClient().chat(
                baseUrl = baseUrl(),
                apiKey = "",
                request = ChatRequest(
                    model = "deepseek-chat",
                    messages = listOf(ChatMessage.user("ping"))
                )
            )
            assertEquals("pong", response.firstMessage?.textContent)
        }
        assertEquals("/v1/chat/completions", server.takeRequest().path)
    }

    @Test
    fun `不填 Key 也能流式对话`() {
        server.enqueue(
            MockResponse()
                .setResponseCode(200)
                .setHeader("Content-Type", "text/event-stream")
                .setBody(sseBody)
        )
        runBlocking {
            val deltas = StringBuilder()
            val response = LlmClient().chatStream(
                baseUrl = baseUrl(),
                apiKey = "",
                request = ChatRequest(
                    model = "deepseek-chat",
                    messages = listOf(ChatMessage.user("ping"))
                )
            ) { piece -> deltas.append(piece) }
            // 分片要按顺序拼回完整回复
            assertEquals("pong", deltas.toString())
            assertEquals("pong", response.firstMessage?.textContent)
        }
    }

    @Test
    fun `Base URL 漏写版本层时自动回退到 v1`() {
        // 先撞 /models（404），再回退 /v1/models（成功）
        server.enqueue(MockResponse().setResponseCode(404).setBody("""{"error":{"message":"nf"}}"""))
        server.enqueue(jsonResponse(modelsJson))

        runBlocking {
            val models = LlmClient().listModels(rootUrl(), apiKey = "")
            assertEquals(listOf("deepseek-chat", "deepseek-reasoner"), models)
        }
        assertEquals("/models", server.takeRequest().path)
        assertEquals("/v1/models", server.takeRequest().path)
    }

    @Test
    fun `按本地端点判定补出的占位令牌能真正打通链路`() {
        // 模拟上层流程：用户什么都没填 → effectiveApiKey 补占位 → 走真实请求
        val key = effectiveApiKey(baseUrl(), apiKey = null)
        assertEquals(LOCAL_BRIDGE_PLACEHOLDER_KEY, key)

        server.enqueue(jsonResponse(modelsJson))
        runBlocking {
            LlmClient().listModels(baseUrl(), apiKey = key.orEmpty())
        }
        assertEquals(
            "Bearer $LOCAL_BRIDGE_PLACEHOLDER_KEY",
            server.takeRequest().getHeader("Authorization")
        )
    }

    @Test
    fun `用户自己填的 Key 会原样发出`() {
        server.enqueue(jsonResponse(modelsJson))
        runBlocking {
            LlmClient().listModels(baseUrl(), apiKey = "sk-user-typed")
        }
        assertEquals("Bearer sk-user-typed", server.takeRequest().getHeader("Authorization"))
    }

    @Test
    fun `桥接返回的模型清单能被容错解析并用于优选`() {
        // 桥接工具常把自己代理的模型一并列出，其中混着非聊天模型
        server.enqueue(
            jsonResponse(
                """{"object":"list","data":[{"id":"bge-m3"},{"id":"deepseek-reasoner"},{"id":"deepseek-chat"}]}"""
            )
        )
        runBlocking {
            val models = LlmClient().listModels(baseUrl(), apiKey = "")
            // 客户端保持服务端返回的顺序，不擅自重排
            assertEquals(listOf("bge-m3", "deepseek-reasoner", "deepseek-chat"), models)
            // 但优选逻辑要能从混杂列表里挑出适合聊天的那个
            assertEquals("deepseek-chat", pickPreferredModel(models))
        }
        assertTrue(server.takeRequest().path?.startsWith("/v1/models") == true)
    }
}
