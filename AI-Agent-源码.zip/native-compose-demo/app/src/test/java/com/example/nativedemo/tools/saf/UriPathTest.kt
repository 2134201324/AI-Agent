package com.example.nativedemo.tools.saf

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * 授权目录路径解析的纯逻辑测试。
 *
 * 这里的错误表现是「明明存在的目录说找不到」，而现场只有模型看到的一句
 * 「未找到目录」，排查成本很高 —— 用户实测就撞上过：模型从 file_list 里
 * 看到目录名 `code_game`，于是调用 file_list("code_game")，旧实现却只会把
 * 根名当子目录去找，必然失败，白烧一轮对话额度。
 */
class UriPathTest {

    @Test
    fun `常见的路径写法都能规整成段`() {
        assertEquals(listOf("code_game", "a.txt"), normalizePathSegments("/sdcard/code_game/a.txt"))
        assertEquals(
            listOf("code_game", "a.txt"),
            normalizePathSegments("storage/emulated/0/code_game/a.txt")
        )
        assertEquals(listOf("code_game"), normalizePathSegments("code_game"))
        assertEquals(listOf("code_game"), normalizePathSegments("  /code_game/  "))
        // 连续斜杠与当前目录记号都要被吃掉
        assertEquals(
            listOf("code_game", "sub", "x.md"),
            normalizePathSegments("code_game//sub/./x.md")
        )
    }

    @Test
    fun `空白输入返回 null`() {
        assertNull(normalizePathSegments(""))
        assertNull(normalizePathSegments("   "))
        assertNull(normalizePathSegments("/"))
        assertNull(normalizePathSegments("storage/emulated/0/"))
    }

    @Test
    fun `拒绝路径穿越`() {
        // 只允许在已授权目录内活动，`..` 一律不接受
        assertNull(normalizePathSegments("../etc/passwd"))
        assertNull(normalizePathSegments("code_game/../../secret"))
    }

    @Test
    fun `路径以授权目录名开头时按相对路径解析`() {
        assertEquals(listOf("sub"), relativeToRoot(listOf("code_game", "sub"), "code_game"))
        assertEquals(
            listOf("sub", "deep", "x.md"),
            relativeToRoot(listOf("code_game", "sub", "deep", "x.md"), "code_game")
        )
    }

    @Test
    fun `只剩授权目录名时剩余为空_表示就是这个目录本身`() {
        // 这正是用户踩到的那个 bug：旧实现在这里返回 null，于是「未找到目录」。
        // 空列表是有意义的返回值，代表授权目录自身。
        assertEquals(emptyList<String>(), relativeToRoot(listOf("code_game"), "code_game"))
    }

    @Test
    fun `不带目录名的路径原样返回`() {
        assertEquals(listOf("sub"), relativeToRoot(listOf("sub"), "code_game"))
        assertEquals(listOf("a.txt"), relativeToRoot(listOf("a.txt"), "code_game"))
    }

    @Test
    fun `不做前缀模糊匹配`() {
        // code_game2 不是 code_game，按前缀匹配会误伤成完全不同的目录
        assertEquals(
            listOf("code_game2", "sub"),
            relativeToRoot(listOf("code_game2", "sub"), "code_game")
        )
    }

    @Test
    fun `根目录名未知时不吞掉任何一段`() {
        assertEquals(listOf("code_game", "sub"), relativeToRoot(listOf("code_game", "sub"), ""))
    }
}
