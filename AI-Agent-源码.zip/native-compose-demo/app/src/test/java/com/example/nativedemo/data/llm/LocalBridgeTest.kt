package com.example.nativedemo.data.llm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 网页桥接「免 Key」判定的测试。
 *
 * 这组规则决定了用户还会不会被「请先填写 API Key」拦住 ——
 * 判太窄用户依旧被拦，判太宽则云服务会拿着占位令牌去撞 401。
 */
class LocalBridgeTest {

    @Test
    fun `回环地址算本地端点`() {
        assertTrue(isLocalEndpoint("http://127.0.0.1:8000/v1"))
        assertTrue(isLocalEndpoint("http://localhost:8000/v1"))
        assertTrue(isLocalEndpoint("127.0.0.1:8000/v1"))
        assertTrue(isLocalEndpoint("http://[::1]:8000/v1"))
        assertTrue(isLocalEndpoint("http://0.0.0.0:8000/v1"))
    }

    @Test
    fun `私有网段算本地端点`() {
        assertTrue(isLocalEndpoint("http://192.168.1.42:8000/v1"))
        assertTrue(isLocalEndpoint("http://10.132.45.7:8000/v1"))
        assertTrue(isLocalEndpoint("http://172.16.0.9:8000/v1"))
        assertTrue(isLocalEndpoint("http://172.31.255.254:8000/v1"))
        // 手机热点直连常见网段
        assertTrue(isLocalEndpoint("http://169.254.10.20:8000/v1"))
        assertTrue(isLocalEndpoint("http://mac-mini.local:8000/v1"))
    }

    @Test
    fun `云服务不算本地端点`() {
        assertFalse(isLocalEndpoint("https://api.openai.com/v1"))
        assertFalse(isLocalEndpoint("https://api.deepseek.com/v1"))
        assertFalse(isLocalEndpoint("https://open.bigmodel.cn/api/paas/v4"))
        assertFalse(isLocalEndpoint("https://dashscope.aliyuncs.com/compatible-mode/v1"))
        // 172 段只有 16~31 是私有，32 已经是公网
        assertFalse(isLocalEndpoint("http://172.32.0.1:8000/v1"))
        assertFalse(isLocalEndpoint("http://192.169.1.1:8000/v1"))
    }

    @Test
    fun `空地址与非法地址不算本地端点`() {
        assertFalse(isLocalEndpoint(""))
        assertFalse(isLocalEndpoint("   "))
        assertFalse(isLocalEndpoint("不是地址"))
    }

    @Test
    fun `本地端点空 Key 时自动补占位令牌`() {
        assertEquals(
            LOCAL_BRIDGE_PLACEHOLDER_KEY,
            effectiveApiKey("http://192.168.1.42:8000/v1", null)
        )
        assertEquals(
            LOCAL_BRIDGE_PLACEHOLDER_KEY,
            effectiveApiKey("http://127.0.0.1:8000/v1", "")
        )
        assertEquals(
            LOCAL_BRIDGE_PLACEHOLDER_KEY,
            effectiveApiKey("http://127.0.0.1:8000/v1", "   ")
        )
    }

    @Test
    fun `用户自己填的 Key 优先于占位令牌`() {
        assertEquals("sk-real", effectiveApiKey("http://127.0.0.1:8000/v1", "sk-real"))
        // 两端空白会被裁掉
        assertEquals("sk-trim", effectiveApiKey("https://api.openai.com/v1", " sk-trim "))
    }

    @Test
    fun `云服务没有 Key 时仍然要求填写`() {
        assertNull(effectiveApiKey("https://api.openai.com/v1", null))
        assertNull(effectiveApiKey("https://api.openai.com/v1", "  "))
    }

    @Test
    fun `模型优选顺序`() {
        // 精确命中 deepseek-chat
        assertEquals(
            "deepseek-chat",
            pickPreferredModel(listOf("glm-4-flash", "deepseek-reasoner", "deepseek-chat"))
        )
        // 没有精确命中时先挑 deepseek 系
        assertEquals(
            "deepseek-reasoner",
            pickPreferredModel(listOf("qwen-plus", "deepseek-reasoner"))
        )
        // 再退一步挑带 chat 的
        assertEquals("qwen-chat", pickPreferredModel(listOf("qwen-plus", "qwen-chat", "bge-m3")))
        // 最后兜底第一个
        assertEquals("bge-m3", pickPreferredModel(listOf("bge-m3", "whisper-1")))
        assertNull(pickPreferredModel(emptyList()))
    }

    // ── 地址规范化：这是「配置过程绝对简化」的关键一环 ──────────────

    @Test
    fun `只给 ip 和端口时自动补协议与版本层`() {
        assertEquals("http://192.168.1.5:8000/v1", normalizeBaseUrl("192.168.1.5:8000"))
        assertEquals("http://127.0.0.1:8000/v1", normalizeBaseUrl("127.0.0.1:8000"))
    }

    @Test
    fun `已有版本层的地址原样保留`() {
        assertEquals("http://192.168.1.5:8000/v1", normalizeBaseUrl("http://192.168.1.5:8000/v1"))
        assertEquals("http://192.168.1.5:8000/v1", normalizeBaseUrl("http://192.168.1.5:8000/v1/"))
        assertEquals("https://api.openai.com/v1", normalizeBaseUrl("https://api.openai.com/v1"))
    }

    @Test
    fun `粘贴来的具体接口地址会被剥成 Base URL`() {
        // 这是最典型的一个坑：用户直接复制了完整接口地址，
        // 客户端再拼一次就变成 .../chat/completions/chat/completions → 404
        assertEquals(
            "https://open.bigmodel.cn/api/paas/v4",
            normalizeBaseUrl("https://open.bigmodel.cn/api/paas/v4/chat/completions")
        )
        assertEquals(
            "http://192.168.1.5:8000/v1",
            normalizeBaseUrl("http://192.168.1.5:8000/v1/chat/completions")
        )
    }

    @Test
    fun `云服务商的非标准路径不被篡改`() {
        // 百炼、智谱的路径都不是 /v1，不能自作主张补 /v1
        assertEquals(
            "https://dashscope.aliyuncs.com/compatible-mode/v1",
            normalizeBaseUrl("https://dashscope.aliyuncs.com/compatible-mode/v1")
        )
        assertEquals(
            "https://open.bigmodel.cn/api/paas/v4",
            normalizeBaseUrl("https://open.bigmodel.cn/api/paas/v4")
        )
    }

    @Test
    fun `空串与纯空白安全返回`() {
        assertEquals("", normalizeBaseUrl(""))
        assertEquals("", normalizeBaseUrl("   "))
    }

    // ── 桥接模式：免 Key 的兜底 ────────────────────────────────────

    @Test
    fun `桥接模式即使地址是公网域名也免 Key`() {
        // 内网穿透场景：地址是 https 公网域名，但依然是桥接，不该要 Key
        assertEquals(
            LOCAL_BRIDGE_PLACEHOLDER_KEY,
            effectiveApiKey("https://abc.ngrok-free.app/v1", null, bridgeMode = true)
        )
    }

    @Test
    fun `非桥接模式的公网地址仍然要求 Key`() {
        assertNull(effectiveApiKey("https://abc.ngrok-free.app/v1", null, bridgeMode = false))
    }

    @Test
    fun `用户填了 Key 时永远优先`() {
        assertEquals(
            "sk-real",
            effectiveApiKey("https://abc.ngrok-free.app/v1", "sk-real", bridgeMode = true)
        )
    }
}
