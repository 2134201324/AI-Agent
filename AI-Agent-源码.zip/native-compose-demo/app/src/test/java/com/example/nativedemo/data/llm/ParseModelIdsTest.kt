package com.example.nativedemo.data.llm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * parseModelIds 的容错行为测试。
 *
 * 覆盖三种常见响应形态与各种脏数据 —— 扫描与「获取模型清单」
 * 两条链路都靠「空列表 = 不是模型端点」做判断，解析错一点就会误判。
 */
class ParseModelIdsTest {

    @Test
    fun `标准 OpenAI 形态取 data 数组的 id`() {
        val raw = """
            {"object":"list","data":[
              {"id":"gpt-4o","object":"model","owned_by":"openai"},
              {"id":"gpt-4o-mini","object":"model","owned_by":"openai"}
            ]}
        """.trimIndent()
        assertEquals(listOf("gpt-4o", "gpt-4o-mini"), parseModelIds(raw))
    }

    @Test
    fun `models 包裹形态也认`() {
        val raw = """{"models":[{"id":"qwen-plus"},{"id":"qwen-turbo"}]}"""
        assertEquals(listOf("qwen-plus", "qwen-turbo"), parseModelIds(raw))
    }

    @Test
    fun `models 为裸字符串数组也认`() {
        val raw = """{"models":["deepseek-chat","deepseek-reasoner"]}"""
        assertEquals(listOf("deepseek-chat", "deepseek-reasoner"), parseModelIds(raw))
    }

    @Test
    fun `顶层就是裸数组也认`() {
        val raw = """[{"id":"a"},{"id":"b"}]"""
        assertEquals(listOf("a", "b"), parseModelIds(raw))
    }

    @Test
    fun `顶层字符串数组也认`() {
        val raw = """["m1","m2"]"""
        assertEquals(listOf("m1", "m2"), parseModelIds(raw))
    }

    @Test
    fun `空 id 与重复 id 被清理`() {
        val raw = """{"data":[{"id":"x"},{"id":""},{"id":"x"},{"id":"y"}]}"""
        assertEquals(listOf("x", "y"), parseModelIds(raw))
    }

    @Test
    fun `脏数据一律返回空而不是抛异常`() {
        assertTrue(parseModelIds("").isEmpty())
        assertTrue(parseModelIds("   ").isEmpty())
        assertTrue(parseModelIds("not json at all").isEmpty())
        assertTrue(parseModelIds("<html><body>404</body></html>").isEmpty())
        // 是 JSON 但不是模型清单形态（例如聊天响应）
        assertTrue(parseModelIds("""{"choices":[{"message":{"content":"hi"}}]}""").isEmpty())
        assertTrue(parseModelIds("""{"data":"not-an-array"}""").isEmpty())
        assertTrue(parseModelIds("""{"data":[1,2,3]}""").isEmpty())
        assertTrue(parseModelIds("null").isEmpty())
        assertTrue(parseModelIds("42").isEmpty())
    }

    @Test
    fun `DSH 一类桥接的典型响应`() {
        // 桥接工具常把自己代理的模型直接列出来
        val raw = """
            {"object":"list","data":[
              {"id":"deepseek-chat","object":"model","owned_by":"deepseek"},
              {"id":"deepseek-reasoner","object":"model","owned_by":"deepseek"}
            ]}
        """.trimIndent()
        assertEquals(listOf("deepseek-chat", "deepseek-reasoner"), parseModelIds(raw))
    }
}
