package com.example.nativedemo.ui.theme

import com.example.nativedemo.data.settings.BackdropStats
import com.example.nativedemo.data.settings.BackdropStatsCodec
import com.example.nativedemo.data.settings.ColorSlot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 「智能图文适配」的纯 JVM 测试。
 *
 * 这个功能是「文字压在任意图片上都要可读」的最后防线，推导错了我
 * 用户毫无感知地收获一团糊字的界面 —— 所以把对比度约束钉死：
 * 遍历整个亮度 × 繁忙度空间，每一档文字都必须满足最低对比度。
 */
class SmartTextTest {

    @Test
    fun `white is brightest black is darkest`() {
        assertEquals(1f, relativeLuminance(1f, 1f, 1f), 1e-4f)
        assertEquals(0f, relativeLuminance(0f, 0f, 0f), 1e-4f)
        // 中灰的线性亮度约 0.216（sRGB 50%）
        assertEquals(0.216f, relativeLuminance(0.5f, 0.5f, 0.5f), 0.01f)
    }

    @Test
    fun `contrast white black is 21`() {
        assertEquals(21f, contrastRatio(1f, 0f), 0.01f)
        assertEquals(1f, contrastRatio(0.3f, 0.3f), 1e-6f)
    }

    @Test
    fun `gray argb is opaque neutral and monotonic`() {
        assertEquals(0xFF000000L, grayArgb(0f))
        assertEquals(0xFFFFFFFFL, grayArgb(1f))
        assertTrue(grayArgb(0.5f) > grayArgb(0.2f))
        assertTrue(grayArgb(0.2f) > grayArgb(0f))
        // 中性灰：三个通道相等
        val v = grayArgb(0.5f)
        assertEquals((v shr 16) and 0xFF, (v shr 8) and 0xFF)
        assertEquals((v shr 8) and 0xFF, v and 0xFF)
        assertEquals(0xFFL, (v shr 24) and 0xFF)
    }

    @Test
    fun `polarity follows background darkness`() {
        assertTrue(smartTextLevels(BackdropStats(0.02f, 0.3f)).lightText)
        assertTrue(smartTextLevels(BackdropStats(0.15f, 0.3f)).lightText)
        assertTrue(!smartTextLevels(BackdropStats(0.60f, 0.3f)).lightText)
        assertTrue(!smartTextLevels(BackdropStats(0.95f, 0.3f)).lightText)
    }

    @Test
    fun `every level stays readable across the whole luminance range`() {
        for (i in 0..40) {
            val luminance = i / 40f
            for (busyness in floatArrayOf(0f, 0.5f, 1f)) {
                val stats = BackdropStats(luminance, busyness)
                val levels = smartTextLevels(stats)
                val bg = if (levels.lightText) {
                    luminance * (1f - levels.scrimAlpha)
                } else {
                    luminance * (1f - levels.scrimAlpha) + levels.scrimAlpha
                }

                val fg = contrastRatio(levels.fg, bg)
                val muted = contrastRatio(levels.muted, bg)
                val faint = contrastRatio(levels.faint, bg)

                assertTrue("正文太暗 lum=$luminance busy=$busyness ratio=$fg", fg >= 3.5f)
                assertTrue("次要太暗 lum=$luminance busy=$busyness ratio=$muted", muted >= 2.8f)
                assertTrue("备注太暗 lum=$luminance busy=$busyness ratio=$faint", faint >= 2.2f)

                // 三档必须保持「正文 > 次要 > 备注」的强弱次序
                if (levels.lightText) {
                    assertTrue(levels.fg > levels.muted && levels.muted > levels.faint)
                } else {
                    assertTrue(levels.fg < levels.muted && levels.muted < levels.faint)
                }

                // 薄纱强度有界
                assertTrue(levels.scrimAlpha in 0f..0.40f)
            }
        }
    }

    @Test
    fun `extreme backgrounds get high contrast`() {
        // 纯黑照片配浅色文字：正文对比度应该远超 AA
        val dark = smartTextLevels(BackdropStats(0.01f, 0.1f))
        val darkBg = 0.01f * (1f - dark.scrimAlpha)
        assertTrue(contrastRatio(dark.fg, darkBg) >= 7f)
        // 明亮照片配深色文字
        val light = smartTextLevels(BackdropStats(0.95f, 0.1f))
        val lightBg = 0.95f * (1f - light.scrimAlpha) + light.scrimAlpha
        assertTrue(contrastRatio(light.fg, lightBg) >= 7f)
    }

    @Test
    fun `scrim thickens on busy mid tone backdrops`() {
        val flat = smartScrimAlpha(BackdropStats(0.24f, 0f), lightText = true)
        val busy = smartScrimAlpha(BackdropStats(0.24f, 1f), lightText = true)
        val extreme = smartScrimAlpha(BackdropStats(0.02f, 0f), lightText = true)
        assertTrue(busy > flat)
        assertTrue(flat > extreme)
        // 白纱收敛到 70%，避免洗白画面
        val whiteVeil = smartScrimAlpha(BackdropStats(0.24f, 1f), lightText = false)
        assertTrue(whiteVeil < busy)
    }

    @Test
    fun `scrim color opposes text polarity`() {
        val dark = smartScrim(BackdropStats(0.05f, 0.5f))
        assertEquals(0f, dark.red, 1e-3f)
        assertEquals(0f, dark.green, 1e-3f)
        assertEquals(0f, dark.blue, 1e-3f)

        val light = smartScrim(BackdropStats(0.85f, 0.5f))
        assertEquals(1f, light.red, 1e-3f)
        assertEquals(1f, light.green, 1e-3f)
        assertEquals(1f, light.blue, 1e-3f)
    }

    @Test
    fun `flat pixels analyze to zero busyness`() {
        val pixels = IntArray(32 * 32) { 0xFF203040.toInt() }
        val stats = analyzeBackdropPixels(pixels, 32, 32)
        assertEquals(0f, stats.busyness, 1e-6f)
        assertTrue(stats.luminance < 0.05f)
    }

    @Test
    fun `noisy pixels analyze to high busyness`() {
        // 黑白竖条纹：水平相邻全不同、垂直相邻全相同，平均差约 0.5 → 繁忙度封顶
        val pixels = IntArray(32 * 32) { if (it % 2 == 0) 0xFF000000.toInt() else 0xFFFFFFFF.toInt() }
        val stats = analyzeBackdropPixels(pixels, 32, 32)
        assertTrue(stats.busyness > 0.8f)
        // 黑白对半的平均亮度约为 0.5
        assertTrue(stats.luminance > 0.45f && stats.luminance < 0.55f)
    }

    @Test
    fun `busyness is clamped and luminance tracks brightness`() {
        val black = IntArray(16 * 16) { 0xFF000000.toInt() }
        val white = IntArray(16 * 16) { 0xFFFFFFFF.toInt() }
        assertEquals(0f, analyzeBackdropPixels(black, 16, 16).luminance, 1e-6f)
        assertEquals(1f, analyzeBackdropPixels(white, 16, 16).luminance, 1e-6f)

        // 非法尺寸不给结论也不炸
        val stats = analyzeBackdropPixels(IntArray(10), 0, 0)
        assertEquals(BackdropStats.default, stats)
    }

    @Test
    fun `stats codec round trips`() {
        val stats = BackdropStats(luminance = 0.42f, busyness = 0.77f)
        assertEquals(stats, BackdropStatsCodec.decode(BackdropStatsCodec.encode(stats)))
        assertEquals(null, BackdropStatsCodec.decode(null))
        assertEquals(null, BackdropStatsCodec.decode(""))
        assertEquals(null, BackdropStatsCodec.decode("garbage"))
        assertEquals(null, BackdropStatsCodec.decode("0.5"))
    }

    @Test
    fun `smart overrides only cover the three text slots`() {
        val map = smartTextOverrides(BackdropStats(0.1f, 0.3f))
        assertEquals(
            setOf(ColorSlot.TEXT, ColorSlot.MUTED, ColorSlot.FAINT),
            map.keys
        )
        // 三个值互不相同（否则三档没有意义）
        assertEquals(3, map.values.toSet().size)
    }

    @Test
    fun `labels describe the backdrop`() {
        assertEquals("很暗", BackdropStats(0.05f, 0f).brightnessLabel())
        assertEquals("偏亮", BackdropStats(0.65f, 0f).brightnessLabel())
        assertEquals("简洁", BackdropStats(0.5f, 0.1f).busynessLabel())
        assertEquals("丰富", BackdropStats(0.5f, 0.9f).busynessLabel())
    }
}
