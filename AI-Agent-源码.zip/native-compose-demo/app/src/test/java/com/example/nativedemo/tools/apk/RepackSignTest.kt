package com.example.nativedemo.tools.apk

import com.android.apksig.ApkSigner
import com.android.apksig.ApkVerifier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * 「改包」链路的端到端测试：**自签证书 → 重建 ZIP → apksig 签名 → 验证通过**。
 *
 * 这四步任何一步出错，产出都是一个装不上的包，所以必须整链验证而不是分段断言。
 * 尤其 ZIP 重建：apksig 对包结构有严格要求（中央目录、偏移、对齐都要正确），
 * 它能签成功并通过验证，等于反过来证明了 [ApkZipWriter] 拼的字节是合规的。
 */
class RepackSignTest {

    private val sampleBytes: ByteArray by lazy {
        javaClass.classLoader!!.getResourceAsStream("sample.apk")?.use(InputStream::readBytes)
            ?: error("测试样本 sample.apk 缺失")
    }

    private val entries: Map<String, ByteArray> by lazy {
        val result = mutableMapOf<String, ByteArray>()
        ZipInputStream(sampleBytes.inputStream()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                // 原签名文件必须剔除：保留它们会与新的签名冲突
                if (!entry.isDirectory && !entry.name.startsWith("META-INF/")) {
                    result[entry.name] = zip.readBytes()
                }
            }
        }
        result
    }

    private fun KeyMaterial.toSignerConfig() =
        ApkSigner.SignerConfig.Builder(alias, privateKey, listOf(certificate)).build()

    // ── 自签名证书 ─────────────────────────────────────────────────────

    @Test
    fun `生成的证书是合法自签名证书`() {
        val material = SelfSignedCert.create(
            alias = "test",
            password = "pw".toCharArray(),
            subject = "CN=Repack Test, O=AI Agent, C=CN"
        )
        val cert = material.certificate

        assertTrue(cert.subjectX500Principal.name, cert.subjectX500Principal.name.contains("CN=Repack Test"))
        assertTrue(cert.subjectX500Principal.name, cert.subjectX500Principal.name.contains("O=AI Agent"))
        // 自签名：颁发者就是自己
        assertEquals(cert.subjectX500Principal, cert.issuerX500Principal)
        // 用证书里的公钥能验通它自身的签名 —— 证明 DER 拼对了、公私钥配对
        cert.verify(cert.publicKey)
        // 有效期应当还没过期
        assertTrue(cert.notAfter.after(java.util.Date()))
    }

    @Test
    fun `keystore 能保存并读回同一对密钥`() {
        val file = File.createTempFile("test-keystore", ".p12")
        try {
            val password = "secret".toCharArray()
            val created = SelfSignedCert.loadOrCreate(file, "mykey", password, "CN=Persist Test")

            val loaded = SelfSignedCert.load(file, "mykey", password)
            assertNotNull("应当能读回刚写入的密钥", loaded)
            assertEquals(created.certificate, loaded!!.certificate)
            assertEquals(created.privateKey, loaded.privateKey)

            // 口令不对 → 读不出来（而不是抛异常）
            assertNull("口令错误时应当返回 null", SelfSignedCert.load(file, "mykey", "wrong".toCharArray()))
        } finally {
            file.delete()
        }
    }

    // ── 私钥可导出契约（v1.12.0 真机事故的回归防护）────────────────────

    @Test
    fun `生成的私钥必须可导出`() {
        // ⚠️ 这个断言是 v1.12.0 真机事故的回归防护：
        // Android 上 KeyPairGenerator.getInstance("RSA") 会解析到 AndroidKeyStore，
        // 私钥不可导出（getEncoded() 返回 null），导致 save() 必失败、
        // 内置签名密钥从第一次调用就不可用（apk_sign/apk_pack/apk_replace 全挂）。
        // 桌面 JVM 上是 SunRsaSign（可导出），所以单测恒绿 —— 它锁的是契约，
        // 防的是将来有人把 provider 又改回某个不可导出的实现。
        val material = SelfSignedCert.create(
            alias = "exportable",
            password = "pw".toCharArray(),
            subject = "CN=Export Test"
        )
        assertNotNull("私钥必须带 PKCS#8 编码", material.privateKey.encoded)
        assertTrue("私钥编码不能为空", material.privateKey.encoded!!.isNotEmpty())
        assertEquals("RSA", material.privateKey.algorithm)
    }

    @Test
    fun `provider 候选表里绝不能出现 AndroidKeyStore`() {
        val forbidden = setOf("androidkeystore", "androidkeystorebcworkaround")
        SelfSignedCert.EXPORTABLE_KEY_PROVIDERS.forEach { name ->
            assertTrue(
                "provider「$name」的私钥不可导出，绝不允许用于 keystore 持久化",
                name.lowercase() !in forbidden
            )
        }
    }

    @Test
    fun `keystore 写入失败时错误信息可读`() {
        // 传一个「已存在的目录」当 keystore 文件，save() 的 outputStream 必失败
        val dir = File.createTempFile("not-a-file", ".d").apply { delete(); mkdirs() }
        try {
            val failure = runCatching {
                SelfSignedCert.loadOrCreate(dir, "k", "pw".toCharArray(), "CN=X")
            }.exceptionOrNull()
            assertTrue("应当抛 ResParseException，实际：$failure", failure is ResParseException)
            val message = failure?.message.orEmpty()
            assertTrue(
                "错误信息应当点名失败的文件与原因，实际：$message",
                message.contains(dir.name) && message.contains("写入")
            )
        } finally {
            dir.delete()
        }
    }

    // ── 重建 + 签名 ────────────────────────────────────────────────────

    @Test
    fun `重建的包结构正确且 arsc 保持未压缩`() {
        val rebuilt = rebuildSample()

        ZipFile(rebuilt).use { zip ->
            val names = zip.entries().toList().map { it.name }.sorted()
            assertEquals(entries.keys.sorted(), names)

            // resources.arsc 必须 STORED —— 否则 Android 11+ 会拒绝安装
            val arsc = zip.getEntry("resources.arsc")
            assertNotNull(arsc)
            assertEquals(
                "resources.arsc 必须未压缩",
                ZipEntry.STORED,
                arsc!!.method
            )
        }
        rebuilt.delete()
    }

    @Test
    fun `重建并签名后能通过 apksig 校验`() {
        val rebuilt = rebuildSample()
        val signed = File.createTempFile("signed", ".apk")
        try {
            val material = SelfSignedCert.create(
                alias = "repack",
                password = "pw".toCharArray(),
                subject = "CN=Repack Test"
            )

            ApkSigner.Builder(listOf(material.toSignerConfig()))
                .setInputApk(rebuilt)
                .setOutputApk(signed)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .build()
                .sign()

            // apksig 自己的校验器：这是最权威的判据
            val result = ApkVerifier.Builder(signed).build().verify()
            assertTrue(
                "签名后应当校验通过，实际错误：${result.errors}",
                result.isVerified
            )

            // 再用我们自己的签名检测器看一遍 —— 两条独立实现互相印证
            val schemes = ApkSignatureInspector.detectSchemes(signed)
            assertTrue("应当检测到 v1：${schemes.describe()}", schemes.v1)
            assertTrue("应当检测到 v2：${schemes.describe()}", schemes.v2)

            // 签名后的包必须仍然能被标准 ZIP 正常读取（说明中央目录没被写坏）
            ZipFile(signed).use { zip ->
                assertTrue(zip.entries().toList().any { it.name == "resources.arsc" })
                assertTrue(zip.entries().toList().any { it.name.startsWith("META-INF/") })
            }
        } finally {
            rebuilt.delete()
            signed.delete()
        }
    }

    @Test
    fun `校验器能识别出未签名的包`() {
        val rebuilt = rebuildSample()
        try {
            val result = ApkVerifier.Builder(rebuilt).build().verify()
            assertFalse("未签名的包不应通过校验", result.isVerified)
        } finally {
            rebuilt.delete()
        }
    }

    // ── 辅助 ──────────────────────────────────────────────────────────

    /** 用 [ApkZipWriter] 把样本条目重新打包（模拟「替换条目后重建」的动作）。 */
    private fun rebuildSample(data: Map<String, ByteArray> = entries): File {
        val out = File.createTempFile("rebuilt", ".apk")
        ByteArrayOutputStream().use { buffer ->
            val zip = ApkZipWriter(buffer)
            data.forEach { (name, bytes) ->
                zip.putEntry(
                    name = name,
                    data = bytes,
                    compress = shouldCompress(name),
                    alignment = alignmentFor(name)
                )
            }
            zip.finish()
            out.writeBytes(buffer.toByteArray())
        }
        return out
    }

    /** 实测：arsc 不压缩；这里给出与打包工具一致的策略。 */
    private fun shouldCompress(name: String): Boolean =
        name != "resources.arsc" && !name.endsWith(".so")

    private fun alignmentFor(name: String): Int =
        if (name.endsWith(".so")) ApkZipWriter.NATIVE_LIB_ALIGNMENT else ApkZipWriter.DEFAULT_ALIGNMENT

    /** 顺带验证「替换单个条目」这条路：改一张图片再重建。 */
    @Test
    fun `替换条目后重建包内容确实变了`() {
        val replaced = entries.toMutableMap()
        // resources.arsc 换成别的字节，模拟「改了一个文件」
        val fake = ByteArray(64) { 0x42 }
        replaced["resources.arsc"] = fake

        val rebuilt = rebuildSample(replaced)
        try {
            ZipFile(rebuilt).use { zip ->
                val read = zip.getInputStream(zip.getEntry("resources.arsc")).readBytes()
                assertEquals(fake.size, read.size)
                assertTrue(read.all { it == 0x42.toByte() })
            }
        } finally {
            rebuilt.delete()
        }
    }

    /** 顺带验证 ZIP 写入器对「空条目」与「不可压缩内容」的处理。 */
    @Test
    fun `边界内容也能正确写入`() {
        val out = File.createTempFile("edge", ".zip")
        try {
            ByteArrayOutputStream().use { buffer ->
                val zip = ApkZipWriter(buffer)
                zip.putEntry("empty.txt", ByteArray(0), compress = true)
                zip.putEntry("empty-stored.bin", ByteArray(0), compress = false)
                zip.putEntry("random.bin", ByteArray(5000) { (it * 31 % 251).toByte() }, compress = true)
                zip.putEntry("中文条目名.txt", "内容".toByteArray(), compress = true)
                zip.finish()
                out.writeBytes(buffer.toByteArray())
            }

            ZipFile(out).use { zip ->
                assertEquals(4, zip.entries().toList().size)
                assertEquals("内容", zip.getInputStream(zip.getEntry("中文条目名.txt")).readBytes().toString(Charsets.UTF_8))
                assertEquals(0, zip.getEntry("empty.txt").size)
                assertEquals(5000, zip.getEntry("random.bin").size)
                // 内容要能原样读回
                assertEquals(
                    (0 until 5000).map { (it * 31 % 251).toByte() },
                    zip.getInputStream(zip.getEntry("random.bin")).readBytes().toList()
                )
            }
        } finally {
            out.delete()
        }
    }

    /** 顺带确认 JDK 的 ZipOutputStream 也能读我们写的包（跨实现兼容）。 */
    @Test
    fun `用标准库也能解出我们写的包`() {
        val rebuilt = rebuildSample()
        try {
            val out = ByteArrayOutputStream()
            ZipOutputStream(out).use { target ->
                ZipFile(rebuilt).use { source ->
                    source.entries().toList().forEach { entry ->
                        target.putNextEntry(ZipEntry(entry.name))
                        source.getInputStream(entry).use { it.copyTo(target) }
                        target.closeEntry()
                    }
                }
            }
            assertTrue(out.size() > 0)
        } finally {
            rebuilt.delete()
        }
    }
}
