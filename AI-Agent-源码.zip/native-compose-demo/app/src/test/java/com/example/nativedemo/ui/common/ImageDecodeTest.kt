package com.example.nativedemo.ui.common

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.ByteArrayInputStream

/**
 * [readJpegExifOrientation] / [sampleSizeFor] 的纯 JVM 测试。
 *
 * EXIF 字节流按规范手工拼装：SOI + APP1("Exif\0\0" + TIFF) + EOI。
 * 这条路径只在 API 24-27 上兜底使用，但解析错了用户毫无感知
 * （背景横躺），所以必须钉住。
 */
class ImageDecodeTest {

    /** 拼一张带 EXIF Orientation 的最小 JPEG。[little] 为 true 时用 "II" 字节序。 */
    private fun jpegWithExif(little: Boolean, orientation: Int): ByteArray {
        val tiff = ArrayList<Byte>(22)

        fun u16(v: Int) {
            if (little) {
                tiff += (v and 0xFF).toByte()
                tiff += ((v shr 8) and 0xFF).toByte()
            } else {
                tiff += ((v shr 8) and 0xFF).toByte()
                tiff += (v and 0xFF).toByte()
            }
        }

        /** 4 字节值字段里放一个 SHORT：真实值占前 2 字节，后 2 字节补零。 */
        fun u16ValueField(v: Int) {
            u16(v)
            tiff += 0x00.toByte()
            tiff += 0x00.toByte()
        }

        fun u32(v: Int) {
            if (little) {
                tiff += (v and 0xFF).toByte()
                tiff += ((v shr 8) and 0xFF).toByte()
                tiff += ((v shr 16) and 0xFF).toByte()
                tiff += ((v shr 24) and 0xFF).toByte()
            } else {
                tiff += ((v shr 24) and 0xFF).toByte()
                tiff += ((v shr 16) and 0xFF).toByte()
                tiff += ((v shr 8) and 0xFF).toByte()
                tiff += (v and 0xFF).toByte()
            }
        }

        // TIFF 头：字节序标记 + 42 + IFD0 偏移（相对 TIFF 起点，此处为 8）
        u16(if (little) 0x4949 else 0x4D4D)
        u16(0x002A)
        u32(8)
        // IFD0：1 个条目
        u16(1)
        // 条目：tag=0x0112(Orientation), type=SHORT, count=1, value
        u16(0x0112)
        u16(3)
        u32(1)
        u16ValueField(orientation)

        val payload = byteArrayOf(0x45, 0x78, 0x69, 0x66, 0x00, 0x00) + tiff.toByteArray()
        val segmentLength = payload.size + 2

        return byteArrayOf(
            0xFF.toByte(), 0xD8.toByte(),                                   // SOI
            0xFF.toByte(), 0xE1.toByte(),                                   // APP1
            ((segmentLength shr 8) and 0xFF).toByte(),
            (segmentLength and 0xFF).toByte()
        ) + payload + byteArrayOf(0xFF.toByte(), 0xD9.toByte())             // EOI
    }

    @Test
    fun `读取小端 EXIF 方向`() {
        val jpeg = jpegWithExif(little = true, orientation = 6)
        assertEquals(6, readJpegExifOrientation(ByteArrayInputStream(jpeg)))
    }

    @Test
    fun `读取大端 EXIF 方向`() {
        val jpeg = jpegWithExif(little = false, orientation = 8)
        assertEquals(8, readJpegExifOrientation(ByteArrayInputStream(jpeg)))
    }

    @Test
    fun `方向 3 旋转 180 度`() {
        val jpeg = jpegWithExif(little = true, orientation = 3)
        assertEquals(3, readJpegExifOrientation(ByteArrayInputStream(jpeg)))
    }

    @Test
    fun `越界方向值回落为 1`() {
        val jpeg = jpegWithExif(little = true, orientation = 9)
        assertEquals(1, readJpegExifOrientation(ByteArrayInputStream(jpeg)))
    }

    @Test
    fun `没有 APP1 段时返回 1`() {
        // SOI + APP0(长度4) + EOI
        val jpeg = byteArrayOf(
            0xFF.toByte(), 0xD8.toByte(),
            0xFF.toByte(), 0xE0.toByte(), 0x00, 0x04, 0x00, 0x00,
            0xFF.toByte(), 0xD9.toByte()
        )
        assertEquals(1, readJpegExifOrientation(ByteArrayInputStream(jpeg)))
    }

    @Test
    fun `非 JPEG 数据返回 1`() {
        val png = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
        assertEquals(1, readJpegExifOrientation(ByteArrayInputStream(png)))
    }

    @Test
    fun `截断的 EXIF 段返回 1`() {
        // APP1 声称 30 字节，实际只给了 1 字节
        val broken = byteArrayOf(
            0xFF.toByte(), 0xD8.toByte(),
            0xFF.toByte(), 0xE1.toByte(), 0x00, 0x1E, 0x45,
            0xFF.toByte(), 0xD9.toByte()
        )
        assertEquals(1, readJpegExifOrientation(ByteArrayInputStream(broken)))
    }

    @Test
    fun `空流返回 1`() {
        assertEquals(1, readJpegExifOrientation(ByteArrayInputStream(ByteArray(0))))
    }

    @Test
    fun `采样率为 2 的幂且结果不小于目标边长`() {
        // 小图不采样
        assertEquals(1, sampleSizeFor(800, 600, 1600))
        assertEquals(1, sampleSizeFor(1600, 1200, 1600))
        // 3200 -> /2=1600 >= 1600 仍需缩一半，最终 sample=2
        assertEquals(2, sampleSizeFor(3200, 2400, 1600))
        // 10000 -> 5000 -> 2500 -> 1250 < 1600 停：保持"解码后仍不小于目标"
        assertEquals(4, sampleSizeFor(10000, 8000, 1600))
        // maxEdge 非法时按 1 处理，不会死循环
        assertEquals(1, sampleSizeFor(100, 100, 0))
    }
}
