package com.example.nativedemo.data.agent

import com.example.nativedemo.data.llm.ChatMessage
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 编排引擎纯函数测试。
 *
 * 这里钉住的是「权限模型」：主模型的分配只是建议、不可用就回退并明说；
 * 子 AI 横向通道只有 ask_agent 且不能问自己。这些逻辑一旦松了，
 * 用户对 agent 分配的掌控就会被模型悄悄绕过。
 */
class OrchestratorTest {

    private fun sub(id: String, label: String) = ResolvedProfile(
        id = id,
        label = label,
        baseUrl = "https://example.com/v1",
        model = "m-$id",
        apiKey = "k-$id"
    )

    private val subs = listOf(
        sub("a", "阿尔法"),
        sub("b", "贝塔"),
        sub("c", "伽马")
    )

    // ── 计划解析 ──────────────────────────────────────────────────────

    @Test
    fun `plan from tool arguments parses all fields`() {
        val json = """
            {"tasks":[
              {"id":"t1","title":"查资料","instruction":"搜索并总结","assignTo":"a"},
              {"id":"t2","title":"写稿","instruction":"根据资料写一篇文章","assignTo":"贝塔"}
            ]}
        """.trimIndent()
        val tasks = parsePlanFromToolArguments(json)
        assertEquals(2, tasks.size)
        assertEquals("t1", tasks[0].id)
        assertEquals("查资料", tasks[0].title)
        assertEquals("搜索并总结", tasks[0].instruction)
        assertEquals("a", tasks[0].suggestedAgent)
        assertEquals("贝塔", tasks[1].suggestedAgent)
    }

    @Test
    fun `plan tolerates missing id title and drops empty instruction`() {
        val json = """
            {"tasks":[
              {"instruction":"只有指令没有 id 和标题"},
              {"title":"只有标题没有指令"},
              {"id":"t3","instruction":"完整的一项","assignTo":""}
            ]}
        """.trimIndent()
        val tasks = parsePlanFromToolArguments(json)
        assertEquals(2, tasks.size)
        // 缺 id → 按下标补；缺 title → 用指令截断
        assertEquals("t1", tasks[0].id)
        assertTrue(tasks[0].title.isNotBlank())
        assertTrue(tasks[0].title.length <= 24)
        // 空 instruction 的任务被丢弃；空 assignTo 归一为 null
        assertEquals("t3", tasks[1].id)
        assertNull(tasks[1].suggestedAgent)
    }

    @Test
    fun `plan parser rejects garbage`() {
        assertTrue(parsePlanFromToolArguments("").isEmpty())
        assertTrue(parsePlanFromToolArguments("not json").isEmpty())
        assertTrue(parsePlanFromToolArguments("""{"no_tasks":1}""").isEmpty())
        assertTrue(parsePlanFromToolArguments("""{"tasks":"not-array"}""").isEmpty())
    }

    @Test
    fun `plan from text prefers fenced json block`() {
        val text = """
            好的，我来拆分：
            ```json
            {"tasks":[{"id":"t1","title":"甲","instruction":"做甲事"}]}
            ```
            以上计划。
        """.trimIndent()
        val tasks = parsePlanFromText(text)
        assertEquals(1, tasks.size)
        assertEquals("做甲事", tasks[0].instruction)
    }

    @Test
    fun `plan from text falls back to first brace`() {
        val text = """前面是废话 {"tasks":[{"title":"乙","instruction":"做乙事"}]} 后面也是废话"""
        val tasks = parsePlanFromText(text)
        assertEquals(1, tasks.size)
        assertEquals("乙", tasks[0].title)
    }

    @Test
    fun `plan from text returns empty for plain prose`() {
        assertTrue(parsePlanFromText("这个问题我直接回答即可，不需要拆分。").isEmpty())
        assertTrue(parsePlanFromText("").isEmpty())
    }

    @Test
    fun `json object extraction is string aware`() {
        // 花括号出现在字符串里时不能误判配平
        val tricky = """{"tasks":[{"title":"甲","instruction":"输出 {"}]} 后面的废话"""
        assertEquals(
            """{"tasks":[{"title":"甲","instruction":"输出 {"}]}""",
            extractFirstJsonObject(tricky)
        )
        // 引号内的反斜杠转义也不能骗过扫描
        val escaped = """{"a":"say \"hi\""} tail"""
        assertEquals("""{"a":"say \"hi\""}""", extractFirstJsonObject(escaped))
        // 不成对的就是没有
        assertNull(extractFirstJsonObject("没有 json"))
        assertNull(extractFirstJsonObject("""{"a":1"""))
    }

    @Test
    fun `plan from text survives trailing prose after json`() {
        // 模型经典输出：JSON 后面接一段自我解释
        val text = """{"tasks":[{"id":"t1","title":"甲","instruction":"做甲事"}]}
        以上是我的拆分，接下来我会等待子任务结果。"""
        val tasks = parsePlanFromText(text)
        assertEquals(1, tasks.size)
        assertEquals("做甲事", tasks[0].instruction)
    }

    // ── 任务分配（用户权限高于模型建议）────────────────────────────────

    @Test
    fun `no suggestion round-robins across subs`() {
        val first = resolveAssignment(null, subs, taskIndex = 0)
        val second = resolveAssignment(null, subs, taskIndex = 1)
        val third = resolveAssignment(null, subs, taskIndex = 2)
        assertEquals("a", first!!.profile.id)
        assertEquals("b", second!!.profile.id)
        assertEquals("c", third!!.profile.id)
        // 均衡分配不该带回退说明
        assertNull(first.note)
    }

    @Test
    fun `suggestion matches by id then label then containment`() {
        assertEquals("b", resolveAssignment("b", subs, 0)!!.profile.id)
        assertEquals("b", resolveAssignment("贝塔", subs, 0)!!.profile.id)
        assertEquals("c", resolveAssignment("伽", subs, 0)!!.profile.id)
    }

    @Test
    fun `unknown suggestion falls back with a visible note`() {
        val result = resolveAssignment("不存在的模型", subs, taskIndex = 0)
        assertNotNull(result)
        // 用户没配这个档案：回退到轮询位，并把「模型想给谁、实际给了谁」说清楚
        assertEquals("a", result!!.profile.id)
        assertTrue(result.note!!.contains("不存在的模型"))
        assertTrue(result.note!!.contains("阿尔法"))
    }

    @Test
    fun `assignment with empty subs is null`() {
        assertNull(resolveAssignment("a", emptyList(), 0))
        assertNull(resolveAssignment(null, emptyList(), 0))
    }

    // ── 子 AI 横向通道 ────────────────────────────────────────────────

    @Test
    fun `ask target never resolves to self`() {
        assertNull(resolveAskTarget("a", subs, selfId = "a"))
        assertNull(resolveAskTarget("阿尔法", subs, selfId = "a"))
        // 别人可以
        assertEquals("b", resolveAskTarget("b", subs, selfId = "a")!!.id)
        assertEquals("c", resolveAskTarget("伽马", subs, selfId = "a")!!.id)
    }

    @Test
    fun `ask target rejects blank`() {
        assertNull(resolveAskTarget("", subs, selfId = "a"))
        assertNull(resolveAskTarget("   ", subs, selfId = "a"))
    }

    // ── 提示词 ────────────────────────────────────────────────────────

    @Test
    fun `planning prompt switches between tool and json fallback`() {
        val withTools = buildPlanningSystemPrompt(subs[0], subs, jsonFallback = false)
        assertTrue(withTools.contains(DELEGATE_TOOL))
        assertTrue(withTools.contains("阿尔法"))
        assertTrue(withTools.contains("你的分配只是建议"))

        val jsonMode = buildPlanningSystemPrompt(subs[0], subs, jsonFallback = true)
        assertTrue(jsonMode.contains("```json"))
        assertTrue(!jsonMode.contains("调用 $DELEGATE_TOOL"))
    }

    @Test
    fun `sub prompt states the ask budget and excludes self from peers`() {
        val rules = SubAgentRules(maxAsksPerTask = 3)
        val prompt = buildSubSystemPrompt(subs[0], subs, rules)
        assertTrue(prompt.contains("阿尔法"))
        assertTrue(prompt.contains(ASK_TOOL))
        assertTrue(prompt.contains("最多 3 次"))
        // 可询问对象里没有自己
        assertTrue(prompt.contains("贝塔、伽马"))
        assertTrue(!prompt.contains("可询问的对象：阿尔法"))
        // 边界写死：不能指挥其他子 AI
        assertTrue(prompt.contains("不能指挥"))
    }

    @Test
    fun `integration messages carry request results and failure flags`() {
        val results = listOf(
            TaskResult(
                task = PlannedTask("t1", "查资料", "搜索并总结", null),
                agentLabel = "阿尔法",
                output = "这是查到的资料",
                ok = true
            ),
            TaskResult(
                task = PlannedTask("t2", "画图", "生成一张图", null),
                agentLabel = "贝塔",
                output = "（子任务异常：超时）",
                ok = false
            )
        )
        val messages = buildIntegrationMessages(JsonPrimitive("帮我做份周报"), results)
        assertEquals(2, messages.size)
        assertEquals("system", messages[0].role)
        assertEquals("user", messages[1].role)

        val userText = messages[1].textContent.orEmpty()
        assertTrue(userText.contains("帮我做份周报"))
        assertTrue(userText.contains("查资料"))
        assertTrue(userText.contains("这是查到的资料"))
        assertTrue(userText.contains("成功"))
        // 失败项必须显式标出，整合者才不会照搬错误结果
        assertTrue(userText.contains("失败"))
        assertTrue(userText.contains("（子任务异常：超时）"))
        // 指令也带上：整合者需要判断子任务有没有答非所问
        assertTrue(userText.contains("搜索并总结"))
    }

    @Test
    fun `integration messages degrade gracefully for multimodal input`() {
        // 多模态数组没有 asTextOrNull 可读文本时给占位说明，不崩
        val array = JsonArray(
            listOf(
                buildJsonObject {
                    put("type", "image_url")
                }
            )
        )
        val fallback = buildIntegrationMessages(array, emptyList())
        // 数组里没有可读文本时给整合者的必须是占位说明，而不是空串
        assertTrue(fallback[1].textContent!!.contains("多媒体"))
    }

    @Test
    fun `assistant chat message round trip keeps text`() {
        val message = ChatMessage.assistant("最终答复")
        assertEquals("最终答复", message.textContent)
    }
}
