package com.example.nativedemo.tools.builtin

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * run_command 黑名单回归测试。
 *
 * 这些正则挡的是**模型生成**的命令 —— 用户没逐字看过，所以：
 * - 漏拦的代价是全机数据，测试先把已知绕过手法钉死；
 * - 误拦只是让模型换个写法，测试同时保证日常命令不被挡。
 */
class CommandToolBlocklistTest {

    private fun blocked(command: String): Boolean =
        CommandTool.BLOCKED_PATTERNS.any { it.containsMatchIn(command) }

    @Test
    fun `拦截删库级 rm`() {
        assertTrue(blocked("rm -rf /"))
        assertTrue(blocked("rm -rf / "))
        assertTrue(blocked("rm -fr /*"))
        assertTrue(blocked("rm -r /"))
        assertTrue(blocked("rm -rf /; echo done"))
        assertTrue(blocked("rm -rf / && echo ok"))
        assertTrue(blocked("rm -rf /data"))
        assertTrue(blocked("rm -rf /data/data/com.example"))
        assertTrue(blocked("rm -rf /system/app"))
        assertTrue(blocked("rm -rf /sdcard"))
        assertTrue(blocked("rm -rf /sdcard/DCIM"))
        assertTrue(blocked("rm -rf /storage/emulated/0"))
        // --no-preserve-root 之类的长选项不能成为绕过手段
        assertTrue(blocked("rm -rf --no-preserve-root /"))
        assertTrue(blocked("rm -r --force --no-preserve-root /data"))
    }

    @Test
    fun `拦截格式化关机与块设备裸写`() {
        assertTrue(blocked("mkfs.ext4 /dev/block/mmcblk0"))
        assertTrue(blocked("mkfs /dev/block/sda"))
        assertTrue(blocked("reboot"))
        assertTrue(blocked("shutdown -h now"))
        assertTrue(blocked("poweroff"))
        assertTrue(blocked("dd if=/dev/zero of=/dev/block/mmcblk0 bs=1M"))
        assertTrue(blocked("echo x > /dev/block/mmcblk0"))
        assertTrue(blocked("cat a >/dev/block/sda"))
    }

    @Test
    fun `拦截 fork 炸弹与写系统伪文件`() {
        assertTrue(blocked(":(){ :|:& };:"))
        assertTrue(blocked("echo 1 > /proc/sys/kernel/pid_max"))
        assertTrue(blocked("echo x >> /sys/kernel/foo"))
    }

    @Test
    fun `放行日常命令`() {
        assertFalse(blocked("ls -la"))
        assertFalse(blocked("ls -la /sdcard/Download"))
        assertFalse(blocked("getprop ro.product.model"))
        assertFalse(blocked("ps -A"))
        assertFalse(blocked("cat /proc/cpuinfo"))
        assertFalse(blocked("grep -r foo /sdcard/Documents"))
        assertFalse(blocked("find /sdcard -name '*.txt'"))
        assertFalse(blocked("df -h"))
        assertFalse(blocked("echo hello"))
        assertFalse(blocked("tar czf a.tgz dir"))
        assertFalse(blocked("sed -i 's/a/b/' file.txt"))
    }

    @Test
    fun `放行应用私有目录内的删除`() {
        // 递归删自己的 build 目录是正常开发操作
        assertFalse(blocked("rm -rf ./build"))
        assertFalse(blocked("rm -rf build/"))
        assertFalse(blocked("rm -rf files/terminal/tmp"))
        assertFalse(blocked("rm file.txt"))
        assertFalse(blocked("rm -f file.txt"))
        // /data 下的路径一律按敏感处理：宁可误拦，不让模型碰
        assertTrue(blocked("rm -r /data/local/tmp/x"))
    }
}
