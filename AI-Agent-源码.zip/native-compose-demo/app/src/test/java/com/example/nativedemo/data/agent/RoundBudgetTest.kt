package com.example.nativedemo.data.agent

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 工具轮次预算的边界测试。
 *
 * 这条逻辑直接决定「一次逆向任务能做多少步」：旧版本写死 8 轮，用户的真实反馈是
 * 「活儿做到一半被掐断」。所以把额度、自动延长、最终放弃这三个边界的算术锁住。
 */
class RoundBudgetTest {

    @Test
    fun `默认额度内一路放行`() {
        val budget = AgentEngine.DEFAULT_MAX_ROUNDS
        for (round in 1..budget) {
            assertEquals(
                "第 $round 轮应当放行",
                RoundBudgetDecision.Proceed,
                decideRoundBudget(round, budget, extensions = 0)
            )
        }
    }

    @Test
    fun `超出一份额度时自动延长而不是失败`() {
        val budget = 30
        val decision = decideRoundBudget(round = 31, budget = budget, extensions = 0)

        assertTrue("应当是延长而不是放弃", decision is RoundBudgetDecision.Extend)
        decision as RoundBudgetDecision.Extend
        assertEquals(1, decision.extensions)
        assertEquals(60, decision.newLimit)
    }

    @Test
    fun `延长后的额度可以继续用`() {
        val budget = 30
        // 第二次延长的额度内（31..60）都应当放行
        assertEquals(RoundBudgetDecision.Proceed, decideRoundBudget(60, budget, extensions = 1))
        assertEquals(RoundBudgetDecision.Proceed, decideRoundBudget(90, budget, extensions = 2))
    }

    @Test
    fun `用满全部延长次数后才放弃`() {
        val budget = 30
        val maxExtensions = AgentEngine.MAX_ROUND_EXTENSIONS

        // 最后一次延长：61 轮触发第二次延长
        val second = decideRoundBudget(61, budget, extensions = 1)
        assertTrue(second is RoundBudgetDecision.Extend)
        assertEquals(2, (second as RoundBudgetDecision.Extend).extensions)

        // 到了 91 轮、延长次数也已用尽 —— 此时才交回控制权
        val exhausted = decideRoundBudget(91, budget, extensions = maxExtensions)
        assertTrue(exhausted is RoundBudgetDecision.Exhausted)
        assertEquals(90, (exhausted as RoundBudgetDecision.Exhausted).totalRounds)
    }

    @Test
    fun `总可用轮次是额度的三倍`() {
        // 用户视角最重要的一条：默认 30 轮设置下，实际最多能做 90 轮工具调用。
        // 这个数字如果变小，说明延长机制被改坏了。
        val budget = AgentEngine.DEFAULT_MAX_ROUNDS
        val total = (decideRoundBudget(
            round = budget * 10,
            budget = budget,
            extensions = AgentEngine.MAX_ROUND_EXTENSIONS
        ) as RoundBudgetDecision.Exhausted).totalRounds

        assertEquals(budget * 3, total)
    }

    @Test
    fun `额度为 0 或负数时不会把任务直接判死`() {
        // 设置页有下限保护，但历史配置里可能残留脏值 —— 这里必须兜住，
        // 否则用户会看到「一调工具就停」这种完全没法用的状态。
        assertEquals(RoundBudgetDecision.Proceed, decideRoundBudget(1, 0, 0))
        assertEquals(RoundBudgetDecision.Proceed, decideRoundBudget(1, -5, 0))
    }
}
