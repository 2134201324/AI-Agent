package com.example.nativedemo.data.agent

import com.example.nativedemo.data.llm.ChatMessage
import com.example.nativedemo.data.llm.ChatRequest
import com.example.nativedemo.data.llm.LlmClient
import com.example.nativedemo.data.llm.LlmException
import com.example.nativedemo.data.llm.looksLikeRichContentRejected
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * 端到端复现 + 验证：**发过一次图片之后，这个会话为什么就再也用不了了**。
 *
 * 这里用真实 HTTP 往返（MockWebServer 扮演那台只接受字符串 content 的网关），
 * 断言两件事：
 * 1. 带着多模态数组发过去，确实会被拒（复现 bug）；
 * 2. 压平成纯文本后，同一个请求能正常完成，且服务端收到的是字符串 +
 *    图片的可见占位符。
 */
class RichContentFallbackIntegrationTest {

    private lateinit var server: MockWebServer

    /** 截图里那台网关的原话（Zod 校验器输出）。 */
    private val zodRejection =
        """{"success":false,"error":{"issues":[{"code":"invalid_union",""" +
            """"unionErrors":[{"issues":[{"code":"invalid_type","expected":"string",""" +
            """"received":"array","path":["messages",13,"content"],""" +
            """"message":"Expected string, received array"}]}],"name":"ZodError"}]}}"""

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    private fun baseUrl() = server.url("/v1").toString().trimEnd('/')

    private fun okStream() = MockResponse()
        .setResponseCode(200)
        .setHeader("Content-Type", "text/event-stream")
        .setBody(
            buildString {
                append("data: {\"choices\":[{\"index\":0,\"delta\":{\"content\":\"收到\"}}]}\n\n")
                append("data: {\"choices\":[{\"index\":0,\"delta\":{},\"finish_reason\":\"stop\"}]}\n\n")
                append("data: [DONE]\n\n")
            }
        )

    /** 用户「发了一张图 + 一句文字」时，历史里那条消息的真实形态。 */
    private fun richHistory(): List<ChatMessage> = listOf(
        ChatMessage.system("你是助手"),
        ChatMessage(
            role = "user",
            content = JsonArray(
                listOf(
                    buildJsonObject {
                        put("type", "text")
                        put("text", "修改开屏动画图片为这个图片")
                    },
                    buildJsonObject {
                        put("type", "image_url")
                        putJsonObject("image_url") { put("url", "data:image/jpeg;base64,AAAA") }
                    }
                )
            )
        )
    )

    /** 取出服务端实际收到的第 index 条消息的 content。 */
    private fun sentContent(index: Int) = Json
        .parseToJsonElement(server.takeRequest().body.readUtf8())
        .jsonObject["messages"]!!
        .jsonArray[index]
        .jsonObject["content"]!!

    @Test
    fun `带数组 content 的请求会被这类网关拒绝`() = runBlocking {
        server.enqueue(MockResponse().setResponseCode(400).setBody(zodRejection))

        val error = runCatching {
            LlmClient().chatStream(
                baseUrl = baseUrl(),
                apiKey = "x",
                request = ChatRequest(model = "m", messages = richHistory(), stream = true),
                onTextDelta = {}
            )
        }.exceptionOrNull()

        assertNotNull("应当抛错，而不是静默成功", error)
        val bad = error as LlmException.BadRequest

        // 这就是「会话中毒」的入口：引擎必须认得出这条报文，才能自愈
        assertTrue(looksLikeRichContentRejected(bad.serverRaw))

        // 同时确认：真正发出去的 content 是数组 —— 被拒的原因就在这
        assertTrue(sentContent(index = 1) is JsonArray)
    }

    @Test
    fun `压平之后同一个请求可以正常完成`() = runBlocking {
        server.enqueue(okStream())

        val flattened = RequestPayloadGuard
            .prepare(richHistory(), keepLastUserRich = false)
            .messages

        val received = StringBuilder()
        LlmClient().chatStream(
            baseUrl = baseUrl(),
            apiKey = "x",
            request = ChatRequest(model = "m", messages = flattened, stream = true),
            onTextDelta = { received.append(it) }
        )

        assertEquals("收到", received.toString())

        // 服务端这次拿到的是字符串，且图片留下了可见占位（不是凭空消失）
        val content = sentContent(index = 1).jsonPrimitive.content
        assertTrue(content, content.contains("修改开屏动画图片为这个图片"))
        assertTrue(content, content.contains(IMAGE_PLACEHOLDER))
    }
}
