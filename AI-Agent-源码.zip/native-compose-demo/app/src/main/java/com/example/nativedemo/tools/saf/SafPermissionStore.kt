package com.example.nativedemo.tools.saf

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.nativedemo.data.settings.SettingsRepository

data class AuthorizedRoot(
    val uri: Uri,
    val canRead: Boolean,
    val canWrite: Boolean
) {
    /** 展示用名称，取 URI 末段（如 primary:Documents → Documents） */
    val displayName: String
        get() = uri.lastPathSegment
            ?.substringAfterLast(':')
            ?.substringAfterLast('/')
            ?.takeIf { it.isNotBlank() }
            ?: uri.toString()
}

/**
 * SAF 持久化授权的记录与撤销。
 *
 * 注意：持久化授权在卸载 App、清除数据后失效，用户也可随时在系统设置里撤销，
 * 因此每次工具调用都必须动态复核（见 [UriAccessPolicy]）。
 */
class SafPermissionStore(
    private val context: Context,
    private val settings: SettingsRepository
) {

    /** 存储格式：`uri|r` 或 `uri|rw`。URI 字符串本身不含 '|'，可安全用末位分隔。 */
    fun encode(uri: Uri, canWrite: Boolean): String =
        "$uri|r${if (canWrite) "w" else ""}"

    fun decode(entry: String): AuthorizedRoot? {
        val sep = entry.lastIndexOf('|')
        if (sep <= 0) return null
        val uri = runCatching { Uri.parse(entry.substring(0, sep)) }.getOrNull() ?: return null
        val flags = entry.substring(sep + 1)
        return AuthorizedRoot(uri = uri, canRead = flags.contains('r'), canWrite = flags.contains('w'))
    }

    suspend fun currentRoots(): List<AuthorizedRoot> =
        settings.snapshot().authorizedUris.mapNotNull { decode(it) }

    /** 调用 takePersistableUriPermission 并落库。URI 必须来自带持久化标志的系统选择器。 */
    suspend fun persist(uri: Uri, canWrite: Boolean) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
            (if (canWrite) Intent.FLAG_GRANT_WRITE_URI_PERMISSION else 0)
        context.contentResolver.takePersistableUriPermission(uri, flags)
        settings.addAuthorizedUri(encode(uri, canWrite))
    }

    suspend fun release(entry: String) {
        val root = decode(entry) ?: return
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
            (if (root.canWrite) Intent.FLAG_GRANT_WRITE_URI_PERMISSION else 0)
        runCatching {
            context.contentResolver.releasePersistableUriPermission(root.uri, flags)
        }
        settings.removeAuthorizedUri(entry)
    }

    /** 清掉系统已回收的授权记录，避免列表里堆积失效项。 */
    suspend fun pruneInvalid() {
        val persisted = context.contentResolver.persistedUriPermissions
            .map { it.uri.toString() }
            .toSet()
        val alive = settings.snapshot().authorizedUris.filter { entry ->
            val root = decode(entry)
            root != null && root.uri.toString() in persisted
        }.toSet()
        settings.replaceAuthorizedUris(alive)
    }
}
