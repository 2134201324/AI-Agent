package com.example.nativedemo.data.settings

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * 使用平台 Android Keystore 做 AES-256-GCM 加解密。
 *
 * 刻意不使用 androidx.security:security-crypto —— 该库自 1.1.0 起已全量弃用，
 * 官方建议直接使用平台 Keystore。AES/GCM 自 API 23 起可用（本项目 minSdk 24）。
 *
 * 存储格式：Base64( IV(12 bytes) || Ciphertext+Tag )
 *
 * 别名可指定是为了支持**多个 API Key**（多模型编排时每个模型档案各存一把）：
 * 默认别名给「单模型模式」的旧 Key 用，模型档案用 [aliasForProfile] 派生。
 */
class SecureStore {

    private companion object {
        const val TAG = "SecureStore"
        const val KEYSTORE = "AndroidKeyStore"
        const val DEFAULT_ALIAS = "agent_api_key_v1"
        const val PROFILE_ALIAS_PREFIX = "agent_api_key_profile_"
        /** REA 网关访问令牌专用别名（与模型 Key 分开，清除时互不影响） */
        const val REA_TOKEN_ALIAS = "rea_gateway_token_v1"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val IV_LENGTH = 12
        const val TAG_LENGTH_BITS = 128
    }

    /** REA 网关令牌的别名。 */
    fun reaTokenAlias(): String = REA_TOKEN_ALIAS

    /**
     * 模型档案的密钥别名。按档案 id 派生，删档案时一并删密钥。
     *
     * 迁移来的「默认模型」档案（id = [ModelProfile.LEGACY_DEFAULT_ID]）复用旧
     * 默认别名，这样它的密文可以原样搬进档案，不需要重新加密。
     */
    fun aliasForProfile(profileId: String): String =
        if (profileId == ModelProfile.LEGACY_DEFAULT_ID) DEFAULT_ALIAS
        else PROFILE_ALIAS_PREFIX + profileId

    private fun loadOrCreateKey(alias: String): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        (keyStore.getEntry(alias, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    /** 加密失败返回 null（例如设备 Keystore 异常），调用方需处理。 */
    fun encrypt(plain: String, alias: String = DEFAULT_ALIAS): String? = try {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, loadOrCreateKey(alias))
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        val combined = ByteArray(iv.size + encrypted.size)
        System.arraycopy(iv, 0, combined, 0, iv.size)
        System.arraycopy(encrypted, 0, combined, iv.size, encrypted.size)
        Base64.encodeToString(combined, Base64.NO_WRAP)
    } catch (t: Throwable) {
        Log.w(TAG, "加密失败", t)
        null
    }

    /**
     * 解密失败返回 null。常见原因：
     * - 换机恢复（Keystore 中没有对应密钥）→ AEADBadTag / KeyStoreException
     * - 密钥被系统作废 → KeyPermanentlyInvalidatedException
     * 调用方应清空密文并要求用户重新输入。
     */
    fun decrypt(encoded: String, alias: String = DEFAULT_ALIAS): String? = try {
        val combined = Base64.decode(encoded, Base64.NO_WRAP)
        if (combined.size <= IV_LENGTH) {
            null
        } else {
            val iv = combined.copyOfRange(0, IV_LENGTH)
            val payload = combined.copyOfRange(IV_LENGTH, combined.size)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, loadOrCreateKey(alias), GCMParameterSpec(TAG_LENGTH_BITS, iv))
            String(cipher.doFinal(payload), Charsets.UTF_8)
        }
    } catch (t: Throwable) {
        Log.w(TAG, "解密失败（可能是换机恢复或密钥失效）", t)
        null
    }

    fun deleteKey(alias: String = DEFAULT_ALIAS) {
        try {
            KeyStore.getInstance(KEYSTORE).apply { load(null) }.deleteEntry(alias)
        } catch (t: Throwable) {
            Log.w(TAG, "删除密钥失败", t)
        }
    }
}
