package com.example.nativedemo.data.rea

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * REA 网关的 MCP over HTTP 客户端。
 *
 * 对应网关 `POST /mcp` 的 JSON-RPC 2.0 协议。网关侧已做：
 * - 单会话串行化（REA 是单会话进程，并发调用会互相踩状态）
 * - 输出截断（>180KB 的响应对 content.text 做裁剪）
 *
 * 客户端侧仍然保留两道自己的防线：
 * 1. 读超时放到 5 分钟 —— Ghidra headless 首次分析 .so 可能要一两分钟；
 * 2. 结果二次截断（[MAX_TEXT_CHARS]）—— 170 个工具的返回体量差异极大，
 *    不设上限会把模型上下文打爆。
 *
 * 鉴权头同时发 `Authorization: Bearer` 与 `X-Auth-Token`：
 * 公网反向代理会剥掉前者（实测），本机直连两种都认，双发保证两条路径都能过。
 */
class ReaClient(
    private val baseUrl: String,
    private val token: String
) {

    companion object {
        const val PROTOCOL_VERSION = "2025-03-26"

        /** 工具结果文本上限。超过则保留头尾、中间标注省略——清单类信息头部最有价值。 */
        const val MAX_TEXT_CHARS = 40_000

        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
        private val OCTET_MEDIA = "application/octet-stream".toMediaType()
    }

    private val json: Json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        isLenient = true
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private var nextId = 1

    /** MCP 握手。返回服务端信息；失败抛 [ReaException]。 */
    suspend fun initialize(): McpServerInfo = rpc("initialize") {
        put("protocolVersion", PROTOCOL_VERSION)
        putJsonObject("capabilities") {}
        putJsonObject("clientInfo") {
            put("name", "native-agent")
            put("version", "1.0.0")
        }
    }.let { result ->
        result?.serverInfo ?: McpServerInfo()
    }

    /** 拉取工具清单（initialize 之后调用）。 */
    suspend fun listTools(): List<McpToolDescriptor> {
        val result = rpc("tools/list") { put("cursor", "") } ?: return emptyList()
        return result.tools ?: emptyList()
    }

    /**
     * 调用一个 REA 工具。
     *
     * @param name REA 工具名（如 `binary_overview`、`procedure_pseudo_code`）
     * @param arguments 工具参数，原样透传（REA 用 Zod 校验，字段名必须与 schema 一致）
     */
    suspend fun callTool(name: String, arguments: JsonObject): ReaToolResult {
        val result = rpc("tools/call") {
            put("name", name)
            put("arguments", arguments)
        }
        // mapNotNull 拿非空 text，避免对跨 lambda 的可空属性做智能转换
        val text = result?.content
            ?.mapNotNull { item ->
                item.text?.takeIf { item.type == "text" && it.isNotBlank() }
            }
            ?.joinToString("\n")
            ?: ""
        val isError = result?.isError == true
        return ReaToolResult(text = clip(text), isError = isError)
    }

    /**
     * 上传文件到网关（POST /upload）。返回服务器上的落盘路径，
     * 该路径可直接作为 REA 工具的 `path` 参数。
     */
    suspend fun upload(bytes: ByteArray, filename: String): String =
        upload(bytes.size.toLong(), filename) { _, sink -> sink.write(bytes) }

    /**
     * 流式上传：APK 动辄几十 MB，整文件读进 ByteArray 在低端机上有 OOM 风险，
     * 因此按需从输入流分块写（OkHttp 会以 chunked 编码发送，网关按长度上限保护）。
     *
     * @param length 内容长度；-1 表示未知（用 chunked）
     */
    suspend fun upload(length: Long, filename: String, writeBody: (Long, okio.BufferedSink) -> Unit): String =
        withContext(Dispatchers.IO) {
            val body = object : RequestBody() {
                override fun contentType() = OCTET_MEDIA
                override fun contentLength() = length
                override fun writeTo(sink: okio.BufferedSink) {
                    writeBody(contentLength(), sink)
                }
            }
            val request = Request.Builder()
                .url(endpoint("/upload"))
                .header("X-Auth-Token", token)
                .header("Authorization", "Bearer $token")
                .header("X-Filename", filename)
                .post(body)
                .build()
            client.newCall(request).execute().use { response ->
                val respBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw ReaException("上传失败（HTTP ${response.code}）：${respBody.take(300)}")
                }
                val parsed = runCatching {
                    json.decodeFromString(UploadResponse.serializer(), respBody)
                }.getOrNull()
                parsed?.path ?: throw ReaException("上传响应缺少 path 字段：${respBody.take(200)}")
            }
        }

    // ── 内部 ────────────────────────────────────────────────────────────

    /** 规范化基地址：去掉末尾斜杠，拼上路径。 */
    private fun endpoint(path: String): String =
        baseUrl.trim().trimEnd('/') + path

    /** 发一个 JSON-RPC 请求并解出 result；任何失败都转成 [ReaException]。 */
    private suspend fun rpc(
        method: String,
        params: JsonObjectBuilder.() -> Unit
    ): McpResult? = withContext(Dispatchers.IO) {
        val payload = buildJsonObject {
            put("jsonrpc", "2.0")
            put("id", nextId++)
            put("method", method)
            put("params", buildJsonObject(params))
        }
        val request = Request.Builder()
            .url(endpoint("/mcp"))
            .header("X-Auth-Token", token)
            .header("Authorization", "Bearer $token")
            .post(json.encodeToString(JsonObject.serializer(), payload).toRequestBody(JSON_MEDIA))
            .build()
        val body = try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw ReaException("网关返回 HTTP ${response.code}")
                }
                response.body?.string().orEmpty()
            }
        } catch (e: IOException) {
            throw ReaException("网络错误：${e.message ?: e::class.java.simpleName}")
        }
        val parsed = try {
            json.decodeFromString(McpResponse.serializer(), body)
        } catch (e: Exception) {
            throw ReaException("响应解析失败：${e.message ?: body.take(200)}")
        }
        parsed.error?.let { throw ReaException("网关错误 ${it.code}：${it.message}") }
        parsed.result
    }

    /** 头尾保留式截断：清单/错误信息头部最有价值，尾部往往带结论。 */
    internal fun clip(text: String): String {
        if (text.length <= MAX_TEXT_CHARS) return text
        val head = (MAX_TEXT_CHARS * 0.7).toInt()
        val tail = MAX_TEXT_CHARS - head
        return buildString {
            append(text.take(head))
            append("\n…［本地截断］原文 ${text.length} 字符，中间省略 ${text.length - MAX_TEXT_CHARS} 字符。")
            append("需要完整数据时可缩小查询范围（指定单个函数/单段地址）后重试。\n")
            append(text.takeLast(tail))
        }
    }
}

/** [ReaClient.callTool] 的返回。 */
data class ReaToolResult(
    val text: String,
    val isError: Boolean
)

@kotlinx.serialization.Serializable
data class UploadResponse(
    val ok: Boolean = false,
    val path: String = "",
    val bytes: Long = 0
)

/** REA 网关调用失败（网络 / 协议 / 服务端错误）。消息已按「可直接展示给模型」的标准组织。 */
class ReaException(message: String) : Exception(message)

/** buildJsonObject 的 lambda 别名，少写一个 import。 */
private typealias JsonObjectBuilder = kotlinx.serialization.json.JsonObjectBuilder
