package com.example.nativedemo.data.rea

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

/**
 * MCP（Model Context Protocol）JSON-RPC 2.0 over HTTP 的数据模型。
 *
 * 网关把 REA 的 stdio MCP server 包装成 HTTP 服务（POST /mcp），
 * 这里只实现客户端必需的最小子集：initialize / tools/list / tools/call。
 */

/** JSON-RPC 响应：result 与 error 二选一。 */
@Serializable
data class McpResponse(
    val jsonrpc: String = "2.0",
    val id: Int? = null,
    val result: McpResult? = null,
    val error: McpError? = null
)

@Serializable
data class McpError(
    val code: Int = 0,
    val message: String = ""
)

/**
 * MCP 结果载荷。不同 method 的 result 形状不同，用可空字段 + ignoreUnknownKeys 兼容：
 * - initialize → protocolVersion / serverInfo
 * - tools/list  → tools
 * - tools/call  → content / isError
 */
@Serializable
data class McpResult(
    val protocolVersion: String? = null,
    val serverInfo: McpServerInfo? = null,
    val tools: List<McpToolDescriptor>? = null,
    val content: List<McpContentItem>? = null,
    val isError: Boolean? = null
)

@Serializable
data class McpServerInfo(
    val name: String = "",
    val version: String = ""
)

@Serializable
data class McpToolDescriptor(
    val name: String,
    val description: String = "",
    /** 原始 JSON Schema，原样透传给模型（OpenAI tools 的 parameters 字段同构）。 */
    val inputSchema: JsonObject? = null
)

@Serializable
data class McpContentItem(
    val type: String = "text",
    val text: String? = null,
    @SerialName("mimeType") val mimeType: String? = null,
    val data: String? = null
)
