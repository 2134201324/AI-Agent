package com.example.nativedemo.tools.rea

import com.example.nativedemo.data.rea.ReaClient
import com.example.nativedemo.data.rea.ReaException
import com.example.nativedemo.data.rea.ReaGateway
import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.bool
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import com.example.nativedemo.tools.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * REA 远程逆向引擎工具集。
 *
 * 架构：App 上配置的 AI → 本工具集 → REA 网关（HTTP MCP）→ 服务器上的
 * Ghidra 12.1.4 / Apktool 等桌面级引擎。手机上只做"发起与呈现"，
 * 重分析全在服务器沙盒里跑。
 *
 * 工具分三类：
 * 1. **精选平铺**（rea_open / rea_overview / rea_decompile …）—— 把 REA 170 个
 *    工具里最高频的十几个包成固定参数的工具，模型按名字就能调用，不用记 schema；
 * 2. **rea_run 通用兜底** —— 传 REA 工具名 + 参数 JSON，覆盖其余全部能力；
 * 3. **rea_tools 目录查询** —— 列出 REA 侧可用工具，配合 rea_run 使用；
 * 4. **rea_upload 上传** —— 把手机已授权目录里的文件送到服务器，拿到服务器路径
 *    （后续所有 REA 工具都吃这个路径）。
 *
 * 典型链路：rea_upload（手机文件 → 服务器路径）→ rea_open（Ghidra 分析）→
 * rea_overview（段/函数/字符串统计）→ rea_search_functions / rea_decompile …
 */

/** 所有 REA 工具的公共外壳：取客户端 → 组参数 → 调用 → 整理结果。 */
abstract class ReaBridgeTool(
    protected val gateway: ReaGateway
) : Tool {

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val client = gateway.client()
            ?: return ToolResult.failure(gateway.missingReason)
        val reaArgs = try {
            buildReaArgs(args)
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }
        return callRea(client, reaTool, reaArgs)
    }

    /** 对应的 REA 工具名。 */
    protected abstract val reaTool: String

    /** 把模型给的参数映射为 REA 工具的参数（字段名必须与 REA schema 一致）。 */
    protected abstract fun buildReaArgs(args: JsonObject): JsonObject

    protected suspend fun callRea(
        client: ReaClient,
        reaTool: String,
        reaArgs: JsonObject
    ): ToolResult = try {
        val result = client.callTool(reaTool, reaArgs)
        if (result.isError) {
            ToolResult.failure("REA 引擎返回错误：${result.text.ifBlank { "（无详细信息）" }}")
        } else {
            ToolResult.success(result.text.ifBlank { "（引擎无返回内容）" })
        }
    } catch (e: ReaException) {
        ToolResult.failure("REA 网关调用失败：${e.message}")
    } catch (e: Exception) {
        ToolResult.failure("REA 调用异常：${e.message ?: e::class.java.simpleName}")
    }
}

// ── 精选平铺工具 ────────────────────────────────────────────────────────

/** 打开服务器上的二进制文件（ELF/Mach-O/PE/APK/IPA…），之后所有分析类工具都作用于它。 */
class ReaOpenTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "open_binary"
    override val spec = ToolSpec(
        name = "rea_open",
        description = "在服务器上打开一个二进制文件并完成 Ghidra 自动分析，返回格式/架构/哈希等身份信息。" +
            "这是所有 native 分析的第一步；APK 请先确认目标 so 已解包（可用 rea_extract）。" +
            "path 用 rea_upload 返回的服务器路径。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {
            string("path", "服务器上的文件绝对路径（rea_upload 的返回值）")
        }
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {
        put("path", args.requireStr("path"))
    }
}

/** 提取当前打开的归档（APK/IPA/ZIP），把里面的文件释放到服务器目录供分析。 */
class ReaExtractTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "extract_artifact"
    override val spec = ToolSpec(
        name = "rea_extract",
        description = "把当前打开的归档文件（APK/IPA/ZIP）解包到服务器目录，返回释放出的文件清单。" +
            "典型用法：rea_upload 上传 APK → rea_open 打开 → rea_extract 解包 → 对 lib/arm64-v8a/*.so 再次 rea_open。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {}
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {}
}

/** 当前二进制的总体统计：段、函数、字符串数量与内存布局。 */
class ReaOverviewTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "binary_overview"
    override val spec = ToolSpec(
        name = "rea_overview",
        description = "返回当前打开二进制的元数据、全部内存段及其长度、函数与字符串的统计数量。" +
            "分析任何文件后先调它建立整体认识，再按名字去查具体函数。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {}
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {}
}

/** 列出当前二进制的全部函数名。 */
class ReaFunctionsTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "list_procedures"
    override val spec = ToolSpec(
        name = "rea_functions",
        description = "列出当前二进制里已识别的全部函数（含导入导出符号）。" +
            "函数很多时输出会很长，优先用 rea_search_functions 按关键词定位。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {}
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {}
}

/** 按名字搜索函数。 */
class ReaSearchFunctionsTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "search_procedures"
    override val spec = ToolSpec(
        name = "rea_search_functions",
        description = "按函数名搜索（默认字面匹配，mode=regex 时按正则）。" +
            "找 JNI 函数、加密入口、网络请求处等都用它，例如 pattern=JNI_OnLoad。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {
            string("pattern", "要搜索的函数名关键词或正则")
            string(
                "mode", "匹配模式：literal（默认）或 regex",
                required = false, enumValues = listOf("literal", "regex")
            )
        }
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {
        put("pattern", args.requireStr("pattern"))
        args.str("mode")?.let { put("mode", it) }
    }
}

/** 反编译函数为伪 C 代码。 */
class ReaDecompileTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "procedure_pseudo_code"
    override val spec = ToolSpec(
        name = "rea_decompile",
        description = "把指定函数反编译为伪 C 代码（Ghidra 反编译器输出，非原始源码）。" +
            "外部函数与无函数体的目标返回空。函数名先用 rea_search_functions 确认。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {
            string("procedure", "函数名（符号）或规范化地址，如 JNI_OnLoad")
        }
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {
        put("procedure", args.requireStr("procedure"))
    }
}

/** 反汇编函数。 */
class ReaDisassembleTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "procedure_assembly"
    override val spec = ToolSpec(
        name = "rea_disassemble",
        description = "把指定函数反汇编为指令序列。需要指令级精确度（寄存器、调用约定）时用它，" +
            "普通逻辑理解优先用 rea_decompile。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {
            string("procedure", "函数名或规范化地址")
        }
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {
        put("procedure", args.requireStr("procedure"))
    }
}

/** 函数元信息（地址、大小、签名、调用约定）。 */
class ReaFunctionInfoTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "procedure_info"
    override val spec = ToolSpec(
        name = "rea_function_info",
        description = "返回函数的元信息：入口地址、体范围、参数与调用约定等。轻量，适合先摸底再决定是否反编译。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {
            string("procedure", "函数名或规范化地址")
        }
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {
        put("procedure", args.requireStr("procedure"))
    }
}

/** 谁调用了这个函数（交叉引用，向上）。 */
class ReaCallersTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "procedure_callers"
    override val spec = ToolSpec(
        name = "rea_callers",
        description = "列出调用了指定函数的全部位置（调用方函数与调用点地址）。" +
            "追根溯源用：想知道某函数被谁触发就看它。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {
            string("procedure", "函数名或规范化地址")
        }
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {
        put("procedure", args.requireStr("procedure"))
    }
}

/** 这个函数调用了谁（向下）。 */
class ReaCalleesTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "procedure_callees"
    override val spec = ToolSpec(
        name = "rea_callees",
        description = "列出指定函数内部调用的全部函数。绘制调用链、判断函数职责时用它。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {
            string("procedure", "函数名或规范化地址")
        }
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {
        put("procedure", args.requireStr("procedure"))
    }
}

/** 字符串清单。 */
class ReaStringsTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "list_strings"
    override val spec = ToolSpec(
        name = "rea_strings",
        description = "列出当前二进制里定义的全部字符串（地址 + 内容）。" +
            "找 URL、密钥提示、错误文案、包名碎片时最高效的一招。输出较长，可用 rea_search_strings 过滤。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {}
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {}
}

/** 搜索字符串。 */
class ReaSearchStringsTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "search_strings"
    override val spec = ToolSpec(
        name = "rea_search_strings",
        description = "按内容搜索字符串（默认字面匹配，mode=regex 时按正则）。" +
            "例如 pattern=https 找接口域名，pattern=key 找密钥线索。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {
            string("pattern", "要搜索的字符串关键词或正则")
            string(
                "mode", "匹配模式：literal（默认）或 regex",
                required = false, enumValues = listOf("literal", "regex")
            )
        }
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {
        put("pattern", args.requireStr("pattern"))
        args.str("mode")?.let { put("mode", it) }
    }
}

/** APK 资源解码：清单、权限、字符串资源。 */
class ReaAndroidResourcesTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "decode_android_resources"
    override val spec = ToolSpec(
        name = "rea_android_resources",
        description = "解码 APK 的二进制资源：AndroidManifest（包名/版本/权限/组件，明文输出）、" +
            "默认 strings.xml 资源表。比 apk_manifest 更适合看资源层细节；两者可互相印证。" +
            "path 用 rea_upload 返回的服务器路径（APK 无需先 open）。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {
            string("path", "服务器上的 APK 绝对路径")
            boolean("include_strings", "是否附带默认 strings.xml 资源条目", required = false)
        }
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {
        put("path", args.requireStr("path"))
        if (args.bool("include_strings")) put("include_strings", true)
    }
}

/** APK 包结构检视。 */
class ReaAndroidPackageTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "inspect_android_package"
    override val spec = ToolSpec(
        name = "rea_android_package",
        description = "检视 APK 包结构（条目清单、native 库、签名信息等），目标文件只在服务器上被读取、不会被执行。" +
            "path 用 rea_upload 返回的服务器路径。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {
            string("path", "服务器上的 APK 绝对路径")
        }
    )

    override fun buildReaArgs(args: JsonObject) = buildJsonObject {
        put("path", args.requireStr("path"))
    }
}

// ── 通用兜底与目录 ──────────────────────────────────────────────────────

/**
 * 通用调用：任意 REA 工具。
 *
 * 精选工具覆盖不了的长尾能力（批处理反编译、调用图、注释、书签、Objective-C/Swift
 * 类分析等 150+ 个）都从这里走。先用 rea_tools 查工具名与参数，再调本工具。
 */
class ReaRunTool(gateway: ReaGateway) : ReaBridgeTool(gateway) {
    override val reaTool = "(dynamic)"
    override val spec = ToolSpec(
        name = "rea_run",
        description = "调用服务器 REA 引擎的任意工具（共 170 个）。先用 rea_tools 查工具名与参数 schema，" +
            "再把工具名传给 tool、参数按 schema 组成 JSON 字符串传给 arguments。" +
            "常用场景：batch_decompile 批量反编译、get_call_graph 调用图、find_xrefs_to_name 交叉引用、" +
            "get_objc_classes / analyze_swift_types 苹果阵营分析。只有精选工具不满足需求时才用它。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {
            string("tool", "REA 工具名，如 batch_decompile、get_call_graph")
            string(
                "arguments", "该工具的 JSON 参数对象（字符串形式），字段名必须与 rea_tools " +
                    "返回的 schema 一致；无参数的工具传 {}",
                required = false
            )
        }
    )

    override fun buildReaArgs(args: JsonObject): JsonObject {
        // 本工具的"REA 参数"是双层：外层 tool 名 + 内层 arguments。
        // 直接复用 invoke 的形态会丢信息，所以在 invoke 里特调，这里给个占位实现。
        throw IllegalArgumentException("rea_run 的参数在 invoke 内特殊处理")
    }

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val client = gateway.client()
            ?: return ToolResult.failure(gateway.missingReason)
        val tool = args.str("tool")?.trim()
            ?: return ToolResult.failure("缺少必填参数 'tool'（REA 工具名，可先用 rea_tools 查询）")
        val arguments = parseArguments(args.str("arguments"))
            ?: return ToolResult.failure("arguments 不是合法 JSON 对象（应形如 {\"procedure\":\"JNI_OnLoad\"}）")
        return callRea(client, tool, arguments)
    }

    companion object {
        private val lenientJson = Json { ignoreUnknownKeys = true; isLenient = true }

        /** 解析模型手写的 JSON 参数；空/缺省返回空对象，解析失败返回 null。 */
        fun parseArguments(raw: String?): JsonObject? {
            val text = raw?.trim().orEmpty()
            if (text.isEmpty() || text == "{}") return JsonObject(emptyMap())
            return runCatching { lenientJson.parseToJsonElement(text) as? JsonObject }.getOrNull()
        }
    }
}

/** 查询 REA 侧全部工具目录（名称 + 说明 + 参数 schema）。 */
class ReaToolsCatalogTool(
    private val gateway: ReaGateway
) : Tool {

    override val spec = ToolSpec(
        name = "rea_tools",
        description = "列出服务器 REA 引擎当前可用的全部工具（名称、说明、参数 schema）。" +
            "需要调用 rea_run 之前先查这里，确认工具名与必填参数。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {}
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val client = gateway.client()
            ?: return ToolResult.failure(gateway.missingReason)
        return try {
            val tools = client.listTools()
            if (tools.isEmpty()) {
                ToolResult.failure("REA 引擎未返回任何工具")
            } else {
                val lines = tools.joinToString("\n") { tool ->
                    val params = tool.inputSchema?.toString().orEmpty()
                    "- ${tool.name}：${tool.description.take(120)}" +
                        if (params.isNotBlank()) "  参数 schema：$params" else ""
                }
                ToolResult.success(
                    "REA 引擎共 ${tools.size} 个工具：\n$lines"
                )
            }
        } catch (e: ReaException) {
            ToolResult.failure("REA 网关调用失败：${e.message}")
        } catch (e: Exception) {
            ToolResult.failure("REA 调用异常：${e.message ?: e::class.java.simpleName}")
        }
    }
}

/**
 * 上传手机本地文件到 REA 服务器，返回服务器路径。
 *
 * 读取走 [com.example.nativedemo.tools.saf.UriAccessPolicy] 已授权目录，
 * 流式 POST 到网关 /upload（不整文件读进内存，APK 再大也不 OOM）。
 */
class ReaUploadTool(
    private val gateway: ReaGateway
) : Tool {

    override val spec = ToolSpec(
        name = "rea_upload",
        description = "把用户已授权目录里的文件上传到 REA 服务器，返回服务器上的路径。" +
            "这是手机文件进入服务器分析流程的唯一入口：上传后用返回的 path 调用 " +
            "rea_open（native 分析）或 rea_android_resources / rea_android_package（APK 分析）。" +
            "支持 APK/so/zip/IPA 等，上限 96MB。",
        category = "REA 逆向",
        layer = "L1",
        params = objectSchema {
            string("path", "已授权目录中的文件路径，如 Download/app.apk")
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val pathArg = try {
            args.requireStr("path")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }
        val document = ctx.uriAccessPolicy.resolveDocument(pathArg)
            ?: return ToolResult.failure(
                "未找到「$pathArg」。可先 file_list 查看已授权目录，或让用户在「设置 → 本地目录」授权。"
            )
        if (document.isDirectory) {
            return ToolResult.failure("「$pathArg」是目录，请指定具体文件。")
        }
        ctx.uriAccessPolicy.denyReason(document.uri, write = false)?.let {
            return ToolResult.failure(it)
        }
        val filename = pathArg.trimEnd('/').substringAfterLast('/').ifBlank { "upload.bin" }

        return withContext(Dispatchers.IO) {
            try {
                val client = gateway.client()
                    ?: return@withContext ToolResult.failure(gateway.missingReason)
                val stream = ctx.contentResolver.openInputStream(document.uri)
                    ?: return@withContext ToolResult.failure("无法打开该文件（可能已被删除或无权访问）")
                // 能拿到文件大小就带上（OkHttp 走定长编码），拿不到用 chunked
                val size = runCatching {
                    ctx.contentResolver.openFileDescriptor(document.uri, "r")?.use { it.statSize }
                }.getOrNull()?.takeIf { it >= 0 } ?: -1L
                val serverPath = stream.use { input ->
                    client.upload(size, filename) { _, sink ->
                        input.copyTo(sink.outputStream())
                    }
                }
                ToolResult.success(
                    "上传成功：$filename\n服务器路径：$serverPath\n" +
                        "下一步：用该路径调用 rea_open（native）或 rea_android_resources（APK 资源解码）。"
                )
            } catch (e: ReaException) {
                ToolResult.failure("上传失败：${e.message}")
            } catch (e: SecurityException) {
                ToolResult.failure("权限不足：${e.message}")
            } catch (e: Exception) {
                ToolResult.failure("上传失败：${e.message ?: e::class.java.simpleName}")
            }
        }
    }
}

/** 一次性装好整个 REA 工具集（AppContainer 用）。 */
fun reaToolSet(gateway: ReaGateway): List<Tool> = listOf(
    ReaUploadTool(gateway),
    ReaOpenTool(gateway),
    ReaExtractTool(gateway),
    ReaOverviewTool(gateway),
    ReaFunctionsTool(gateway),
    ReaSearchFunctionsTool(gateway),
    ReaDecompileTool(gateway),
    ReaDisassembleTool(gateway),
    ReaFunctionInfoTool(gateway),
    ReaCallersTool(gateway),
    ReaCalleesTool(gateway),
    ReaStringsTool(gateway),
    ReaSearchStringsTool(gateway),
    ReaAndroidResourcesTool(gateway),
    ReaAndroidPackageTool(gateway),
    ReaToolsCatalogTool(gateway),
    ReaRunTool(gateway)
)
