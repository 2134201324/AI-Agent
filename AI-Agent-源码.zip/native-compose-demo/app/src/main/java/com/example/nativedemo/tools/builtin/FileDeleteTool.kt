package com.example.nativedemo.tools.builtin

import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject

/**
 * 删除已授权目录中的文件或文件夹。
 * 标记为 destructive，且删除不可撤销 —— 描述里明确提醒模型先确认。
 */
class FileDeleteTool : Tool {

    override val spec = ToolSpec(
        name = "file_delete",
        description = "删除已授权目录中的文件或文件夹（文件夹会连同其中内容一起删除，**不可撤销**）。" +
            "执行前请先向用户说明要删除什么。",
        category = "文件",
        layer = "L1",
        destructive = true,
        params = objectSchema {
            string("path", "要删除的文件或文件夹路径，例如 code_game/old.txt")
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val pathArg = try {
            args.requireStr("path")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }

        val document = ctx.uriAccessPolicy.resolveDocument(pathArg)
            ?: return ToolResult.failure("未找到「$pathArg」，可先用 file_list 查看有哪些文件。")
        val uri = document.uri

        ctx.uriAccessPolicy.denyReason(uri, write = true)?.let { return ToolResult.failure(it) }

        return withContext(Dispatchers.IO) {
            try {
                val isDirectory = document.isDirectory
                val name = document.name ?: pathArg
                if (document.delete()) {
                    ToolResult.success("已删除${if (isDirectory) "文件夹" else "文件"}「$name」")
                } else {
                    ToolResult.failure(
                        "删除失败：系统返回未成功。该文件可能受保护，或所在目录没有写入权限。"
                    )
                }
            } catch (e: SecurityException) {
                ToolResult.failure("权限不足：${e.message}")
            } catch (e: Throwable) {
                ToolResult.failure("删除失败：${e.message ?: e::class.java.simpleName}")
            }
        }
    }
}
