package com.example.nativedemo.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.nativedemo.BuildConfig
import com.example.nativedemo.core.ToolPermissions
import com.example.nativedemo.data.llm.LlmPresets
import com.example.nativedemo.data.llm.isLocalEndpoint
import com.example.nativedemo.ui.common.Banner
import com.example.nativedemo.ui.common.BannerLevel
import com.example.nativedemo.ui.common.InfoCard
import com.example.nativedemo.ui.common.InfoRow
import com.example.nativedemo.ui.common.PrimaryButton
import com.example.nativedemo.ui.common.SecondaryButton
import com.example.nativedemo.ui.common.SectionLabel
import com.example.nativedemo.ui.theme.Accent
import com.example.nativedemo.ui.theme.Accent2
import com.example.nativedemo.ui.theme.CardBg
import com.example.nativedemo.ui.theme.ChipBg
import com.example.nativedemo.ui.theme.Faint
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.LineColor
import com.example.nativedemo.ui.theme.Muted
import com.example.nativedemo.ui.theme.Warn

/**
 * 设置。
 *
 * 结构参照常见的模块化设置页：主页是一个**竖列入口列表**，每一项进入独立的
 * 详细设置子页。这样每页只解决一件事，比把所有选项堆在一条长滚动列表里好找得多。
 *
 * 页面本身不自带顶栏 —— 标题与返回由 [com.example.nativedemo.ui.nav.AppNav] 统一渲染。
 */
@Composable
fun SettingsHome(
    viewModel: SettingsViewModel,
    onOpenModel: () -> Unit,
    onOpenParams: () -> Unit,
    onOpenOrchestration: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenTools: () -> Unit,
    onOpenFiles: () -> Unit,
    onOpenRea: () -> Unit,
    onOpenBuild: () -> Unit,
    onOpenAppearance: () -> Unit,
    onOpenTerminal: () -> Unit,
    onOpenAbout: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val modelSubtitle = state.model.ifBlank { "未配置" }
    val toolsSubtitle = buildString {
        val enabledCount = state.tools.count { viewModel.isToolEnabled(it) }
        append("已启用 $enabledCount / ${state.tools.size} 项")
    }
    val filesSubtitle = if (state.roots.isEmpty()) {
        "未授权任何目录"
    } else {
        "已授权 ${state.roots.size} 个目录"
    }
    val reaSubtitle = when {
        !state.reaHasToken -> "未配置令牌"
        state.reaTestOk == true -> "在线 · ${state.reaToolCount} 个引擎工具"
        else -> "已配置 · 待测试"
    }
    // 云打包与 REA 共用同一网关，所以这里只需要判断网关是否配好
    val buildSubtitle = if (!state.reaHasToken) "未配置网关令牌" else "网页工程 → 可安装 APK"
    val appearanceSubtitle = buildString {
        append(state.brand.label)
        append(" · ")
        append(state.themeMode.label)
        if (state.background.enabled) append(" · 已设背景")
    }
    val orchestrationSubtitle = if (!state.orchestrationEnabled) {
        "已关闭"
    } else {
        val orchestrator = state.profiles.firstOrNull { it.id == state.orchestratorId }
            ?: state.profiles.firstOrNull { it.canOrchestrate }
        val subCount = state.profiles.count { it.canSub && it.id != orchestrator?.id }
        buildString {
            append("主模型 ${orchestrator?.label ?: "未配置"}")
            if (subCount > 0) append(" · $subCount 个子模型")
        }
    }

    // 权限摘要每次进入设置首页都重新查一遍：用户很可能刚从系统设置里改完权限回来，
    // 缓存一个旧值只会让他以为"改了没生效"。
    val permissionSubtitle = run {
        val snapshots = ToolPermissions.snapshot(context)
        val ready = snapshots.count { !it.applicable || it.granted }
        if (ready == snapshots.size) "全部已就绪" else "$ready / ${snapshots.size} 项已就绪"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        SettingsCard {
            SettingsRow("🔌", "模型连接", modelSubtitle, onOpenModel)
            RowDivider()
            SettingsRow("🎛", "模型参数", "温度 ${"%.2f".format(state.temperature)}", onOpenParams)
            RowDivider()
            SettingsRow("🧠", "多模型编排", orchestrationSubtitle, onOpenOrchestration)
            RowDivider()
            SettingsRow("🔐", "权限中心", permissionSubtitle, onOpenPermissions)
            RowDivider()
            SettingsRow("🛠", "工具权限", toolsSubtitle, onOpenTools)
            RowDivider()
            SettingsRow("📂", "本地目录", filesSubtitle, onOpenFiles)
            RowDivider()
            SettingsRow("🔬", "REA 逆向引擎", reaSubtitle, onOpenRea)
            RowDivider()
            SettingsRow("📦", "云端打包", buildSubtitle, onOpenBuild)
            RowDivider()
            SettingsRow("⌨️", "命令终端", "执行 shell 命令", onOpenTerminal)
            RowDivider()
            SettingsRow("🎨", "界面美化", appearanceSubtitle, onOpenAppearance)
            RowDivider()
            SettingsRow("ℹ️", "关于", "版本 ${BuildConfig.VERSION_NAME}", onOpenAbout)
        }

        state.notice?.let { notice ->
            Banner(text = notice, level = BannerLevel.INFO)
        }

        Spacer(Modifier.height(4.dp))
        Text(
            text = "会话与配置均存储于本机",
            color = Faint,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
    }
}

// ── 子页：模型连接 ────────────────────────────────────────────────────

@Composable
fun ModelConnectionPage(viewModel: SettingsViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    // 选用档案后，地址 / 模型 / Key 一律以档案为准（UiState 已同步档案值）
    val activeProfile = state.profiles.firstOrNull { it.id == state.activeProfileId }

    PageColumn {
        InfoCard(title = "模型连接") {
            // 子页不继承设置主页的 notice 展示，这里内联一份
            state.notice?.let { notice ->
                Banner(text = notice, level = BannerLevel.INFO)
                Spacer(Modifier.height(10.dp))
            }

            // ── 第 0 步 · 选用模型配置 ──
            // 档案各绑各的 API Key；不开多模型编排也能在这里切换使用
            if (state.profiles.isNotEmpty()) {
                SectionLabel("第 0 步 · 选用模型配置")
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "每个档案可绑定各自的 API Key，在这里点选即可切换使用。",
                    color = Muted,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PresetChip(
                        label = "默认配置",
                        selected = activeProfile == null
                    ) { viewModel.setActiveProfileId(null) }
                    state.profiles.forEach { profile ->
                        PresetChip(
                            label = profile.label,
                            selected = profile.id == state.activeProfileId
                        ) { viewModel.setActiveProfileId(profile.id) }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            if (activeProfile != null) {
                // ── 选用档案：只读摘要，修改去编排页的档案卡片 ──
                SectionLabel("正在使用档案「${activeProfile.label}」")
                Spacer(Modifier.height(8.dp))
                InfoRow("Base URL", activeProfile.baseUrl.ifBlank { "（未填写）" })
                InfoRow("模型", activeProfile.model.ifBlank { "（未填写）" })
                InfoRow("API Key", if (activeProfile.hasKey) "已保存 ✓" else "未填写")
                InfoRow("编排角色", activeProfile.role.label)
                activeProfile.toolsSupported?.let { supported ->
                    InfoRow("工具调用", if (supported) "支持" else "不支持")
                }
                if (!activeProfile.enabled) {
                    Spacer(Modifier.height(8.dp))
                    Banner(
                        text = "该档案已停用，聊天不会使用它；可到「设置 → 多模型编排」重新启用。",
                        level = BannerLevel.WARN
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "地址、模型与 Key 的修改请在「设置 → 多模型编排」的档案卡片中完成，本页只负责选用。",
                    color = Muted,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
                if (activeProfile.baseUrl.trim().let {
                        it.startsWith("http://127.0.0.1") || it.startsWith("http://localhost")
                    }
                ) {
                    Spacer(Modifier.height(12.dp))
                    DshGuideCard()
                }
                Spacer(Modifier.height(14.dp))
                TestConnectionSection(state = state, viewModel = viewModel)
            } else {
                SectionLabel("第 1 步 · 选服务商（地址与模型会自动填好）")
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LlmPresets.all.forEach { preset ->
                        PresetChip(
                            label = preset.label,
                            selected = state.selectedPresetLabel == preset.label
                        ) { viewModel.applyPreset(preset) }
                    }
                }

                val matched = LlmPresets.match(state.baseUrl)
                if (matched != null && matched.modelSuggestions.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    SectionLabel("推荐模型（点一下即可）")
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        matched.modelSuggestions.forEach { name ->
                            PresetChip(
                                label = name,
                                selected = state.model == name
                            ) { viewModel.onModelChange(name) }
                        }
                    }
                }

                // 选中「DeepSeek 网页桥接」预设时，就地给出桥接工具的使用方法
                if (state.selectedPresetLabel == "DeepSeek 网页桥接") {
                    Spacer(Modifier.height(12.dp))
                    DshGuideCard()
                }

                Spacer(Modifier.height(16.dp))
                SectionLabel("第 2 步 · 填你自己的 API Key")
                Spacer(Modifier.height(4.dp))
                Field(
                    label = "Base URL（选了服务商后通常不用改）",
                    value = state.baseUrl,
                    placeholder = "https://api.openai.com/v1",
                    onValueChange = viewModel::onBaseUrlChange
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    text = "实际请求：${state.baseUrl.trim().trimEnd('/')}/chat/completions",
                    color = Accent2,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
                Spacer(Modifier.height(10.dp))
                Field(
                    label = "模型名",
                    value = state.model,
                    placeholder = "gpt-4o-mini",
                    onValueChange = viewModel::onModelChange
                )
                Spacer(Modifier.height(8.dp))
                // 与其猜模型名，直接问服务端要这份 Key 能用的模型清单
                ModelListFetchRow(
                    loading = state.modelFetch is ModelFetchState.Loading,
                    onFetch = {
                        viewModel.fetchModelList(
                            baseUrl = state.baseUrl,
                            apiKey = state.apiKeyInput,
                            targetProfileId = null,
                            allowStoredFallback = true
                        )
                    }
                )
                val fetch = state.modelFetch
                if (fetch is ModelFetchState.Failure && fetch.targetProfileId == null) {
                    Spacer(Modifier.height(8.dp))
                    Banner(text = fetch.message, level = BannerLevel.ERROR)
                }
                Spacer(Modifier.height(10.dp))
                // 本地 / 局域网桥接用网页登录态，不需要 Key —— 直说，别让用户去编一个
                val keyOptional = isLocalEndpoint(state.baseUrl)
                Field(
                    label = when {
                        keyOptional -> "API Key（网页桥接不需要，留空即可）"
                        state.hasStoredKey -> "API Key（已保存，留空则不修改）"
                        else -> "API Key"
                    },
                    value = state.apiKeyInput,
                    placeholder = if (keyOptional) "留空即可" else "sk-…",
                    onValueChange = viewModel::onApiKeyChange,
                    isSecret = true
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = when {
                        keyOptional ->
                            "这是本地 / 局域网地址：桥接工具转发的是网页登录态，" +
                                "协议要求的令牌会自动补一个占位值，无需你填写。"
                        state.hasStoredKey -> "已使用设备密钥库（Android Keystore）加密存储，明文不落盘。"
                        else -> "Key 仅保存在本机，经 Keystore 加密；换机恢复后需要重新填写。"
                    },
                    color = Muted,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
                Spacer(Modifier.height(14.dp))
                PrimaryButton(text = "保存", onClick = viewModel::save)
                Spacer(Modifier.height(8.dp))
                TestConnectionSection(state = state, viewModel = viewModel)
                if (state.hasStoredKey) {
                    Spacer(Modifier.height(8.dp))
                    SecondaryButton(text = "清除已保存的 Key", onClick = viewModel::clearApiKey)
                }
            }

            if (state.profiles.isEmpty()) {
                Spacer(Modifier.height(14.dp))
                Banner(
                    text = "想绑定多个 API Key 按需切换，或让多个模型分工协作？" +
                        "到「设置 → 多模型编排」添加模型档案。",
                    level = BannerLevel.INFO
                )
            }
        }

        // 局域网自动发现：与电脑同一 WiFi 时免去手填桥接 IP。
        // 选用档案时地址在编排页的档案卡片里维护，这里不出现，避免填了不生效。
        if (activeProfile == null) {
            InfoCard(title = "🌉 网页桥接（一键连接）") {
                BridgeDiscoverySection(
                    state = state,
                    viewModel = viewModel,
                    onAutoConfigure = viewModel::autoConfigureBridge
                )
            }
        }
    }

    // 模型清单选择框：拉取成功、或点选扫描结果时弹出
    val fetch = state.modelFetch
    if (fetch is ModelFetchState.Success && fetch.targetProfileId == null) {
        AlertDialog(
            onDismissRequest = viewModel::dismissModelFetch,
            title = { Text("可用模型（${fetch.models.size}）") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                    items(fetch.models) { name ->
                        val selected = name == state.model
                        Text(
                            text = name,
                            color = if (selected) Accent else Fg,
                            fontSize = 14.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.onModelChange(name)
                                    // 顺手落盘：选了却忘了点「保存」的话，聊天仍会用旧
                                    // 模型名继续撞 400 —— 这正是「模型不存在」的死循环
                                    viewModel.save()
                                    viewModel.dismissModelFetch()
                                }
                                .padding(vertical = 10.dp, horizontal = 4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = viewModel::dismissModelFetch) { Text("关闭") }
            }
        )
    }
}

/**
 * 局域网自动发现区：扫描 → 进度 → 结果列表 → 填入。
 *
 * 扫不到时的指引是重点：用户很可能正在用移动数据，与电脑不在同一可达
 * 网段 —— 这不是故障，必须把「同一 WiFi」与「内网穿透」两条路说清楚。
 */
@Composable
private fun BridgeDiscoverySection(
    state: SettingsViewModel.UiState,
    viewModel: SettingsViewModel,
    onAutoConfigure: () -> Unit
) {
    Text(
        text = "把电脑上跑的 DSH 等网页桥接工具接进来。点一下按钮全自动：" +
            "找地址 → 选模型 → 免填 Key → 验证。也支持手机上自建的桥接服务。",
        color = Muted,
        fontSize = 11.sp,
        lineHeight = 16.sp
    )
    Spacer(Modifier.height(10.dp))

    // 桥接模式状态：说明为什么不需要 Key、为什么工具调用不可用
    if (state.bridgeMode) {
        Banner(
            text = "桥接模式已开启：不需要 API Key，也不会发送工具调用。" +
                "（桥接转发的是浏览器里的网页登录态，本身不支持工具调用）",
            level = BannerLevel.INFO
        )
        Spacer(Modifier.height(10.dp))
    }

    when (val scan = state.bridgeScan) {
        is BridgeScanState.Running -> {
            Text(
                text = "本机 IP：${scan.ownIp ?: "未获取到（请检查网络）"}",
                color = Fg,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            if (scan.total > 0) {
                LinearProgressIndicator(
                    progress = { scan.scanned.toFloat() / scan.total },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp),
                    color = Accent
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "已扫描 ${scan.scanned} / ${scan.total} 个地址…",
                    color = Muted,
                    fontSize = 11.sp
                )
            } else {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp),
                    color = Accent
                )
                Spacer(Modifier.height(6.dp))
                Text("正在准备扫描…", color = Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(10.dp))
            SecondaryButton(text = "取消扫描", onClick = viewModel::cancelBridgeScan)
        }

        is BridgeScanState.Done -> {
            Text(
                text = "本机 IP：${scan.ownIp ?: "未获取到（请检查网络）"}" +
                    if (scan.timedOut) "（扫描超时，以下是已完成部分的结果）" else "",
                color = Fg,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            if (scan.bridges.isEmpty()) {
                Banner(
                    text = buildString {
                        append("没找到桥接服务。按顺序检查这三条：\n")
                        append("1. 桥接工具是否以 0.0.0.0 监听？默认只监听 127.0.0.1，")
                        append("手机连不上（启动时加 --host 0.0.0.0 之类的参数）；\n")
                        append("2. 手机与电脑是否连的同一个 WiFi？用移动数据访问不到电脑局域网；\n")
                        append("3. 电脑防火墙是否放行了该端口。")
                    },
                    level = BannerLevel.WARN
                )
            } else {
                scan.bridges.forEach { bridge ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.applyDiscoveredBridge(bridge) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = bridge.baseUrl,
                                color = Accent,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (bridge.needsKey) {
                                    "需要 API Key 才能看到模型清单"
                                } else {
                                    "可用模型 ${bridge.models.size} 个：" +
                                        bridge.models.take(3).joinToString("、") +
                                        if (bridge.models.size > 3) " 等" else ""
                                },
                                color = Muted,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                        Text("填入", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "点一下填入 Base URL；能列出模型的服务会直接弹出选择框。",
                    color = Muted,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
            Spacer(Modifier.height(10.dp))
            PrimaryButton(text = "🔌 一键连接网页桥接", onClick = onAutoConfigure)
            Spacer(Modifier.height(8.dp))
            SecondaryButton(text = "重新扫描", onClick = viewModel::startBridgeScan)
        }

        BridgeScanState.Idle -> {
            PrimaryButton(text = "🔌 一键连接网页桥接", onClick = onAutoConfigure)
            Spacer(Modifier.height(6.dp))
            Text(
                text = "自动完成：扫描 → 填入地址 → 免填 Key → 选模型 → 保存 → 测试连接",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
            Spacer(Modifier.height(10.dp))
            SecondaryButton(text = "仅扫描局域网", onClick = viewModel::startBridgeScan)
        }
    }
}

/** 「获取模型清单」按钮行：默认配置页与档案编辑框共用。 */
@Composable
internal fun ModelListFetchRow(loading: Boolean, onFetch: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        SecondaryButton(
            text = if (loading) "正在获取…" else "获取模型清单",
            enabled = !loading,
            onClick = onFetch
        )
        if (loading) {
            Spacer(Modifier.width(12.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(14.dp),
                color = Accent,
                strokeWidth = 1.5.dp
            )
            Spacer(Modifier.width(8.dp))
            Text("正在向服务端询问可用模型…", color = Muted, fontSize = 11.sp)
        }
    }
}

/** 测试连接区：选用档案与默认配置两条路径共用。 */
@Composable
private fun TestConnectionSection(
    state: SettingsViewModel.UiState,
    viewModel: SettingsViewModel
) {
    SecondaryButton(
        text = if (state.testing) "正在测试…" else "测试连接",
        enabled = !state.testing,
        onClick = viewModel::testConnection
    )
    if (state.testing) {
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(
                modifier = Modifier.height(14.dp),
                color = Accent,
                strokeWidth = 1.5.dp
            )
            Spacer(Modifier.width(10.dp))
            Text("正在向服务端发起一次最小请求…", color = Muted, fontSize = 12.sp)
        }
    }
    state.testMessage?.let { message ->
        Spacer(Modifier.height(10.dp))
        Banner(
            text = message,
            level = if (state.testOk == true) BannerLevel.INFO else BannerLevel.ERROR
        )
    }
}

/**
 * DeepSeek 网页桥接（DSH）指引卡。
 *
 * DSH 一类工具把 DeepSeek 网页端逆向封装成本地 OpenAI 兼容服务，
 * 因此地址是**本机 / 局域网**的 http 地址、Key 一般不校验 ——
 * 这些与常规云 API 的差异必须写在明处，否则用户会拿着 sk- 问为什么连不上。
 */
@Composable
private fun DshGuideCard() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(10.dp))
            .border(1.dp, LineColor, RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Text(
            text = "🌉 DeepSeek 网页桥接（DSH）使用指引",
            color = Fg,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "1. 在电脑上运行 DSH WebTokens / DeepSeek-Harness 等桥接工具，启动它的本地服务；\n" +
                "2. 点下方「🔌 一键连接网页桥接」——它会自动扫出地址、选好模型并验证；" +
                "若手工填写：模拟器/本机填 http://127.0.0.1:8000/v1，" +
                "真机与电脑同局域网时填 http://<电脑IP>:8000/v1；\n" +
                "3. API Key 完全不需要：桥接转发的是你浏览器的网页登录态，" +
                "协议要求的令牌由 App 自动补占位值；\n" +
                "4. 配置完成后回到对话页直接提问即可。",
            color = Muted,
            fontSize = 12.sp,
            lineHeight = 18.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "注意：桥接的是网页端会话，稳定性与额度受网页版限制，适合体验与轻度使用；" +
                "重要场景建议使用 DeepSeek 官方 API。",
            color = Warn,
            fontSize = 11.sp,
            lineHeight = 16.sp
        )
    }
}

// ── 子页：模型参数 ────────────────────────────────────────────────────

/** 最大输出长度的可选项；0 表示不发送该参数，由服务端自行决定。 */
private val OUTPUT_TOKEN_OPTIONS = listOf(
    "4096" to 4096,
    "8192" to 8192,
    "16384" to 16384,
    "32768" to 32768,
    "不限制" to 0
)

/**
 * 工具轮次上限的可选档位。
 *
 * 逆向工程这类任务天然要几十步（上传 → 打开 → 总览 → 搜函数 → 反编译 → 追交叉引用…），
 * 所以档位整体偏大；额度用尽时引擎还会自动延长两次，实际可用轮次是这个值的 1~3 倍。
 */
private val TOOL_ROUND_OPTIONS = listOf(
    "8（旧默认）" to 8,
    "20" to 20,
    "30（默认）" to 30,
    "60" to 60,
    "120" to 120
)

@Composable
fun ModelParamsPage(viewModel: SettingsViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    PageColumn {
        InfoCard(title = "模型参数") {
            Text(
                text = "温度：${"%.2f".format(state.temperature)}",
                color = Fg,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Slider(
                value = state.temperature,
                onValueChange = viewModel::onTemperatureChange,
                valueRange = 0f..2f
            )
            Text(
                text = "越高越有创造性，越低越稳定。写代码、做事实性任务建议 0.2~0.5。",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )

            Spacer(Modifier.height(18.dp))
            SectionLabel("最大输出长度")
            Spacer(Modifier.height(4.dp))
            Text(
                text = "推理模型的**思考过程也占用这份额度**。思考强度一大，额度不够就会" +
                    "话说到一半停住。默认 8192；调大能减少截断，调小可省钱。",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OUTPUT_TOKEN_OPTIONS.forEach { (label, value) ->
                    PresetChip(
                        label = label,
                        selected = state.maxOutputTokens == value
                    ) { viewModel.setMaxOutputTokens(value) }
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = "改动立即生效。若服务端不接受该参数，会自动去掉它重试一次。",
                color = Faint,
                fontSize = 10.sp
            )
            Spacer(Modifier.height(14.dp))
            SectionLabel("工具调用轮次上限")
            Spacer(Modifier.height(6.dp))
            Text(
                text = "一次任务里模型最多能「调用工具 → 拿到结果 → 再决定下一步」多少轮。" +
                    "逆向分析动辄几十步，8 轮会把任务掐断在半路。额度用尽但任务仍在推进时，" +
                    "会自动延长两次；真跑不完会给出「继续执行」按钮，点了就从断点接着做。",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TOOL_ROUND_OPTIONS.forEach { (label, value) ->
                    PresetChip(
                        label = label,
                        selected = state.maxToolRounds == value
                    ) { viewModel.setMaxToolRounds(value) }
                }
            }
            Spacer(Modifier.height(14.dp))
            Field(
                label = "系统提示词",
                value = state.systemPrompt,
                placeholder = "描述 Agent 的角色与行为准则",
                onValueChange = viewModel::onSystemPromptChange,
                singleLine = false
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "提示词改动需要点「保存」才会写入。",
                color = Muted,
                fontSize = 11.sp
            )
            Spacer(Modifier.height(14.dp))
            PrimaryButton(text = "保存", onClick = viewModel::save)
        }
    }
}

// ── 子页：工具权限 ────────────────────────────────────────────────────

@Composable
fun ToolPermissionPage(viewModel: SettingsViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    PageColumn {
        InfoCard(title = "工具权限") {
            Text(
                text = "关闭某项工具后，模型将看不到它，也就无法调用。",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
            Spacer(Modifier.height(8.dp))
            state.tools.forEach { spec ->
                val enabled = viewModel.isToolEnabled(spec)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            spec.name,
                            color = Fg,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = spec.description,
                            color = Muted,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                        // 能力面大的工具把风险说在明处，别让用户稀里糊涂打开
                        spec.securityNote?.let { note ->
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "⚠ $note",
                                color = Warn,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                    Switch(
                        checked = enabled,
                        onCheckedChange = { viewModel.toggleTool(spec.name, it) }
                    )
                }
            }
        }
    }
}

// ── 子页：本地目录 ────────────────────────────────────────────────────

@Composable
fun FileAccessPage(viewModel: SettingsViewModel, onPickTree: () -> Unit) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    PageColumn {
        SafPermissionSection(
            roots = state.roots,
            entries = state.rootEntries,
            onAdd = onPickTree,
            onRemove = viewModel::removeAuthorizedRoot
        )
    }
}

// ── 子页：界面美化 ────────────────────────────────────────────────────

@Composable
fun AppearancePage(viewModel: SettingsViewModel, onOpenBackground: () -> Unit) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    PageColumn {
        AppearanceSection(
            brand = state.brand,
            mode = state.themeMode,
            fontScale = state.fontScaleOption,
            density = state.density,
            corner = state.bubbleCorner,
            background = state.background,
            overrideCount = state.colorOverrides.size,
            onBrand = viewModel::setBrand,
            onMode = viewModel::setThemeMode,
            onFontScale = viewModel::setFontScale,
            onDensity = viewModel::setDensity,
            onCorner = viewModel::setBubbleCorner,
            onOpenBackground = onOpenBackground
        )
    }
}

// ── 子页：关于 ────────────────────────────────────────────────────────

@Composable
fun AboutPage() {
    PageColumn {
        InfoCard(title = "关于") {
            InfoRow(label = "应用", value = "AI Agent 助手")
            InfoRow(label = "版本", value = "${BuildConfig.VERSION_NAME}（${BuildConfig.VERSION_CODE}）")
            InfoRow(label = "包名", value = "com.example.nativedemo")
            Spacer(Modifier.height(8.dp))
            Text(
                text = "API Key 经 Android Keystore 加密后存储；会话记录、外观配置、" +
                    "背景图全部保存在应用私有目录，不会上传。",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
        }

        InfoCard(title = "打包能力") {
            InfoRow(label = "云端构建", value = "已接入", highlight = true)
            InfoRow(label = "本机工具链", value = "未接入", highlight = false)
            Spacer(Modifier.height(6.dp))
            Text(
                text = "云端构建在「设置 → 云端打包」：把网页工程交给服务器上的 " +
                    "JDK + Android SDK + Gradle 工具链编译并签名，产出可直接安装的 APK。" +
                    "手机端不需要任何构建环境。\n" +
                    "本机工具链（在手机里直接跑 aapt2/d8/apksigner）能力与之重叠，" +
                    "却要随包分发整套 build-tools，因此不接入。",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
        }
    }
}

// ── 子页：REA 远程逆向引擎 ─────────────────────────────────────────────

/**
 * REA 引擎接入配置。
 *
 * 这个页面是「手机 → 服务器重算力」的桥头堡：地址与令牌配好后，
 * 聊天里的 AI 就能把用户授权目录里的 APK/so 传到服务器，用 Ghidra 12.1.4
 * 做 native 层深度分析。令牌经 Keystore 加密，不明文落盘。
 */
@Composable
fun ReaEnginePage(viewModel: SettingsViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val reaToolCount = state.tools.count { it.name.startsWith("rea_") }

    PageColumn {
        InfoCard(title = "网关配置") {
            Field(
                label = "服务器地址",
                value = state.reaServerUrl,
                placeholder = "https://你的网关域名",
                onValueChange = viewModel::onReaServerUrlChange
            )
            Spacer(Modifier.height(12.dp))
            Field(
                label = "访问令牌",
                value = state.reaTokenInput,
                placeholder = if (state.reaHasToken) "已保存（留空表示不修改）" else "粘贴网关令牌",
                onValueChange = viewModel::onReaTokenChange,
                isSecret = true
            )
            if (state.reaHasToken) {
                Spacer(Modifier.height(6.dp))
                Text("令牌已加密保存 ✓", color = Accent2, fontSize = 11.sp)
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton(text = "保存配置", onClick = viewModel::saveReaConfig)
                SecondaryButton(
                    text = if (state.reaTesting) "正在测试…" else "测试连接",
                    enabled = !state.reaTesting,
                    onClick = viewModel::testReaConnection
                )
            }
            if (state.reaTesting) {
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.height(14.dp),
                        color = Accent,
                        strokeWidth = 1.5.dp
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("正在握手并拉取工具清单（服务器首次分析可能要一两分钟）…", color = Muted, fontSize = 12.sp)
                }
            }
            state.reaTestMessage?.let { message ->
                Spacer(Modifier.height(10.dp))
                Banner(
                    text = message,
                    level = if (state.reaTestOk == true) BannerLevel.INFO else BannerLevel.ERROR
                )
            }
            if (state.reaHasToken) {
                Spacer(Modifier.height(10.dp))
                TextButton(onClick = viewModel::clearReaToken) {
                    Text("清除已保存的令牌", color = Warn, fontSize = 12.sp)
                }
            }
        }

        InfoCard(title = "运行状态") {
            InfoRow(
                label = "REA 工具",
                value = if (reaToolCount > 0) "已注册 $reaToolCount 个" else "未注册",
                highlight = reaToolCount > 0
            )
            InfoRow(
                label = "引擎状态",
                value = when {
                    !state.reaHasToken -> "未配置令牌"
                    state.reaTestOk == true -> "在线（${state.reaToolCount} 个引擎工具）"
                    else -> "地址已填，待测试"
                }
            )
            InfoRow("分析引擎", "Ghidra 12.1.4 · Apktool（服务器侧）")
        }

        InfoCard(title = "使用指引") {
            SectionLabel("典型链路")
            Spacer(Modifier.height(6.dp))
            Text(
                text = "1. 在「设置 → 本地目录」授权存放 APK/so 的目录；\n" +
                    "2. 对话里让 AI 分析某文件，它会先调 rea_upload 上传；\n" +
                    "3. native 分析：rea_open → rea_overview → rea_search_functions / rea_decompile；\n" +
                    "4. APK 分析：rea_android_resources（清单/资源）或 rea_android_package（包结构）；\n" +
                    "5. 长尾能力：rea_tools 查目录 → rea_run 调任意工具。",
                color = Fg,
                fontSize = 13.sp,
                lineHeight = 20.sp
            )
            Spacer(Modifier.height(12.dp))
            SectionLabel("能力边界")
            Spacer(Modifier.height(6.dp))
            Text(
                text = "· REA 的 Ghidra 打不开 classes.dex —— dex 分析用 App 内置的 apk_* 工具，两者互补；\n" +
                    "· 文件只在服务器沙盒内被读取分析，不会在服务器上执行；\n" +
                    "· 上传上限 96MB；单次分析结果超长会自动截断；\n" +
                    "· 手机侧只保存地址与令牌，不保存任何服务器文件。",
                color = Muted,
                fontSize = 12.sp,
                lineHeight = 19.sp
            )
        }
    }
}

// ── 通用构件 ──────────────────────────────────────────────────────────

/** 子页统一的外层：可滚动 + 统一内边距。 */
@Composable
private fun PageColumn(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        content()
    }
}

/** 入口列表的外层卡片：整块圆角，内部行之间用极细分隔线。 */
@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CardBg)
            .border(1.dp, LineColor, RoundedCornerShape(16.dp))
    ) {
        content()
    }
}

@Composable
private fun RowDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 52.dp)
            .height(1.dp)
            .background(LineColor)
    )
}

@Composable
private fun SettingsRow(
    icon: String,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(ChipBg),
            contentAlignment = Alignment.Center
        ) {
            Text(icon, fontSize = 15.sp)
        }

        Spacer(Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Fg, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            if (subtitle.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(subtitle, color = Faint, fontSize = 11.sp)
            }
        }

        Text("›", color = Faint, fontSize = 20.sp)
    }
}

@Composable
private fun PresetChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(
                color = if (selected) Accent.copy(alpha = 0.18f) else CardBg,
                shape = RoundedCornerShape(999.dp)
            )
            .border(
                width = 1.dp,
                color = if (selected) Accent.copy(alpha = 0.65f) else LineColor,
                shape = RoundedCornerShape(999.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(
            text = label,
            color = if (selected) Accent else Muted,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    placeholder: String,
    onValueChange: (String) -> Unit,
    isSecret: Boolean = false,
    singleLine: Boolean = true
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(label, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(5.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(placeholder, color = Muted, fontSize = 13.sp) },
            singleLine = singleLine,
            minLines = if (singleLine) 1 else 3,
            maxLines = if (singleLine) 1 else 8,
            visualTransformation = if (isSecret) {
                androidx.compose.ui.text.input.PasswordVisualTransformation()
            } else {
                androidx.compose.ui.text.input.VisualTransformation.None
            }
        )
    }
}
