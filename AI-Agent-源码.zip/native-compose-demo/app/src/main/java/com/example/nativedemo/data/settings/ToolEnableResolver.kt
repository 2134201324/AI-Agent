package com.example.nativedemo.data.settings

/**
 * 工具启用集的「升级补齐」规则。
 *
 * ## 要解决的问题
 * 用户的启用集是**按版本快照**存在本地的。假设他在 1.9.2 时把工具开关调成了
 * 「除 run_command 外全开」，那一串工具名就固化进 DataStore 了。
 * 到 1.9.3 新增 web_search / mt_open 时，它们不在这串名字里 ——
 * 若直接按存储值判定，新工具对老用户就是**静默不可见**的：
 * 升级完发现"说好的联网搜索呢"，而且开关页里它明明是开着的（默认值），
 * 只有模型那边收不到。
 *
 * ## 怎么区分"新工具"和"用户主动关掉的工具"
 * 靠 [known] 这个「用户见过哪些工具」的集合：
 * - 注册表里有、[known] 里没有 → **本版本新增**，按 [defaultEnabled] 补上；
 * - [known] 里有但 [stored] 里没有 → 用户**主动关掉的**，尊重他的决定，绝不补。
 *
 * ## 为什么必须配套落盘
 * 补齐只发生在 [known] 还是旧值的那一瞬间。调用方把补齐结果**写回**存储、
 * 同时更新 [known] 之后，这个"新工具"状态才算消费掉。
 * 只更新 [known] 而不落盘启用集，会让补齐结果在下一次读取时凭空消失 ——
 * 表现成"开关自己弹回去"，比不补还难查。
 *
 * @return null 表示用户从未动过开关，此时不应有"启用集"的概念，
 *         由 ToolRegistry 全量按各自 defaultEnabled 判定。
 */
internal fun computeEnabledTools(
    stored: Set<String>?,
    known: Set<String>,
    allToolNames: Set<String>,
    defaultEnabled: Set<String>
): Set<String>? {
    if (stored == null) return null
    val newcomers = allToolNames - known
    if (newcomers.isEmpty()) return stored
    return stored + newcomers.filter { it in defaultEnabled }
}
