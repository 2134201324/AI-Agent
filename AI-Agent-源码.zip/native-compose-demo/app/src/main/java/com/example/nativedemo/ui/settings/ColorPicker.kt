package com.example.nativedemo.ui.settings

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.nativedemo.ui.common.PrimaryButton
import com.example.nativedemo.ui.common.SecondaryButton
import com.example.nativedemo.ui.theme.Accent
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.LineColor
import com.example.nativedemo.ui.theme.Muted
import com.example.nativedemo.ui.theme.OverlayBg

/**
 * 颜色选择器。
 *
 * 用 HSV 三个滑块而不是只给预设色板 —— 壁纸配色需要和背景图"配得上"，
 * 能给任意色才能真的调出想要的效果。透明度单独一档，因为半透明是
 * 覆盖在壁纸上的关键手段。
 *
 * 内部统一用 `0xAARRGGBB`（Long）；界面展示用 `#RRGGBBAA`，与常见设计工具一致。
 */
@Composable
fun ColorPickerDialog(
    title: String,
    initial: Long,
    allowReset: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Long) -> Unit,
    onReset: () -> Unit
) {
    val initialHsv = remember(initial) { argbToHsv(initial) }
    var hue by remember(initial) { mutableFloatStateOf(initialHsv[0]) }
    var saturation by remember(initial) { mutableFloatStateOf(initialHsv[1]) }
    var brightness by remember(initial) { mutableFloatStateOf(initialHsv[2]) }
    var alpha by remember(initial) { mutableIntStateOf(((initial shr 24) and 0xFF).toInt()) }
    var hexText by remember(initial) { mutableStateOf(toHexRgba(initial)) }

    val current = hsvToArgb(hue, saturation, brightness, alpha)
    val swatch = Color(current.toInt())

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(OverlayBg)
                .border(1.dp, LineColor, RoundedCornerShape(18.dp))
                .padding(18.dp)
        ) {
            Text(title, color = Fg, fontSize = 15.sp, fontWeight = FontWeight.Bold)

            Spacer(Modifier.height(14.dp))

            // 预览：棋盘底 + 当前色，半透明时能看出通透程度
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF2A2A2A)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .background(swatch)
                )
            }

            Spacer(Modifier.height(8.dp))
            Text(toHexRgba(current), color = Muted, fontSize = 12.sp)

            Spacer(Modifier.height(12.dp))

            ChannelSlider("色相", hue, 0f, 360f) {
                hue = it
                hexText = toHexRgba(hsvToArgb(hue, saturation, brightness, alpha))
            }
            ChannelSlider("饱和度", saturation, 0f, 1f) {
                saturation = it
                hexText = toHexRgba(hsvToArgb(hue, saturation, brightness, alpha))
            }
            ChannelSlider("明度", brightness, 0f, 1f) {
                brightness = it
                hexText = toHexRgba(hsvToArgb(hue, saturation, brightness, alpha))
            }
            ChannelSlider("透明度", alpha / 255f, 0f, 1f) {
                alpha = (it * 255f).toInt().coerceIn(0, 255)
                hexText = toHexRgba(hsvToArgb(hue, saturation, brightness, alpha))
            }

            Spacer(Modifier.height(4.dp))
            Text("常用色", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            PresetSwatches { argb ->
                val hsv = argbToHsv(argb)
                hue = hsv[0]
                saturation = hsv[1]
                brightness = hsv[2]
                alpha = ((argb shr 24) and 0xFF).toInt()
                hexText = toHexRgba(argb)
            }

            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = hexText,
                onValueChange = { text ->
                    hexText = text
                    parseHexRgba(text)?.let { argb ->
                        val hsv = argbToHsv(argb)
                        hue = hsv[0]
                        saturation = hsv[1]
                        brightness = hsv[2]
                        alpha = ((argb shr 24) and 0xFF).toInt()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("十六进制 #RRGGBBAA", fontSize = 11.sp) }
            )

            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (allowReset) {
                    Box(modifier = Modifier.weight(1f)) {
                        SecondaryButton(text = "恢复默认", onClick = onReset)
                    }
                }
                Box(modifier = Modifier.weight(1f)) {
                    PrimaryButton(text = "确定", onClick = { onConfirm(current) })
                }
            }
            Spacer(Modifier.height(8.dp))
            Box(modifier = Modifier.fillMaxWidth()) {
                SecondaryButton(text = "取消", onClick = onDismiss)
            }
        }
    }
}

@Composable
private fun ChannelSlider(
    label: String,
    value: Float,
    from: Float,
    to: Float,
    onChange: (Float) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.width(46.dp))
        Slider(
            value = value.coerceIn(from, to),
            onValueChange = onChange,
            valueRange = from..to,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun PresetSwatches(onPick: (Long) -> Unit) {
    val colors = remember {
        listOf(
            0xFF000000, 0xFF202020, 0xFF303030, 0xFF424242, 0xFF6B7280, 0xFF9AA1AE,
            0xFFE0E0E0, 0xFFFCFCFC, 0xFFFFFFFF, 0xFF16181D, 0xFFF7F8FA, 0xFFEDEFF4,
            0xFF4D6BFE, 0xFF8B5CF6, 0xFFE5484D, 0xFFF5A623, 0xFF2FB344, 0xFF12B5A8
        )
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        colors.chunked(6).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { argb ->
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(argb.toInt()))
                            .border(1.dp, LineColor, RoundedCornerShape(8.dp))
                            .clickable { onPick(argb) }
                    )
                }
            }
        }
    }
}

// ── 颜色格式转换 ──────────────────────────────────────────────────────

/** `0xAARRGGBB` → HSV 三元组（H 为 0..360）。 */
fun argbToHsv(argb: Long): FloatArray {
    val hsv = FloatArray(3)
    AndroidColor.colorToHSV(argb.toInt(), hsv)
    return hsv
}

/** HSV + alpha → `0xAARRGGBB`。 */
fun hsvToArgb(hue: Float, saturation: Float, brightness: Float, alpha: Int): Long {
    val rgb = AndroidColor.HSVToColor(
        floatArrayOf(
            hue.coerceIn(0f, 360f),
            saturation.coerceIn(0f, 1f),
            brightness.coerceIn(0f, 1f)
        )
    )
    return ((alpha.toLong() and 0xFF) shl 24) or (rgb.toLong() and 0xFFFFFF)
}

/** `0xAARRGGBB` → `#RRGGBBAA`（与设计工具的习惯一致）。 */
fun toHexRgba(argb: Long): String {
    val a = (argb shr 24) and 0xFF
    val r = (argb shr 16) and 0xFF
    val g = (argb shr 8) and 0xFF
    val b = argb and 0xFF
    return "#%02X%02X%02X%02X".format(r, g, b, a)
}

/** 解析 `#RRGGBB` / `#RRGGBBAA` / `#AARRGGBB`（8 位按 RRGGBBAA 处理）。失败返回 null。 */
fun parseHexRgba(text: String): Long? {
    val clean = text.trim().removePrefix("#").replace(" ", "")
    return when (clean.length) {
        6 -> clean.toLongOrNull(16)?.let { 0xFF000000L or it }
        8 -> {
            val rgba = clean.toLongOrNull(16) ?: return null
            val r = (rgba shr 24) and 0xFF
            val g = (rgba shr 16) and 0xFF
            val b = (rgba shr 8) and 0xFF
            val a = rgba and 0xFF
            (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        else -> null
    }
}
