package com.example.nativedemo.tools.apk

import java.io.ByteArrayOutputStream

/**
 * 解析 Android 二进制格式（AXML / resources.arsc / DEX）失败。
 *
 * 自成一支异常类型：这些格式来自**用户的文件**，畸形数据是常态而不是异常情况，
 * 上层需要能区分「解析器不认识这个文件」与「程序自身出错」。
 */
class ResParseException(message: String, cause: Throwable? = null) : Exception(message, cause)

/**
 * 小端字节游标。
 *
 * Android 的二进制资源格式一律小端；用游标而不是各种 ByteBuffer，是因为这些
 * chunk 结构的偏移大多是**相对各自 chunk 起点**的，需要频繁 seek，游标写起来更直白。
 */
internal class ByteCursor(private val data: ByteArray, var pos: Int = 0) {

    val size: Int get() = data.size
    val remaining: Int get() = data.size - pos

    fun atEnd(): Boolean = pos >= data.size

    fun require(n: Int) {
        if (pos + n > data.size) {
            throw ResParseException("数据越界：需要 $n 字节，仅剩 $remaining")
        }
    }

    fun u8(): Int {
        require(1)
        return data[pos++].toInt() and 0xFF
    }

    fun u16(): Int {
        require(2)
        val v = (data[pos].toInt() and 0xFF) or ((data[pos + 1].toInt() and 0xFF) shl 8)
        pos += 2
        return v
    }

    fun i32(): Int {
        require(4)
        val v = (data[pos].toInt() and 0xFF) or
            ((data[pos + 1].toInt() and 0xFF) shl 8) or
            ((data[pos + 2].toInt() and 0xFF) shl 16) or
            ((data[pos + 3].toInt() and 0xFF) shl 24)
        pos += 4
        return v
    }

    /** 读 32 位无符号数（偏移量经常超过 Int 正区间）。 */
    fun u32(): Long = i32().toLong() and 0xFFFFFFFFL

    fun bytes(n: Int): ByteArray {
        require(n)
        val out = data.copyOfRange(pos, pos + n)
        pos += n
        return out
    }

    fun skip(n: Int) {
        require(n)
        pos += n
    }

    fun seek(target: Int) {
        if (target < 0 || target > data.size) {
            throw ResParseException("越界跳转：$target（总长 ${data.size}）")
        }
        pos = target
    }

    /**
     * DEX 用的 ULEB128 变长无符号整数（每字节低 7 位有效，最高位表示「还有后续」）。
     *
     * 最坏情况下 5 字节；超过即视为数据损坏 —— DEX 规范里没有任何合法值需要第 6 字节。
     */
    fun uleb128(): Int {
        var result = 0
        var shift = 0
        while (true) {
            val b = u8()
            result = result or ((b and 0x7F) shl shift)
            if (b and 0x80 == 0) return result
            shift += 7
            if (shift > 28) throw ResParseException("ULEB128 超过 5 字节，数据已损坏")
        }
    }
}

/** 从字节数组视图里按小端读一个 32 位无符号数（不移动游标）。 */
internal fun ByteArray.u32At(offset: Int): Long {
    if (offset + 4 > size) throw ResParseException("读取 u32 越界 @$offset")
    return ((this[offset].toInt() and 0xFF).toLong()) or
        ((this[offset + 1].toInt() and 0xFF).toLong() shl 8) or
        ((this[offset + 2].toInt() and 0xFF).toLong() shl 16) or
        ((this[offset + 3].toInt() and 0xFF).toLong() shl 24)
}

/** 累加小块字节时用它，避免反复扩容。 */
internal fun writeAll(chunks: List<ByteArray>): ByteArray {
    val out = ByteArrayOutputStream()
    chunks.forEach { out.write(it) }
    return out.toByteArray()
}

// ── Android 资源 chunk 类型常量 ─────────────────────────────────────────

internal object ChunkType {
    const val NULL = 0x0000
    const val STRING_POOL = 0x0001
    const val TABLE = 0x0002
    const val XML = 0x0003

    const val XML_START_NAMESPACE = 0x0100
    const val XML_END_NAMESPACE = 0x0101
    const val XML_START_ELEMENT = 0x0102
    const val XML_END_ELEMENT = 0x0103
    const val XML_CDATA = 0x0104
    const val XML_RESOURCE_MAP = 0x0180

    const val TABLE_PACKAGE = 0x0200
    const val TABLE_TYPE = 0x0201
    const val TABLE_TYPE_SPEC = 0x0202
    const val TABLE_LIBRARY = 0x0203
    const val TABLE_OVERLAYABLE = 0x0204

    fun name(type: Int): String = when (type) {
        NULL -> "NULL"
        STRING_POOL -> "STRING_POOL"
        TABLE -> "TABLE"
        XML -> "XML"
        XML_START_NAMESPACE -> "XML_START_NAMESPACE"
        XML_END_NAMESPACE -> "XML_END_NAMESPACE"
        XML_START_ELEMENT -> "XML_START_ELEMENT"
        XML_END_ELEMENT -> "XML_END_ELEMENT"
        XML_CDATA -> "XML_CDATA"
        XML_RESOURCE_MAP -> "XML_RESOURCE_MAP"
        TABLE_PACKAGE -> "TABLE_PACKAGE"
        TABLE_TYPE -> "TABLE_TYPE"
        TABLE_TYPE_SPEC -> "TABLE_TYPE_SPEC"
        TABLE_LIBRARY -> "TABLE_LIBRARY"
        TABLE_OVERLAYABLE -> "TABLE_OVERLAYABLE"
        else -> "0x${type.toString(16)}"
    }
}

// ── Res_value 的数据类型 ────────────────────────────────────────────────

internal object ResValueType {
    const val NULL = 0x00
    const val REFERENCE = 0x01
    const val ATTRIBUTE = 0x02
    const val STRING = 0x03
    const val FLOAT = 0x04
    const val DIMENSION = 0x05
    const val FRACTION = 0x06
    const val DYNAMIC_REFERENCE = 0x07
    const val INT_DEC = 0x10
    const val INT_HEX = 0x11
    const val INT_BOOLEAN = 0x12
    const val INT_COLOR_ARGB8 = 0x1C
    const val INT_COLOR_RGB8 = 0x1D
}
