package com.example.nativedemo.ui.chat

/**
 * 展示用的换行规整。
 *
 * 把连续 3 个以上换行压成 2 个（保留一个空行，那是真正的段落分隔），
 * 并去掉首尾空行。
 *
 * 为什么需要：模型在正文与工具调用之间经常吐出一串换行，直接渲染就是
 * 一大片无意义的空白 —— 用户要滑半天才看到下一段内容。
 * 保留「一个空行」是因为那确实代表段落边界，压掉会让大段文字糊成一坨。
 *
 * 纯函数，随每个流式 token 重算，所以刻意用正则而不是逐字符循环。
 */
fun normalizeDisplayText(text: String): String =
    text.replace(Regex("\n{3,}"), "\n\n").trim('\n')

/**
 * 助手消息的分段：普通文本 与 代码块。
 *
 * 为什么不让代码直接铺在气泡里：模型一写长串代码（几十行的脚本、整段配置），
 * 对话流就被冲得七零八落，用户要滑好久才能回到自己的问题。折叠收集之后，
 * 对话主干始终是「人话」，代码按需展开。
 */
sealed interface MsgSegment {
    data class Text(val text: String) : MsgSegment

    /**
     * @param lang 围栏标注的语言（可能为空）
     * @param closed 围栏是否已闭合；流式生成中最后一个代码块是未闭合的
     */
    data class Code(
        val lang: String,
        val code: String,
        val closed: Boolean
    ) : MsgSegment
}

/**
 * 把消息文本切成 文本 / 代码 交替的段。
 *
 * 规则对齐 CommonMark 的最小子集：三个反引号开始一个代码块，同一行反引号后
 * 的第一个词是语言标注，直到下一组三个反引号（或文本结束）为代码内容。
 * 围栏外的文字归为 [MsgSegment.Text]；空文本段丢弃。
 *
 * 纯函数：流式生成里每个 token 都会重算，必须便宜且可单测。
 */
fun parseMessageSegments(text: String): List<MsgSegment> {
    if (text.isEmpty()) return emptyList()
    val fence = "```"
    val segments = mutableListOf<MsgSegment>()
    var cursor = 0

    while (cursor < text.length) {
        val start = text.indexOf(fence, cursor)
        if (start < 0) {
            segments += MsgSegment.Text(text.substring(cursor))
            break
        }
        if (start > cursor) {
            segments += MsgSegment.Text(text.substring(cursor, start))
        }

        // 语言标注：开围栏之后到行尾
        val lineEnd = text.indexOf('\n', start + fence.length)
            .let { if (it < 0) text.length else it }
        val lang = text.substring(start + fence.length, lineEnd).trim()
        val codeStart = if (lineEnd < text.length) lineEnd + 1 else text.length

        val close = text.indexOf(fence, codeStart)
        if (close < 0) {
            // 流式中：代码块还没写完
            segments += MsgSegment.Code(lang, text.substring(codeStart), closed = false)
            cursor = text.length
        } else {
            segments += MsgSegment.Code(lang, text.substring(codeStart, close), closed = true)
            // 闭围栏那一行的换行是块级分隔，随围栏一起消耗，不产生空文本段
            cursor = close + fence.length
            if (cursor < text.length && text[cursor] == '\n') cursor++
        }
    }

    return segments.filterNot {
        it is MsgSegment.Text && it.text.isBlank()
    }
}

/**
 * 代码行数（用于折叠态展示）。空代码算 0 行。
 *
 * 末尾换行要先去掉：围栏里的代码通常以换行结束，直接数换行会**多算一行**，
 * 折叠卡上就会把一段 2 行的脚本标成 3 行。
 */
val MsgSegment.Code.lineCount: Int
    get() {
        val trimmed = code.trimEnd('\n', '\r')
        return if (trimmed.isEmpty()) 0 else trimmed.count { it == '\n' } + 1
    }

/**
 * 一条助手消息的「摘要视图」，供折叠态使用。
 *
 * ## 为什么需要折叠
 *
 * 对话一长，满屏都是历史回复和代码块，想回到之前某一轮得滑很久。
 * 把较旧的长回复压成一行摘要后，一屏能扫过十几轮对话 —— 定位历史靠的是
 * 「看标题」，而不是逐条重读。
 */
data class MessageDigest(
    /** 去掉代码块正文后的摘要文本。 */
    val preview: String,
    val textLength: Int,
    val codeBlocks: Int,
    val codeLines: Int
) {
    /**
     * 是否值得折叠。
     *
     * 短消息折叠只会平白多一次点击，所以设两道门槛：文字够长，或代码够多。
     */
    val worthCollapsing: Boolean
        get() = textLength >= COLLAPSE_MIN_CHARS || codeLines >= COLLAPSE_MIN_CODE_LINES

    companion object {
        const val COLLAPSE_MIN_CHARS = 600
        const val COLLAPSE_MIN_CODE_LINES = 24
    }
}

/**
 * 生成摘要（纯函数）。
 *
 * 代码块**不复制正文**，只留下「［代码 N 行］」占位 —— 那才是摘要该有的粒度：
 * 让人一眼看出"这条回复里有一段 40 行的脚本"，而不是把 40 行原样塞进折叠行。
 */
fun digestMessage(text: String, maxPreview: Int = 160): MessageDigest {
    val segments = parseMessageSegments(text)
    val builder = StringBuilder()
    var codeBlocks = 0
    var codeLines = 0

    segments.forEach { segment ->
        when (segment) {
            is MsgSegment.Text -> {
                val trimmed = segment.text.trim()
                if (trimmed.isNotEmpty()) {
                    if (builder.isNotEmpty()) builder.append(' ')
                    builder.append(trimmed)
                }
            }

            is MsgSegment.Code -> {
                codeBlocks++
                codeLines += segment.lineCount
                if (builder.isNotEmpty()) builder.append(' ')
                builder.append("［代码 ${segment.lineCount} 行］")
            }
        }
    }

    val flat = builder.toString().replace(Regex("\\s+"), " ").trim()
    val preview = if (flat.length <= maxPreview) flat else flat.take(maxPreview).trimEnd() + "…"
    return MessageDigest(
        preview = preview,
        textLength = text.length,
        codeBlocks = codeBlocks,
        codeLines = codeLines
    )
}
