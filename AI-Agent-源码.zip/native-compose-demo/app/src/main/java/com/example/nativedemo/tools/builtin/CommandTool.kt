package com.example.nativedemo.tools.builtin

import com.example.nativedemo.data.terminal.TerminalEngine
import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.int
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import kotlinx.coroutines.flow.collect
import kotlinx.serialization.json.JsonObject

/**
 * 在手机本机执行 shell 命令（`sh -c`），把模型武装成「能动手的系统管理员」。
 *
 * 与其他工具的区别与边界：
 * - 以**应用自身 UID** 运行，无 root。能读系统公开信息（getprop/uname/ps…）、
 *   能读写应用私有目录；共享存储要用户先在终端页授权「所有文件访问」。
 * - 默认**关闭**（见 [ToolSpec.defaultEnabled]）：这是全 App 能力面最大的工具，
 *   必须由用户在「工具权限」里显式打开。
 * - 有命令黑名单：模型幻觉出一条 `rm -rf /` 的代价是全机数据，必须拦在引擎前面。
 *   用户在终端页**手动**执行不受此限 —— 那是用户自己的决定，与模型无关。
 */
class CommandTool(
    private val engine: TerminalEngine
) : Tool {

    override val spec = ToolSpec(
        name = "run_command",
        description = "在手机本机执行一条 shell 命令（sh -c），返回 stdout/stderr 合并输出。" +
            "以应用自身权限运行，无 root；可读取系统信息、操作应用私有目录，" +
            "共享存储需用户已授权。输出超长会截断。",
        category = "系统",
        layer = "L1",
        defaultEnabled = false,
        destructive = true,
        securityNote = "允许模型执行任意 shell 命令。请只在你信任当前对话内容时开启；" +
            "终端页手动执行不受此开关影响。",
        params = objectSchema {
            string(
                "command",
                "要执行的完整 shell 命令，例如：ls -la /sdcard/Download 或 getprop ro.product.model"
            )
            integer(
                "timeout_seconds",
                "超时时间（秒），默认 30，最大 120。超时命令会被终止。",
                required = false
            )
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val command = try {
            args.requireStr("command")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }
        val timeoutSeconds = args.int("timeout_seconds", 30).coerceIn(1, MAX_TIMEOUT_SECONDS)

        val blocked = BLOCKED_PATTERNS.firstOrNull { it.containsMatchIn(command) }
        if (blocked != null) {
            return ToolResult.failure(
                "安全策略已拦截该命令（${blocked.pattern}）。" +
                    "如确需执行，请用户在 App 的「命令终端」页手动运行。"
            )
        }

        val output = StringBuilder()
        var exitCode: Int? = null
        var timedOut = false
        var durationMs = 0L
        var truncated = false

        return try {
            engine.run(command, timeoutMs = timeoutSeconds * 1000L).collect { event ->
                when (event) {
                    is TerminalEngine.Event.Output -> {
                        // 上限保护：模型上下文装不下一整片 find / 的输出
                        if (output.length < MAX_OUTPUT_CHARS) {
                            output.appendLine(event.text)
                            if (output.length >= MAX_OUTPUT_CHARS) truncated = true
                        }
                    }

                    is TerminalEngine.Event.Exit -> {
                        exitCode = event.code
                        timedOut = event.timedOut
                        durationMs = event.durationMs
                    }
                }
            }

            val body = output.toString().take(MAX_OUTPUT_CHARS)
            val header = buildString {
                appendLine("命令：$command")
                appendLine("退出码：${exitCode ?: "无"}")
                appendLine("耗时：${durationMs} ms")
                if (timedOut) appendLine("状态：已超时终止")
                if (truncated) appendLine("提示：输出超过 $MAX_OUTPUT_CHARS 字符，已截断")
                append("---")
            }
            ToolResult.success("$header\n$body".trimEnd())
        } catch (e: Throwable) {
            ToolResult.failure("命令执行失败：${e.message ?: e::class.java.simpleName}")
        }
    }

    companion object {
        const val MAX_OUTPUT_CHARS = 8_000
        const val MAX_TIMEOUT_SECONDS = 120

        /**
         * 命令黑名单。宁可误拦（用户还能去终端页手动跑），不可漏拦——
         * 模型生成的命令是在替用户做事，用户并没有逐字看过。
         *
         * 匹配前会先做「去选项」归一化之外的兜底：rm 的两条规则允许
         * `--no-preserve-root` 之类的长选项出现在标志与路径之间，
         * 否则 `rm -rf --no-preserve-root /` 就能绕过。
         */
        internal val BLOCKED_PATTERNS = listOf(
            // 递归删除且目标是根目录（含 /* 、后面跟 ; && | 的情况）
            Regex("""\brm\b[^|;&]*-[A-Za-z]*r[A-Za-z]*[^|;&]*\s+/(\s|;|&|\||\*|$)"""),
            // 递归删除且目标是关键目录（data/system/storage/sdcard…）
            Regex("""\brm\b[^|;&]*-[A-Za-z]*r[A-Za-z]*[^|;&]*\s+/(data|system|vendor|storage|sdcard|proc|sys|mnt)(/|\s|;|&|\||$)"""),
            // 格式化 / 关机重启
            Regex("""\b(mkfs|reboot|shutdown|poweroff|halt)\b"""),
            // 块设备裸写（dd of=…、直接重定向）
            Regex("""\bdd\b[^|;&]*of=/dev/"""),
            Regex(""">\s*/dev/(block|sd)"""),
            // fork 炸弹
            Regex(""":\s*\(\s*\)\s*\{.*\|.*&\s*\}"""),
            // 写系统伪文件
            Regex("""(>|>>)\s*/(proc|sys)/""")
        )
    }
}
