package com.example.nativedemo.tools.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * 安全网页抓取器。复刻参考实现（markitdown/_markitdown_sources.py）的防护范式：
 *
 * - 协议白名单（仅 http/https），拒绝 URL 内嵌账号密码
 * - DNS 解析后拒绝内网 / 本机 / 链路本地 / CGNAT 地址（防 SSRF）
 * - **手动处理重定向**：每次跳转都重新做主机校验，并限制跳转次数
 * - 流式读取，边读边算 SHA-256，并对 Content-Length 与累计字节做双上限
 * - 记录 URL 前对敏感 query 参数整体脱敏
 */
class SafeHttpFetcher {

    companion object {
        const val DEFAULT_MAX_BYTES = 2 * 1024 * 1024
        private const val MAX_REDIRECTS = 5
        private const val TIMEOUT_SECONDS = 20L
        private const val READ_CHUNK = 8 * 1024
        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Mobile Safari/537.36"
        private val SENSITIVE_QUERY_KEYS =
            setOf("token", "api_key", "apikey", "key", "password", "passwd", "signature", "sig", "access_token", "secret")
    }

    data class FetchResult(
        val finalUrl: String,
        val contentType: String,
        val body: ByteArray,
        val sha256: String,
        val truncated: Boolean
    )

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .followRedirects(false)
        .followSslRedirects(false)
        .build()

    private sealed interface Step {
        data class Redirect(val location: HttpUrl) : Step
        data class Done(val result: FetchResult) : Step
    }

    /**
     * 抓取一个 URL。
     *
     * [headers] 用于覆盖/追加请求头 —— 联网搜索需要它：搜索结果的可用性对
     * Referer 与 UA 很敏感，百度尤其如此（不带 Referer 常常直接返回验证页）。
     * 安全校验（协议白名单 / SSRF 拦截 / 重定向复检 / 大小上限）对调用方一视同仁。
     */
    suspend fun fetch(
        rawUrl: String,
        maxBytes: Int = DEFAULT_MAX_BYTES,
        headers: Map<String, String> = emptyMap(),
        timeoutSeconds: Long = TIMEOUT_SECONDS
    ): FetchResult =
        withContext(Dispatchers.IO) {
            val limit = if (maxBytes <= 0) DEFAULT_MAX_BYTES else maxBytes
            var url = validate(rawUrl)
            var redirects = 0

            while (true) {
                val builder = Request.Builder()
                    .url(url)
                    .header("User-Agent", USER_AGENT)
                    .header(
                        "Accept",
                        "text/html,application/xhtml+xml,application/xml,text/plain,application/json;q=0.9,*/*;q=0.5"
                    )
                headers.forEach { (name, value) ->
                    builder.header(name, value)
                }

                // 单次调用可覆盖超时：搜索要连打多个引擎，每个都得快进快出，
                // 沿用默认的 20 秒会让"四个引擎全挂"最坏拖到 80 秒。
                val call = client.newCall(builder.get().build())
                if (timeoutSeconds != TIMEOUT_SECONDS) {
                    call.timeout()?.timeout(timeoutSeconds, TimeUnit.SECONDS)
                }

                val step = call.execute().use { response ->
                    handle(response, limit)
                }

                when (step) {
                    is Step.Done -> return@withContext step.result
                    is Step.Redirect -> {
                        redirects++
                        if (redirects > MAX_REDIRECTS) {
                            throw SecurityException("重定向次数超过上限（$MAX_REDIRECTS 次），已中止")
                        }
                        url = validate(step.location.toString())
                    }
                }
            }
            @Suppress("UNREACHABLE_CODE")
            throw IllegalStateException("不可达")
        }

    private fun handle(response: okhttp3.Response, limit: Int): Step {
        if (response.isRedirect) {
            val location = response.header("Location")
                ?: throw IllegalStateException("服务端返回了重定向但缺少 Location 头")
            val next = response.request.url.resolve(location)
                ?: throw IllegalArgumentException("无法解析重定向目标：$location")
            return Step.Redirect(next)
        }

        if (!response.isSuccessful) {
            throw IllegalStateException("抓取失败：HTTP ${response.code} ${response.message}")
        }

        val body = response.body ?: throw IllegalStateException("响应没有内容体")
        val declared = body.contentLength()
        if (declared > limit) {
            throw IllegalStateException("响应体过大（${declared / 1024} KB），超过上限 ${limit / 1024} KB")
        }

        val out = ByteArrayOutputStream()
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(READ_CHUNK)
        var total = 0
        var truncated = false

        body.source().use { source ->
            while (true) {
                val read = source.read(buffer)
                if (read == -1) break
                total += read
                if (total > limit) {
                    truncated = true
                    break
                }
                out.write(buffer, 0, read)
                digest.update(buffer, 0, read)
            }
        }

        return Step.Done(
            FetchResult(
                finalUrl = response.request.url.toString(),
                contentType = body.contentType()?.toString().orEmpty(),
                body = out.toByteArray(),
                sha256 = digest.digest().joinToString("") { "%02x".format(it) },
                truncated = truncated
            )
        )
    }

    private fun validate(raw: String): HttpUrl {
        val url = raw.trim().toHttpUrlOrNull()
            ?: throw IllegalArgumentException("不是合法的 URL：$raw")
        if (url.scheme != "http" && url.scheme != "https") {
            throw SecurityException("仅支持 http/https 协议，收到：${url.scheme}")
        }
        if (url.username.isNotEmpty() || url.password.isNotEmpty()) {
            throw SecurityException("URL 中不允许包含用户名或密码")
        }
        assertPublicHost(url.host)
        return url
    }

    /** 解析主机名并拒绝一切非公网地址。 */
    private fun assertPublicHost(host: String) {
        val addresses = try {
            InetAddress.getAllByName(host)
        } catch (t: Throwable) {
            throw IllegalStateException("无法解析主机名：$host")
        }
        if (addresses.isEmpty()) throw IllegalStateException("无法解析主机名：$host")
        for (address in addresses) {
            if (isPrivate(address)) {
                throw SecurityException("已拦截内网地址访问：$host（${address.hostAddress}）")
            }
        }
    }

    private fun isPrivate(address: InetAddress): Boolean {
        if (address.isAnyLocalAddress ||
            address.isLoopbackAddress ||
            address.isLinkLocalAddress ||
            address.isSiteLocalAddress ||
            address.isMulticastAddress
        ) return true

        val bytes = address.address
        if (bytes.size == 16) {
            // IPv6 唯一本地地址 fc00::/7
            val b0 = bytes[0].toInt() and 0xFF
            if (b0 == 0xFC || b0 == 0xFD) return true
        }
        if (bytes.size == 4) {
            val b0 = bytes[0].toInt() and 0xFF
            val b1 = bytes[1].toInt() and 0xFF
            // CGNAT 100.64.0.0/10
            if (b0 == 100 && b1 in 64..127) return true
            // 192.0.0.0/24（含 IETF 保留段）
            if (b0 == 192 && b1 == 0 && (bytes[2].toInt() and 0xFF) == 0) return true
        }
        return false
    }

    /** 记录日志前对可能含凭证的 query 整体脱敏。 */
    fun redact(rawUrl: String): String {
        return try {
            val url = rawUrl.toHttpUrlOrNull() ?: return rawUrl
            if (url.querySize == 0) return rawUrl
            val hasSensitive = (0 until url.querySize).any { index ->
                url.queryParameterName(index).lowercase() in SENSITIVE_QUERY_KEYS
            }
            if (!hasSensitive) rawUrl else url.newBuilder().query("<redacted>").build().toString()
        } catch (t: Throwable) {
            rawUrl
        }
    }
}
