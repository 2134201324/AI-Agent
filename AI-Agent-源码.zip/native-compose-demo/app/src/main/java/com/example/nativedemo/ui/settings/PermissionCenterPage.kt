package com.example.nativedemo.ui.settings

import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.example.nativedemo.core.PermissionSnapshot
import com.example.nativedemo.core.ToolPermission
import com.example.nativedemo.core.ToolPermissions
import com.example.nativedemo.ui.common.Banner
import com.example.nativedemo.ui.common.BannerLevel
import com.example.nativedemo.ui.common.InfoCard
import com.example.nativedemo.ui.common.PrimaryButton
import com.example.nativedemo.ui.theme.Accent
import com.example.nativedemo.ui.theme.Danger
import com.example.nativedemo.ui.theme.Faint
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.LineColor
import com.example.nativedemo.ui.theme.Muted
import com.example.nativedemo.ui.theme.Warn

/**
 * 把「申请权限」串成一条流的编排器。
 *
 * ## 为什么需要它
 * App 需要的权限横跨三种申请方式：运行时弹窗、跳系统设置页、跳应用详情。
 * 逐个点一次还好，攒到五项就是五次来回 ——
 * "一键启动"的价值就是把这些串成一次连续操作，用户只需一路点下去。
 *
 * ## 为什么要等回调而不是一口气全发
 * 跳系统设置会**离开本应用**，必须等用户处理完返回后才能发下一个；
 * 一口气 startActivity 多次只会互相覆盖、只留下最后一个。
 * 所以这里是一个"发起一项 → 等回调 → 再发起下一项"的状态机。
 *
 * 状态用 Compose 的可变状态持有，因为它的消费者是界面（要显示"正在申请第几项"）。
 */
class PermissionFlow(
    private val context: Context,
    private val launchRuntime: (Array<String>) -> Unit,
    private val launchSettings: (Intent) -> Unit
) {

    var running by mutableStateOf(false)
        private set

    /** 当前正在申请的项，用于在界面上高亮。 */
    var current by mutableStateOf<ToolPermission?>(null)
        private set

    var message by mutableStateOf<String?>(null)
        private set

    private var queue: List<ToolPermission> = emptyList()
    private var remaining: Int = 0

    /** 一键启动：把「所有尚未授予、且本机适用」的项排成队列依次申请。 */
    fun start() {
        val pending = ToolPermissions.pending(context)
        if (pending.isEmpty()) {
            running = false
            current = null
            message = "所有权限都已就绪，无需申请。"
            return
        }
        queue = pending
        remaining = pending.size
        running = true
        message = "共 ${pending.size} 项待处理，正在依次申请…"
        step()
    }

    /** 单项申请：不进入队列，申请完就停。 */
    fun requestSingle(permission: ToolPermission) {
        if (running) return
        current = permission
        message = null
        dispatch(permission) { /* 不做队列推进 */ }
    }

    /** 由 ActivityResult 回调驱动：上一项处理完了，继续下一项。 */
    fun onStepFinished() {
        if (!running) {
            current = null
            return
        }
        step()
    }

    private fun step() {
        val next = queue.firstOrNull()
        queue = queue.drop(1)
        if (next == null) {
            running = false
            current = null
            message = "已依次处理完所有权限项。仍未开启的，可以单独点击重试（有些项需要你在系统页面里手动打开）。"
            return
        }
        current = next
        remaining = queue.size + 1
        message = "正在申请：${next.label()}（还剩 $remaining 项）"
        dispatch(next) { step() }
    }

    /**
     * 发起一项申请。
     *
     * [onCannotLaunch] 用于"这一项在本机无法通过 Intent 申请"（例如跳转目标不存在）
     * 时立刻跳过 —— 否则这个状态机会永远卡在等一个不会到来的回调上。
     */
    private fun dispatch(permission: ToolPermission, onCannotLaunch: () -> Unit) {
        try {
            val runtime = ToolPermissions.runtimePermissions(permission)
            if (runtime.isNotEmpty()) {
                launchRuntime(runtime)
                return
            }
            val intent = ToolPermissions.settingsIntent(context, permission)
            if (intent == null) {
                onCannotLaunch()
            } else {
                launchSettings(intent)
            }
        } catch (t: Throwable) {
            // 跳转失败（个别 ROM 裁掉了对应设置页）：跳过该项，别把整条流卡死
            message = "${permission.label()}：本机没有对应的设置页面，已跳过。"
            onCannotLaunch()
        }
    }
}

private fun ToolPermission.label(): String = when (this) {
    ToolPermission.NOTIFICATION -> "通知权限"
    ToolPermission.STORAGE -> "存储读写权限"
    ToolPermission.ALL_FILES -> "所有文件访问"
    ToolPermission.OVERLAY -> "悬浮窗权限"
    ToolPermission.BATTERY -> "电池优化白名单"
}

/**
 * 「工具权限」页。
 *
 * 上半部分是一键启动，下半部分是可单独操作的明细 —— 因为每个人的用法不同：
 * 只想让 AI 联网搜索的人不用开存储；而想让 AI 改包、联动 MT 的人，
 * 直接点一键最省事。
 */
@Composable
fun PermissionCenterPage() {
    val context = LocalContext.current

    var snapshots by remember { mutableStateOf(ToolPermissions.snapshot(context)) }
    fun refresh() {
        snapshots = ToolPermissions.snapshot(context)
    }

    // 从系统设置页切回来时自动刷新：用户在那边开了权限，回到这里应当立刻看到变化，
    // 而不是看到一个过期的"未开启"。
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refresh() }

    // 用一层可变状态打破"回调要引用 flow、flow 又要引用回调"的循环依赖
    val flowRef = remember { mutableStateOf<PermissionFlow?>(null) }

    val runtimeLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refresh()
        flowRef.value?.onStepFinished()
    }

    val settingsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        refresh()
        flowRef.value?.onStepFinished()
    }

    val flow = remember {
        PermissionFlow(
            context = context,
            launchRuntime = { permissions -> runtimeLauncher.launch(permissions) },
            launchSettings = { intent -> settingsLauncher.launch(intent) }
        )
    }
    SideEffect { flowRef.value = flow }

    val grantedCount = snapshots.count { !it.applicable || it.granted }
    val total = snapshots.size

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Banner(
            text = "这些是 Agent 工具链依赖的系统权限，按需开即可：只聊天不碰文件，可以一个都不开。",
            level = BannerLevel.INFO
        )

        InfoCard(title = "一键启动") {
            Text(
                text = "点一下，会把本机尚未授予的权限按顺序申请一遍。跳转系统页面时请在那里手动打开开关，" +
                    "处理完返回本应用，会自动继续下一项。",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
            Spacer(Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "$grantedCount / $total 项已就绪",
                    color = if (grantedCount == total) Accent else Fg,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { refresh() }) {
                    Text("刷新", color = Muted, fontSize = 12.sp)
                }
            }

            Spacer(Modifier.height(10.dp))
            PrimaryButton(
                text = if (grantedCount == total) "全部已开启（可复检）" else "一键开启全部所需权限",
                enabled = !flow.running
            ) { flow.start() }

            flow.message?.let { text ->
                Spacer(Modifier.height(10.dp))
                Text(
                    text = text,
                    color = if (flow.running) Accent else Muted,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        InfoCard(title = "权限明细") {
            Text(
                text = "每一项都可以单独申请。带「必需」标记的缺失时，对应工具会直接报错。",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
            Spacer(Modifier.height(6.dp))

            snapshots.forEachIndexed { index, snapshot ->
                if (index > 0) {
                    Spacer(
                        Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(LineColor)
                    )
                }
                PermissionRow(
                    snapshot = snapshot,
                    pendingNow = flow.current == snapshot.permission,
                    onRequest = { flow.requestSingle(snapshot.permission) }
                )
            }
        }

        InfoCard(title = "边界说明") {
            Text(
                text = "AI 不会操作你的手机：本应用不申请无障碍服务，没有任何" +
                    "「读取屏幕、模拟点击」能力。AI 能做的仅限于 —— 读写你授权的目录、" +
                    "在本机终端沙盒里执行命令、分析与改包、把 MT 管理器拉到某个路径" +
                    "（到那里之后由你自己接手）、以及联网搜索与抓取网页。\n\n" +
                    "风险较高的工具（mt_script、run_command 等）默认关闭，" +
                    "需要你到「设置 → 工具权限」里逐个打开，按对话生效、随时可关。",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
private fun PermissionRow(
    snapshot: PermissionSnapshot,
    pendingNow: Boolean,
    onRequest: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = snapshot.title,
                color = Fg,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            StatusChip(
                text = when {
                    !snapshot.applicable -> "无需"
                    snapshot.granted -> "已开启"
                    else -> "未开启"
                },
                ok = !snapshot.applicable || snapshot.granted
            )
        }

        Spacer(Modifier.height(4.dp))
        Text(
            text = snapshot.rationale,
            color = Muted,
            fontSize = 11.sp,
            lineHeight = 15.sp
        )

        snapshot.statusNote?.let { note ->
            Spacer(Modifier.height(4.dp))
            Text(
                text = note,
                color = if (snapshot.granted) Faint else Warn,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }

        if (snapshot.applicable && !snapshot.granted) {
            Spacer(Modifier.height(2.dp))
            TextButton(
                onClick = onRequest,
                enabled = !pendingNow
            ) {
                Text(
                    text = if (pendingNow) "申请中…" else "去开启",
                    color = if (pendingNow) Faint else Accent,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun StatusChip(text: String, ok: Boolean) {
    val color = when {
        ok -> Accent
        text == "未开启" -> Danger
        else -> Muted
    }
    Text(
        text = text,
        color = color,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(999.dp))
            .padding(horizontal = 9.dp, vertical = 3.dp)
    )
}
