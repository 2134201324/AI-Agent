package com.example.nativedemo.tools

import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull

/** 从模型给出的 arguments（JsonObject）里安全取值。 */
fun JsonObject.str(name: String): String? =
    (this[name] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }

fun JsonObject.requireStr(name: String): String =
    str(name) ?: throw IllegalArgumentException("缺少必填参数 '$name'")

fun JsonObject.int(name: String, default: Int): Int =
    (this[name] as? JsonPrimitive)?.intOrNull ?: default

fun JsonObject.bool(name: String, default: Boolean = false): Boolean =
    (this[name] as? JsonPrimitive)?.contentOrNull?.toBooleanStrictOrNull() ?: default
