package com.example.nativedemo.core

import android.content.Context
import com.example.nativedemo.data.agent.ChatSession
import com.example.nativedemo.service.ChatForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

/**
 * 把「会话是否在跑、跑到哪一步」翻译成前台服务与通知栏。
 *
 * 放在 AppContainer 这一层而不是 ViewModel：通知的生命周期要和**任务**一致，
 * 而不是和界面一致 —— 用户切走之后通知仍要显示进度，生成结束才消失。
 */
class ChatNotifier(
    private val context: Context,
    private val session: ChatSession,
    scope: CoroutineScope
) {

    init {
        scope.launch {
            // 曾经真的在跑过才需要停服务：否则应用一启动就会白发一次 ACTION_STOP，
            // 白白把服务拉起来又停掉
            var everRan = false

            combine(session.running, session.progress) { running, progress -> running to progress }
                .distinctUntilChanged()
                .collect { (running, progress) ->
                    if (running) {
                        everRan = true
                        if (progress.isBlank()) {
                            ChatForegroundService.start(context, "正在生成回复…")
                        } else {
                            ChatForegroundService.update(context, progress)
                        }
                    } else if (everRan) {
                        everRan = false
                        ChatForegroundService.stop(context)
                    }
                }
        }
    }
}
