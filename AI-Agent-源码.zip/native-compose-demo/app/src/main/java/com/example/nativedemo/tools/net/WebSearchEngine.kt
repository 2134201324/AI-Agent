package com.example.nativedemo.tools.net

import java.net.URLDecoder

/**
 * 联网搜索：把搜索引擎的结果页（HTML）解析成结构化的「标题 / 链接 / 摘要」。
 *
 * ## 为什么不用搜索 API
 * Bing / Google 的官方搜索 API 要付费、要 Key，而用户在这个 App 里最不想干的事
 * 就是再配一个 Key。公开搜索引擎的**网页版结果页**对普通 GET 请求是可读的，
 * 解析它的 HTML 就得到了一份免 Key 的搜索结果 —— 代价是解析规则会随对方改版失效，
 * 所以这里做了三件事来兜住：多引擎轮换、每个引擎配专属解析、专属解析为空时退化到通用启发式。
 *
 * ## 反爬的现实
 * 数据中心 IP 常常拿不到结果（返回验证页或空页），而真实手机上的家用/移动网络通常可以。
 * 因此**解析器写宽松一些、宁可多带点噪音也别漏**：漏掉一条结果模型无从知晓，
 * 多带一条导航链接它自己会忽略。
 */
enum class SearchEngine(val id: String, val label: String) {
    BING("bing", "Bing"),
    SO360("360", "360 搜索"),
    BAIDU("baidu", "百度"),
    DUCKDUCKGO("duckduckgo", "DuckDuckGo");

    companion object {
        fun fromId(value: String?): SearchEngine? =
            value?.trim()?.lowercase()?.let { id -> entries.firstOrNull { it.id == id } }

        /**
         * 默认轮换顺序。
         *
         * Bing 打头：它的结果页结构最稳定、对非浏览器请求最宽容，中文质量也够用；
         * 百度放在后面 —— 它对异常 UA/无 Cookie 的请求最容易返回验证页，
         * 而一旦被拦会拖慢整次搜索，所以让它做备选而不是首选。
         */
        val DEFAULT_ORDER = listOf(BING, SO360, BAIDU, DUCKDUCKGO)
    }
}

data class SearchHit(
    val title: String,
    val url: String,
    val snippet: String
) {
    fun render(): String = buildString {
        appendLine(title)
        appendLine("  $url")
        if (snippet.isNotBlank()) appendLine("  $snippet")
    }.trimEnd()
}

object SerpParser {

    /** 搜索引擎自身域名：结果里指向它们的链接是导航/翻页，不是答案。 */
    private val ENGINE_HOSTS = listOf(
        "bing.com", "microsofttranslator", "msn.com",
        "so.com", "360.cn", "360kuai.com", "qihoo.com",
        "baidu.com", "bdstatic.com",
        "duckduckgo.com", "google.com", "gstatic.com",
        "sogou.com", "toutiao.com", "sina.com.cn/sf"
    )

    fun parse(engine: SearchEngine, html: String, limit: Int): List<SearchHit> {
        val primary = when (engine) {
            SearchEngine.BING -> parseBing(html)
            SearchEngine.SO360 -> parse360(html)
            SearchEngine.BAIDU -> parseBaidu(html)
            SearchEngine.DUCKDUCKGO -> parseDuckDuckGo(html)
        }
        // 专属规则没命中（对方改版了）时，用通用启发式再捞一次 ——
        // 拿到的是"大概能用"的结果，也远好过整个工具直接失败。
        val candidates = if (primary.isEmpty()) primary + genericAnchors(html) else primary

        // 清洗放在最后统一做：兜底结果同样要过滤与去重，
        // 否则它会绕过这些规则，把站内跳转链接和重复项直接递给模型。
        return candidates
            .filter { it.url.startsWith("http") && it.title.length >= 4 }
            .filter { !isEngineHost(it.url) }
            .distinctBy { it.url.substringBefore('#') }
            .take(limit)
    }

    // ── Bing ────────────────────────────────────────────────────────────
    // 结构：<li class="b_algo"> … <div class="b_algoheader">
    //            <a href="真实地址"><h2>标题</h2></a></div>
    //            <div class="b_caption"><p>摘要</p></div> … </li>
    private fun parseBing(html: String): List<SearchHit> {
        val blockSplit = html.split(Regex("""<li class="b_algo""""))
        val out = mutableListOf<SearchHit>()
        for (index in 1 until blockSplit.size) {
            val block = blockSplit[index].take(12_000)
            val head = Regex(
                """<a[^>]*href="(https?://[^"]+)"[^>]*>\s*<h2[^>]*>(.*?)</h2>""",
                RegexOption.DOT_MATCHES_ALL
            ).find(block) ?: continue
            val url = decodeEntities(head.groupValues[1])
            val title = cleanHtml(head.groupValues[2])
            if (title.isBlank()) continue
            val snippet = Regex("""<p[^>]*>(.*?)</p>""", RegexOption.DOT_MATCHES_ALL)
                .find(block)?.groupValues?.get(1)
                ?.let { cleanHtml(it) }
                .orEmpty()
            out += SearchHit(title, url, snippet)
        }
        return out
    }

    // ── 360 搜索 ────────────────────────────────────────────────────────
    // 结果锚点的 href 是站内跳转（m.so.com/jump?u=…），真实地址藏在容器
    // 的 data-url 属性里 —— 所以不能按 href 走，必须先拿到 data-url 再向后找标题。
    private fun parse360(html: String): List<SearchHit> {
        val out = mutableListOf<SearchHit>()
        val head = Regex(
            """data-url="(https?://[^"]+)"[\s\S]{0,3000}?<h3[^>]*class="res-title[^"]*"[^>]*>([\s\S]*?)</h3>"""
        )
        for (match in head.findAll(html)) {
            val url = decodeEntities(match.groupValues[1])
            val title = cleanHtml(match.groupValues[2])
            if (title.isBlank()) continue
            val after = html.substring(match.range.last, minOf(html.length, match.range.last + 4000))
            val snippet = Regex("""class="con[^"]*"[^>]*>([\s\S]*?)</div>""")
                .find(after)?.groupValues?.get(1)
                ?.let { cleanHtml(it) }
                .orEmpty()
            out += SearchHit(title, url, snippet)
        }
        return out
    }

    // ── 百度 ────────────────────────────────────────────────────────────
    // 百度的结果容器 class 常年在变（result / c-container / result-op…），
    // 唯一稳定的是「div 带 mu 或 data-url 属性指向真实地址」。拿不到就交给通用兜底。
    private fun parseBaidu(html: String): List<SearchHit> {
        val out = mutableListOf<SearchHit>()
        val pattern = Regex(
            """<(?:div|h3)[^>]*class="[^"]*(?:result|c-container)[^"]*"[^>]*>[\s\S]{0,800}?""" +
                """<a[^>]*href="(https?://[^"]+)"[^>]*>([\s\S]{0,300}?)</a>"""
        )
        for (match in pattern.findAll(html)) {
            val url = decodeEntities(match.groupValues[1])
            val title = cleanHtml(match.groupValues[2])
            if (title.length < 4) continue
            out += SearchHit(title, url, "")
        }
        return out
    }

    // ── DuckDuckGo（HTML 版）────────────────────────────────────────────
    private fun parseDuckDuckGo(html: String): List<SearchHit> {
        val out = mutableListOf<SearchHit>()
        val titles = Regex(
            """class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)</a>"""
        ).findAll(html).toList()
        val snippets = Regex(
            """class="result__snippet"[^>]*>([\s\S]*?)</a>"""
        ).findAll(html).toList()

        titles.forEachIndexed { index, match ->
            val url = unwrapDuckDuckGo(decodeEntities(match.groupValues[1]))
            val title = cleanHtml(match.groupValues[2])
            if (title.isBlank()) return@forEachIndexed
            val snippet = snippets.getOrNull(index)?.groupValues?.get(1)
                ?.let { cleanHtml(it) }
                .orEmpty()
            out += SearchHit(title, url, snippet)
        }
        return out
    }

    /** DDG 的链接被包成 `//duckduckgo.com/l/?uddg=<编码后的真实地址>`。 */
    private fun unwrapDuckDuckGo(url: String): String {
        if (!url.contains("uddg=")) return if (url.startsWith("//")) "https:$url" else url
        return try {
            val raw = url.substringAfter("uddg=").substringBefore('&')
            URLDecoder.decode(raw, "UTF-8")
        } catch (t: Throwable) {
            url
        }
    }

    // ── 通用兜底 ────────────────────────────────────────────────────────

    /**
     * 不认 class、只认语义：凡是「链接文字足够长、且不指向搜索引擎自己」的锚点，
     * 都当成一条结果。噪音肯定比专属解析多，但能保证对方改版后工具不至于直接哑掉。
     */
    private fun genericAnchors(html: String): List<SearchHit> {
        val out = mutableListOf<SearchHit>()
        val anchor = Regex("""<a\s[^>]*href="(https?://[^"]+)"[^>]*>([\s\S]*?)</a>""")
        for (match in anchor.findAll(html)) {
            if (out.size >= 40) break
            val url = decodeEntities(match.groupValues[1])
            val title = cleanHtml(match.groupValues[2])
            // 过滤"更多""登录""下一页"这类短导航文本
            if (title.length < 10) continue
            if (isEngineHost(url)) continue
            out += SearchHit(title, url, "")
        }
        return out
    }

    private fun isEngineHost(url: String): Boolean =
        ENGINE_HOSTS.any { url.contains(it, ignoreCase = true) }

    /** 去掉标签 + 解码实体 + 压平空白。 */
    fun cleanHtml(raw: String): String = decodeEntities(
        raw.replace(Regex("""<(script|style)[\s\S]*?</\1>""", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("<[^>]+>"), " ")
    ).replace(Regex("\\s+"), " ").trim()

    /** 只处理 HTML 里真正会出现在正文中的那几个实体，够用且不会误伤。 */
    fun decodeEntities(raw: String): String {
        if (!raw.contains('&')) return raw
        return raw
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
            .replace("&hellip;", "…")
            .replace("&middot;", "·")
            .replace("&mdash;", "—")
            .replace("&ndash;", "–")
            .replace(Regex("&#(\\d{1,6});")) { m ->
                m.groupValues[1].toIntOrNull()?.let { codePoint ->
                    runCatching { String(Character.toChars(codePoint)) }.getOrDefault("")
                } ?: ""
            }
            .replace(Regex("&#[xX]([0-9a-fA-F]{1,6});")) { m ->
                m.groupValues[1].toIntOrNull(16)?.let { codePoint ->
                    runCatching { String(Character.toChars(codePoint)) }.getOrDefault("")
                } ?: ""
            }
    }

    /** 结果页的字符集：优先 HTTP 头，其次页面 meta，最后按 UTF-8 赌一把。 */
    fun detectCharset(bytes: ByteArray, contentType: String?): String {
        val fromHeader = contentType?.let { Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(it) }
            ?.groupValues?.get(1)
        if (fromHeader != null) return normalize(fromHeader)

        val head = String(bytes, 0, minOf(bytes.size, 4096), Charsets.ISO_8859_1)
        val fromMeta = Regex(
            """<meta[^>]+charset=["']?([\w-]+)""",
            RegexOption.IGNORE_CASE
        ).find(head)?.groupValues?.get(1)
        return normalize(fromMeta ?: "UTF-8")
    }

    /**
     * 把字符集别名收敛成 Java 认识的标准名。
     * 注意 `utf-8` 这类**小写带横线**的写法在 HTTP 头里极常见，
     * 不归一化会让后续 `Charset.forName` 拿到一个大小写不匹配的名字。
     */
    private fun normalize(name: String): String = when (name.lowercase()) {
        "gb2312", "gbk", "gb18030", "x-gbk" -> "GB18030"
        "utf8", "utf-8" -> "UTF-8"
        "big5", "big-5" -> "Big5"
        "iso-8859-1", "latin1" -> "ISO-8859-1"
        else -> name
    }
}
