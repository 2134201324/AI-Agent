package com.example.nativedemo.data.llm

import java.net.URI

/**
 * 本地桥接（网页桥接版）的端点语义。
 *
 * **为什么会有「API Key」这个问题**：OpenAI 兼容协议规定客户端在
 * `Authorization` 头里带 Bearer 令牌，几乎所有 SDK / 客户端都硬编码了这个头。
 * 而 DSH（DeepSeek-Harness）一类网页桥接工具是把你浏览器里的网页登录态
 * 转发出去，**本来就不校验令牌** —— 它要的是网页会话，不是 API Key。
 *
 * 也就是说：桥接版根本不需要 API Key，之前的「必须填一个 Key」纯粹是
 * 协议形式带来的摩擦。这里把「本地端点」识别出来，让它自动免 Key：
 * 客户端改用占位令牌（个别桥接实现要求该头存在才放行），用户不必再管。
 */

/**
 * 桥接端点用的占位令牌。
 *
 * 并不用于鉴权 —— 只是让 `Authorization` 头「存在且格式合法」，
 * 以兼容那些会对缺失请求头直接 4xx 的桥接实现。
 */
const val LOCAL_BRIDGE_PLACEHOLDER_KEY = "sk-bridge-local"

/** 从 Base URL 里取出主机名；解析不了返回 null。 */
private fun hostOf(baseUrl: String): String? {
    val raw = baseUrl.trim()
    if (raw.isEmpty()) return null
    // 允许用户只填 host:port（没写 scheme）
    val withScheme = if (raw.contains("://")) raw else "http://$raw"
    return runCatching { URI(withScheme).host }
        .getOrNull()
        ?.lowercase()
        ?.removeSurrounding("[", "]")
        ?.takeIf { it.isNotBlank() }
}

/**
 * 是否「本地 / 局域网」端点（无需 API Key 的那些）。
 *
 * 覆盖：回环地址、私有网段（10/8、172.16/12、192.168/16）、链路本地
 * （169.254/16，手机热点直连常见）、`.local` 这类 mDNS 名、容器别名。
 */
fun isLocalEndpoint(baseUrl: String): Boolean {
    val host = hostOf(baseUrl) ?: return false
    if (host == "localhost" || host.endsWith(".localhost")) return true
    if (host == "::1" || host == "0.0.0.0") return true
    if (host.endsWith(".local") || host == "host.docker.internal") return true

    val octets = host.split(".")
    if (octets.size != 4) return false
    val values = octets.map { it.toIntOrNull() ?: return false }
    if (values.any { it !in 0..255 }) return false
    val (a, b) = values
    return when {
        a == 127 -> true // 回环
        a == 10 -> true // 私有 A 段
        a == 192 && b == 168 -> true // 私有 C 段
        a == 172 && b in 16..31 -> true // 私有 B 段
        a == 169 && b == 254 -> true // 链路本地
        else -> false
    }
}

/**
 * 求实际要发送的令牌：用户填的优先，本地端点或桥接模式留空则自动用占位令牌。
 *
 * @param bridgeMode 该配置被标记为「网页桥接」。**不能只看地址是否局域网** ——
 *   桥接跑在电脑上、手机在内网穿透（公网域名）下访问时地址是 https 公网域名，
 *   但依然不需要 Key。所以需要这个显式标记兜底。
 *
 * 返回 null 表示「云服务却没有任何 Key」—— 上层应拦住并提示填写。
 */
fun effectiveApiKey(
    baseUrl: String,
    apiKey: String?,
    bridgeMode: Boolean = false
): String? =
    apiKey?.trim()?.takeIf { it.isNotEmpty() }
        ?: LOCAL_BRIDGE_PLACEHOLDER_KEY.takeIf { bridgeMode || isLocalEndpoint(baseUrl) }

/**
 * 把用户填的地址规范成可用的 Base URL。
 *
 * 这是「配置过程绝对简化」的关键一环：用户手上只有一个形如
 * `192.168.1.5:8000` 的地址，而客户端需要的是 `http://192.168.1.5:8000/v1`。
 * 与其要求用户补齐协议、端口、版本层，不如全部自动纠正。
 *
 * 处理三件最常见的事：
 * 1. 缺协议 → 补 `http://`（本地服务几乎都是 http）；
 * 2. 粘贴进来的具体接口地址（`.../chat/completions`）→ 剥掉，
 *    否则客户端再拼一次会变成 `.../chat/completions/chat/completions` 直接 404；
 * 3. 只有主机、没有路径 → 补版本层 `/v1`。
 *
 * 注意：**已有路径的地址原样保留** —— 云服务商的路径千奇百怪
 * （如百炼的 `/compatible-mode/v1`、智谱的 `/api/paas/v4`），不能乱改。
 */
fun normalizeBaseUrl(raw: String): String {
    var s = raw.trim().trimEnd('/')
    if (s.isEmpty()) return s

    for (suffix in listOf("/chat/completions", "/completions")) {
        if (s.endsWith(suffix, ignoreCase = true)) {
            s = s.dropLast(suffix.length).trimEnd('/')
        }
    }
    if (s.isEmpty()) return s

    if (!s.contains("://")) s = "http://$s"

    val path = runCatching { URI(s) }.getOrNull()?.path.orEmpty()
    return if (path.isBlank() || path == "/") "$s/v1" else s
}

/**
 * 从模型清单里挑一个「最可能可用」的默认项。
 *
 * 桥接通常会把多个网页模型都列出来，用户面对列表需要一个合理默认值：
 * 聊天场景首选 deepseek-chat（便宜、够用），其次任何 deepseek 系，
 * 最后兜底取第一个。
 */
fun pickPreferredModel(models: List<String>): String? {
    if (models.isEmpty()) return null
    val pairs = models.map { it to it.lowercase() }
    return (
        pairs.firstOrNull { (_, lower) -> lower == "deepseek-chat" }
            ?: pairs.firstOrNull { (_, lower) -> lower.startsWith("deepseek-chat") }
            ?: pairs.firstOrNull { (_, lower) -> lower.startsWith("deepseek") }
            ?: pairs.firstOrNull { (_, lower) -> lower.contains("chat") }
            ?: pairs.firstOrNull()
        )?.first
}
