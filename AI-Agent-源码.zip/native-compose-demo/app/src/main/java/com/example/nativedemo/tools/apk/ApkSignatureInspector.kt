package com.example.nativedemo.tools.apk

import android.content.Context
import android.content.pm.PackageManager
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipFile

/** APK 用了哪几种签名方案。 */
data class ApkSigningSchemes(
    val v1: Boolean,
    val v2: Boolean,
    val v3: Boolean,
    /** v3.1：支持密钥轮换的增量方案。 */
    val v31: Boolean
) {
    val any: Boolean get() = v1 || v2 || v3 || v31

    fun describe(): String = buildList {
        if (v1) add("v1（JAR 签名）")
        if (v2) add("v2（APK Signature Scheme v2）")
        if (v3) add("v3（含密钥轮换信息）")
        if (v31) add("v3.1（旋转密钥）")
    }.joinToString("、").ifEmpty { "未检测到任何签名方案" }
}

/** 一张签名证书的关键信息。 */
data class CertInfo(
    val subject: String,
    val issuer: String,
    val serial: String,
    val notBefore: String,
    val notAfter: String,
    val signatureAlgorithm: String,
    val sha256: String,
    val sha1: String
) {
    val isSelfSigned: Boolean get() = subject == issuer
    val isExpired: Boolean
        get() = runCatching { DATE_FORMAT.parse(notAfter)?.before(Date()) == true }.getOrDefault(false)

    private companion object {
        val DATE_FORMAT = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    }
}

/**
 * APK 签名检查。
 *
 * ## 逆向分析为什么先看签名
 *
 * - **判断是否重打包**：与原版签名指纹不一致，基本就是被改过的包（塞广告、改逻辑）；
 * - **判断自签名 / 调试证书**：`CN=Android Debug` 说明是开发构建；
 * - **看签名方案**：只有 v1 而没有 v2/v3 的包通常是老工具链打的，某些加固/改包
 *   工具也会留下这个特征。
 *
 * ## 两件事分两条路做
 *
 * - **方案检测**走纯文件解析：v1 看 `META-INF` 下有没有签名文件，v2/v3 看
 *   「APK Signing Block」里有没有对应的 id —— 这段不依赖 Android 框架，可单测；
 * - **证书信息**走 `PackageManager`：系统已经实现了证书链解析，没必要重复造。
 */
object ApkSignatureInspector {

    /** APK Signing Block 的尾部魔数。 */
    private val SIG_BLOCK_MAGIC = "APK Sig Block 42".toByteArray(Charsets.US_ASCII)

    private const val ID_V2 = 0x7109871A
    private const val ID_V31 = 0x1B93AD61

    /**
     * v3 的 id 超过 Int 正区间，必须显式 `.toInt()` ——
     * 否则字面量会被推断成 Long，与 `List<Int>` 比较时类型不匹配。
     */
    private val ID_V3 = 0xF05368C0.toInt()

    /** EOCD 之前允许的最大扫描距离。 */
    private const val MAX_EOCD_SCAN = 0xFFFF + 22

    /** 检测签名方案（纯文件解析，不依赖 Android 框架）。 */
    fun detectSchemes(file: File): ApkSigningSchemes {
        val v1 = detectV1(file)
        val blockIds = runCatching { signingBlockIds(file) }.getOrDefault(emptyList<Int>())
        return ApkSigningSchemes(
            v1 = v1,
            v2 = ID_V2 in blockIds,
            v3 = ID_V3 in blockIds,
            v31 = ID_V31 in blockIds
        )
    }

    /** v1：`META-INF` 下存在 `.RSA` / `.DSA` / `.EC` 签名块。 */
    private fun detectV1(file: File): Boolean = runCatching {
        ZipFile(file).use { zip ->
            zip.entries().asSequence().any { entry ->
                val name = entry.name.uppercase(Locale.US)
                name.startsWith("META-INF/") &&
                    (name.endsWith(".RSA") || name.endsWith(".DSA") || name.endsWith(".EC"))
            }
        }
    }.getOrDefault(false)

    /**
     * 读出 APK Signing Block 里全部 id。
     *
     * 定位方式：EOCD 给出中央目录偏移，而签名块**紧贴在中央目录之前**，
     * 其尾部 16 字节是固定魔数。所以从 `cdOffset - 16` 反着读即可，不必全文扫描。
     */
    private fun signingBlockIds(file: File): List<Int> {
        if (file.length() < 32) return emptyList()
        val raf = RandomAccessFile(file, "r")
        try {
            val fileLength = raf.length()

            val eocd = findEocd(raf) ?: return emptyList()
            raf.seek(eocd + 16)
            val cdOffset = readU32(raf)
            if (cdOffset < 32 || cdOffset > fileLength) return emptyList()

            // 签名块的尾部 16 字节是固定魔数，紧贴在中央目录之前
            raf.seek(cdOffset - 16)
            val magic = ByteArray(16)
            raf.readFully(magic)
            if (!magic.contentEquals(SIG_BLOCK_MAGIC)) return emptyList()

            // 魔数前 8 字节是块长度（不含自身），据此回推块起点
            raf.seek(cdOffset - 24)
            val blockSize = readU64(raf)
            if (blockSize < 24 || blockSize > cdOffset) return emptyList()
            val blockStart = cdOffset - 8 - blockSize
            if (blockStart < 0) return emptyList()

            raf.seek(blockStart)
            val leadingSize = readU64(raf)
            // 首尾长度必须一致，否则不是合法签名块（可能只是恰巧撞上魔数）
            if (leadingSize != blockSize) return emptyList()

            // id-value 对：[uint64 长度][uint32 id][value...]，长度含 id 自身的 4 字节
            val ids = mutableListOf<Int>()
            var pos = blockStart + 8
            val pairsEnd = cdOffset - 24
            while (pos + 12 <= pairsEnd) {
                raf.seek(pos)
                val pairSize = readU64(raf)
                if (pairSize < 4 || pos + 8 + pairSize > pairsEnd) break
                val id = readU32(raf).toInt()
                ids += id
                pos += 8 + pairSize
            }
            return ids
        } finally {
            runCatching { raf.close() }
        }
    }

    private fun findEocd(raf: RandomAccessFile): Long? {
        val fileLength = raf.length()
        val scan = minOf(fileLength, MAX_EOCD_SCAN.toLong()).toInt()
        if (scan < 22) return null
        val buffer = ByteArray(scan)
        raf.seek(fileLength - scan)
        raf.readFully(buffer)
        // 从后往前找第一条 EOCD 记录（注释区可能包含同名字节，所以要倒着找）
        for (i in buffer.size - 22 downTo 0) {
            if (buffer[i] == 0x50.toByte() && buffer[i + 1] == 0x4B.toByte() &&
                buffer[i + 2] == 0x05.toByte() && buffer[i + 3] == 0x06.toByte()
            ) {
                return fileLength - scan + i
            }
        }
        return null
    }

    private fun readU32(raf: RandomAccessFile): Long {
        val b = ByteArray(4)
        raf.readFully(b)
        return (b[0].toLong() and 0xFF) or
            ((b[1].toLong() and 0xFF) shl 8) or
            ((b[2].toLong() and 0xFF) shl 16) or
            ((b[3].toLong() and 0xFF) shl 24)
    }

    private fun readU64(raf: RandomAccessFile): Long {
        val low = readU32(raf)
        val high = readU32(raf)
        return low or (high shl 32)
    }

    /**
     * 读取签名证书（依赖 Android 框架）。
     *
     * 允许文件路径而不是 URI：此时 APK 已被复制到应用私有目录，路径一定可读。
     */
    fun certificates(context: Context, file: File): List<CertInfo> {
        val pm = context.packageManager
        val info = runCatching {
            @Suppress("DEPRECATION")
            pm.getPackageArchiveInfo(file.absolutePath, PackageManager.GET_SIGNATURES)
        }.getOrNull() ?: return emptyList()

        val signatures = info.signatures.orEmpty()
        return signatures.mapNotNull { signature ->
            runCatching {
                val cert = java.security.cert.CertificateFactory
                    .getInstance("X.509")
                    .generateCertificate(signature.toByteArray().inputStream()) as X509Certificate
                toCertInfo(cert)
            }.getOrNull()
        }
    }

    private fun toCertInfo(cert: X509Certificate): CertInfo = CertInfo(
        subject = cert.subjectX500Principal.name,
        issuer = cert.issuerX500Principal.name,
        serial = cert.serialNumber.toString(16),
        notBefore = format(cert.notBefore),
        notAfter = format(cert.notAfter),
        signatureAlgorithm = cert.sigAlgName ?: "",
        sha256 = digest(cert.encoded, "SHA-256"),
        sha1 = digest(cert.encoded, "SHA-1")
    )

    private fun format(date: Date): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(date)

    private fun digest(bytes: ByteArray, algorithm: String): String =
        MessageDigest.getInstance(algorithm).digest(bytes)
            .joinToString(":") { "%02X".format(it) }
}
