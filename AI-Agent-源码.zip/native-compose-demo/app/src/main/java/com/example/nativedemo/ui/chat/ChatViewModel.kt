package com.example.nativedemo.ui.chat

import android.net.Uri
import android.util.Base64
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.nativedemo.core.AppContainer
import com.example.nativedemo.core.AppError
import com.example.nativedemo.data.agent.AgentConfig
import com.example.nativedemo.data.agent.AgentEngine
import com.example.nativedemo.data.agent.ConversationFile
import com.example.nativedemo.data.agent.ConversationMeta
import com.example.nativedemo.data.agent.ConversationSanitizer
import com.example.nativedemo.data.agent.Orchestrator
import com.example.nativedemo.data.agent.OrchestratorEvent
import com.example.nativedemo.data.agent.ResolvedProfile
import com.example.nativedemo.data.agent.ToolInvocation
import com.example.nativedemo.data.agent.UiMessage
import com.example.nativedemo.data.agent.UiRole
import com.example.nativedemo.data.llm.effectiveApiKey
import com.example.nativedemo.data.llm.normalizeBaseUrl
import com.example.nativedemo.data.settings.AgentSettings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import java.io.ByteArrayOutputStream

class ChatViewModel(
    private val container: AppContainer
) : ViewModel() {

    private val repository = container.conversationRepository
    private val appContext = container.appContext

    /**
     * 消息与运行态都取自应用级会话（见 [com.example.nativedemo.data.agent.ChatSession]）。
     *
     * 不再由本 ViewModel 自己持有：界面会随转屏/回收销毁重建，状态若跟着走，
     * 用户切回来就会看到"生成到一半没了"，而后台那一轮其实还在跑。
     */
    private val chatSession = container.chatSession

    val messages: StateFlow<List<UiMessage>> = chatSession.messages

    private val _conversations = MutableStateFlow<List<ConversationMeta>>(emptyList())
    val conversations: StateFlow<List<ConversationMeta>> = _conversations.asStateFlow()

    private val _currentId = MutableStateFlow(container.conversationStore.conversationId)
    val currentId: StateFlow<String> = _currentId.asStateFlow()

    val running: StateFlow<Boolean> = chatSession.running

    init {
        // 开屏保持「新对话」，历史会话从侧边栏进入 —— 与 DeepSeek 的习惯一致
        viewModelScope.launch { refreshList() }
    }

    /**
     * 从断点继续上一次未完成的任务。
     *
     * 用在「工具轮次额度用尽」这类可续跑的失败上：已经做完的每一步都还在会话历史里，
     * 再发一句话就等于从断点续跑。提示词特意强调「别重做已完成的步骤」——
     * 否则模型很容易从头再来一遍，把新额度又烧在同一段上。
     */
    fun continueTask() {
        send(CONTINUE_TASK_PROMPT)
    }

    fun send(rawInput: String, attachments: List<ChatAttachment> = emptyList()) {
        val input = rawInput.trim()
        if ((input.isEmpty() && attachments.isEmpty()) || chatSession.running.value) return

        chatSession.setRunning(true)

        chatSession.job = container.launchInBackground {
            try {
                val settings = container.settingsRepository.snapshot()

                // 编排开关（用户最高权限的体现）：开着且配置齐全就走多模型链路
                if (settings.orchestrationReady) {
                    runOrchestration(settings, input, attachments)
                    return@launchInBackground
                }

                val activeProfile = settings.activeProfile
                val config: AgentConfig = if (activeProfile != null) {
                    // 选用档案：地址 / 模型 / Key 全部来自档案
                    val bridge = activeProfile.bridgeMode
                    val profileKey = effectiveApiKey(
                        activeProfile.baseUrl,
                        container.settingsRepository.apiKeyForProfile(activeProfile),
                        bridge
                    )
                    if (profileKey == null) {
                        appendError("档案「${activeProfile.label}」的 API Key 解密失败，请在「设置 → 多模型编排」重新填写。")
                        return@launchInBackground
                    }
                    buildAgentConfig(activeProfile.baseUrl, profileKey, activeProfile.model, bridge, settings)
                } else {
                    // 桥接模式 / 局域网地址都不需要 Key：effectiveApiKey 会自动补占位令牌
                    val bridge = settings.bridgeMode
                    val apiKey = effectiveApiKey(settings.baseUrl, container.settingsRepository.apiKey(), bridge)
                    if (apiKey == null) {
                        appendError("尚未配置 API Key。点击左上角菜单进入「设置」填写后再试。")
                        return@launchInBackground
                    }
                    buildAgentConfig(settings.baseUrl, apiKey, settings.model, bridge, settings)
                }

                val (content, displayText) = buildUserContent(input, attachments)
                chatSession.updateMessages { it + UiMessage(role = UiRole.USER, text = displayText) }

                container.agentEngine.run(
                    userContent = content,
                    config = config,
                    toolContext = container.newToolContext()
                ) { event -> handleEvent(event) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                appendError(e.message ?: "发生未知错误")
            } finally {
                finishStreaming()
                chatSession.setRunning(false)
        lastProgress = ""
                persistAndRefresh()
            }
        }
    }

    /**
     * 组装单模型请求配置。
     *
     * 两处与「网页桥接」有关的差异：
     * - 地址先规范化：用户往往只拿到 `192.168.1.5:8000` 这样的地址，
     *   补齐协议与 `/v1` 才可用；
     * - **不发 tools**：网页桥接转发的是浏览器里的网页会话，基本不支持
     *   function calling；带上 tools 很容易被服务端直接拒绝，表现就是
     *   「网页桥接版无法调用」。
     */
    private fun buildAgentConfig(
        baseUrl: String,
        apiKey: String,
        model: String,
        bridgeMode: Boolean,
        settings: AgentSettings
    ) = AgentConfig(
        baseUrl = normalizeBaseUrl(baseUrl),
        apiKey = apiKey,
        model = model,
        temperature = settings.temperature,
        systemPrompt = settings.systemPrompt,
        enabledTools = if (bridgeMode) emptySet() else settings.enabledTools,
        maxOutputTokens = settings.maxOutputTokens.takeIf { it > 0 },
        maxToolRounds = settings.maxToolRounds
    )

    /**
     * 多模型编排链路：主模型拆任务 → 多个子模型并行生成 → 主模型整合纠错。
     *
     * 与单模型链路共用同一条 job / running / 持久化管道，只是把事件源换成
     * [Orchestrator]。档案的 Key 在这里统一解密：任何一个解不开都整体放弃本轮
     * 并指明是哪个档案，而不是让子任务带着 null Key 悄悄失败。
     */
    private suspend fun runOrchestration(
        settings: AgentSettings,
        input: String,
        attachments: List<ChatAttachment>
    ) {
        val orchestratorProfile = settings.orchestrator
        val subProfiles = settings.subProfiles
        if (orchestratorProfile == null || subProfiles.isEmpty()) {
            appendError("多模型编排尚未配置好：需要 1 个主模型和至少 1 个子模型，请到「设置 → 多模型编排」检查。")
            return
        }

        val orchestratorKey = effectiveApiKey(
            orchestratorProfile.baseUrl,
            container.settingsRepository.apiKeyForProfile(orchestratorProfile),
            orchestratorProfile.bridgeMode
        )
        if (orchestratorKey == null) {
            appendError("主模型「${orchestratorProfile.label}」的 API Key 解密失败，请在「设置 → 多模型编排」重新填写。")
            return
        }

        val resolvedSubs = mutableListOf<ResolvedProfile>()
        for (profile in subProfiles) {
            val key = effectiveApiKey(
                profile.baseUrl,
                container.settingsRepository.apiKeyForProfile(profile),
                profile.bridgeMode
            )
            if (key == null) {
                appendError("子模型「${profile.label}」的 API Key 解密失败，请在「设置 → 多模型编排」重新填写。")
                return
            }
            resolvedSubs += ResolvedProfile(
                id = profile.id,
                label = profile.label,
                baseUrl = normalizeBaseUrl(profile.baseUrl),
                model = profile.model,
                apiKey = key,
                // 网页桥接转发的是网页会话，不支持 function calling ——
                // 明确标记为 false，编排会走「不用工具的 JSON 降级」路径
                toolsSupported = if (profile.bridgeMode) false else profile.toolsSupported
            )
        }

        val (content, displayText) = buildUserContent(input, attachments)
        chatSession.updateMessages { it + UiMessage(role = UiRole.USER, text = displayText) }

        val orchestrator = ResolvedProfile(
            id = orchestratorProfile.id,
            label = orchestratorProfile.label,
            baseUrl = normalizeBaseUrl(orchestratorProfile.baseUrl),
            model = orchestratorProfile.model,
            apiKey = orchestratorKey,
            toolsSupported = if (orchestratorProfile.bridgeMode) false else orchestratorProfile.toolsSupported
        )

        container.orchestrator.run(
            userContent = content,
            orchestrator = orchestrator,
            subs = resolvedSubs,
            maxOutputTokens = settings.maxOutputTokens.takeIf { it > 0 }
        ) { event -> handleOrchestrationEvent(event) }
    }

    fun stop() {
        chatSession.job?.cancel()
        chatSession.job = null
        finishStreaming()
        chatSession.setRunning(false)
        persistAndRefresh()
    }

    fun newConversation() {
        viewModelScope.launch {
            persistNow()
            container.conversationStore.reset()
            _currentId.value = container.conversationStore.conversationId
            chatSession.setMessages(emptyList())
            refreshList()
        }
    }

    fun openConversation(id: String) {
        if (id == _currentId.value) return
        viewModelScope.launch {
            persistNow()
            val data = repository.load(id)
            if (data == null) {
                refreshList()
                return@launch
            }

            // 已落盘的会话可能残留 arguments 非法的 tool_call —— 那会让之后每一轮
            // 请求都返回 400，而重开 App 也修不好。在打开时净化并回存，让存量中毒会话自愈。
            val cleaned = ConversationSanitizer.analyze(data.llmMessages)
            container.conversationStore.restore(
                id = data.id,
                createdAt = data.createdAt,
                history = cleaned.messages
            )
            if (cleaned.changed) {
                repository.save(data.copy(llmMessages = cleaned.messages))
            }

            _currentId.value = data.id
            chatSession.setMessages(data.uiMessages.map { it.copy(streaming = false) })
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            repository.delete(id)
            if (id == _currentId.value) {
                container.conversationStore.reset()
                _currentId.value = container.conversationStore.conversationId
                chatSession.setMessages(emptyList())
            }
            refreshList()
        }
    }

    // ── 附件读取 ──────────────────────────────────────────────────────

    /**
     * 把「文本 + 附件」组装成一条用户消息。
     *
     * 返回两个值：给模型的内容（可能是多模态数组），以及界面上展示的摘要文本
     * —— 图片的 base64 绝不能出现在界面里。
     */
    private suspend fun buildUserContent(
        text: String,
        attachments: List<ChatAttachment>
    ): Pair<JsonElement, String> {
        if (attachments.isEmpty()) {
            return JsonPrimitive(text) to text
        }

        val parts = mutableListOf<JsonElement>()
        val display = mutableListOf<String>()

        if (text.isNotBlank()) {
            parts += JsonPrimitive(text)
            display += text
        }

        attachments.forEach { attachment ->
            when (attachment.kind) {
                ChatAttachment.Kind.FILE -> {
                    val body = readText(attachment.uri, MAX_TEXT_BYTES)
                    parts += JsonPrimitive("【附件：${attachment.name}】\n$body")
                    display += "📎 ${attachment.name}"
                }

                ChatAttachment.Kind.DIRECTORY -> {
                    val tree = listDirectory(attachment.uri)
                    parts += JsonPrimitive("【文件夹：${attachment.name}】\n$tree")
                    display += "📁 ${attachment.name}"
                }

                ChatAttachment.Kind.IMAGE -> {
                    val base64 = readBase64(attachment.uri, MAX_IMAGE_BYTES)
                    if (base64 != null) {
                        val mime = attachment.mimeType.ifBlank { "image/jpeg" }
                        parts += buildJsonObject {
                            put("type", "image_url")
                            putJsonObject("image_url") {
                                put("url", "data:$mime;base64,$base64")
                            }
                        }
                        display += "🖼 ${attachment.name}"
                    } else {
                        display += "🖼 ${attachment.name}（读取失败或超过 ${MAX_IMAGE_BYTES / 1024 / 1024}MB）"
                    }
                }
            }
        }

        val content: JsonElement = if (parts.size == 1) parts.first() else JsonArray(parts)
        return content to display.joinToString("\n")
    }

    private suspend fun readText(uri: Uri, maxBytes: Int): String = withContext(Dispatchers.IO) {
        runCatching {
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                var truncated = false
                while (true) {
                    val read = input.read(buffer)
                    if (read == -1) break
                    if (total + read > maxBytes) {
                        out.write(buffer, 0, maxBytes - total)
                        truncated = true
                        break
                    }
                    out.write(buffer, 0, read)
                    total += read
                }
                out.toByteArray().toString(Charsets.UTF_8) +
                    if (truncated) "\n…（内容过长，已截断）" else ""
            } ?: "（无法读取该文件）"
        }.getOrDefault("（读取失败）")
    }

    private suspend fun readBase64(uri: Uri, maxBytes: Int): String? = withContext(Dispatchers.IO) {
        runCatching {
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                val bytes = input.readBytes()
                if (bytes.size > maxBytes) null
                else Base64.encodeToString(bytes, Base64.NO_WRAP)
            }
        }.getOrNull()
    }

    private suspend fun listDirectory(uri: Uri): String = withContext(Dispatchers.IO) {
        runCatching {
            val root = DocumentFile.fromTreeUri(appContext, uri)
            if (root == null || !root.isDirectory) return@runCatching "（无法打开该文件夹）"
            val sb = StringBuilder()
            fun walk(dir: DocumentFile, indent: String, depth: Int) {
                if (depth > MAX_DIR_DEPTH) return
                val children = runCatching { dir.listFiles() }.getOrDefault(emptyArray())
                children
                    .sortedWith(compareByDescending<DocumentFile> { it.isDirectory }.thenBy { it.name ?: "" })
                    .take(MAX_DIR_ENTRIES)
                    .forEach { child ->
                        if (child.isDirectory) {
                            sb.appendLine("$indent${child.name}/")
                            walk(child, "$indent  ", depth + 1)
                        } else {
                            sb.appendLine("$indent${child.name}（${child.length()} B）")
                        }
                    }
            }
            walk(root, "", 1)
            sb.toString().ifBlank { "（空文件夹）" }
        }.getOrDefault("（读取失败）")
    }

    // ── 事件处理 ──────────────────────────────────────────────────────

    private fun handleEvent(event: AgentEngine.Event) {
        // 通知栏进度：用户切出去之后，靠它知道跑到哪一步了
        progressOfEngineEvent(event)?.let { updateProgress(it) }

        when (event) {
            // 流式增量：追加到当前正在生成的那条消息尾部
            is AgentEngine.Event.AssistantDelta -> appendAssistantDelta(event.text)

            // 思考增量：单独挂在消息的 thinking 字段上，折叠展示
            is AgentEngine.Event.ThinkingDelta -> appendThinkingDelta(event.text)

            is AgentEngine.Event.AssistantText -> appendAssistantText(event.text)

            is AgentEngine.Event.Notice -> appendNotice(event.text)

            is AgentEngine.Event.ToolStarted -> appendToolCard(
                callId = event.callId,
                name = event.name,
                arguments = event.arguments
            )

            is AgentEngine.Event.ToolFinished -> updateToolCard(
                callId = event.callId,
                ok = event.ok,
                preview = event.preview
            )

            is AgentEngine.Event.Failed -> appendEngineError(event.error, event.resumable)

            AgentEngine.Event.Done -> finishStreaming()
        }
    }

    /**
     * 编排事件 → 界面。
     *
     * 复用现有组件、零新增 UI 原子元素：
     * - 阶段提示 → SYSTEM 横幅（[UiRole.SYSTEM]）；
     * - 任务 / 询问 → 工具卡（`ToolCallCard`），按 callId 更新状态；
     * - 流式整合文本 / 失败 / 收尾 → 与单模型链路完全相同的处理。
     */
    private fun handleOrchestrationEvent(event: OrchestratorEvent) {
        progressOfOrchestrationEvent(event)?.let { updateProgress(it) }

        when (event) {
            is OrchestratorEvent.Phase ->
                chatSession.updateMessages { it + UiMessage(role = UiRole.SYSTEM, text = event.text) }

            is OrchestratorEvent.PlanReady -> {
                val summary = buildString {
                    append("📋 任务拆解（${event.tasks.size} 项）：")
                    event.tasks.forEachIndexed { index, task ->
                        append("\n${index + 1}. ${task.title}")
                    }
                }
                chatSession.updateMessages { it + UiMessage(role = UiRole.SYSTEM, text = summary) }
            }

            is OrchestratorEvent.TaskStarted -> appendToolCard(
                callId = event.task.id,
                name = "🤖 ${event.agentLabel} · ${event.task.title}",
                arguments = event.task.instruction
            )

            is OrchestratorEvent.TaskFinished -> updateToolCard(
                callId = event.taskId,
                ok = event.ok,
                preview = event.preview
            )

            is OrchestratorEvent.AskIssued -> appendToolCard(
                callId = event.askId,
                name = "💬 ${event.fromLabel} → ${event.toLabel}",
                arguments = event.question
            )

            is OrchestratorEvent.AskAnswered -> updateToolCard(
                callId = event.askId,
                ok = true,
                preview = event.answer
            )

            is OrchestratorEvent.AssistantDelta -> appendAssistantDelta(event.text)

            is OrchestratorEvent.AssistantText -> appendAssistantText(event.text)

            is OrchestratorEvent.Failed -> appendEngineError(event.error)

            OrchestratorEvent.Done -> finishStreaming()
        }
    }

    /** 流式增量：追加到当前正在生成的那条消息尾部；没有就新起一条。 */
    /** 上一条写进通知栏的进度，用于去重。 */
    private var lastProgress = ""

    /**
     * 更新通知栏进度。
     *
     * 必须去重：流式生成时 [AgentEngine.Event.AssistantDelta] 每来一个 token 触发一次，
     * 若每次都 notify，通知栏会被刷爆（既费电又闪屏）。文本没变就什么都不做。
     */
    private fun updateProgress(text: String) {
        if (text == lastProgress) return
        lastProgress = text
        chatSession.setProgress(text)
    }

    /** 引擎事件 → 一句进度；null 表示这一步不值得更新通知。 */
    private fun progressOfEngineEvent(event: AgentEngine.Event): String? = when (event) {
        is AgentEngine.Event.ThinkingDelta -> "正在思考…"
        is AgentEngine.Event.AssistantDelta -> "正在生成回复…"
        is AgentEngine.Event.ToolStarted -> "正在执行工具 ${event.name}"
        is AgentEngine.Event.ToolFinished -> "工具执行完毕，继续生成…"
        else -> null
    }

    /** 编排事件 → 一句进度；Phase 本身就是给用户看的阶段描述，直接复用。 */
    private fun progressOfOrchestrationEvent(event: OrchestratorEvent): String? = when (event) {
        is OrchestratorEvent.Phase -> event.text
        is OrchestratorEvent.TaskStarted -> "子任务执行中：${event.task.title}"
        is OrchestratorEvent.AssistantDelta -> "正在整合结果…"
        else -> null
    }

    private fun appendAssistantDelta(text: String) {
        if (text.isEmpty()) return
        chatSession.updateMessages { list ->
            val last = list.lastOrNull()
            if (last != null &&
                last.role == UiRole.ASSISTANT &&
                last.streaming &&
                last.toolInvocations.isEmpty()
            ) {
                list.dropLast(1) + last.copy(text = last.text + text)
            } else if (text.isBlank()) {
                // 纯空白增量不单独起一条消息。
                //
                // 模型（尤其在带工具调用的长任务里）常在正文前后吐一串换行；
                // 若此刻刚好没有正在流式的助手消息（比如上一轮以工具卡收尾），
                // 这一串换行就会被建成一条**只有空白、却占满一整屏高度**的消息 ——
                // 用户看到的就是两段内容之间莫名其妙的一大片空行。
                // 换行本身没有展示价值，等有实际内容时再起消息即可。
                list
            } else {
                list + UiMessage(role = UiRole.ASSISTANT, text = text, streaming = true)
            }
        }
    }

    /**
     * 思考增量：挂在同一条消息的 [UiMessage.thinking] 上。
     *
     * 与正文分开存放有两个原因：界面要折叠展示；更重要的是**它不能进入对话
     * 历史** —— 多数服务商不允许回传 reasoning_content，混进去下一轮就 400。
     */
    private fun appendThinkingDelta(text: String) {
        chatSession.updateMessages { list ->
            val last = list.lastOrNull()
            if (last != null && last.role == UiRole.ASSISTANT && last.streaming) {
                list.dropLast(1) + last.copy(thinking = (last.thinking ?: "") + text)
            } else {
                list + UiMessage(role = UiRole.ASSISTANT, thinking = text, streaming = true)
            }
        }
    }

    /**
     * 过程提示（自动续写、自动降级…）单独成条，不混进正文。
     *
     * 顺便把上一条流式消息收尾：否则光标会一直闪在已经不动的消息上。
     */
    private fun appendNotice(text: String) {
        chatSession.updateMessages { list ->
            val finalized = if (list.lastOrNull()?.streaming == true) {
                list.dropLast(1) + list.last().copy(streaming = false)
            } else {
                list
            }
            finalized + UiMessage(role = UiRole.SYSTEM, text = text)
        }
    }

    /** 非流式整段文本：收尾流式消息，或与上一条助手消息拼接，或新起一条。 */
    private fun appendAssistantText(text: String) {
        chatSession.updateMessages { list ->
            val last = list.lastOrNull()
            if (last != null && last.role == UiRole.ASSISTANT && last.streaming) {
                // 流式已写过一遍，这里只负责收尾
                list.dropLast(1) + last.copy(streaming = false)
            } else if (last != null &&
                last.role == UiRole.ASSISTANT &&
                last.toolInvocations.isEmpty() &&
                last.text.isNotBlank()
            ) {
                list.dropLast(1) + last.copy(
                    text = last.text + "\n\n" + text,
                    streaming = false
                )
            } else {
                list + UiMessage(role = UiRole.ASSISTANT, text = text)
            }
        }
    }

    /** 追加一张「执行中」的工具卡；先把还在流式的消息收尾，保证时间线不乱。 */
    private fun appendToolCard(callId: String, name: String, arguments: String) {
        chatSession.updateMessages { list ->
            val settled = list.map { if (it.streaming) it.copy(streaming = false) else it }
            settled + UiMessage(
                role = UiRole.ASSISTANT,
                toolInvocations = listOf(
                    ToolInvocation(
                        callId = callId,
                        name = name,
                        arguments = arguments,
                        state = ToolInvocation.State.RUNNING
                    )
                )
            )
        }
    }

    /** 按 callId 找到工具卡并更新终态与结果摘要。 */
    private fun updateToolCard(callId: String, ok: Boolean, preview: String?) {
        chatSession.updateMessages { list ->
            list.map { message ->
                if (message.toolInvocations.none { it.callId == callId }) {
                    message
                } else {
                    message.copy(
                        toolInvocations = message.toolInvocations.map { invocation ->
                            if (invocation.callId != callId) {
                                invocation
                            } else {
                                invocation.copy(
                                    state = if (ok) {
                                        ToolInvocation.State.SUCCESS
                                    } else {
                                        ToolInvocation.State.FAILED
                                    },
                                    resultPreview = preview
                                )
                            }
                        }
                    )
                }
            }
        }
    }

    private fun appendEngineError(error: AppError, resumable: Boolean = false) {
        appendError(
            buildString {
                append(error.message)
                error.hint?.let { append("\n提示：").append(it) }
            },
            resumable = resumable
        )
    }

    private fun finishStreaming() {
        chatSession.updateMessages { list ->
            if (list.none { it.streaming }) list
            else list.map { if (it.streaming) it.copy(streaming = false) else it }
        }
    }

    private fun appendError(text: String, resumable: Boolean = false) {
        chatSession.updateMessages {
            it + UiMessage(role = UiRole.ERROR, text = text, resumable = resumable)
        }
    }

    // ── 持久化 ────────────────────────────────────────────────────────

    private fun persistAndRefresh() {
        viewModelScope.launch {
            persistNow()
            refreshList()
        }
    }

    private suspend fun persistNow() {
        val id = _currentId.value
        val ui = chatSession.messages.value.map { it.copy(streaming = false) }
        val llm = container.conversationStore.snapshot()
        if (ui.isEmpty() && llm.isEmpty()) return

        repository.save(
            ConversationFile(
                id = id,
                title = deriveTitle(ui),
                createdAt = container.conversationStore.createdAt,
                updatedAt = System.currentTimeMillis(),
                uiMessages = ui,
                llmMessages = llm
            )
        )
    }

    private suspend fun refreshList() {
        _conversations.value = repository.list()
    }

    private fun deriveTitle(ui: List<UiMessage>): String =
        ui.firstOrNull { it.role == UiRole.USER }
            ?.text
            ?.replace('\n', ' ')
            ?.trim()
            ?.take(24)
            ?.takeIf { it.isNotEmpty() }
            ?: "新对话"

    companion object {
        /**
         * 「接着做」的提示词。
         *
         * 关键是最后半句：不叮嘱的话，模型常常把已经跑完的步骤重来一遍，
         * 新给的额度又花在同一段路上，用户会觉得「点了继续也没往前走」。
         */
        private const val CONTINUE_TASK_PROMPT =
            "继续执行上一个任务，从中断处接着做。已经完成并写入的成果不要重复执行，" +
                "直接推进剩下的步骤；全部完成后给出结论。"

        private const val MAX_TEXT_BYTES = 200_000
        private const val MAX_IMAGE_BYTES = 3 * 1024 * 1024
        private const val MAX_DIR_DEPTH = 3
        private const val MAX_DIR_ENTRIES = 200

        fun factory(container: AppContainer) = viewModelFactory {
            initializer { ChatViewModel(container) }
        }
    }
}
