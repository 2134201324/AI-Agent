package com.example.nativedemo.data.agent

import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * 当前这一轮对话的运行态。
 *
 * ## 为什么要从 ViewModel 里搬出来
 *
 * `ViewModel` 会随 Activity 销毁而清掉（转屏、切后台被系统回收、用户从最近任务划走），
 * 而一轮生成可能要跑几分钟（多轮工具调用 + 长回复）。状态跟着 ViewModel 走，就会
 * 出现「切回来发现生成到一半没了」—— 这正是「进后台有概率被中断」的表象之一。
 *
 * 搬到全局单例后：
 * - 界面重建 → 新的 ViewModel 订阅同一份状态，消息与"正在运行"都不丢；
 * - 生成任务跑在 Application 级作用域里，**不随界面销毁而取消**；
 * - 配合前台服务，切后台也能继续跑完。
 */
class ChatSession {

    private val _messages = MutableStateFlow<List<UiMessage>>(emptyList())
    val messages: StateFlow<List<UiMessage>> = _messages.asStateFlow()

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    /** 当前进度的一句话描述，用于通知栏。 */
    private val _progress = MutableStateFlow("")
    val progress: StateFlow<String> = _progress.asStateFlow()

    /**
     * 正在执行的那一轮。
     *
     * 也放在这里：`stop()` 需要在界面重建后依然能取消到正确的任务。
     */
    @Volatile
    var job: Job? = null

    fun updateMessages(block: (List<UiMessage>) -> List<UiMessage>) = _messages.update(block)

    fun setMessages(list: List<UiMessage>) {
        _messages.value = list
    }

    fun setRunning(value: Boolean) {
        _running.value = value
        // 收尾时清掉进度，否则下次启动前会闪一下上一轮的旧文案
        if (!value) _progress.value = ""
    }

    fun setProgress(text: String) {
        _progress.value = text
    }
}
