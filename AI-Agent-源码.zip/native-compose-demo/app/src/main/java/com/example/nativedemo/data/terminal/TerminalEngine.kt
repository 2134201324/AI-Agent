package com.example.nativedemo.data.terminal

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

/**
 * 命令终端执行引擎 —— App 内的「沙盒版 Termux」。
 *
 * 每条命令都以 `/system/bin/sh -c` 起一个**独立进程**，以应用自身 UID 运行：
 * - 能跑：toybox 全家桶（ls/cat/grep/find/ps/df/getprop/uname…）、应用私有目录读写
 * - 不能跑：root 命令、访问其他应用私有数据、apt 装包（没有包管理器也没有权限）
 *
 * 两个关键设计：
 * 1. **流式输出** —— 边执行边吐行，`ps`/`find` 这类长命令不用等结束才看到内容；
 * 2. **可停止 + 超时** —— `ping` 之类的命令会永远跑下去，必须有停止按钮与默认超时。
 *    超时/取消时 `destroyForcibly` 整个进程，读写管道随之关闭，读取循环自然退出。
 */
class TerminalEngine(private val workDir: File) {

    sealed interface Event {
        /** 一行（或一块）标准输出/错误（已合并重定向）。 */
        data class Output(val text: String) : Event

        /**
         * 命令结束。
         * [code] 为 null 表示没拿到退出码（启动失败、被强杀、超时）。
         * [error] 非空表示启动阶段就失败了。
         */
        data class Exit(
            val code: Int?,
            val timedOut: Boolean,
            val durationMs: Long,
            val error: String? = null
        ) : Event
    }

    @Volatile
    private var current: Process? = null
    private val lock = Any()

    /** 停止最近一次执行的命令。没有在跑的命令时是空操作。 */
    fun stop() {
        synchronized(lock) { current }?.destroyForcibly()
    }

    /**
     * 执行一条命令，输出以 [Event] 流的形式发出。
     *
     * @param cwd 命令的工作目录（每次调用独立，shell 的 cd 不会跨命令保留 ——
     *            需要持久目录的由上层自己跟踪，见 TerminalViewModel）
     * @param timeoutMs 超时；超时后强杀进程并发出 timedOut 的 Exit
     */
    fun run(
        command: String,
        cwd: File = workDir,
        timeoutMs: Long = DEFAULT_TIMEOUT_MS
    ): Flow<Event> = channelFlow {
        val startedAt = System.currentTimeMillis()

        val process = try {
            ProcessBuilder("/system/bin/sh", "-c", command)
                .directory(cwd.takeIf { it.isDirectory } ?: workDir)
                .apply {
                    // sh 默认继承应用进程环境；HOME 指向应用私有目录，
                    // 避免某些工具把配置写到不可写的位置
                    environment()["HOME"] = workDir.absolutePath
                    environment()["TMPDIR"] = workDir.absolutePath
                }
                .redirectErrorStream(true)
                .start()
        } catch (e: Throwable) {
            send(
                Event.Exit(
                    code = null,
                    timedOut = false,
                    durationMs = System.currentTimeMillis() - startedAt,
                    error = e.message ?: e::class.java.simpleName
                )
            )
            return@channelFlow
        }

        synchronized(lock) { current = process }
        var timedOut = false
        try {
            val reader = BufferedReader(InputStreamReader(process.inputStream, Charsets.UTF_8))

            // 读取必须放在子协程里：readLine() 是阻塞系统调用，协程取消**中断不了**
            // 它 —— 所以超时（sleep 300 这种不出输出的命令）唯一的解脱方式是
            // 杀掉进程让管道关闭，readLine 才会返回 null。
            val readJob = launch(Dispatchers.IO) {
                try {
                    while (isActive) {
                        val line = reader.readLine() ?: break
                        send(Event.Output(line))
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Throwable) {
                    // 读流异常（进程被杀时的管道错误）：静默结束，退出信息由下面统一发
                }
            }

            val completed = withTimeoutOrNull(timeoutMs.coerceAtLeast(1_000L)) { readJob.join() }
            if (completed == null) {
                timedOut = true
                process.destroyForcibly()
                // 给读取循环一点时间，把管道里残留的输出排空再发结束事件
                withTimeoutOrNull(GRACE_MS) { readJob.join() }
            }

            val code = if (timedOut) null else runCatching { process.waitFor() }.getOrNull()
            send(
                Event.Exit(
                    code = code,
                    timedOut = timedOut,
                    durationMs = System.currentTimeMillis() - startedAt
                )
            )
        } finally {
            // 双保险：即使读取循环异常退出也要收尸，避免僵尸进程
            runCatching { process.destroyForcibly() }
            synchronized(lock) { if (current === process) current = null }
        }
    }

    companion object {
        /** UI 终端默认超时：60 秒。绝大多数命令远小于此；长命令用「停止」按钮。 */
        const val DEFAULT_TIMEOUT_MS = 60_000L

        /** 超时杀进程后，等读取循环排空管道的最长时间。 */
        private const val GRACE_MS = 2_000L
    }
}
