package com.example.nativedemo.data.agent

import kotlinx.serialization.Serializable
import java.util.UUID

/** 界面展示用的消息模型。加 @Serializable 是为了随会话一起落盘。 */

@Serializable
enum class UiRole { USER, ASSISTANT, SYSTEM, ERROR }

@Serializable
data class ToolInvocation(
    val callId: String,
    val name: String,
    val arguments: String,
    val state: State = State.RUNNING,
    val resultPreview: String? = null
) {
    @Serializable
    enum class State { RUNNING, SUCCESS, FAILED }
}

@Serializable
data class UiMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: UiRole,
    val text: String = "",
    val toolInvocations: List<ToolInvocation> = emptyList(),
    /**
     * 推理模型的思考过程（reasoning_content）。
     *
     * 只用于界面展示，**不进入对话历史** —— 多数服务商不接受把思考内容回传，
     * 混进消息体里会导致下一轮直接 400。
     */
    val thinking: String? = null,
    /** 正在流式接收中：决定增量是追加还是新起一条，也用于显示光标 */
    val streaming: Boolean = false,
    /**
     * 这条失败消息是否「可以接着做」。
     *
     * 例如工具轮次额度用尽 —— 任务没失败，只是这一步停下来歇口气。
     * 界面据此给出「继续」按钮，用户点一下就能让它接着跑完，
     * 而不必自己想一句提示词。
     */
    val resumable: Boolean = false
)
