package com.example.nativedemo.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import com.example.nativedemo.data.settings.AppBrand
import com.example.nativedemo.data.settings.BackdropStats
import com.example.nativedemo.data.settings.ColorSlot
import com.example.nativedemo.data.settings.FontScaleOption
import com.example.nativedemo.data.settings.ThemeMode

/**
 * 应用主题。
 *
 * 参数都来自用户设置，改动后立即全局生效：
 * - [brand] 品牌色
 * - [mode] 深浅模式（可跟随系统）
 * - [fontScale] 字号档位，通过覆盖 LocalDensity 的 fontScale 实现 ——
 *   这样所有以 sp 书写的尺寸一起缩放，不必逐个改字号常量。
 * - [colorOverrides] 逐槽手动覆盖；[smartStats] 非空时启用「智能图文适配」，
 *   按背景图推导文字色，且 [colorOverrides] 优先。
 */
@Composable
fun AppTheme(
    brand: AppBrand = AppBrand.default,
    mode: ThemeMode = ThemeMode.default,
    fontScale: FontScaleOption = FontScaleOption.default,
    colorOverrides: Map<ColorSlot, Long> = emptyMap(),
    smartStats: BackdropStats? = null,
    content: @Composable () -> Unit
) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }

    val palette = remember(brand, dark, colorOverrides, smartStats) {
        AppPalette.of(brand, dark).withSmartText(smartStats).withOverrides(colorOverrides)
    }
    // 同步写入全局调色板：content 在本函数之后才组合，
    // 因此第一帧读到的就已经是新配色，不会闪。
    Palette.apply(brand, dark, colorOverrides, smartStats)

    val density = LocalDensity.current
    val scaledDensity = remember(density, fontScale) {
        Density(density = density.density, fontScale = density.fontScale * fontScale.value)
    }

    val scheme = if (dark) {
        darkColorScheme(
            primary = palette.accent,
            onPrimary = Color.White,
            secondary = palette.accent2,
            onSecondary = Color(0xFF06231C),
            background = palette.bg,
            onBackground = palette.fg,
            surface = palette.bg,
            onSurface = palette.fg,
            surfaceVariant = palette.chipBg,
            onSurfaceVariant = palette.muted,
            outline = palette.lineColor,
            outlineVariant = palette.lineColor,
            error = palette.danger,
            onError = Color.White
        )
    } else {
        lightColorScheme(
            primary = palette.accent,
            onPrimary = Color.White,
            secondary = palette.accent2,
            onSecondary = Color.White,
            background = palette.bg,
            onBackground = palette.fg,
            surface = palette.bg,
            onSurface = palette.fg,
            surfaceVariant = palette.chipBg,
            onSurfaceVariant = palette.muted,
            outline = palette.lineColor,
            outlineVariant = palette.lineColor,
            error = palette.danger,
            onError = Color.White
        )
    }

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalDensity provides scaledDensity) {
            content()
        }
    }
}
