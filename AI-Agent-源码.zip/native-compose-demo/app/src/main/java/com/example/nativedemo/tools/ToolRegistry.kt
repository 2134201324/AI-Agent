package com.example.nativedemo.tools

import com.example.nativedemo.data.llm.FunctionDefinition
import com.example.nativedemo.data.llm.ToolDefinition

/**
 * 工具注册表。对应参考实现 registry.py 的 _ACTION_REGISTRY：
 * - [register] 做重名校验
 * - [names] 等价 get_all_action_names()
 * - [toOpenAiTools] 直接产出 OpenAI tools 数组
 */
class ToolRegistry {

    private val tools = LinkedHashMap<String, Tool>()

    @Synchronized
    fun register(tool: Tool) {
        val name = tool.spec.name
        require(NAME_PATTERN.matches(name)) { "工具名不合法：'$name'（需匹配 $NAME_PATTERN）" }
        require(!tools.containsKey(name)) { "工具名重复：'$name'" }
        tools[name] = tool
    }

    @Synchronized
    fun registerAll(vararg items: Tool) {
        items.forEach { register(it) }
    }

    fun get(name: String): Tool? = tools[name]

    fun names(): Set<String> = tools.keys.toSet()

    fun all(): List<Tool> = tools.values.toList()

    fun size(): Int = tools.size

    /**
     * 映射为 OpenAI 的 tools 数组。
     *
     * [enabled] 为空集时视为「全部启用」—— 但 [ToolSpec.defaultEnabled] 为 false 的
     * 工具（如 run_command）仍然排除，除非用户显式把它加进集合。
     */
    fun toOpenAiTools(enabled: Set<String> = emptySet()): List<ToolDefinition> =
        all()
            .filter { tool ->
                if (enabled.isEmpty()) tool.spec.defaultEnabled else tool.spec.name in enabled
            }
            .map { tool ->
                ToolDefinition(
                    function = FunctionDefinition(
                        name = tool.spec.name,
                        description = tool.spec.description,
                        parameters = tool.spec.params
                    )
                )
            }

    /** 某个工具当前是否生效（与 [toOpenAiTools] 同一套判定）。 */
    fun isEnabled(spec: ToolSpec, enabled: Set<String>): Boolean =
        if (enabled.isEmpty()) spec.defaultEnabled else spec.name in enabled

    private companion object {
        val NAME_PATTERN = Regex("^[a-zA-Z0-9_-]{1,64}$")
    }
}
