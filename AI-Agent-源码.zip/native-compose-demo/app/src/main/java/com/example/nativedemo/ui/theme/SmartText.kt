package com.example.nativedemo.ui.theme

import androidx.compose.ui.graphics.Color
import com.example.nativedemo.data.settings.BackdropStats
import com.example.nativedemo.data.settings.ColorSlot

/**
 * 「智能图文适配」：按背景图自动推导文字颜色。
 *
 * 要解决的问题：用户换了一张花哨的壁纸后，正文、备注小字直接压在图上，
 * 与图片相互打架（割裂感），要么看不清、要么颜色「飘」在图上。
 *
 * 做法分三步，全部是纯函数、可单测：
 * 1. [analyzeBackdropPixels] 统计背景图的平均亮度与繁忙度（见 [BackdropStats]）；
 * 2. [smartTextLevels] 按平均亮度选文字极性（深底浅字 / 浅底深字），
 *    反推正文 / 次要 / 备注三档灰度，保证每一档对背景都有足够对比度；
 * 3. [smartScrim] 在背景图上加一层与文字极性相反的薄纱 —— 画面越繁忙、
 *    明暗越接近中间值，薄纱越厚，文字像「融」在图上而不是「贴」在图上。
 *
 * 优先级：用户在颜色槽里手动调过的值 > 智能推导 > 主题预设。
 * 所以这里是「覆盖层」而不是「另存一套配色」—— 见 [AppPalette.withSmartText]。
 */

/** WCAG 相对亮度。输入为 0..1 的 sRGB 分量，输出 0..1。 */
fun relativeLuminance(r: Float, g: Float, b: Float): Float {
    fun channel(c: Float): Float {
        val v = c.coerceIn(0f, 1f)
        return if (v <= 0.03928f) {
            v / 12.92f
        } else {
            Math.pow(((v + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
        }
    }
    return 0.2126f * channel(r) + 0.7152f * channel(g) + 0.0722f * channel(b)
}

/** WCAG 对比度，范围 1（完全相同）..21（纯黑对纯白）。 */
fun contrastRatio(l1: Float, l2: Float): Float {
    val a = maxOf(l1, l2)
    val b = minOf(l1, l2)
    return (a + 0.05f) / (b + 0.05f)
}

/** 线性亮度 → sRGB 分量（0..1）。 */
internal fun linearToSrgb(linear: Float): Float {
    val v = linear.coerceIn(0f, 1f)
    return if (v <= 0.0031308f) {
        v * 12.92f
    } else {
        1.055f * Math.pow(v.toDouble(), 1.0 / 2.4).toFloat() - 0.055f
    }
}

/** 线性亮度 → 不透明灰度 ARGB（`0xFFVVVVVV`）。 */
fun grayArgb(linearLuminance: Float): Long {
    val v = Math.round(linearToSrgb(linearLuminance) * 255f).coerceIn(0, 255)
    return 0xFF000000L or (v.toLong() shl 16) or (v.toLong() shl 8) or v.toLong()
}

/** 线性亮度 → Compose 灰度色。 */
fun grayColor(linearLuminance: Float): Color = Color(grayArgb(linearLuminance).toInt())

/**
 * 明暗分界：背景平均亮度低于它用浅色文字，高于它用深色文字。
 *
 * 0.24 不是随手取的 —— 浅色文字最亮只能到 0.90、深色文字最深只能到 0.010
 * （见下面的三档亮度），两种极性能达到的最大对比度在 0.24 附近相等，
 * 再靠薄纱把有效背景亮度往各自极性推。
 */
private const val MID_LUMINANCE = 0.24f

/** 三档亮度「拉开 / 收敛」的过渡区间宽度。 */
private const val SPREAD_RANGE = 0.35f

/**
 * 智能推导的一组文字色（线性亮度，0..1，越大越亮）与衬底薄纱强度。
 *
 * 三档的用途：
 * - [fg] 正文（聊天内容、列表主标题）
 * - [muted] 次要文字（说明、副标题）
 * - [faint] 备注小字（时间戳、提示尾注）
 */
data class SmartTextLevels(
    val lightText: Boolean,
    val fg: Float,
    val muted: Float,
    val faint: Float,
    val scrimAlpha: Float
)

/**
 * 衬底薄纱强度：画面越繁忙、明暗越接近中间值，薄纱越厚（上限 0.40）。
 *
 * 白纱有「洗白」感，比黑纱更伤画面，所以深色文字场景下整体收敛到 70%。
 */
fun smartScrimAlpha(stats: BackdropStats, lightText: Boolean): Float {
    val midness = (1f - Math.abs(stats.luminance - MID_LUMINANCE) / MID_LUMINANCE)
        .coerceIn(0f, 1f)
    val base = 0.08f + 0.16f * stats.busyness + 0.14f * midness
    return (if (lightText) base else base * 0.7f).coerceIn(0f, 0.40f)
}

/** 薄纱盖上去之后的 effective 背景亮度（gamma 域近似）。 */
private fun veiledLuminance(luminance: Float, veil: Float, lightText: Boolean): Float =
    if (lightText) luminance * (1f - veil) else luminance * (1f - veil) + veil

/**
 * 由背景统计推导三档文字亮度。
 *
 * 极性分界附近的背景最难配（两种文字都不够 contrast），所以薄纱在那一带最厚，
 * 把有效背景推离分界；同时三档亮度在分界附近拉得最开、在足够极端的背景上收敛，
 * 保证最弱的「备注小字」也始终可读。
 */
fun smartTextLevels(stats: BackdropStats): SmartTextLevels {
    val lightText = stats.luminance < MID_LUMINANCE
    val veil = smartScrimAlpha(stats, lightText)
    val bg = veiledLuminance(stats.luminance, veil, lightText)

    // spread：0 = 明暗分界（三档拉开），1 = 背景足够极端（三档收敛，向正文靠拢）
    val spread = (Math.abs(bg - MID_LUMINANCE) / SPREAD_RANGE).coerceIn(0f, 1f)

    fun lerp(from: Float, to: Float) = from + (to - from) * spread

    return if (lightText) {
        SmartTextLevels(
            lightText = true,
            fg = 0.90f,
            muted = lerp(0.62f, 0.80f),
            faint = lerp(0.50f, 0.72f),
            scrimAlpha = veil
        )
    } else {
        SmartTextLevels(
            lightText = false,
            fg = 0.010f,
            muted = lerp(0.075f, 0.030f),
            faint = lerp(0.115f, 0.055f),
            scrimAlpha = veil
        )
    }
}

/** 衬底薄纱颜色：与文字极性相反 —— 浅色文字配黑纱，深色文字配白纱。 */
fun smartScrim(stats: BackdropStats): Color {
    val levels = smartTextLevels(stats)
    val base = if (levels.lightText) Color.Black else Color.White
    return base.copy(alpha = levels.scrimAlpha)
}

/** 智能推导覆盖的颜色槽 → ARGB。只动三档文字色，背景类槽位交给用户。 */
fun smartTextOverrides(stats: BackdropStats): Map<ColorSlot, Long> {
    val levels = smartTextLevels(stats)
    return mapOf(
        ColorSlot.TEXT to grayArgb(levels.fg),
        ColorSlot.MUTED to grayArgb(levels.muted),
        ColorSlot.FAINT to grayArgb(levels.faint)
    )
}

/** 背景亮度的一句话描述，展示在「智能图文适配」开关下面。 */
fun BackdropStats.brightnessLabel(): String = when {
    luminance < 0.12f -> "很暗"
    luminance < 0.28f -> "偏暗"
    luminance < 0.55f -> "适中"
    luminance < 0.80f -> "偏亮"
    else -> "很亮"
}

/** 画面繁忙度的一句话描述。 */
fun BackdropStats.busynessLabel(): String = when {
    busyness < 0.25f -> "简洁"
    busyness < 0.55f -> "较丰富"
    else -> "丰富"
}

/**
 * 统计一堆 ARGB 像素的平均亮度与繁忙度。
 *
 * 亮度用 WCAG 相对亮度（线性域，暗部差异不被压扁）；
 * 繁忙度用 **gamma 域**的相邻像素（右 / 下）亮度差均值 ——
 * 线性域会把暗部的小差异压没，照片会集体显得「不繁忙」。
 *
 * 调用方传下采样到 ~96px 的位图像素即可，成本忽略不计。
 */
fun analyzeBackdropPixels(pixels: IntArray, width: Int, height: Int): BackdropStats {
    if (width <= 0 || height <= 0 || pixels.size < width * height) return BackdropStats()

    var lumSum = 0.0
    val luma = FloatArray(width * height)
    for (i in 0 until width * height) {
        val p = pixels[i]
        val r = ((p shr 16) and 0xFF) / 255f
        val g = ((p shr 8) and 0xFF) / 255f
        val b = (p and 0xFF) / 255f
        lumSum += relativeLuminance(r, g, b)
        luma[i] = 0.299f * r + 0.587f * g + 0.114f * b
    }

    var diffSum = 0.0
    var diffCount = 0
    for (y in 0 until height) {
        for (x in 0 until width) {
            val i = y * width + x
            if (x + 1 < width) {
                diffSum += Math.abs(luma[i] - luma[i + 1]).toDouble()
                diffCount++
            }
            if (y + 1 < height) {
                diffSum += Math.abs(luma[i] - luma[i + width]).toDouble()
                diffCount++
            }
        }
    }
    val meanDiff = if (diffCount == 0) 0.0 else diffSum / diffCount

    return BackdropStats(
        luminance = (lumSum / (width * height)).toFloat(),
        // 0.10 是标定值：纯色图 0，下采样后的普通照片大致 0.1~0.6，细碎纹理封顶 1
        busyness = (meanDiff / 0.10).toFloat().coerceIn(0f, 1f)
    )
}
