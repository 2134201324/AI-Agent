package com.example.nativedemo.tools.builtin

import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import com.example.nativedemo.tools.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject

/**
 * 在已授权目录中新建文件。
 *
 * 与 file_write 的分工：file_write 只处理**已存在**的文件（内部走 resolveDocument），
 * 新建则需要先定位父目录再 createFile，是另一条路径。
 *
 * 父目录链不存在时会自动创建（等价 `mkdir -p`）：模型不知道用户磁盘上现成的结构，
 * 要求它先探测再创建只会浪费轮次 —— 而轮次是逆向这类长任务最稀缺的资源。
 */
class FileCreateTool : Tool {

    override val spec = ToolSpec(
        name = "file_create",
        description = "在已授权目录中新建文件并写入初始内容。**中间目录不存在会自动创建**，" +
            "因此可以直接写 a/b/c/notes.md。若同名文件已存在会失败，此时应改用 file_write。",
        category = "文件",
        layer = "L1",
        params = objectSchema {
            string("path", "新文件路径，例如 code_game/notes.txt（中间目录会自动创建）")
            string("content", "初始内容，可为空", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val pathArg = try {
            args.requireStr("path")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }
        val content = args.str("content").orEmpty()

        val target = ctx.uriAccessPolicy.resolveOrCreateParent(pathArg)
            ?: return ToolResult.failure(
                "无法在「$pathArg」创建：没有可写的已授权目录，或路径被同名文件占用。" +
                    "可先用 file_list 查看当前授权了哪些目录。"
            )

        ctx.uriAccessPolicy.denyReason(target.parent.uri, write = true)
            ?.let { return ToolResult.failure(it) }

        return withContext(Dispatchers.IO) {
            try {
                if (target.parent.findFile(target.fileName) != null) {
                    return@withContext ToolResult.failure(
                        "「${target.fileName}」已存在。若想改写内容请用 file_write，想改某段文字请用 file_edit。"
                    )
                }

                val created = target.parent.createFile(mimeFor(target.extension), target.fileName)
                    ?: return@withContext ToolResult.failure("创建失败：父目录可能只读。")

                if (content.isNotEmpty()) {
                    ctx.contentResolver.openOutputStream(created.uri, "rwt")?.use { output ->
                        output.write(content.toByteArray(Charsets.UTF_8))
                        output.flush()
                    }
                }

                ToolResult.success(
                    "已创建「${created.name ?: target.fileName}」，写入 ${content.length} 字符"
                )
            } catch (e: SecurityException) {
                ToolResult.failure("权限不足：${e.message}")
            } catch (e: Throwable) {
                ToolResult.failure("创建失败：${e.message ?: e::class.java.simpleName}")
            }
        }
    }

    private fun mimeFor(extension: String): String = when (extension.lowercase()) {
        "txt", "log" -> "text/plain"
        "md", "markdown" -> "text/markdown"
        "json" -> "application/json"
        "html", "htm" -> "text/html"
        "xml" -> "text/xml"
        "csv" -> "text/csv"
        "js" -> "application/javascript"
        "css" -> "text/css"
        "kt", "java", "py", "c", "cpp", "h", "sh", "yaml", "yml", "toml" -> "text/plain"
        else -> "application/octet-stream"
    }
}
