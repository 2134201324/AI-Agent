package com.example.nativedemo.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nativedemo.ui.common.CollapseChip
import com.example.nativedemo.ui.theme.Accent
import com.example.nativedemo.ui.theme.ChipBg
import com.example.nativedemo.ui.theme.Faint
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.LineColor

/** 展开态思考区的高度上限，超了内部纵滚。 */
private val THINKING_MAX_HEIGHT = 240.dp

/**
 * 「思考过程」折叠卡。
 *
 * 推理模型（deepseek-reasoner、GLM / Qwen 的思考模式等）在正式回答之前会先吐出
 * 大段 `reasoning_content`。此前客户端把这个字段整个忽略 —— 于是思考强度一大，
 * 界面在整段思考期间没有任何可见变化，用户就会以为「卡住了 / 中断了」。
 *
 * 现在把它折叠收集，而且**折叠态只占一行**：长对话里一屏能扫过很多轮，
 * 想找之前的内容时不必翻半天的思考文本。点一下即可展开看完整推理过程。
 *
 * ── 关于折叠交互（踩过的坑）──
 *
 * 早先版本把整张卡做成 clickable，而它又被外层消息的 `SelectionContainer` 包着。
 * 选区容器为了「点空白处取消选区」会拦下容器内的点击，结果思考卡展开之后
 * 就点不回去了 —— 手势被选区层吃掉，卡片的回调根本收不到。
 *
 * 现在两道保障：
 * 1. 卡片整体移出外层选区容器（见 ChatScreen.MessageItem），点击不再被抢；
 * 2. 折叠同时提供**两个**明确入口：顶部整行标题 + 展开后的底部「收起思考」。
 *    卡片较高时不必再回到顶部去找那个小三角。
 *
 * 文本本身仍然可选中复制：它自己带一个内层选区容器，只覆盖文本区域。
 *
 * @param streaming 思考是否仍在进行中
 * @param stateKey 状态键。传消息 id，避免列表回收时把别人卡片的展开态接过来。
 */
@Composable
fun ThinkingBlockCard(
    thinking: String,
    streaming: Boolean,
    stateKey: Any,
    modifier: Modifier = Modifier
) {
    var expanded by rememberSaveable(stateKey) { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ChipBg)
            .border(1.dp, LineColor, RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        // 标题行即开关：整行可点，命中面积足够大
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (expanded) "▾" else "▸",
                color = Accent,
                fontSize = 11.sp
            )
            Spacer(Modifier.width(7.dp))
            Text(
                text = "🧠 深度思考",
                color = Accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.width(7.dp))
            Text(
                text = "${thinking.length} 字",
                color = Faint,
                fontSize = 11.sp
            )
            if (streaming) {
                Spacer(Modifier.width(7.dp))
                Text(
                    text = "思考中…",
                    color = Accent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(Modifier.weight(1f))
            // 把动作写在明面上，而不是让用户去猜那个小三角
            Text(
                text = if (expanded) "收起" else "展开",
                color = Accent,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        if (expanded) {
            Spacer(Modifier.height(7.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = THINKING_MAX_HEIGHT)
                    .clip(RoundedCornerShape(7.dp))
                    .background(Fg.copy(alpha = 0.05f))
                    .verticalScroll(rememberScrollState())
                    .padding(9.dp)
            ) {
                // 内层选区容器只盖住文本区域：思考内容照样长按可选可复制，
                // 而卡片的点击区域（标题行、底部收起）都在它之外，不会互相抢手势
                SelectionContainer {
                    Text(
                        text = thinking.ifBlank { "（无思考内容）" },
                        color = Fg,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    )
                }
            }
            if (streaming) {
                Spacer(Modifier.height(5.dp))
                Text(
                    text = "思考仍在进行，收起可避免画面跳动",
                    color = Faint,
                    fontSize = 10.sp
                )
            }
            Spacer(Modifier.height(6.dp))
            CollapseChip(text = "▴ 收起思考") { expanded = false }
        }
    }
}
