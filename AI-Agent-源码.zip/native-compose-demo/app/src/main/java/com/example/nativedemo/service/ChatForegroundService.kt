package com.example.nativedemo.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.nativedemo.MainActivity
import com.example.nativedemo.R

/**
 * 生成期间的前台服务 —— 保证切到后台也能把这一轮跑完，并在通知栏给出进度。
 *
 * ## 为什么必须有它
 *
 * Android 从 8.0 起对后台进程有严格限制：应用退到后台后，进程随时可能被冻结或回收，
 * 而一轮生成涉及网络请求、多轮工具调用，动辄几十秒到几分钟。没有前台服务，
 * 「进后台就被中断」是必然，只是概率问题。
 *
 * 前台服务的本质是**向系统要一个"我正在为用户干活"的契约**：只要通知还在，
 * 系统就不会随意杀掉这个进程。
 *
 * ## 用途类型
 *
 * Android 14 (API 34) 起必须声明 `foregroundServiceType`，否则启动即崩。
 * 这里用 `specialUse`：AI 对话生成不属于导航/媒体播放/位置等既有类别，
 * 「用户发起的长任务」正是 specialUse 的适用场景（对应 manifest 里的 subtype 声明）。
 */
class ChatForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val text = intent?.getStringExtra(EXTRA_TEXT).orEmpty()
        when (intent?.action) {
            ACTION_UPDATE -> updateNotification(text)

            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }

            else -> {
                // 必须**立即**调用 startForeground：Android 要求 startForegroundService
                // 之后 5 秒内完成，否则直接抛 ANR 级的异常
                startForeground(NOTIFICATION_ID, buildNotification(text))
            }
        }
        return START_NOT_STICKY
    }

    private fun updateNotification(text: String) {
        runCatching {
            getSystemService(NotificationManager::class.java)
                ?.notify(NOTIFICATION_ID, buildNotification(text))
        }
    }

    private fun buildNotification(text: String): Notification {
        ensureChannel()

        // 点通知回到应用（不要新建任务栈上的重复实例）
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("AI Agent 正在运行")
            .setContentText(text.ifBlank { "正在生成回复…" })
            .setContentIntent(contentIntent)
            .setOngoing(true)                 // 不可划掉：任务还在跑
            .setOnlyAlertOnce(true)           // 进度更新时不再响铃/震动
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .build()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return

        val channel = NotificationChannel(
            CHANNEL_ID,
            "生成进度",
            // LOW：进度类通知不该打扰用户，但要一直在那里
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "生成回复期间显示运行进度；完成后自动消失"
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    companion object {
        private const val CHANNEL_ID = "ai_agent_running"
        private const val NOTIFICATION_ID = 1001

        private const val ACTION_START = "com.example.nativedemo.action.CHAT_START"
        private const val ACTION_UPDATE = "com.example.nativedemo.action.CHAT_UPDATE"
        private const val ACTION_STOP = "com.example.nativedemo.action.CHAT_STOP"

        private const val EXTRA_TEXT = "text"

        /** 开始运行：拉起前台服务并显示通知。 */
        fun start(context: Context, text: String) {
            val intent = Intent(context, ChatForegroundService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_TEXT, text)
            }
            // 用 startForegroundService 才能满足「启动后 5 秒内 startForeground」的契约；
            // 老系统上退化为普通 startService。
            runCatching { ContextCompat.startForegroundService(context, intent) }
        }

        /** 更新进度文本。 */
        fun update(context: Context, text: String) {
            val intent = Intent(context, ChatForegroundService::class.java).apply {
                action = ACTION_UPDATE
                putExtra(EXTRA_TEXT, text)
            }
            runCatching { context.startService(intent) }
        }

        /** 结束：撤掉通知并停止服务。 */
        fun stop(context: Context) {
            val intent = Intent(context, ChatForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            runCatching { context.startService(intent) }
        }
    }
}
