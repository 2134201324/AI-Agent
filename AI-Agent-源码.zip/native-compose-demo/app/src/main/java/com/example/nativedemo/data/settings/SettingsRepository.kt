package com.example.nativedemo.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import com.example.nativedemo.data.agent.AgentEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/** DataStore 必须全局单例，多实例会抛 IllegalStateException。 */
private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "agent_settings"
)

data class AgentSettings(
    val baseUrl: String = SettingsDefaults.BASE_URL,
    val model: String = SettingsDefaults.MODEL,
    val temperature: Float = SettingsDefaults.TEMPERATURE,
    val systemPrompt: String = SettingsDefaults.SYSTEM_PROMPT,
    val hasApiKey: Boolean = false,
    val enabledTools: Set<String> = emptySet(),
    /** 元素格式 `uri|flags`，flags 含 r / w */
    val authorizedUris: Set<String> = emptySet(),
    // ── 界面外观 ──
    val brand: AppBrand = AppBrand.default,
    val themeMode: ThemeMode = ThemeMode.default,
    val fontScale: FontScaleOption = FontScaleOption.default,
    val density: UiDensity = UiDensity.default,
    val bubbleCorner: BubbleCorner = BubbleCorner.default,
    val background: BackgroundStyle = BackgroundStyle.default,
    /** 逐槽自定义颜色（ARGB）。未出现的槽位跟随主题预设。 */
    val colorOverrides: Map<ColorSlot, Long> = emptyMap(),
    // ── 多模型编排 ──
    /** 全部模型档案（含迁移来的「默认模型」）。 */
    val profiles: List<ModelProfile> = emptyList(),
    /** 主模型档案 id。 */
    val orchestratorId: String? = null,
    /** 多模型编排开关；关闭时聊天走单模型链路。 */
    val orchestrationEnabled: Boolean = false,
    /**
     * 单模型模式下选用的档案。用户在这里在多个已绑定 Key 的模型配置间切换，
     * 不开编排也能用；为空表示用传统的默认配置。
     */
    val activeProfileId: String? = null,
    /**
     * 单次请求的最大输出长度（token）；0 = 不向服务端发送该参数。
     * 见 [SettingsKeys.MAX_OUTPUT_TOKENS]。
     */
    val maxOutputTokens: Int = SettingsDefaults.MAX_OUTPUT_TOKENS,
    /** 单次任务的工具调用轮次上限。见 [SettingsKeys.MAX_TOOL_ROUNDS]。 */
    val maxToolRounds: Int = SettingsDefaults.MAX_TOOL_ROUNDS,
    /** 该配置是否为「网页桥接」：免 Key，且默认不发 tools。见 [SettingsKeys.BRIDGE_MODE]。 */
    val bridgeMode: Boolean = false,
    // ── REA 远程逆向引擎 ──
    /** REA 网关地址；空串表示未配置（工具调用时会提示用户去设置页填写）。 */
    val reaServerUrl: String = "",
    /** REA 令牌是否已保存（能否真正调用）。 */
    val reaTokenReady: Boolean = false
) {
    val configured: Boolean get() = hasApiKey && baseUrl.isNotBlank() && model.isNotBlank()

    /** 主模型档案：用户指定的优先，否则第一个能当主模型的。 */
    val orchestrator: ModelProfile?
        get() = profiles.firstOrNull { it.id == orchestratorId && it.canOrchestrate }
            ?: profiles.firstOrNull { it.canOrchestrate }

    /** 可参与子任务的档案（排除主模型本人）。 */
    val subProfiles: List<ModelProfile>
        get() = profiles.filter { it.canSub && it.id != orchestrator?.id }

    /** 编排是否真正可用：开着、有主模型、至少一个子模型。 */
    val orchestrationReady: Boolean
        get() = orchestrationEnabled && orchestrator != null && subProfiles.isNotEmpty()

    /** 单模型模式选用的档案：已启用且有 Key 才作数，否则回退默认配置。 */
    val activeProfile: ModelProfile?
        get() = activeProfileId?.let { id ->
            profiles.firstOrNull { it.id == id && it.enabled && it.hasKey }
        }
}

class SettingsRepository(
    private val context: Context,
    private val secureStore: SecureStore,
    /**
     * 「从未设置过工具开关」时的默认启用集。
     *
     * 没有它，空集既表示"全默认"又表示"什么都没选"：用户在全默认状态下关掉一个工具，
     * 写回时会从空集里减，结果还是空集 —— 开关看着动了，实际什么都没发生。
     */
    private val defaultEnabledToolNames: Set<String> = emptySet(),
    /** 当前版本注册表里的全部工具名，用于识别"升级后才出现的新工具"。 */
    private val allToolNames: Set<String> = emptySet()
) {

    val settings: Flow<AgentSettings> = context.settingsDataStore.data.map { prefs ->
        AgentSettings(
            baseUrl = prefs[SettingsKeys.BASE_URL] ?: SettingsDefaults.BASE_URL,
            model = prefs[SettingsKeys.MODEL] ?: SettingsDefaults.MODEL,
            temperature = prefs[SettingsKeys.TEMPERATURE] ?: SettingsDefaults.TEMPERATURE,
            maxOutputTokens = prefs[SettingsKeys.MAX_OUTPUT_TOKENS]
                ?: SettingsDefaults.MAX_OUTPUT_TOKENS,
            maxToolRounds = prefs[SettingsKeys.MAX_TOOL_ROUNDS]
                ?: SettingsDefaults.MAX_TOOL_ROUNDS,
            bridgeMode = prefs[SettingsKeys.BRIDGE_MODE] ?: false,
            reaServerUrl = prefs[SettingsKeys.REA_SERVER_URL]
                ?.takeIf { it.isNotBlank() }
                ?: SettingsDefaults.REA_SERVER_URL,
            reaTokenReady = !prefs[SettingsKeys.REA_TOKEN_CIPHER].isNullOrBlank(),
            systemPrompt = prefs[SettingsKeys.SYSTEM_PROMPT] ?: SettingsDefaults.SYSTEM_PROMPT,
            hasApiKey = !prefs[SettingsKeys.API_KEY_CIPHER].isNullOrBlank(),
            enabledTools = resolveEnabledTools(prefs) ?: emptySet(),
            authorizedUris = prefs[SettingsKeys.AUTHORIZED_URIS] ?: emptySet(),
            brand = AppBrand.parse(prefs[SettingsKeys.APPEARANCE_BRAND]),
            themeMode = ThemeMode.parse(prefs[SettingsKeys.APPEARANCE_THEME_MODE]),
            fontScale = FontScaleOption.parse(prefs[SettingsKeys.APPEARANCE_FONT_SCALE]),
            density = UiDensity.parse(prefs[SettingsKeys.APPEARANCE_DENSITY]),
            bubbleCorner = BubbleCorner.parse(prefs[SettingsKeys.APPEARANCE_CORNER]),
            background = BackgroundStyle(
                uri = prefs[SettingsKeys.APPEARANCE_BG_URI]?.takeIf { it.isNotBlank() },
                blur = (prefs[SettingsKeys.APPEARANCE_BG_BLUR] ?: 0f)
                    .coerceIn(0f, BackgroundStyle.MAX_BLUR),
                alpha = (prefs[SettingsKeys.APPEARANCE_BG_ALPHA] ?: 1f)
                    .coerceIn(BackgroundStyle.MIN_ALPHA, 1f),
                smartContrast = prefs[SettingsKeys.APPEARANCE_BG_SMART] ?: false,
                stats = BackdropStatsCodec.decode(prefs[SettingsKeys.APPEARANCE_BG_STATS])
            ),
            colorOverrides = ColorSlotCodec.decodeAll(
                prefs[SettingsKeys.APPEARANCE_SLOTS] ?: emptySet()
            ),
            // 旧配置首次读取时收编为「默认模型」档案，老用户升级不丢配置
            profiles = migrateLegacyProfiles(
                existingJson = prefs[SettingsKeys.MODEL_PROFILES],
                legacyBaseUrl = prefs[SettingsKeys.BASE_URL] ?: SettingsDefaults.BASE_URL,
                legacyModel = prefs[SettingsKeys.MODEL] ?: SettingsDefaults.MODEL,
                legacyKeyCipher = prefs[SettingsKeys.API_KEY_CIPHER]
            ),
            orchestratorId = prefs[SettingsKeys.ORCHESTRATOR_PROFILE_ID]
                ?.takeIf { it.isNotBlank() },
            orchestrationEnabled = prefs[SettingsKeys.ORCHESTRATION_ENABLED] ?: false,
            activeProfileId = prefs[SettingsKeys.ACTIVE_PROFILE_ID]
                ?.takeIf { it.isNotBlank() }
        )
    }

    suspend fun snapshot(): AgentSettings = settings.first()

    /** 读取明文 API Key。解密失败会清掉密文并返回 null，提示用户重填。 */
    suspend fun apiKey(): String? {
        val cipherText = context.settingsDataStore.data.first()[SettingsKeys.API_KEY_CIPHER]
        if (cipherText.isNullOrBlank()) return null
        val plain = secureStore.decrypt(cipherText)
        if (plain == null) {
            context.settingsDataStore.edit { it.remove(SettingsKeys.API_KEY_CIPHER) }
        }
        return plain
    }

    suspend fun saveApiKey(raw: String) {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) {
            context.settingsDataStore.edit { it.remove(SettingsKeys.API_KEY_CIPHER) }
            return
        }
        val encrypted = secureStore.encrypt(trimmed)
            ?: throw IllegalStateException("设备密钥库不可用，无法安全保存 API Key")
        context.settingsDataStore.edit { it[SettingsKeys.API_KEY_CIPHER] = encrypted }
    }

    suspend fun saveBaseUrl(value: String) {
        context.settingsDataStore.edit {
            it[SettingsKeys.BASE_URL] = value.trim().ifBlank { SettingsDefaults.BASE_URL }
        }
    }

    // ── REA 远程逆向引擎 ────────────────────────────────────────────────

    /** 读取明文 REA 令牌。解密失败会清掉密文并返回 null（与 API Key 同策略）。 */
    suspend fun reaToken(): String? {
        val cipherText = context.settingsDataStore.data.first()[SettingsKeys.REA_TOKEN_CIPHER]
        if (cipherText.isNullOrBlank()) return null
        val plain = secureStore.decrypt(cipherText, secureStore.reaTokenAlias())
        if (plain == null) {
            context.settingsDataStore.edit { it.remove(SettingsKeys.REA_TOKEN_CIPHER) }
        }
        return plain
    }

    /** 保存 REA 网关地址。 */
    suspend fun saveReaServerUrl(value: String) {
        context.settingsDataStore.edit {
            it[SettingsKeys.REA_SERVER_URL] = value.trim()
        }
    }

    /** 保存 REA 令牌（加密后落盘）；空串表示清除。 */
    suspend fun saveReaToken(raw: String) {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) {
            clearReaToken()
            return
        }
        val encrypted = secureStore.encrypt(trimmed, secureStore.reaTokenAlias())
            ?: throw IllegalStateException("设备密钥库不可用，无法安全保存 REA 令牌")
        context.settingsDataStore.edit { it[SettingsKeys.REA_TOKEN_CIPHER] = encrypted }
    }

    /** 清除 REA 令牌（密文 + Keystore 密钥一并删）。 */
    suspend fun clearReaToken() {
        context.settingsDataStore.edit { it.remove(SettingsKeys.REA_TOKEN_CIPHER) }
        secureStore.deleteKey(secureStore.reaTokenAlias())
    }

    suspend fun saveModel(value: String) {
        context.settingsDataStore.edit {
            it[SettingsKeys.MODEL] = value.trim().ifBlank { SettingsDefaults.MODEL }
        }
    }

    suspend fun saveTemperature(value: Float) {
        context.settingsDataStore.edit { it[SettingsKeys.TEMPERATURE] = value.coerceIn(0f, 2f) }
    }

    /**
     * 保存输出上限。0 表示不发送该参数（由服务端决定）；
     * 其余值做一次下限保护，避免手滑设成 1 这种必然截断的值。
     */
    /** 切换「网页桥接」模式。 */
    suspend fun saveBridgeMode(value: Boolean) {
        context.settingsDataStore.edit { it[SettingsKeys.BRIDGE_MODE] = value }
    }

    suspend fun saveMaxOutputTokens(value: Int) {
        context.settingsDataStore.edit {
            it[SettingsKeys.MAX_OUTPUT_TOKENS] = when {
                value <= 0 -> 0
                value < 256 -> 256
                else -> value
            }
        }
    }

    /**
     * 保存工具轮次上限。
     *
     * 下限给到 2：设成 1 意味着模型一调工具就停，任何多步任务都做不成，
     * 那是个必然出问题的配置。上限在引擎侧还有一道 [AgentEngine.MAX_ROUNDS_CEILING] 兜底。
     */
    suspend fun saveMaxToolRounds(value: Int) {
        context.settingsDataStore.edit {
            it[SettingsKeys.MAX_TOOL_ROUNDS] = value.coerceIn(2, AgentEngine.MAX_ROUNDS_CEILING)
        }
    }

    /**
     * 实际生效的启用集。规则见 [computeEnabledTools]（抽成纯函数是为了能单测）。
     */
    private fun resolveEnabledTools(prefs: Preferences): Set<String>? =
        computeEnabledTools(
            stored = prefs[SettingsKeys.ENABLED_TOOLS],
            known = prefs[SettingsKeys.KNOWN_TOOLS] ?: emptySet(),
            allToolNames = allToolNames,
            defaultEnabled = defaultEnabledToolNames
        )

    /**
     * 落定"升级补齐"的结果，并记录用户已经见过这些工具。
     *
     * 必须在 App 启动时调用一次。两步的顺序不能颠倒：
     * 1. 先按**旧的** [SettingsKeys.KNOWN_TOOLS] 算出补齐后的启用集，写回存储 ——
     *    此刻 KNOWN_TOOLS 还是旧值，补齐逻辑才算得出来；写晚了（先更新 KNOWN_TOOLS）
     *    就永远算不出 newcomers，新工具会直接丢掉；
     * 2. 再把全部工具名并入 KNOWN_TOOLS，宣告"这些用户都见过了"。
     *
     * 缺了第 1 步会发生什么：读取时补上、启动后又消失，开关像自己弹回去。
     */
    suspend fun markToolsSeen(names: Set<String>) {
        if (names.isEmpty()) return
        context.settingsDataStore.edit { prefs ->
            val resolved = resolveEnabledTools(prefs)
            if (resolved != null) {
                prefs[SettingsKeys.ENABLED_TOOLS] = resolved
            }
            val known = prefs[SettingsKeys.KNOWN_TOOLS] ?: emptySet()
            if (!known.containsAll(names)) {
                prefs[SettingsKeys.KNOWN_TOOLS] = known + names
            }
        }
    }

    suspend fun saveSystemPrompt(value: String) {
        context.settingsDataStore.edit {
            it[SettingsKeys.SYSTEM_PROMPT] = value.ifBlank { SettingsDefaults.SYSTEM_PROMPT }
        }
    }

    suspend fun setToolEnabled(toolName: String, enabled: Boolean) {
        context.settingsDataStore.edit { prefs ->
            // 基准取「实际生效集」而不是原始存储值：否则用户关掉一个升级后新增的工具时，
            // 存储值里压根没有它，减了等于没减 —— 开关会被补齐逻辑重新顶开，看着像失灵。
            val current = resolveEnabledTools(prefs) ?: defaultEnabledToolNames
            prefs[SettingsKeys.ENABLED_TOOLS] =
                if (enabled) current + toolName else current - toolName
        }
    }

    suspend fun addAuthorizedUri(entry: String) {
        context.settingsDataStore.edit { prefs ->
            prefs[SettingsKeys.AUTHORIZED_URIS] = (prefs[SettingsKeys.AUTHORIZED_URIS] ?: emptySet()) + entry
        }
    }

    suspend fun removeAuthorizedUri(entry: String) {
        context.settingsDataStore.edit { prefs ->
            prefs[SettingsKeys.AUTHORIZED_URIS] = (prefs[SettingsKeys.AUTHORIZED_URIS] ?: emptySet()) - entry
        }
    }

    suspend fun replaceAuthorizedUris(entries: Set<String>) {
        context.settingsDataStore.edit { it[SettingsKeys.AUTHORIZED_URIS] = entries }
    }

    // ── 界面外观：即时生效，不需要点「保存」────────────────────────────
    suspend fun saveBrand(value: AppBrand) {
        context.settingsDataStore.edit { it[SettingsKeys.APPEARANCE_BRAND] = value.name }
    }

    suspend fun saveThemeMode(value: ThemeMode) {
        context.settingsDataStore.edit { it[SettingsKeys.APPEARANCE_THEME_MODE] = value.name }
    }

    suspend fun saveFontScale(value: FontScaleOption) {
        context.settingsDataStore.edit { it[SettingsKeys.APPEARANCE_FONT_SCALE] = value.name }
    }

    suspend fun saveDensity(value: UiDensity) {
        context.settingsDataStore.edit { it[SettingsKeys.APPEARANCE_DENSITY] = value.name }
    }

    suspend fun saveBubbleCorner(value: BubbleCorner) {
        context.settingsDataStore.edit { it[SettingsKeys.APPEARANCE_CORNER] = value.name }
    }

    suspend fun saveBackground(style: BackgroundStyle) {
        context.settingsDataStore.edit { prefs ->
            val uri = style.uri
            if (uri.isNullOrBlank()) prefs.remove(SettingsKeys.APPEARANCE_BG_URI)
            else prefs[SettingsKeys.APPEARANCE_BG_URI] = uri
            prefs[SettingsKeys.APPEARANCE_BG_BLUR] =
                style.blur.coerceIn(0f, BackgroundStyle.MAX_BLUR)
            prefs[SettingsKeys.APPEARANCE_BG_ALPHA] =
                style.alpha.coerceIn(BackgroundStyle.MIN_ALPHA, 1f)
            prefs[SettingsKeys.APPEARANCE_BG_SMART] = style.smartContrast
            val stats = style.stats
            if (stats == null) prefs.remove(SettingsKeys.APPEARANCE_BG_STATS)
            else prefs[SettingsKeys.APPEARANCE_BG_STATS] = BackdropStatsCodec.encode(stats)
        }
    }

    /** 写入单个颜色槽；[argb] 为 null 时表示恢复该槽的默认配色。 */
    suspend fun saveColorSlot(slot: ColorSlot, argb: Long?) {
        context.settingsDataStore.edit { prefs ->
            val current = prefs[SettingsKeys.APPEARANCE_SLOTS] ?: emptySet()
            val rest = current.filterNot { it.startsWith("${slot.name}|") }.toSet()
            prefs[SettingsKeys.APPEARANCE_SLOTS] =
                if (argb == null) rest else rest + ColorSlotCodec.encode(slot, argb)
        }
    }

    suspend fun resetColorSlots() {
        context.settingsDataStore.edit { it.remove(SettingsKeys.APPEARANCE_SLOTS) }
    }

    // ── 多模型编排 ─────────────────────────────────────────────────────

    suspend fun saveProfiles(profiles: List<ModelProfile>) {
        context.settingsDataStore.edit {
            it[SettingsKeys.MODEL_PROFILES] = ModelProfileCodec.encodeProfiles(profiles)
        }
    }

    suspend fun saveOrchestratorId(id: String?) {
        context.settingsDataStore.edit { prefs ->
            if (id.isNullOrBlank()) prefs.remove(SettingsKeys.ORCHESTRATOR_PROFILE_ID)
            else prefs[SettingsKeys.ORCHESTRATOR_PROFILE_ID] = id
        }
    }

    suspend fun setOrchestrationEnabled(enabled: Boolean) {
        context.settingsDataStore.edit {
            it[SettingsKeys.ORCHESTRATION_ENABLED] = enabled
        }
    }

    /**
     * 选用单模型档案（不开编排也能在多个已绑定 Key 的配置间切换）。
     * 传 null 或空表示回到传统的「默认配置」。
     */
    suspend fun saveActiveProfileId(id: String?) {
        context.settingsDataStore.edit { prefs ->
            if (id.isNullOrBlank()) prefs.remove(SettingsKeys.ACTIVE_PROFILE_ID)
            else prefs[SettingsKeys.ACTIVE_PROFILE_ID] = id
        }
    }

    /** 新增或更新档案（按 id 覆盖）。保存前清掉目标档案的密钥缓存语义由调用方处理。 */
    suspend fun upsertProfile(profile: ModelProfile) {
        val current = snapshot().profiles
        val next = if (current.any { it.id == profile.id }) {
            current.map { if (it.id == profile.id) profile else it }
        } else {
            current + profile
        }
        saveProfiles(next)
    }

    /** 删除档案，并抹掉它在 Keystore 里的密钥。 */
    suspend fun deleteProfile(id: String) {
        secureStore.deleteKey(secureStore.aliasForProfile(id))
        val current = snapshot().profiles
        saveProfiles(current.filterNot { it.id == id })
        val after = snapshot()
        // 被删的正好是主模型 / 当前选用档案时清掉选择，回退到「第一个可用的」
        if (after.orchestratorId == id) saveOrchestratorId(null)
        if (after.activeProfileId == id) saveActiveProfileId(null)
    }

    /** 写入某个档案的 API Key（加密后随档案落盘）。 */
    suspend fun saveProfileKey(id: String, apiKey: String) {
        val trimmed = apiKey.trim()
        val current = snapshot().profiles
        val target = current.firstOrNull { it.id == id } ?: return
        if (trimmed.isEmpty()) {
            secureStore.deleteKey(secureStore.aliasForProfile(id))
            upsertProfile(target.copy(keyCipher = null))
            return
        }
        val cipher = secureStore.encrypt(trimmed, secureStore.aliasForProfile(id))
            ?: throw IllegalStateException("设备密钥库不可用，无法安全保存 API Key")
        upsertProfile(target.copy(keyCipher = cipher))
    }

    /**
     * 读取某个档案的明文 Key。解密失败（换机恢复、密钥失效）会清掉密文，
     * 让界面回到「未填写」状态，而不是每次请求都静默失败。
     */
    suspend fun apiKeyForProfile(profile: ModelProfile): String? {
        val cipher = profile.keyCipher ?: return null
        val plain = secureStore.decrypt(cipher, secureStore.aliasForProfile(profile.id))
        if (plain == null) {
            upsertProfile(profile.copy(keyCipher = null))
            return null
        }
        return plain
    }
}
