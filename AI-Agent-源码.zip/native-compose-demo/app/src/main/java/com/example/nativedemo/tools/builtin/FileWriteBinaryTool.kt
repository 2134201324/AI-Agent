package com.example.nativedemo.tools.builtin

import android.util.Base64
import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.bool
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import com.example.nativedemo.tools.saf.DocumentIo
import com.example.nativedemo.tools.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject

/**
 * 写入**二进制**文件。
 *
 * ## 为什么单开一个工具
 *
 * 原有的 `file_write` 只处理文本：参数按字符串写盘，UTF-8 编码会毁掉任何非文本内容。
 * 于是出现了一个很尴尬的能力空洞 —— **AI 能生成文本，却写不出一个字节的二进制**，
 * 而改 APK 里的图片、so、数据库恰恰都需要它。
 *
 * 两条写入路径覆盖两种典型来路：
 * - `base64`：内容由 AI 自己产出（如构造出的一小段数据）；
 * - `copy_from`：内容已在设备上（用户选的图片、解包出来的文件），直接复制。
 */
class FileWriteBinaryTool : Tool {

    override val spec = ToolSpec(
        name = "file_write_binary",
        description = "把**二进制内容**写入文件（普通 file_write 只能写文本，写图片等会损坏）。" +
            "内容来源二选一：base64（AI 直接给出数据）或 copy_from（复制设备上已有的文件）。" +
            "常用于：把图片写到某个位置供 apk_replace 使用、保存从 APK 提取的原始字节。",
        category = "文件",
        layer = "L1",
        destructive = true,
        params = objectSchema {
            string("path", "目标文件路径（已授权目录内）")
            string("base64", "内容的 Base64 编码", required = false)
            string("copy_from", "改为复制这个已有文件的内容", required = false)
            boolean("create_parent", "父目录不存在时自动创建，默认 false")
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = try {
            args.requireStr("path")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }

        val base64 = args.str("base64")
        val copyFrom = args.str("copy_from")
        when {
            base64.isNullOrBlank() && copyFrom.isNullOrBlank() ->
                return ToolResult.failure("请提供 base64 或 copy_from 之一作为内容来源。")
            !base64.isNullOrBlank() && !copyFrom.isNullOrBlank() ->
                return ToolResult.failure("base64 与 copy_from 只能二选一。")
        }

        val createParent = args.bool("create_parent", false)

        return withContext(Dispatchers.IO) {
            try {
                val bytes: ByteArray = if (!base64.isNullOrBlank()) {
                    // 模型给出的 base64 常带折行与空格，先剔干净再解
                    val cleaned = base64.filterNot { it.isWhitespace() }
                    runCatching { Base64.decode(cleaned, Base64.DEFAULT) }.getOrElse {
                        return@withContext ToolResult.failure(
                            "Base64 解码失败：${it.message}。请确认内容是合法的 Base64。"
                        )
                    }
                } else {
                    DocumentIo.readBytes(ctx, copyFrom!!)
                        ?: return@withContext ToolResult.failure(
                            "读取来源文件「$copyFrom」失败（不存在、是目录或未授权）。"
                        )
                }

                if (createParent) {
                    DocumentIo.ensureDirectory(ctx, path.substringBeforeLast('/', ""))
                }

                val problem = DocumentIo.writeBytes(ctx, path, bytes)
                if (problem != null) return@withContext ToolResult.failure(problem)

                val existed = ctx.uriAccessPolicy.resolveDocument(path) != null
                ToolResult.success(
                    "已写入「$path」（${describeSize(bytes.size)}" +
                        (if (existed) "" else "，新建") + "）"
                )
            } catch (e: SecurityException) {
                ToolResult.failure("权限不足：${e.message}")
            } catch (e: Throwable) {
                ToolResult.failure("写入失败：${e.message ?: e::class.java.simpleName}")
            }
        }
    }

    private fun describeSize(bytes: Int): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
        else -> "%.2f MB".format(bytes / (1024.0 * 1024.0))
    }
}
