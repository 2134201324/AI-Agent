package com.example.nativedemo.tools.apk

import android.content.Context
import java.security.MessageDigest
import java.util.Locale
import java.util.zip.ZipEntry

/**
 * APK 分析门面：把底层解析器组织成**给模型看的文本**。
 *
 * 分成两层是有意的 —— 解析层只管把二进制还原成结构，门面层负责「怎么呈现才利于
 * 判断」：先给结论、再给证据，并在末尾点出可疑之处。模型不需要（也不该）看原始
 * 十六进制，它需要的是「这个包里有哪些组件被导出了」这种可判断的表述。
 */
class ApkAnalyzer(private val context: Context) {

    // ── manifest 里的系统属性 id ──────────────────────────────────────
    // 按 id 匹配而不是名字：名字要经过反查表，表缺项时不可靠
    private object Attr {
        const val NAME = 0x01010003
        const val LABEL = 0x01010001
        const val ICON = 0x01010002
        const val VERSION_CODE = 0x0101021B
        const val VERSION_NAME = 0x0101021C
        const val MIN_SDK = 0x0101020C
        const val TARGET_SDK = 0x01010270
        const val DEBUGGABLE = 0x0101000F
        const val EXPORTED = 0x01010010
        const val AUTHORITIES = 0x01010018
        const val ALLOW_BACKUP = 0x01010280
        const val CLEARTEXT = 0x010104EC
    }

    /** 已知加固/加壳框架的 native 库特征。 */
    private val packerSignatures = mapOf(
        "libjiagu" to "360 加固",
        "libshell" to "腾讯乐固 / 通用壳",
        "libDexHelper" to "梆梆加固",
        "libmobisec" to "阿里聚安全",
        "libtup" to "腾讯加固",
        "libnesec" to "网易易盾",
        "libexec.so" to "通用加壳",
        "libexecmain" to "通用加壳",
        "libbaiduprotect" to "百度加固",
        "libnqshield" to "网秦加固",
        "libapktoolplus" to "可疑（改包工具残留）"
    )

    // ── 总览 ──────────────────────────────────────────────────────────

    fun overview(archive: ApkArchive): String {
        val sb = StringBuilder()
        val doc = runCatching { decodeManifest(archive) }.getOrNull()
        val root = doc?.root

        sb.append("📦 **APK 总览**\n")
        sb.append("文件：${archive.file.name}（${formatSize(archive.totalBytes)}）\n")
        sb.append("条目：${archive.entries.size} 个，解压后 ${formatSize(archive.uncompressedBytes)}\n")
        runCatching { sb.append("SHA-256：${sha256File(archive.file)}\n") }

        // ── 基本信息 ──
        if (root != null) {
            val application = root.childrenNamed("application").firstOrNull()
            val usesSdk = root.childrenNamed("uses-sdk").firstOrNull()

            sb.append("\n**【基本信息】**\n")
            sb.append("包名：${root.attr("package") ?: "（未声明）"}\n")
            application?.attrById(Attr.LABEL, "label")?.let { raw ->
                // label 通常是对资源表的引用（@0x7f0f0001），能还原就还原成真实文案
                val resolved = resolveStringResource(archive, raw) ?: raw
                sb.append("应用名：$resolved\n")
            }
            val versionName = root.attrById(Attr.VERSION_NAME, "versionName")
            val versionCode = root.attrById(Attr.VERSION_CODE, "versionCode")
            sb.append("版本：${versionName ?: "未知"}（versionCode ${versionCode ?: "?"}）\n")
            sb.append(
                "SDK：minSdk ${usesSdk?.attrById(Attr.MIN_SDK, "minSdkVersion") ?: "?"}" +
                    " / targetSdk ${usesSdk?.attrById(Attr.TARGET_SDK, "targetSdkVersion") ?: "?"}\n"
            )
            application?.attrById(Attr.DEBUGGABLE, "debuggable")?.let { sb.append("可调试：$it\n") }
            application?.attrById(Attr.CLEARTEXT, "usesCleartextTraffic")?.let {
                sb.append("允许明文流量：$it\n")
            }
            application?.attrById(Attr.ALLOW_BACKUP, "allowBackup")?.let { sb.append("允许备份：$it\n") }
        } else {
            sb.append("\n⚠️ AndroidManifest.xml 解析失败，以下信息不完整\n")
        }

        // ── 签名 ──
        val schemes = runCatching { ApkSignatureInspector.detectSchemes(archive.file) }.getOrNull()
        if (schemes != null) {
            sb.append("\n**【签名】**\n${schemes.describe()}\n")
        }

        // ── 权限 ──
        if (root != null) {
            val permissions = root.children
                .filter { it.name == "uses-permission" || it.name == "uses-permission-sdk-23" }
                .mapNotNull { it.attrById(Attr.NAME, "name") }
            sb.append("\n**【权限（${permissions.size}）】**\n")
            if (permissions.isEmpty()) {
                sb.append("（无）\n")
            } else {
                permissions.forEach { sb.append("- $it\n") }
            }
        }

        // ── 组件 ──
        if (root != null) {
            val application = root.childrenNamed("application").firstOrNull()
            if (application != null) {
                sb.append("\n**【组件】**\n")
                val exported = mutableListOf<String>()
                listOf("activity", "service", "receiver", "provider").forEach { kind ->
                    val nodes = application.childrenNamed(kind)
                    sb.append("${kind}：${nodes.size} 个\n")
                    nodes.forEach { node ->
                        val isExported = node.attrById(Attr.EXPORTED, "exported")?.toBoolean()
                            ?: false
                        val hasIntentFilter = node.children.any { it.name == "intent-filter" }
                        // 未显式声明 exported 时，带 intent-filter 的组件在旧版系统上默认导出
                        val effectivelyExported = isExported || node.attrById(Attr.EXPORTED, "exported") == null && hasIntentFilter
                        if (effectivelyExported) {
                            val name = node.attrById(Attr.NAME, "name") ?: "?"
                            val auth = node.attrById(Attr.AUTHORITIES, "authorities")
                            exported += "  - $kind $name" +
                                (if (auth != null) "（authorities=$auth）" else "")
                        }
                    }
                }
                if (exported.isNotEmpty()) {
                    sb.append("导出/可被外部调用的组件（${exported.size}）：\n")
                    exported.take(20).forEach { sb.append(it).append('\n') }
                    if (exported.size > 20) sb.append("  …还有 ${exported.size - 20} 个\n")
                }
            }
        }

        // ── 代码 ──
        val dexNames = archive.namesMatching { it.matches(Regex("classes\\d*\\.dex")) }.sorted()
        sb.append("\n**【代码（DEX）】**\n")
        if (dexNames.isEmpty()) {
            sb.append("（没有 dex —— 可能是壳包或纯资源包）\n")
        } else {
            var totalClasses = 0
            var totalMethods = 0
            dexNames.forEach { name ->
                val bytes = runCatching { archive.read(name, 48 * 1024 * 1024) }.getOrNull()
                if (bytes == null) {
                    sb.append("- $name（读取失败）\n")
                    return@forEach
                }
                val dex = runCatching { DexParser.parse(bytes) }.getOrNull()
                if (dex == null) {
                    sb.append("- $name（${formatSize(bytes.size.toLong())}，解析失败）\n")
                } else {
                    totalClasses += dex.classes.size
                    totalMethods += dex.methodCount
                    sb.append(
                        "- $name（${formatSize(bytes.size.toLong())}）：" +
                            "类 ${dex.classes.size}、方法 ${dex.methodCount}、" +
                            "字符串 ${dex.stringCount}\n"
                    )
                }
            }
            sb.append("合计：类 $totalClasses、方法 $totalMethods\n")
        }

        // ── Native 库 ──
        val soFiles = archive.namesMatching { it.startsWith("lib/") && it.endsWith(".so") }
        sb.append("\n**【Native 库（${soFiles.size}）】**\n")
        if (soFiles.isEmpty()) {
            sb.append("（无）\n")
        } else {
            val abis = soFiles.mapNotNull { it.split('/').getOrNull(1) }.distinct().sorted()
            sb.append("支持的 ABI：${abis.joinToString("、")}\n")
            soFiles.take(25).forEach { name ->
                sb.append("- $name（${formatSize(archive.sizeOf(name))}）\n")
            }
            if (soFiles.size > 25) sb.append("…还有 ${soFiles.size - 25} 个\n")
        }

        // ── 资源与资产 ──
        val arscSize = archive.sizeOf("resources.arsc")
        val resFiles = archive.namesMatching { it.startsWith("res/") }
        val assets = archive.namesMatching { it.startsWith("assets/") }
        sb.append("\n**【资源】**\n")
        sb.append("resources.arsc：${if (arscSize > 0) formatSize(arscSize) else "（无）"}\n")
        sb.append("res/ 文件 ${resFiles.size} 个、assets/ 文件 ${assets.size} 个\n")

        // ── 值得注意的地方 ──
        val notes = mutableListOf<String>()
        if (root != null) {
            val application = root.childrenNamed("application").firstOrNull()
            if (application?.attrById(Attr.DEBUGGABLE, "debuggable") == "true") {
                notes += "应用标记为 **可调试**（debuggable=true）：第三方可附加调试器读取内存数据"
            }
            if (application?.attrById(Attr.CLEARTEXT, "usesCleartextTraffic") == "true") {
                notes += "允许 **明文 HTTP 流量**：配合抓包可解析其网络通信"
            }
            val exportedCount = root.childrenNamed("application").firstOrNull()
                ?.children
                ?.count {
                    (it.name == "activity" || it.name == "service" ||
                        it.name == "receiver" || it.name == "provider") &&
                        it.attrById(Attr.EXPORTED, "exported") == "true"
                } ?: 0
            if (exportedCount > 0) {
                notes += "有 $exportedCount 个组件显式导出了（可为其它应用调用），是攻击面常见的入口"
            }
        }
        if (schemes != null && schemes.v1 && !schemes.v2 && !schemes.v3) {
            notes += "只使用 v1 签名：这类包容易被重新签名后二次打包"
        }
        if (schemes != null && !schemes.any) {
            notes += "未检测到任何签名方案"
        }
        val packers = soFiles.mapNotNull { path ->
            packerSignatures.entries.firstOrNull { path.contains(it.key, ignoreCase = true) }?.value
        }.distinct()
        if (packers.isNotEmpty()) {
            notes += "疑似加固：${packers.joinToString("、")}（代码可能被壳保护，dex 不完整）"
        }
        if (dexNames.isEmpty() && soFiles.isNotEmpty()) {
            notes += "没有 dex 但有 native 库：典型的**加固特征**，真实代码藏在 so 或运行时释放"
        }

        if (notes.isNotEmpty()) {
            sb.append("\n**【值得注意】**\n")
            notes.forEach { sb.append("- $it\n") }
        }

        return sb.toString()
    }

    // ── AndroidManifest.xml ────────────────────────────────────────────

    fun manifestXml(archive: ApkArchive, maxChars: Int): String {
        val bytes = archive.read(MANIFEST_ENTRY)
            ?: throw ResParseException("APK 里找不到 $MANIFEST_ENTRY")
        val document = AxmlParser.decode(bytes)
        val xml = AxmlParser.toXml(document)
        return if (xml.length <= maxChars) {
            xml
        } else {
            xml.take(maxChars) + "\n\n（已截断，完整长度 $xml 字符；可调大 max_chars）"
        }
    }

    private fun decodeManifest(archive: ApkArchive): AxmlDocument {
        val bytes = archive.read(MANIFEST_ENTRY)
            ?: throw ResParseException("APK 里找不到 $MANIFEST_ENTRY")
        return AxmlParser.decode(bytes)
    }

    // ── 条目浏览 ───────────────────────────────────────────────────────

    fun listEntries(
        archive: ApkArchive,
        pattern: String?,
        sortBy: String,
        limit: Int
    ): String {
        var entries: List<ZipEntry> = archive.entries

        if (!pattern.isNullOrBlank()) {
            val needle = pattern.lowercase()
            entries = entries.filter { it.name.lowercase().contains(needle) }
        }

        entries = when (sortBy.lowercase(Locale.US)) {
            "size" -> entries.sortedByDescending { if (it.size > 0) it.size else 0L }
            "name" -> entries.sortedBy { it.name }
            else -> entries
        }

        if (entries.isEmpty()) {
            return if (pattern.isNullOrBlank()) "（APK 里没有任何条目）"
            else "没有匹配「$pattern」的条目"
        }

        val sb = StringBuilder()
        val matched = entries.size
        sb.append("【条目】匹配 $matched 个" +
            if (!pattern.isNullOrBlank()) "（过滤：$pattern，排序：$sortBy）" else "（排序：$sortBy）")
        sb.append("\n\n")

        entries.take(limit).forEach { entry ->
            val size = if (entry.size >= 0) formatSize(entry.size) else "?"
            val compressed = if (entry.compressedSize >= 0) formatSize(entry.compressedSize) else "?"
            sb.append("${entry.name}  ($size / 压缩 $compressed)\n")
        }
        if (matched > limit) sb.append("\n…还有 ${matched - limit} 个未显示（可调大 limit）")
        return sb.toString()
    }

    // ── 读取单个条目 ───────────────────────────────────────────────────

    fun readEntry(archive: ApkArchive, name: String, maxChars: Int): String {
        val entryName = resolveEntryName(archive, name)
            ?: throw ResParseException(
                "APK 里没有「$name」这个条目。可先用 apk_list 查看实际路径。"
            )

        val bytes = archive.read(entryName)
            ?: throw ResParseException("无法读取「$entryName」")

        // 二进制 XML 自动解码 —— 用户拿到乱码没有任何意义
        if (entryName.endsWith(".xml", ignoreCase = true) && bytes.size >= 4) {
            val decoded = runCatching { AxmlParser.decode(bytes) }.getOrNull()
            if (decoded != null) {
                val xml = AxmlParser.toXml(decoded)
                return "${entryName}（二进制 XML，已解码）\n\n" + xml.take(maxChars)
            }
        }

        if (DexParser.isDex(bytes)) {
            val dex = DexParser.parse(bytes)
            return "【$entryName】DEX 文件（${formatSize(bytes.size.toLong())}，版本 ${dex.version}）\n" +
                "类 ${dex.classes.size}、方法 ${dex.methodCount}、字段 ${dex.fieldCount}、" +
                "字符串 ${dex.stringCount}\n\n" +
                "提示：用 apk_dex 可以列出类、方法与字符串。"
        }

        if (entryName == "resources.arsc") {
            val table = ResourceTableParser.parse(bytes)
            val topTypes = table.countByType().entries.take(12)
                .joinToString("、") { "${it.key} ${it.value}" }
            return "【resources.arsc】资源表（${formatSize(bytes.size.toLong())}）\n" +
                "包：${table.packages.joinToString("、")}\n" +
                "资源项 ${table.entries.size}、类型 ${table.typeCount} 种\n" +
                "主要类型：$topTypes\n\n" +
                "提示：用 apk_resources 可以按类型或关键字查询具体条目。"
        }

        // 文本类直接给内容
        if (looksLikeText(entryName)) {
            val text = String(bytes, Charsets.UTF_8)
            val printable = text.count { it == '\n' || it == '\t' || it.code in 32..126 || it.code > 0x7F }
            if (printable.toDouble() / text.length.coerceAtLeast(1) > 0.85) {
                return "【$entryName】\n\n" + text.take(maxChars) +
                    if (text.length > maxChars) "\n\n（已截断，完整 $entryName 共 ${text.length} 字符）" else ""
            }
        }

        // 其余二进制：给出头部十六进制，足够判断真实类型
        return buildString {
            append("【$entryName】二进制文件（${formatSize(bytes.size.toLong())}）\n")
            append("文件头（前 64 字节）：\n")
            append(hexDump(bytes, 64))
            magicOf(bytes)?.let { append("\n识别：$it") }
        }
    }

    // ── DEX 查询 ───────────────────────────────────────────────────────

    fun dexQuery(
        archive: ApkArchive,
        mode: String,
        dexName: String?,
        keyword: String?,
        limit: Int
    ): String {
        val names = if (!dexName.isNullOrBlank()) {
            listOf(resolveEntryName(archive, dexName) ?: dexName)
        } else {
            archive.namesMatching { it.matches(Regex("classes\\d*\\.dex")) }.sorted()
        }
        if (names.isEmpty()) throw ResParseException("APK 里没有找到 dex 文件")

        val sb = StringBuilder()
        when (mode.lowercase(Locale.US)) {
            "stat", "stats" -> {
                sb.append("【DEX 统计】\n\n")
                names.forEach { name ->
                    val dex = loadDex(archive, name) ?: run {
                        sb.append("- $name：解析失败\n"); return@forEach
                    }
                    sb.append("- $name（版本 ${dex.version}）\n")
                    sb.append("  类 ${dex.classes.size}、方法 ${dex.methodCount}、" +
                        "字段 ${dex.fieldCount}、字符串 ${dex.stringCount}\n")
                }
            }

            "classes", "class" -> {
                sb.append("【类列表】")
                if (!keyword.isNullOrBlank()) sb.append("过滤「$keyword」")
                sb.append("\n\n")
                var shown = 0
                names.forEach { name ->
                    val dex = loadDex(archive, name) ?: return@forEach
                    val matched = dex.classByNameOrDescriptor(keyword ?: "")
                    matched.forEach { cls ->
                        if (shown >= limit) return@forEach
                        sb.append("${cls.name}\n")
                        sb.append("    ${cls.modifiers}，继承 ${cls.superClass ?: "-"}" +
                            "，方法 ${cls.methodCount}、字段 ${cls.fieldCount}\n")
                        shown++
                    }
                }
                if (shown == 0) sb.append("没有匹配的类")
            }

            "methods", "method" -> {
                sb.append("【方法列表】")
                if (!keyword.isNullOrBlank()) sb.append("过滤「$keyword」")
                sb.append("\n\n")
                var shown = 0
                names.forEach { name ->
                    val dex = loadDex(archive, name) ?: return@forEach
                    val methods = dex.collectMethods(keyword, limit)
                    methods.forEach { m ->
                        if (shown >= limit) return@forEach
                        sb.append("${m.owner}.${m.name}(${m.shorty})\n")
                        shown++
                    }
                }
                if (shown == 0) sb.append("没有匹配的方法")
            }

            else -> {
                // strings
                sb.append("【字符串】")
                if (!keyword.isNullOrBlank()) sb.append("过滤「$keyword」")
                sb.append("\n\n")
                var shown = 0
                names.forEach { name ->
                    val dex = loadDex(archive, name) ?: return@forEach
                    dex.searchStrings(keyword, limit - shown).forEach {
                        sb.append(it).append('\n')
                        shown++
                    }
                }
                if (shown == 0) sb.append("没有匹配的字符串")
            }
        }
        return sb.toString()
    }

    private fun loadDex(archive: ApkArchive, name: String): DexFile? =
        runCatching {
            archive.read(name, 48 * 1024 * 1024)?.let { DexParser.parse(it) }
        }.getOrNull()

    // ── 资源表 ─────────────────────────────────────────────────────────

    fun resources(
        archive: ApkArchive,
        type: String?,
        keyword: String?,
        limit: Int
    ): String {
        val bytes = archive.read("resources.arsc")
            ?: throw ResParseException("APK 里没有 resources.arsc（可能是纯代码包）")
        val table = ResourceTableParser.parse(bytes)

        var entries = table.entries
        if (!type.isNullOrBlank()) {
            entries = entries.filter { it.typeName.equals(type, ignoreCase = true) }
        }
        if (!keyword.isNullOrBlank()) {
            val needle = keyword.lowercase()
            entries = entries.filter {
                it.entryName.lowercase().contains(needle) ||
                    it.value.lowercase().contains(needle)
            }
        }

        val sb = StringBuilder()
        sb.append("【资源】共 ${entries.size} 项")
        if (!type.isNullOrBlank()) sb.append("（类型 $type）")
        if (!keyword.isNullOrBlank()) sb.append("（关键字 $keyword）")
        sb.append("\n\n")

        if (entries.isEmpty()) {
            val available = table.countByType().entries.take(20)
                .joinToString("、") { "${it.key}(${it.value})" }
            return sb.append("没有匹配项。可用的类型有：\n$available").toString()
        }

        entries.take(limit).forEach { entry ->
            sb.append("${entry.typeName}/${entry.entryName}  ${entry.resIdHex}  = ${entry.value}\n")
        }
        if (entries.size > limit) sb.append("\n…还有 ${entries.size - limit} 项（可调大 limit）")
        return sb.toString()
    }

    // ── 全局搜索 ───────────────────────────────────────────────────────

    fun search(archive: ApkArchive, keyword: String, scope: String, limit: Int): String {
        if (keyword.isBlank()) throw ResParseException("keyword 不能为空")
        val needle = keyword.lowercase(Locale.US)
        val scopeLower = scope.lowercase(Locale.US)
        val sb = StringBuilder()
        sb.append("🔍 搜索「$keyword」（范围：$scopeLower）\n\n")
        var hits = 0

        // ① DEX 字符串池 —— 硬编码 URL / 密钥 / 上报点常在这里
        if (scopeLower == "all" || scopeLower == "dex" || scopeLower == "strings") {
            var dexHits = 0
            archive.namesMatching { it.matches(Regex("classes\\d*\\.dex")) }.sorted().forEach { name ->
                val dex = loadDex(archive, name) ?: return@forEach
                val found = dex.searchStrings(keyword, limit - dexHits)
                if (found.isNotEmpty()) {
                    sb.append("【$name】\n")
                    found.forEach {
                        sb.append("  $it\n")
                        dexHits++
                    }
                }
            }
            if (dexHits > 0) hits += dexHits else if (scopeLower == "dex" || scopeLower == "strings") {
                sb.append("（DEX 字符串池中未找到）\n")
            }
        }

        // ② 资源表
        if (scopeLower == "all" || scopeLower == "resources") {
            runCatching {
                archive.read("resources.arsc")?.let { ResourceTableParser.parse(it) }
            }.getOrNull()?.let { table ->
                val found = table.entries.filter {
                    it.entryName.lowercase().contains(needle) ||
                        it.value.lowercase().contains(needle)
                }.take(limit)
                if (found.isNotEmpty()) {
                    sb.append("【资源表】\n")
                    found.forEach {
                        sb.append("  ${it.typeName}/${it.entryName} = ${it.value}\n")
                        hits++
                    }
                }
            }
        }

        // ③ manifest（解码后的文本）
        if (scopeLower == "all" || scopeLower == "manifest") {
            runCatching { manifestXml(archive, Int.MAX_VALUE) }.getOrNull()?.let { xml ->
                val lines = xml.lines().filter { it.lowercase().contains(needle) }
                if (lines.isNotEmpty()) {
                    sb.append("【AndroidManifest.xml】\n")
                    lines.take(limit).forEach {
                        sb.append("  ${it.trim()}\n")
                        hits++
                    }
                }
            }
        }

        // ④ assets 与其它小文本文件
        if (scopeLower == "all" || scopeLower == "assets" || scopeLower == "files") {
            var fileHits = 0
            archive.entries
                .filter { it.size in 1..(512 * 1024) }
                .filter { it.name.startsWith("assets/") || looksLikeText(it.name) }
                .filter { it.name != "resources.arsc" && !it.name.endsWith(".dex", ignoreCase = true) }
                .take(300)
                .forEach { entry ->
                    if (fileHits >= limit) return@forEach
                    val bytes = runCatching { archive.read(entry.name) }.getOrNull() ?: return@forEach
                    val text = runCatching { String(bytes, Charsets.UTF_8) }.getOrNull()
                        ?: return@forEach
                    val lines = text.lines().filter { it.lowercase().contains(needle) }
                    if (lines.isNotEmpty()) {
                        if (fileHits == 0) sb.append("【文件内容】\n")
                        sb.append("  ${entry.name}：\n")
                        lines.take(3).forEach { sb.append("      ${it.trim().take(160)}\n") }
                        fileHits++
                        hits++
                    }
                }
        }

        if (hits == 0) {
            sb.append("没有找到匹配项。\n提示：DEX 里的字符串是**去重后的字面量**，")
            sb.append("如果目标字符串由代码拼接而成，在字符串池里就不会作为整体出现。")
        } else {
            sb.append("\n共 $hits 处命中。")
        }
        return sb.toString()
    }

    // ── 签名详情 ───────────────────────────────────────────────────────

    fun signature(archive: ApkArchive): String {
        val schemes = ApkSignatureInspector.detectSchemes(archive.file)
        val sb = StringBuilder()
        sb.append("🔐 **签名信息**\n\n")
        sb.append("签名方案：${schemes.describe()}\n")
        if (!schemes.any) {
            sb.append("\n⚠️ 未检测到任何签名方案 —— 该 APK 未签名或被剥离了签名。\n")
        }

        // v1 的签名文件名（能看出用了哪个别名）
        val v1Files = archive.namesMatching {
            val n = it.uppercase(Locale.US)
            n.startsWith("META-INF/") && (n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC"))
        }
        if (v1Files.isNotEmpty()) {
            sb.append("v1 签名文件：${v1Files.joinToString("、")}\n")
        }

        val certs = runCatching {
            ApkSignatureInspector.certificates(context, archive.file)
        }.getOrDefault(emptyList())

        if (certs.isEmpty()) {
            sb.append("\n（未能读出证书详情 —— 该包可能未签名，或证书格式不被系统识别）\n")
            return sb.toString()
        }

        certs.forEachIndexed { index, cert ->
            sb.append("\n**【证书 ${index + 1}】**\n")
            sb.append("主题（Subject）：${cert.subject}\n")
            sb.append("颁发者（Issuer）：${cert.issuer}\n")
            sb.append("序列号：${cert.serial}\n")
            sb.append("有效期：${cert.notBefore} ～ ${cert.notAfter}")
            if (cert.isExpired) sb.append("  ⚠️ 已过期")
            sb.append("\n")
            sb.append("签名算法：${cert.signatureAlgorithm}\n")
            sb.append("SHA-256：${cert.sha256}\n")
            sb.append("SHA-1：${cert.sha1}\n")
            if (cert.isSelfSigned) {
                sb.append("类型：自签名证书（Android 应用通常如此，不是安全问题）\n")
            }
            if (cert.subject.contains("Android Debug", ignoreCase = true)) {
                sb.append("⚠️ 这是 **Android 调试证书** —— 说明该包是开发构建，不是正式发布版\n")
            }
        }

        sb.append("\n用法提示：把 SHA-256 指纹与官方版本对比，不一致就说明包被重新签名过。\n")
        return sb.toString()
    }

    // ── 辅助 ──────────────────────────────────────────────────────────

    /** 容错地找条目：先精确匹配，再按后缀匹配（模型常常只记得文件名）。 */
    private fun resolveEntryName(archive: ApkArchive, name: String): String? {
        if (archive.exists(name)) return name
        val cleaned = name.trimStart('/')
        if (archive.exists(cleaned)) return cleaned
        return archive.entries.firstOrNull { it.name.endsWith("/$cleaned") }?.name
            ?: archive.entries.firstOrNull { it.name.equals(cleaned, ignoreCase = true) }?.name
    }

    /**
     * 把 `@0x7f0f0001` 这类引用还原成真实字符串。
     *
     * 失败返回 null —— 应用名解析不出来只是少一行信息，不该让整个总览失败。
     */
    private fun resolveStringResource(archive: ApkArchive, rawValue: String): String? {
        if (!rawValue.startsWith("@")) return rawValue
        val idText = rawValue.removePrefix("@").removePrefix("0x")
        val id = idText.toLongOrNull(16)?.toInt() ?: return null
        return runCatching {
            archive.read("resources.arsc")?.let { ResourceTableParser.parse(it) }
                ?.entries?.firstOrNull { it.resId == id }?.value
        }.getOrNull()
    }

    private fun looksLikeText(name: String): Boolean {
        val lower = name.lowercase(Locale.US)
        return TEXT_EXTENSIONS.any { lower.endsWith(it) }
    }

    private fun magicOf(bytes: ByteArray): String? = when {
        bytes.size >= 4 && bytes[0] == 0x7F.toByte() && bytes[1] == 'E'.code.toByte() ->
            "ELF 可执行 / 动态库"
        bytes.size >= 2 && bytes[0] == 0x1F.toByte() && bytes[1] == 0x8B.toByte() -> "GZIP 压缩数据"
        bytes.size >= 8 && bytes[0] == 0x89.toByte() && bytes[1] == 'P'.code.toByte() -> "PNG 图片"
        bytes.size >= 3 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() -> "JPEG 图片"
        bytes.size >= 4 && String(bytes, 0, 4, Charsets.US_ASCII) == "PK\u0003\u0004" -> "ZIP 归档"
        DexParser.isDex(bytes) -> "DEX 字节码"
        bytes.size >= 4 && bytes[0] == 0x03.toByte() -> "Android 二进制资源 / XML"
        else -> null
    }

    private fun hexDump(bytes: ByteArray, maxBytes: Int): String {
        val sb = StringBuilder()
        val limit = minOf(bytes.size, maxBytes)
        var offset = 0
        while (offset < limit) {
            sb.append("%08x  ".format(offset))
            val row = minOf(16, limit - offset)
            for (i in 0 until 16) {
                if (i < row) sb.append("%02x ".format(bytes[offset + i]))
                else sb.append("   ")
                if (i == 7) sb.append(' ')
            }
            sb.append(" |")
            for (i in 0 until row) {
                val b = bytes[offset + i].toInt() and 0xFF
                sb.append(if (b in 32..126) b.toChar() else '.')
            }
            sb.append("|\n")
            offset += 16
        }
        if (bytes.size > limit) sb.append("…（还有 ${bytes.size - limit} 字节）\n")
        return sb.toString()
    }

    /** 流式计算摘要：APK 体积可能很大，整包读进内存没有必要。 */
    private fun sha256File(file: java.io.File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(1 shl 16)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes < 0 -> "?"
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
        else -> "%.2f MB".format(bytes / (1024.0 * 1024.0))
    }

    private companion object {
        const val MANIFEST_ENTRY = "AndroidManifest.xml"

        val TEXT_EXTENSIONS = listOf(
            ".txt", ".json", ".js", ".mjs", ".html", ".htm", ".css", ".md",
            ".properties", ".cfg", ".ini", ".conf", ".yml", ".yaml",
            ".pro", ".version", ".kotlin_module", ".java", ".kt", ".smali"
        )
    }
}
