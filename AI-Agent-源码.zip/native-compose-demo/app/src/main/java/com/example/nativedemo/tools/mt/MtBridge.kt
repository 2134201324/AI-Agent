package com.example.nativedemo.tools.mt

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.net.toUri
import java.io.File

/**
 * 与 MT 管理器（`bin.mt.plus`）通信的桥。
 *
 * ## 它能干什么、不能干什么
 * MT 管理器对外**只开放了「打开某个路径」这一个动作**（社区逆向出的
 * `ACTION_SHORTCUT` 协议），没有「反编译这个 APK」「批量改名」这类命令式接口。
 * 所以本类只做一件事：把 MT 拉起来并停在目标位置。
 * 到那个界面之后的一切操作由用户自己完成 —— 本应用刻意不提供读取屏幕 /
 * 模拟点击的能力（无 AccessibilityService），AI 不得操作用户的手机。
 *
 * ## 协议来源
 * 官方文档没有公开这套接口，写法来自 MT 官方论坛（bbs.binmt.cc）的实践总结：
 * MT 里「长按文件 → 工具 → 创建快捷方式」本质就是发出一个
 * `ACTION_SHORTCUT` 意图，把参数塞进 `operation` / `path` 两个 extra。
 * 社区实测（Android 14、无 root）确认有效的形态：
 *
 * ```
 * Intent("bin.mt.plus.ACTION_SHORTCUT").apply {
 *     setComponent(ComponentName("bin.mt.plus", "bin.mt.plus.ShortcutActivity"))
 *     addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET)
 *     putExtra("operation", "locate")   // 或 "goto"
 *     putExtra("path", targetPath)
 * }
 * ```
 *
 * 两个容易踩的点（都有论坛实证）：
 * 1. extra 键名就是 `operation` / `path`。`am start` shell 命令里看到的
 *    `S.path` 是 shell 标识「字符串 extra」的语法，不是键名的一部分 ——
 *    在代码里 `putExtra("S.path", ...)` 不生效。
 * 2. `launchFlags=0x80000` 即 `FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET`，
 *    样本里都带它，缺了可能复用一个残留任务栈。
 *
 * 这个桥对 MT 版本有一定假设，调不通时最可靠的办法是让用户
 * 自己长按创建一个快捷方式、用抓取工具导出参数比对。
 */
object MtBridge {

    /** 原版与共存版的包名。共存版让用户可以在同一台设备上装两个互不干扰的 MT。 */
    val PACKAGES = listOf(
        "bin.mt.plus",
        "bin.mt.plus.canary",
        "bin.mt.plus.beta",
        "bin.mt.plus.dev"
    )

    const val ACTION_SHORTCUT = "bin.mt.plus.ACTION_SHORTCUT"

    /** 空路径时退回打开的目录。 */
    private const val FALLBACK_PATH = "/sdcard"

    /** 已安装的 MT 包名；没装返回 null。 */
    fun installedPackage(context: Context): String? =
        PACKAGES.firstOrNull { isInstalled(context, it) }

    fun isInstalled(context: Context, pkg: String = PACKAGES.first()): Boolean = try {
        context.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /** MT 的版本名，用于在工具输出里报出实际环境。 */
    fun versionName(context: Context): String? {
        val pkg = installedPackage(context) ?: return null
        return try {
            context.packageManager.getPackageInfo(pkg, 0).versionName
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    /**
     * 在 MT 中打开一个路径。
     *
     * @param operation `locate` 定位并选中（适合文件），`goto` 直接进入（适合目录）
     */
    fun openIntent(path: String, operation: String = "locate", packageName: String? = null): Intent {
        val target = path.trim().ifEmpty { FALLBACK_PATH }
        val pkg = packageName ?: PACKAGES.first()
        return Intent(ACTION_SHORTCUT).apply {
            component = ComponentName(pkg, "$pkg.ShortcutActivity")
            // 从 application context 启动 Activity 必须带 NEW_TASK；
            // CLEAR_WHEN_TASK_RESET（0x80000）是社区样本里都带的 flag，
            // 避免复用一个残留的 MT 任务栈。
            // （我们调用时通常有前台服务在跑，所以不受"后台启动 Activity"限制。）
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET)
            // 键名就是 operation / path 本身，不要加 "S." 前缀 —— 那是 shell 语法
            putExtra("operation", operation)
            putExtra("path", target)
        }
    }

    /**
     * 用系统「打开方式」的方式交给 MT —— 目录要声明 MIME 为 `resource/folder`，
     * 否则 MT 可能不认领这个 Intent。
     */
    fun viewIntent(path: String, isDirectory: Boolean, packageName: String? = null): Intent {
        val pkg = packageName ?: PACKAGES.first()
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            File(path).toUri()
        } else {
            @Suppress("DEPRECATION")
            Uri.fromFile(File(path))
        }
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, if (isDirectory) "resource/folder" else "*/*")
            component = ComponentName(pkg, "$pkg.Main")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    /** 跳系统设置页，让用户开启"后台弹出界面"（部分 ROM 需要它才允许我们拉起别的 App）。 */
    fun backgroundStartSettings(): Intent? =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /**
     * 发起调起并区分失败原因。
     *
     * 返回 null 表示成功；否则是给模型看的人话解释 —— 让模型知道该建议用户去装 MT
     * 还是去开权限，而不是笼统地报一句"失败了"。
     */
    fun launch(context: Context, intent: Intent, packageName: String? = null): String? {
        val pkg = packageName ?: PACKAGES.first()
        if (!isInstalled(context, pkg)) {
            return "本机没有安装 MT 管理器（已检查 ${PACKAGES.joinToString("/")}）。" +
                "请从 https://mt2.cn 安装后再试。"
        }
        return try {
            context.startActivity(intent)
            null
        } catch (e: android.content.ActivityNotFoundException) {
            "MT 管理器没有响应这个打开请求（可能版本不一致）。" +
                "备选办法：让用户在 MT 里手动定位到该路径。"
        } catch (e: SecurityException) {
            "系统拒绝启动 MT 管理器。部分机型（尤其 MIUI/鸿蒙）需要先在" +
                "「设置 → 应用 → 本应用 → 其他权限」里打开「后台弹出界面/显示悬浮窗」权限。"
        } catch (t: Throwable) {
            "启动 MT 管理器失败：${t.message ?: t::class.java.simpleName}"
        }
    }
}
