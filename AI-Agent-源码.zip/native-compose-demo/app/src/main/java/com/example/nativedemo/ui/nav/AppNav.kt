package com.example.nativedemo.ui.nav

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.nativedemo.core.AppContainer
import com.example.nativedemo.data.agent.ConversationMeta
import com.example.nativedemo.data.agent.UiRole
import com.example.nativedemo.ui.chat.ChatScreen
import com.example.nativedemo.ui.chat.ChatViewModel
import com.example.nativedemo.ui.build.CloudBuildScreen
import com.example.nativedemo.ui.build.CloudBuildViewModel
import com.example.nativedemo.ui.common.BackgroundLayer
import com.example.nativedemo.ui.settings.AboutPage
import com.example.nativedemo.ui.settings.AppearancePage
import com.example.nativedemo.ui.settings.CustomBackgroundScreen
import com.example.nativedemo.ui.settings.FileAccessPage
import com.example.nativedemo.ui.settings.ModelConnectionPage
import com.example.nativedemo.ui.settings.ModelParamsPage
import com.example.nativedemo.ui.settings.OrchestrationPage
import com.example.nativedemo.ui.settings.PermissionCenterPage
import com.example.nativedemo.ui.settings.ReaEnginePage
import com.example.nativedemo.ui.settings.SettingsHome
import com.example.nativedemo.ui.settings.SettingsViewModel
import com.example.nativedemo.ui.settings.ToolPermissionPage
import com.example.nativedemo.ui.terminal.TerminalScreen
import com.example.nativedemo.ui.terminal.TerminalViewModel
import com.example.nativedemo.ui.theme.Bg
import com.example.nativedemo.ui.theme.ChipBg
import com.example.nativedemo.ui.theme.DrawerBg
import com.example.nativedemo.ui.theme.Faint
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.Muted
import com.example.nativedemo.ui.theme.TopBarBg
import com.example.nativedemo.ui.theme.TopBarFg
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Screen(val title: String) {
    CHAT(""),
    SETTINGS("设置"),
    MODEL("模型连接"),
    PARAMS("模型参数"),
    ORCHESTRATION("多模型编排"),
    PERMISSIONS("权限中心"),
    TOOLS("工具权限"),
    FILES("本地目录"),
    REA("REA 逆向引擎"),
    BUILD("云端打包"),
    APPEARANCE("界面美化"),
    BACKGROUND("自定义背景"),
    TERMINAL("命令终端"),
    ABOUT("关于")
}

/** 返回上一级。返回 null 表示已在根页面，此时交给系统（退出应用）。 */
private fun parentOf(screen: Screen): Screen? = when (screen) {
    Screen.CHAT -> null
    Screen.SETTINGS -> Screen.CHAT
    Screen.BACKGROUND -> Screen.APPEARANCE
    Screen.TERMINAL -> Screen.SETTINGS
    else -> Screen.SETTINGS
}

/**
 * 页面导航：对话 → 设置（入口列表）→ 各详细设置子页，外加左侧会话抽屉。
 *
 * 页面是线性的、"子页只回上一级"，所以用一个当前页变量 + [parentOf] 就够，
 * 不需要引入 navigation-compose 或维护返回栈。
 */
@Composable
fun AppNav(container: AppContainer) {
    var screen by rememberSaveable { mutableStateOf(Screen.CHAT) }

    val chatViewModel: ChatViewModel = viewModel(factory = ChatViewModel.factory(container))
    val messages by chatViewModel.messages.collectAsStateWithLifecycle()
    val conversations by chatViewModel.conversations.collectAsStateWithLifecycle()
    val currentId by chatViewModel.currentId.collectAsStateWithLifecycle()

    // 设置与外观共用同一个 ViewModel：外观改动要即时反映到全局主题，
    // 两处各建一个实例会导致状态不同步。
    val settingsViewModel: SettingsViewModel =
        viewModel(factory = SettingsViewModel.factory(container))
    val settings by settingsViewModel.state.collectAsStateWithLifecycle()

    // 用系统相册选择器（Android 13+ 是原生 Photo Picker），
    // 而不是 OpenDocument —— 后者在多数设备上会打开"文件夹/文档"界面，
    // 选图体验完全不对。选中的图会被拷进应用私有目录，不依赖 SAF 授权。
    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) settingsViewModel.applyBackgroundImage(uri)
    }

    val treePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) settingsViewModel.addAuthorizedTree(uri)
    }

    // 云打包的图标选择。与背景图同源（系统相册），但落点不同：
    // 背景图进外观目录且会被压缩，图标要保真，直接存原文件交给服务端校验。
    // ViewModel 在这里创建而不是在页面里：页面切换时不能把构建状态丢掉。
    val buildViewModel: CloudBuildViewModel =
        viewModel(factory = CloudBuildViewModel.factory(container))

    val iconPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) buildViewModel.applyIcon(uri)
    }

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // 返回键分级：抽屉开着 → 关抽屉；子页 → 回上一级；根页面才交给系统退出。
    BackHandler(enabled = drawerState.isOpen || screen != Screen.CHAT) {
        when {
            drawerState.isOpen -> scope.launch { drawerState.close() }
            else -> parentOf(screen)?.let { screen = it }
        }
    }

    val title = if (screen == Screen.CHAT) {
        messages.firstOrNull { it.role == UiRole.USER }
            ?.text
            ?.replace('\n', ' ')
            ?.trim()
            ?.take(18)
            ?.takeIf { it.isNotEmpty() }
            ?: "新对话"
    } else {
        screen.title
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = DrawerBg,
                modifier = Modifier.width(300.dp)
            ) {
                ConversationDrawer(
                    conversations = conversations,
                    currentId = currentId,
                    onNew = {
                        chatViewModel.newConversation()
                        screen = Screen.CHAT
                        scope.launch { drawerState.close() }
                    },
                    onOpen = { id ->
                        chatViewModel.openConversation(id)
                        screen = Screen.CHAT
                        scope.launch { drawerState.close() }
                    },
                    onDelete = { chatViewModel.deleteConversation(it) },
                    onSettings = {
                        screen = Screen.SETTINGS
                        scope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        Box(modifier = Modifier.fillMaxSize().background(Bg)) {
            // 背景图铺在最底层：顶栏与正文都浮在它上面，
            // 各区域自身的背景色若设了透明度就能透出壁纸。
            BackgroundLayer(
                style = settings.background,
                modifier = Modifier.fillMaxSize()
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
            ) {
                AppTopBar(
                    title = title,
                    showBack = screen != Screen.CHAT,
                    onBackOrMenu = {
                        if (screen == Screen.CHAT) {
                            scope.launch {
                                if (drawerState.isClosed) drawerState.open()
                                else drawerState.close()
                            }
                        } else {
                            parentOf(screen)?.let { screen = it }
                        }
                    },
                    onNewChat = {
                        chatViewModel.newConversation()
                        screen = Screen.CHAT
                    }
                )

                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when (screen) {
                        Screen.CHAT -> ChatScreen(
                            viewModel = chatViewModel,
                            densityScale = settings.density.value,
                            bubbleCornerDp = settings.bubbleCorner.radiusDp.dp,
                            currentId = currentId
                        )

                        Screen.SETTINGS -> SettingsHome(
                            viewModel = settingsViewModel,
                            onOpenModel = { screen = Screen.MODEL },
                            onOpenParams = { screen = Screen.PARAMS },
                            onOpenOrchestration = { screen = Screen.ORCHESTRATION },
                            onOpenPermissions = { screen = Screen.PERMISSIONS },
                            onOpenTools = { screen = Screen.TOOLS },
                            onOpenFiles = { screen = Screen.FILES },
                            onOpenRea = { screen = Screen.REA },
                            onOpenBuild = { screen = Screen.BUILD },
                            onOpenAppearance = { screen = Screen.APPEARANCE },
                            onOpenTerminal = { screen = Screen.TERMINAL },
                            onOpenAbout = { screen = Screen.ABOUT }
                        )

                        Screen.MODEL -> ModelConnectionPage(settingsViewModel)
                        Screen.PARAMS -> ModelParamsPage(settingsViewModel)
                        Screen.ORCHESTRATION -> OrchestrationPage(settingsViewModel)
                        Screen.PERMISSIONS -> PermissionCenterPage()
                        Screen.TOOLS -> ToolPermissionPage(settingsViewModel)
                        Screen.FILES -> FileAccessPage(
                            viewModel = settingsViewModel,
                            onPickTree = { treePicker.launch(null) }
                        )

                        Screen.REA -> ReaEnginePage(settingsViewModel)

                        Screen.BUILD -> CloudBuildScreen(
                            viewModel = buildViewModel,
                            onPickIcon = {
                                iconPicker.launch(
                                    PickVisualMediaRequest(
                                        ActivityResultContracts.PickVisualMedia.ImageOnly
                                    )
                                )
                            }
                        )

                        Screen.APPEARANCE -> AppearancePage(
                            viewModel = settingsViewModel,
                            onOpenBackground = { screen = Screen.BACKGROUND }
                        )

                        Screen.TERMINAL -> TerminalScreen(
                            viewModel = viewModel(
                                factory = TerminalViewModel.factory(container)
                            )
                        )

                        Screen.BACKGROUND -> CustomBackgroundScreen(
                            background = settings.background,
                            overrides = settings.colorOverrides,
                            notice = settings.notice,
                            onPickImage = {
                                photoPicker.launch(
                                    PickVisualMediaRequest(
                                        ActivityResultContracts.PickVisualMedia.ImageOnly
                                    )
                                )
                            },
                            onClearImage = settingsViewModel::clearBackgroundImage,
                            onBlurChange = settingsViewModel::setBackgroundBlur,
                            onAlphaChange = settingsViewModel::setBackgroundAlpha,
                            onSmartContrastChange = settingsViewModel::setSmartContrast,
                            onSlotCommit = settingsViewModel::setColorSlot,
                            onResetColors = settingsViewModel::resetColorSlots
                        )

                        Screen.ABOUT -> AboutPage()
                    }
                }
            }
        }
    }
}

@Composable
private fun AppTopBar(
    title: String,
    showBack: Boolean,
    onBackOrMenu: () -> Unit,
    onNewChat: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .background(TopBarBg)
            .padding(horizontal = 4.dp)
    ) {
        IconButton(
            onClick = onBackOrMenu,
            modifier = Modifier.align(Alignment.CenterStart)
        ) {
            Icon(
                imageVector = if (showBack) {
                    Icons.AutoMirrored.Filled.ArrowBack
                } else {
                    Icons.Default.Menu
                },
                contentDescription = if (showBack) "返回" else "会话列表",
                tint = TopBarFg,
                modifier = Modifier.size(22.dp)
            )
        }

        Text(
            text = title,
            color = TopBarFg,
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 64.dp)
        )

        if (!showBack) {
            IconButton(
                onClick = onNewChat,
                modifier = Modifier.align(Alignment.CenterEnd)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "开始新对话",
                    tint = TopBarFg,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

@Composable
private fun ConversationDrawer(
    conversations: List<ConversationMeta>,
    currentId: String,
    onNew: () -> Unit,
    onOpen: (String) -> Unit,
    onDelete: (String) -> Unit,
    onSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .clickable(onClick = onNew)
                .padding(horizontal = 12.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                tint = Fg,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(12.dp))
            Text("新对话", color = Fg, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }

        Spacer(Modifier.height(10.dp))
        Text(
            text = "历史对话",
            color = Faint,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        Spacer(Modifier.height(8.dp))

        if (conversations.isEmpty()) {
            Text(
                text = "暂无历史对话",
                color = Faint,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )
        } else {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(conversations, key = { it.id }) { item ->
                    ConversationRow(
                        item = item,
                        selected = item.id == currentId,
                        onOpen = onOpen,
                        onDelete = onDelete
                    )
                }
            }
        }

        Spacer(Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .clickable(onClick = onSettings)
                .padding(horizontal = 12.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = null,
                tint = Muted,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(12.dp))
            Text("设置", color = Muted, fontSize = 15.sp)
        }
    }
}

@Composable
private fun ConversationRow(
    item: ConversationMeta,
    selected: Boolean,
    onOpen: (String) -> Unit,
    onDelete: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) ChipBg else Color.Transparent)
            .clickable { onOpen(item.id) }
            .padding(start = 12.dp, end = 2.dp, top = 9.dp, bottom = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.title,
                color = Fg,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = formatTime(item.updatedAt),
                color = Faint,
                fontSize = 11.sp
            )
        }
        IconButton(onClick = { onDelete(item.id) }) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "删除会话",
                tint = Faint,
                modifier = Modifier.size(15.dp)
            )
        }
    }
}

private fun formatTime(timestamp: Long): String {
    if (timestamp <= 0L) return ""
    val diff = System.currentTimeMillis() - timestamp
    return when {
        diff < 60_000L -> "刚刚"
        diff < 3_600_000L -> "${diff / 60_000L} 分钟前"
        diff < 86_400_000L -> "${diff / 3_600_000L} 小时前"
        diff < 7 * 86_400_000L -> "${diff / 86_400_000L} 天前"
        else -> SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(timestamp))
    }
}
