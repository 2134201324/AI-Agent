package com.example.nativedemo.tools.builtin

import android.net.Uri
import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.bool
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import com.example.nativedemo.tools.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject

/**
 * 写入用户已授权目录中的文件。标记为 destructive，UI 层可做二次确认。
 */
class FileWriteTool : Tool {

    override val spec = ToolSpec(
        name = "file_write",
        description = "把文本写入已授权目录中的已有文件。默认**整体覆盖**（原内容会被完全替换，" +
            "可用于删除或重写内容）；append=true 时改为追加。要精确修改某段文字，" +
            "用 file_edit 更合适；要新建文件，用 file_create。",
        category = "文件",
        layer = "L1",
        destructive = true,
        params = objectSchema {
            string("path", "目标文件路径，例如 code_game/note.txt，或完整 content:// URI")
            string("content", "要写入的文本内容")
            boolean("append", "为 true 时追加到末尾；默认 false 表示整体覆盖（会截断原文件）", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val pathArg = try {
            args.requireStr("path")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }
        val content = args.str("content") ?: return ToolResult.failure("缺少必填参数 'content'")

        val document = ctx.uriAccessPolicy.resolveDocument(pathArg)
            ?: return ToolResult.failure(
                "未找到「$pathArg」。可以先调用 file_list 确认已授权目录，再指定具体文件名。"
            )
        if (document.isDirectory) {
            return ToolResult.failure("「$pathArg」是一个目录，请指定具体文件名。")
        }
        val uri = document.uri

        ctx.uriAccessPolicy.denyReason(uri, write = true)?.let { return ToolResult.failure(it) }

        val append = args.bool("append", false)

        return withContext(Dispatchers.IO) {
            try {
                val bytes = content.toByteArray(Charsets.UTF_8)
                // 关键：覆盖写入必须用 "rwt"（read-write-truncate）。
                // 若用 "w"，ContentResolver 不保证截断文件 —— 新内容只覆盖前一段，
                // 尾部旧内容残留，表现就是「只能追加、删不掉内容」。
                val mode = if (append) "wa" else "rwt"
                ctx.contentResolver.openOutputStream(uri, mode)?.use { output ->
                    output.write(bytes)
                    output.flush()
                } ?: return@withContext ToolResult.failure("无法打开该文件用于写入")

                ToolResult.success(
                    "已${if (append) "追加" else "覆盖写入"} ${bytes.size} 字节到「${document.name ?: uri}」" +
                        if (append) "" else "（原内容已被整体替换）"
                )
            } catch (e: SecurityException) {
                ToolResult.failure("权限不足：${e.message}")
            } catch (e: Throwable) {
                ToolResult.failure("写入失败：${e.message ?: e::class.java.simpleName}")
            }
        }
    }
}
