package com.example.nativedemo.data.llm

/**
 * 服务商预设。
 *
 * API Key 本身不携带「它属于哪家服务」的信息 —— 同一个 `sk-xxx` 可能是 OpenAI、
 * 阿里云、DeepSeek 或某个中转站的。所以服务端地址必须由用户提供。
 *
 * 但「必须提供」不等于「必须手打」。这里内置常见服务商的正确配置，
 * 用户点一下即可，避免把控制台网页地址（如 bailian.console.aliyun.com）误当成 API 地址。
 */
data class LlmPreset(
    val label: String,
    val baseUrl: String,
    val defaultModel: String,
    val modelSuggestions: List<String> = emptyList(),
    val note: String = "",
    /**
     * 该服务是否需要用户自备 API Key。
     *
     * 网页桥接（DSH 等）转发的是浏览器登录态，本来就不校验令牌 ——
     * 给它填 Key 是协议形式带来的多余步骤，所以标记为 false，界面会自动免填。
     */
    val requiresApiKey: Boolean = true
)

object LlmPresets {

    val all: List<LlmPreset> = listOf(
        LlmPreset(
            label = "阿里云百炼",
            baseUrl = "https://dashscope.aliyuncs.com/compatible-mode/v1",
            defaultModel = "qwen-plus",
            modelSuggestions = listOf("qwen-plus", "qwen-turbo", "qwen-max", "qwen-long")
        ),
        LlmPreset(
            label = "OpenAI",
            baseUrl = "https://api.openai.com/v1",
            defaultModel = "gpt-4o-mini",
            modelSuggestions = listOf("gpt-4o-mini", "gpt-4o", "gpt-4.1-mini")
        ),
        LlmPreset(
            label = "DeepSeek",
            baseUrl = "https://api.deepseek.com/v1",
            defaultModel = "deepseek-chat",
            modelSuggestions = listOf("deepseek-chat", "deepseek-reasoner")
        ),
        LlmPreset(
            label = "月之暗面 Kimi",
            baseUrl = "https://api.moonshot.cn/v1",
            defaultModel = "moonshot-v1-8k",
            modelSuggestions = listOf("moonshot-v1-8k", "moonshot-v1-32k", "moonshot-v1-128k")
        ),
        LlmPreset(
            label = "智谱 GLM",
            baseUrl = "https://open.bigmodel.cn/api/paas/v4",
            defaultModel = "glm-4-flash",
            modelSuggestions = listOf("glm-4-flash", "glm-4-air", "glm-4-plus")
        ),
        LlmPreset(
            label = "硅基流动",
            baseUrl = "https://api.siliconflow.cn/v1",
            defaultModel = "Qwen/Qwen2.5-7B-Instruct",
            modelSuggestions = listOf("Qwen/Qwen2.5-7B-Instruct", "deepseek-ai/DeepSeek-V3")
        ),
        LlmPreset(
            label = "DeepSeek 网页桥接",
            baseUrl = "",
            defaultModel = "deepseek-chat",
            modelSuggestions = listOf("deepseek-chat", "deepseek-reasoner"),
            note = "本地运行 DeepSeek-Harness（DSH）等网页桥接工具后，" +
                "把它的本地地址填进 Base URL（常见为 http://127.0.0.1:8000/v1），" +
                "即可将 DeepSeek 网页端能力以 OpenAI 兼容协议使用；" +
                "桥接用的是网页登录态，不需要 API Key（已自动免填）",
            requiresApiKey = false
        ),
        LlmPreset(
            label = "自定义",
            baseUrl = "",
            defaultModel = "",
            note = "使用服务商或中转站提供给你的 API 地址"
        )
    )

    /** 按 base URL 反查预设，用于回显当前选中项与推荐模型。 */
    fun match(baseUrl: String): LlmPreset? {
        val normalized = baseUrl.trim().trimEnd('/')
        return all.firstOrNull {
            it.baseUrl.isNotBlank() && it.baseUrl.trimEnd('/') == normalized
        }
    }
}
