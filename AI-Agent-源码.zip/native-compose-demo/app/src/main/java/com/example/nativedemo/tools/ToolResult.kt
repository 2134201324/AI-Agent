package com.example.nativedemo.tools

/**
 * 工具执行结果。
 *
 * 设计原则（与参考实现一致）：工具失败不抛异常中断整条链路，
 * 而是转成结构化文本回灌给模型，让它自行修正后重试。
 */
sealed interface ToolResult {

    val ok: Boolean
    val text: String

    data class Success(override val text: String) : ToolResult {
        override val ok: Boolean get() = true
    }

    data class Failure(override val text: String) : ToolResult {
        override val ok: Boolean get() = false
    }

    companion object {
        fun success(text: String): ToolResult = Success(text)
        fun failure(reason: String): ToolResult = Failure(reason)
    }
}
