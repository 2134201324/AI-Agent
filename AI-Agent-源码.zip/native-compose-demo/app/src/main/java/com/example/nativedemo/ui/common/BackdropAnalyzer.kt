package com.example.nativedemo.ui.common

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import com.example.nativedemo.data.settings.BackdropStats
import com.example.nativedemo.ui.theme.analyzeBackdropPixels
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 背景图分析：解码一张下采样小图，统计明暗与繁忙度。
 *
 * 之所以用**独立的 96px 解码**而不是复用界面上的位图：
 * 界面位图长边 1400px，逐像素统计要扫两百万个点；而智能适配只需要
 * 整体特征，96px 的统计结果与全图几乎一致，成本却低两个数量级。
 *
 * 任何失败都返回 null —— 由调用方决定是禁用智能适配还是提示用户。
 */
suspend fun analyzeBackdrop(context: Context, source: String): BackdropStats? =
    withContext(Dispatchers.IO) {
        runCatching {
            val decoded: Bitmap = decodeImage(context, source, 96) ?: return@runCatching null
            // ImageDecoder 在不少设备上会给出 Config#HARDWARE 的位图：画到屏幕上完全正常，
            // 但**不允许逐像素读取**，getPixels 直接抛 IllegalStateException。
            // 这条异常会被下面的 runCatching 吞掉，表现就是「背景图明明显示着，
            // 却提示无法分析、智能适配点不开」。所以读像素前必须先转成软件位图。
            val bitmap = toSoftwareBitmap(decoded)
            try {
                val width = bitmap.width
                val height = bitmap.height
                val pixels = IntArray(width * height)
                bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
                analyzeBackdropPixels(pixels, width, height)
            } finally {
                bitmap.recycle()
            }
        }.getOrNull()
    }

/**
 * 把硬件位图转成可读像素的 ARGB_8888。
 *
 * [Bitmap.Config.HARDWARE] 是 API 26 才有的枚举值，而本项目 minSdk 是 24 ——
 * 低于 26 时连引用这个常量都会 NoSuchFieldError，所以先做版本判断；
 * 那些版本走的是 BitmapFactory，本来也不会产出硬件位图。
 */
private fun toSoftwareBitmap(bitmap: Bitmap): Bitmap {
    val isHardware = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
        bitmap.config == Bitmap.Config.HARDWARE
    if (!isHardware) return bitmap
    val software = bitmap.copy(Bitmap.Config.ARGB_8888, false) ?: return bitmap
    bitmap.recycle()
    return software
}
