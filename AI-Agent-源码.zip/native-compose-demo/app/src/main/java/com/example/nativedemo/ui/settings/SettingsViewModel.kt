package com.example.nativedemo.ui.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.nativedemo.core.AppContainer
import com.example.nativedemo.data.llm.BridgeDiscovery
import com.example.nativedemo.data.llm.DiscoveredBridge
import com.example.nativedemo.data.llm.LOCAL_BRIDGE_PLACEHOLDER_KEY
import com.example.nativedemo.data.llm.LlmPreset
import com.example.nativedemo.data.llm.effectiveApiKey
import com.example.nativedemo.data.llm.localIpv4Address
import com.example.nativedemo.data.llm.normalizeBaseUrl
import com.example.nativedemo.data.llm.pickPreferredModel
import com.example.nativedemo.data.rea.ReaClient
import com.example.nativedemo.data.settings.AppBrand
import com.example.nativedemo.data.settings.BackgroundStyle
import com.example.nativedemo.data.settings.BubbleCorner
import com.example.nativedemo.data.settings.ColorSlot
import com.example.nativedemo.data.settings.FontScaleOption
import com.example.nativedemo.data.settings.ModelProfile
import com.example.nativedemo.data.settings.ProfileRole
import com.example.nativedemo.data.settings.SettingsDefaults
import com.example.nativedemo.data.settings.ThemeMode
import com.example.nativedemo.data.settings.UiDensity
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.saf.AuthorizedRoot
import com.example.nativedemo.ui.common.analyzeBackdrop
import com.example.nativedemo.ui.common.importAsJpeg
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** 单个档案的连接测试状态。同时服务已存档案的测试与编辑框草稿的测试。 */
data class ProfileTestState(
    /** 被测试档案的 id；null = 测试的是尚未保存的草稿。 */
    val profileId: String?,
    val running: Boolean = false,
    val ok: Boolean? = null,
    val message: String? = null,
    /** 探测到的工具调用支持情况，成功时才有值。 */
    val toolsSupported: Boolean? = null
)

/**
 * 「获取模型清单」的状态。一个 Key 能调哪些模型由它自己的权限决定，
 * 与其在输入框里猜名字，不如直接问服务端要清单（GET /models）。
 *
 * [targetProfileId] 指明这次拉取是给谁的：null = 默认配置（或新档案草稿），
 * 否则界面上只把结果展示给对应的档案卡片 / 编辑框，避免串味。
 */
sealed interface ModelFetchState {
    data object Loading : ModelFetchState
    data class Success(
        val models: List<String>,
        val targetProfileId: String?
    ) : ModelFetchState

    data class Failure(
        val message: String,
        val targetProfileId: String?
    ) : ModelFetchState
}

/** 局域网桥接扫描状态。见 [BridgeDiscovery]。 */
sealed interface BridgeScanState {
    data object Idle : BridgeScanState
    data class Running(
        val scanned: Int = 0,
        val total: Int = 0,
        val ownIp: String? = null
    ) : BridgeScanState

    data class Done(
        val bridges: List<DiscoveredBridge>,
        val scanned: Int,
        val total: Int,
        val timedOut: Boolean,
        val ownIp: String?
    ) : BridgeScanState
}

/** 取模型清单状态的归属 id；Loading 态没有归属信息，返回 null。 */
internal fun ModelFetchState.targetProfileIdOrNull(): String? = when (this) {
    is ModelFetchState.Success -> targetProfileId
    is ModelFetchState.Failure -> targetProfileId
    ModelFetchState.Loading -> null
}

class SettingsViewModel(
    private val container: AppContainer
) : ViewModel() {

    private val appContext = container.appContext

    data class UiState(
        val selectedPresetLabel: String? = null,
        val baseUrl: String = "",
        val model: String = "",
        val apiKeyInput: String = "",
        val hasStoredKey: Boolean = false,
        val temperature: Float = 0.7f,
        /** 单次请求输出上限；0 = 不限制（不发送该参数） */
        val maxOutputTokens: Int = SettingsDefaults.MAX_OUTPUT_TOKENS,
        /** 单次任务的工具调用轮次上限。逆向这类长任务需要的轮次很多。 */
        val maxToolRounds: Int = SettingsDefaults.MAX_TOOL_ROUNDS,
        val systemPrompt: String = "",
        val tools: List<ToolSpec> = emptyList(),
        val enabledTools: Set<String> = emptySet(),
        val roots: List<AuthorizedRoot> = emptyList(),
        val rootEntries: List<String> = emptyList(),
        val testing: Boolean = false,
        val testOk: Boolean? = null,
        val testMessage: String? = null,
        val notice: String? = null,
        // ── 多模型编排 ──
        val profiles: List<ModelProfile> = emptyList(),
        val orchestratorId: String? = null,
        val orchestrationEnabled: Boolean = false,
        /** 单模型模式选用的档案 id；null = 用默认配置 */
        val activeProfileId: String? = null,
        /** 档案连接测试的进行态；profileId 为 null 表示测的是编辑框里的草稿。 */
        val profileTest: ProfileTestState? = null,
        /** 「获取模型清单」进行态 / 结果；null = 未发起过。 */
        val modelFetch: ModelFetchState? = null,
        /** 局域网桥接扫描状态。 */
        val bridgeScan: BridgeScanState = BridgeScanState.Idle,
        /** 默认配置是否为「网页桥接」模式（免 Key、不发 tools）。 */
        val bridgeMode: Boolean = false,
        // ── REA 远程逆向引擎 ──
        /** REA 网关地址（设置页可改）。 */
        val reaServerUrl: String = SettingsDefaults.REA_SERVER_URL,
        /** 令牌输入框（只在未保存时使用；保存后清空）。 */
        val reaTokenInput: String = "",
        /** 令牌是否已保存。 */
        val reaHasToken: Boolean = false,
        /** REA 连接测试进行态。 */
        val reaTesting: Boolean = false,
        val reaTestOk: Boolean? = null,
        val reaTestMessage: String? = null,
        /** 上次成功测试时引擎报告的工具数（0 = 未测过）。 */
        val reaToolCount: Int = 0,
        // ── 界面外观 ──
        val brand: AppBrand = AppBrand.default,
        val themeMode: ThemeMode = ThemeMode.default,
        val fontScaleOption: FontScaleOption = FontScaleOption.default,
        val density: UiDensity = UiDensity.default,
        val bubbleCorner: BubbleCorner = BubbleCorner.default,
        val background: BackgroundStyle = BackgroundStyle.default,
        val colorOverrides: Map<ColorSlot, Long> = emptyMap()
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            container.settingsRepository.settings.collect { settings ->
                _state.update {
                    it.copy(
                        // 选用了档案时，地址/模型/Key 状态以档案为准（不开编排也能切换使用）
                        baseUrl = settings.activeProfile?.baseUrl ?: settings.baseUrl,
                        model = settings.activeProfile?.model ?: settings.model,
                        hasStoredKey = settings.activeProfile?.hasKey ?: settings.hasApiKey,
                        temperature = settings.temperature,
                        maxOutputTokens = settings.maxOutputTokens,
                        maxToolRounds = settings.maxToolRounds,
                        systemPrompt = settings.systemPrompt,
                        enabledTools = settings.enabledTools,
                        brand = settings.brand,
                        themeMode = settings.themeMode,
                        fontScaleOption = settings.fontScale,
                        density = settings.density,
                        bubbleCorner = settings.bubbleCorner,
                        background = settings.background,
                        colorOverrides = settings.colorOverrides,
                        profiles = settings.profiles,
                        orchestratorId = settings.orchestrator?.id,
                        orchestrationEnabled = settings.orchestrationEnabled,
                        activeProfileId = settings.activeProfileId,
                        bridgeMode = settings.bridgeMode,
                        reaServerUrl = settings.reaServerUrl,
                        reaHasToken = settings.reaTokenReady
                    )
                }
            }
        }
        _state.update { it.copy(tools = container.toolRegistry.all().map { tool -> tool.spec }) }
        refreshRoots()
    }

    fun onBaseUrlChange(value: String) = _state.update { it.copy(baseUrl = value, notice = null) }

    fun onModelChange(value: String) = _state.update { it.copy(model = value, notice = null) }

    /** 一键套用服务商预设：填好地址与默认模型，用户只需再填 API Key。 */
    fun applyPreset(preset: LlmPreset) {
        // 「不需要 Key」的预设即网页桥接：同步打开桥接模式，
        // 这样除了免 Key，还会自动不发 tools（桥接不支持 function calling）
        val isBridge = !preset.requiresApiKey
        _state.update { current ->
            current.copy(
                selectedPresetLabel = preset.label,
                baseUrl = preset.baseUrl.ifBlank { current.baseUrl },
                model = preset.defaultModel.ifBlank { current.model },
                bridgeMode = isBridge,
                // 网页桥接不需要 Key：自动填占位值，省去「随便编一个」的步骤
                apiKeyInput = if (isBridge && current.apiKeyInput.isBlank()) {
                    LOCAL_BRIDGE_PLACEHOLDER_KEY
                } else {
                    current.apiKeyInput
                },
                notice = when {
                    isBridge ->
                        "已进入网页桥接模式：不需要 API Key，也不会发送工具调用。" +
                            "填好地址后可直接点「🔌 一键连接网页桥接」自动完成"
                    preset.baseUrl.isBlank() ->
                        "请填写服务商或中转站提供的 API 地址（通常以 /v1 结尾）"
                    else -> "已套用「${preset.label}」，接下来只需填写 API Key"
                },
                testMessage = null,
                testOk = null
            )
        }
        viewModelScope.launch { container.settingsRepository.saveBridgeMode(isBridge) }
        // 地址已知就顺手把可用模型拉回来 —— 云服务最常见的问题就是模型名写错，
        // 与其等用户手打后撞 400，不如直接给可选项（失败静默，不打扰）
        val baseUrl = _state.value.baseUrl
        if (preset.requiresApiKey && baseUrl.isNotBlank()) {
            fetchModelList(
                baseUrl = baseUrl,
                apiKey = null,
                targetProfileId = null,
                allowStoredFallback = true,
                silentOnFailure = true
            )
        }
    }

    fun onApiKeyChange(value: String) = _state.update { it.copy(apiKeyInput = value, notice = null) }

    fun onTemperatureChange(value: Float) = _state.update { it.copy(temperature = value) }

    /**
     * 输出上限改动立即落盘。
     *
     * 不做成「点保存才生效」：这个值直接决定长回复会不会被截断，
     * 用户改完就想马上试，忘了保存会以为改动无效。
     */
    fun setMaxOutputTokens(value: Int) {
        _state.update { it.copy(maxOutputTokens = value) }
        viewModelScope.launch { container.settingsRepository.saveMaxOutputTokens(value) }
    }

    /**
     * 工具轮次上限改动立即落盘，理由同 [setMaxOutputTokens]：
     * 用户改这个值多半是因为上一轮被「轮次用尽」打断了，改完就要立刻重试。
     */
    fun setMaxToolRounds(value: Int) {
        _state.update { it.copy(maxToolRounds = value) }
        viewModelScope.launch { container.settingsRepository.saveMaxToolRounds(value) }
    }

    fun onSystemPromptChange(value: String) = _state.update { it.copy(systemPrompt = value) }

    fun save() {
        viewModelScope.launch {
            try {
                val current = _state.value
                // 选用档案时，地址 / 模型 / Key 由档案维护，这里只存全局参数，
                // 避免把档案值写回「默认配置」造成串味
                if (current.activeProfileId == null) {
                    container.settingsRepository.saveBaseUrl(current.baseUrl)
                    container.settingsRepository.saveModel(current.model)
                    if (current.apiKeyInput.isNotBlank()) {
                        container.settingsRepository.saveApiKey(current.apiKeyInput)
                        _state.update { it.copy(apiKeyInput = "", hasStoredKey = true) }
                    }
                }
                container.settingsRepository.saveTemperature(current.temperature)
                container.settingsRepository.saveSystemPrompt(current.systemPrompt)
                _state.update {
                    it.copy(notice = "设置已保存", testMessage = null, testOk = null)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.update { it.copy(notice = "保存失败：${e.message}") }
            }
        }
    }

    fun clearApiKey() {
        viewModelScope.launch {
            container.settingsRepository.saveApiKey("")
            _state.update { it.copy(apiKeyInput = "", hasStoredKey = false, notice = "已清除 API Key") }
        }
    }

    fun testConnection() {
        if (_state.value.testing) return
        _state.update { it.copy(testing = true, testMessage = null, testOk = null) }
        viewModelScope.launch {
            try {
                val current = _state.value
                // 选用档案时 Key 从档案解密；否则用默认配置的 Key。
                // 本地桥接不需要 Key：effectiveApiKey 会自动补占位令牌。
                val typed = current.apiKeyInput.takeIf { it.isNotBlank() }
                val stored = if (typed == null) {
                    val profile = container.settingsRepository.snapshot().activeProfile
                    if (profile != null) {
                        container.settingsRepository.apiKeyForProfile(profile)
                    } else {
                        container.settingsRepository.apiKey()
                    }
                } else {
                    null
                }
                val key = effectiveApiKey(current.baseUrl, typed ?: stored)
                if (key == null) {
                    _state.update {
                        it.copy(testing = false, testOk = false, testMessage = "请先填写 API Key")
                    }
                    return@launch
                }
                val diagnosis = container.llmClient.diagnose(
                    baseUrl = current.baseUrl,
                    apiKey = key,
                    model = current.model
                )
                _state.update {
                    it.copy(
                        testing = false,
                        testOk = diagnosis.ok,
                        testMessage = diagnosis.message
                    )
                }
                // 失败多半是「模型名不对」——直接把服务端的可用模型拉回来，
                // 用户点一下就能换对（地址与 Key 都对、只有模型名错是最常见的一种）
                if (!diagnosis.ok) {
                    fetchModelList(
                        baseUrl = current.baseUrl,
                        apiKey = typed,
                        targetProfileId = null,
                        allowStoredFallback = true,
                        silentOnFailure = true
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.update {
                    it.copy(testing = false, testOk = false, testMessage = e.message ?: "连接失败")
                }
            }
        }
    }

    fun addAuthorizedTree(uri: Uri) {
        viewModelScope.launch {
            try {
                container.safPermissionStore.persist(uri, canWrite = true)
                refreshRoots()
                _state.update { it.copy(notice = "已授权目录，Agent 现在可以读写其中的文件") }
            } catch (e: CancellationException) {
                throw e
            } catch (e: SecurityException) {
                _state.update {
                    it.copy(notice = "授权失败：系统未授予持久化权限（${e.message}）")
                }
            } catch (e: Throwable) {
                _state.update { it.copy(notice = "授权失败：${e.message}") }
            }
        }
    }

    fun removeAuthorizedRoot(entry: String) {
        viewModelScope.launch {
            container.safPermissionStore.release(entry)
            refreshRoots()
            _state.update { it.copy(notice = "已撤销该目录的访问权限") }
        }
    }

    fun toggleTool(toolName: String, enabled: Boolean) {
        viewModelScope.launch {
            container.settingsRepository.setToolEnabled(toolName, enabled)
        }
    }

    /**
     * 工具当前是否启用。与 [com.example.nativedemo.tools.ToolRegistry.toOpenAiTools]
     * 同一套判定：空集 = 未设置过，按每个工具自己的 defaultEnabled 来。
     */
    fun isToolEnabled(spec: ToolSpec): Boolean {
        val enabled = _state.value.enabledTools
        return if (enabled.isEmpty()) spec.defaultEnabled else spec.name in enabled
    }

    // ── 界面外观：改完立刻落盘，主题订阅后即时生效 ──────────────────────

    fun setBrand(value: AppBrand) {
        viewModelScope.launch { container.settingsRepository.saveBrand(value) }
    }

    fun setThemeMode(value: ThemeMode) {
        viewModelScope.launch { container.settingsRepository.saveThemeMode(value) }
    }

    fun setFontScale(value: FontScaleOption) {
        viewModelScope.launch { container.settingsRepository.saveFontScale(value) }
    }

    fun setDensity(value: UiDensity) {
        viewModelScope.launch { container.settingsRepository.saveDensity(value) }
    }

    fun setBubbleCorner(value: BubbleCorner) {
        viewModelScope.launch { container.settingsRepository.saveBubbleCorner(value) }
    }

    /**
     * 设置背景图：把选中的图片**解码后转码成 JPEG** 再存进应用私有目录。
     *
     * 这里做三件事，缺一不可：
     * 1. **不直接存 content:// URI** —— SAF 授权「可用但易失」，三方相册可能
     *    拒绝持久化授权，用户清理数据后 URI 失效，背景变成一片空白且不报错；
     * 2. **不原样拷贝字节** —— 国产相册大量返回 HEIC，BitmapFactory 解不动，
     *    表现同样是「选了没反应」；转码时顺带按长边 2000px 采样，避免超大图 OOM；
     * 3. **先写临时文件再替换** —— 解码失败时不影响已有背景，也不会留下半张图。
     *
     * 导入成功后顺手分析一次背景图（96px 下采样，成本忽略不计）并缓存结果：
     * 用户之后打开「智能图文适配」不必再解码一遍；正在用智能适配时换图，
     * 文字色也会跟着新图自动重算。
     */
    fun applyBackgroundImage(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(notice = "正在导入图片…") }
            val saved = withContext(Dispatchers.IO) {
                runCatching {
                    val dir = File(appContext.filesDir, BACKGROUND_DIR).apply { mkdirs() }
                    val tmp = File(dir, "bg_importing.tmp")
                    if (!importAsJpeg(appContext, uri, tmp)) {
                        tmp.delete()
                        return@runCatching null
                    }
                    // 只保留一张背景，避免每次换图都堆积
                    dir.listFiles()?.forEach { if (it != tmp) it.delete() }
                    val target = File(dir, "bg.jpg")
                    if (!tmp.renameTo(target)) {
                        tmp.copyTo(target, overwrite = true)
                        tmp.delete()
                    }
                    target.absolutePath
                }.getOrNull()
            }

            if (saved == null) {
                _state.update {
                    it.copy(notice = "这张图片无法读取（格式不支持或文件已损坏），请换一张试试")
                }
                return@launch
            }
            // 分析失败只当没有缓存：开关切换时会再试一次，并明确提示
            val smartWasOn = _state.value.background.smartContrast
            val stats = withContext(Dispatchers.IO) { analyzeBackdrop(appContext, saved) }
            val smartOn = smartWasOn && stats != null
            container.settingsRepository.saveBackground(
                _state.value.background.copy(
                    uri = saved,
                    stats = stats,
                    smartContrast = smartOn
                )
            )
            _state.update {
                it.copy(
                    notice = when {
                        smartOn -> "背景已更新，文字颜色已按新图重新适配"
                        smartWasOn -> "背景已更新，但图片无法分析，智能适配已暂时关闭"
                        else -> "背景已更新"
                    }
                )
            }
        }
    }

    fun clearBackgroundImage() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                runCatching {
                    File(appContext.filesDir, BACKGROUND_DIR).listFiles()?.forEach { it.delete() }
                }
            }
            // 没有背景图时智能适配无从谈起，连同统计缓存一起清掉
            container.settingsRepository.saveBackground(
                _state.value.background.copy(
                    uri = null,
                    smartContrast = false,
                    stats = null
                )
            )
            _state.update { it.copy(notice = "已清除背景图") }
        }
    }

    fun setBackgroundBlur(value: Float) {
        viewModelScope.launch {
            container.settingsRepository.saveBackground(
                _state.value.background.copy(blur = value)
            )
        }
    }

    fun setBackgroundAlpha(value: Float) {
        viewModelScope.launch {
            container.settingsRepository.saveBackground(
                _state.value.background.copy(alpha = value)
            )
        }
    }

    /**
     * 「智能图文适配」开关。
     *
     * 开启时若还没有缓存分析结果（老版本升级过来、或上次分析失败），
     * 就地解一次当前背景图补上；补不上就保持关闭并明说原因，
     * 不给用户一个「开了却没反应」的假开关。
     */
    fun setSmartContrast(enabled: Boolean) {
        viewModelScope.launch {
            val current = _state.value.background
            if (!enabled) {
                container.settingsRepository.saveBackground(current.copy(smartContrast = false))
                _state.update { it.copy(notice = "已关闭智能图文适配，文字颜色恢复主题默认") }
                return@launch
            }
            val stats = current.stats ?: withContext(Dispatchers.IO) {
                current.uri?.let { analyzeBackdrop(appContext, it) }
            }
            if (stats == null) {
                _state.update {
                    it.copy(notice = "无法分析当前背景图（文件可能已损坏），请重新选择图片")
                }
                return@launch
            }
            container.settingsRepository.saveBackground(
                current.copy(smartContrast = true, stats = stats)
            )
            _state.update { it.copy(notice = "智能图文适配已开启") }
        }
    }

    /** [argb] 为 null 表示该槽位恢复跟随主题。 */
    fun setColorSlot(slot: ColorSlot, argb: Long?) {
        viewModelScope.launch { container.settingsRepository.saveColorSlot(slot, argb) }
    }

    fun resetColorSlots() {
        viewModelScope.launch {
            container.settingsRepository.resetColorSlots()
            _state.update { it.copy(notice = "配色已恢复默认") }
        }
    }

    fun dismissNotice() = _state.update { it.copy(notice = null) }

    // ── 多模型编排 ─────────────────────────────────────────────────────

    /**
     * 选用单模型档案（不开编排也能在多个已绑定 Key 的模型配置间切换）。
     * 传 null 表示回到传统的「默认配置」。
     */
    fun setActiveProfileId(id: String?) {
        viewModelScope.launch { container.settingsRepository.saveActiveProfileId(id) }
        // 清掉输入框里的旧 Key 与上次测试结果：选用档案后 Key 来自档案解密，
        // 输入框残留的文本会让「测试连接」误用默认配置的 Key
        _state.update { it.copy(apiKeyInput = "", testMessage = null, testOk = null) }
    }

    // ── 模型清单（按 Key 拉取服务端支持的模型）─────────────────────────

    /**
     * 拉取模型清单（GET /models）。
     *
     * @param apiKey 调用方手里的 Key（可能是编辑框里刚填的）；为空时按
     *   [allowStoredFallback] 决定是否回退到已保存的 Key。
     * @param targetProfileId 结果归属：null = 默认配置 / 新档案草稿。
     * @param allowStoredFallback 是否允许用已保存的 Key。
     *   「默认配置」允许（输入框留空 = 不修改已存 Key）；
     *   新档案草稿不允许 —— 没有 Key 就应该让用户先填，而不是偷偷用别人的 Key。
     * @param silentOnFailure 静默模式：失败不弹错误横幅（用于「测试连接失败后
     *   自动拉清单」这类后台补位，免得用户看到两条互相干扰的报错）。
     */
    fun fetchModelList(
        baseUrl: String,
        apiKey: String?,
        targetProfileId: String?,
        allowStoredFallback: Boolean,
        silentOnFailure: Boolean = false
    ) {
        if (_state.value.modelFetch is ModelFetchState.Loading) return
        _state.update { it.copy(modelFetch = ModelFetchState.Loading) }
        viewModelScope.launch {
            try {
                val raw = apiKey?.takeIf { it.isNotBlank() }
                    ?: if (allowStoredFallback) resolveStoredKey(targetProfileId) else null
                // 本地桥接不需要 Key，留空时自动用占位令牌
                val key = effectiveApiKey(baseUrl, raw)
                if (key == null) {
                    _state.update {
                        it.copy(
                            modelFetch = if (silentOnFailure) {
                                null
                            } else {
                                ModelFetchState.Failure(
                                    "没有可用的 API Key：请先填写 Key（或先用「测试连接」验证）。",
                                    targetProfileId
                                )
                            }
                        )
                    }
                    return@launch
                }
                val models = container.llmClient.listModels(baseUrl.trim(), key)
                _state.update {
                    it.copy(
                        modelFetch = ModelFetchState.Success(
                            models = models.sorted(),
                            targetProfileId = targetProfileId
                        )
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.update {
                    it.copy(
                        modelFetch = if (silentOnFailure) {
                            null
                        } else {
                            ModelFetchState.Failure(
                                e.message ?: "获取模型清单失败",
                                targetProfileId
                            )
                        }
                    )
                }
            }
        }
    }

    fun dismissModelFetch() = _state.update { it.copy(modelFetch = null) }

    /** 已保存 Key 的解析顺序：指定档案 → 当前选用档案 → 默认配置。 */
    private suspend fun resolveStoredKey(targetProfileId: String?): String? {
        val snapshot = container.settingsRepository.snapshot()
        val profile = targetProfileId
            ?.let { id -> snapshot.profiles.firstOrNull { it.id == id } }
            ?: snapshot.activeProfile
        return if (profile != null) {
            container.settingsRepository.apiKeyForProfile(profile)
        } else {
            container.settingsRepository.apiKey()
        }
    }

    // ── 局域网桥接自动发现 ─────────────────────────────────────────────

    private var bridgeScanJob: Job? = null

    /**
     * 开始扫描局域网内的桥接服务。与电脑同一 WiFi 时能直接找到 DSH 一类工具，
     * 免去用户手填 IP；移动数据下扫不到属预期，界面会给出对应指引。
     */
    fun startBridgeScan() {
        if (_state.value.bridgeScan is BridgeScanState.Running) return
        val ownIp = localIpv4Address()
        _state.update {
            it.copy(bridgeScan = BridgeScanState.Running(scanned = 0, total = 0, ownIp = ownIp))
        }
        bridgeScanJob = viewModelScope.launch {
            try {
                val result = container.bridgeDiscovery.scan(ownIp) { scanned, total ->
                    _state.update { current ->
                        val running = current.bridgeScan
                        if (running is BridgeScanState.Running) {
                            current.copy(
                                bridgeScan = running.copy(scanned = scanned, total = total)
                            )
                        } else {
                            current
                        }
                    }
                }
                _state.update {
                    it.copy(
                        bridgeScan = BridgeScanState.Done(
                            bridges = result.bridges,
                            scanned = result.scanned,
                            total = result.total,
                            timedOut = result.timedOut,
                            ownIp = ownIp
                        )
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.update {
                    it.copy(
                        bridgeScan = BridgeScanState.Done(
                            bridges = emptyList(),
                            scanned = 0,
                            total = 0,
                            timedOut = false,
                            ownIp = ownIp
                        )
                    )
                }
            }
        }
    }

    fun cancelBridgeScan() {
        bridgeScanJob?.cancel()
        bridgeScanJob = null
        _state.update { it.copy(bridgeScan = BridgeScanState.Idle) }
    }

    /**
     * 填入扫描发现的桥接地址。
     *
     * 扫描时本来就**不带 Key**就拿到了模型清单（DSH 一类工具不校验 Key），
     * 所以有清单就直接打开选择框，用户不必再走一遍「获取模型清单」。
     */
    fun applyDiscoveredBridge(bridge: DiscoveredBridge) {
        // 规范化地址，并顺手打开桥接模式：扫到的服务就是桥接，
        // 免 Key + 不发 tools 这两件事必须一起生效，否则一定卡在同一个地方
        val baseUrl = normalizeBaseUrl(bridge.baseUrl)
        _state.update {
            it.copy(
                baseUrl = baseUrl,
                bridgeMode = true,
                modelFetch = if (bridge.models.isNotEmpty()) {
                    ModelFetchState.Success(models = bridge.models.sorted(), targetProfileId = null)
                } else {
                    null
                },
                notice = if (bridge.models.isNotEmpty()) {
                    "已连接 $baseUrl（桥接模式：免 Key、不发工具），请选择要使用的模型"
                } else {
                    "已连接 $baseUrl（桥接模式：免 Key、不发工具）"
                },
                testMessage = null,
                testOk = null
            )
        }
        viewModelScope.launch { container.settingsRepository.saveBridgeMode(true) }
    }

    /**
     * 一键连接网页桥接（配置过程极简化的核心）。
     *
     * 用户只需点一次，其余全自动：
     * 1. 先探**本机**（127.0.0.1 / 模拟器宿主）—— 手机上自建桥接时立刻命中；
     * 2. 再扫局域网（8000/8001/8080/3000/5000/1234/11434）；
     * 3. 命中后：地址规范化 → 自动选模型 → **打开桥接模式**（免 Key、不发 tools）
     *    → 落盘 → 立即验证；
     * 4. 若当前选用了某个模型档案，会切回默认配置 —— 否则刚配好的桥接根本用不上。
     */
    fun autoConfigureBridge() {
        if (_state.value.bridgeScan is BridgeScanState.Running) return
        val ownIp = localIpv4Address()
        _state.update {
            it.copy(
                bridgeScan = BridgeScanState.Running(scanned = 0, total = 0, ownIp = ownIp),
                modelFetch = null,
                testMessage = null,
                testOk = null,
                notice = "正在查找网页桥接服务…"
            )
        }
        bridgeScanJob = viewModelScope.launch {
            try {
                // 1) 本机优先：毫秒级出结果
                val local = runCatching { container.bridgeDiscovery.scanLocal() }
                    .getOrDefault(emptyList())

                // 2) 局域网扫描（带进度）
                val lan = container.bridgeDiscovery.scan(ownIp) { scanned, total ->
                    _state.update { current ->
                        val running = current.bridgeScan
                        if (running is BridgeScanState.Running) {
                            current.copy(bridgeScan = running.copy(scanned = scanned, total = total))
                        } else {
                            current
                        }
                    }
                }

                val bridges = (local + lan.bridges).distinctBy { it.baseUrl }
                _state.update {
                    it.copy(
                        bridgeScan = BridgeScanState.Done(
                            bridges = bridges,
                            scanned = lan.scanned,
                            total = lan.total,
                            timedOut = lan.timedOut,
                            ownIp = ownIp
                        )
                    )
                }

                // 优先选「能列出模型」的：说明它已就绪且不校验鉴权
                val best = bridges.firstOrNull { it.models.isNotEmpty() } ?: bridges.firstOrNull()
                if (best == null) {
                    _state.update { it.copy(notice = "没有找到桥接服务，请按下方三行排查") }
                    return@launch
                }
                applyBridge(best)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.update { it.copy(notice = "连接失败：${e.message}") }
            }
        }
    }

    /**
     * 把扫到的桥接落成可用配置。
     *
     * 关键点：**同时打开桥接模式**。桥接转发的是网页登录态，既不需要 API Key，
     * 也不支持 function calling —— 不打开这个标记，后面就会卡在「要求填 Key」
     * 或「服务端拒绝 tools」上，这正是「网页桥接版无法调用」的两大原因。
     */
    private suspend fun applyBridge(bridge: DiscoveredBridge) {
        val baseUrl = normalizeBaseUrl(bridge.baseUrl)
        val model = pickPreferredModel(bridge.models)

        container.settingsRepository.saveBaseUrl(baseUrl)
        container.settingsRepository.saveBridgeMode(true)
        // 若当前选用了某个档案，聊天走的是档案而不是默认配置 —— 切回来，
        // 否则用户点完「一键连接」会发现根本没生效
        if (container.settingsRepository.snapshot().activeProfileId != null) {
            container.settingsRepository.saveActiveProfileId(null)
        }
        if (!model.isNullOrBlank()) container.settingsRepository.saveModel(model)

        _state.update {
            it.copy(
                baseUrl = baseUrl,
                model = model ?: it.model,
                bridgeMode = true,
                activeProfileId = null,
                hasStoredKey = true,
                apiKeyInput = "",
                selectedPresetLabel = "DeepSeek 网页桥接",
                notice = "已连接：$baseUrl" + (model?.let { m -> "，模型 $m" } ?: "") + "，正在验证…"
            )
        }
        testConnection()
    }

    /** 手动开关桥接模式（通常是自动打开的，这里留给用户纠错）。 */
    fun setBridgeMode(enabled: Boolean) {
        _state.update { it.copy(bridgeMode = enabled, testMessage = null, testOk = null) }
        viewModelScope.launch {
            container.settingsRepository.saveBridgeMode(enabled)
            _state.update {
                it.copy(
                    notice = if (enabled) {
                        "已开启网页桥接模式：不需要 API Key，也不会发送工具调用"
                    } else {
                        "已关闭网页桥接模式"
                    }
                )
            }
        }
    }

    /**
     * 编排总开关。用户拥有最高权限：只有用户在这里打开，
     * 聊天才会走「主模型拆任务 → 子模型并行 → 主模型整合」链路。
     */
    fun setOrchestrationEnabled(enabled: Boolean) {
        viewModelScope.launch {
            container.settingsRepository.setOrchestrationEnabled(enabled)
            _state.update {
                it.copy(
                    notice = if (enabled) {
                        "多模型编排已开启：新消息将按主模型拆分、子模型并行的方式处理"
                    } else {
                        "多模型编排已关闭，恢复为单模型对话"
                    }
                )
            }
        }
    }

    /** 指定主模型档案；传 null 表示「用第一个可用的」。 */
    fun setOrchestratorId(id: String?) {
        viewModelScope.launch { container.settingsRepository.saveOrchestratorId(id) }
    }

    /** 新增或更新档案（不含 API Key；Key 走 [saveProfileKey]）。 */
    fun saveProfile(profile: ModelProfile) {
        viewModelScope.launch {
            try {
                container.settingsRepository.upsertProfile(profile)
                _state.update { it.copy(notice = "已保存档案「${profile.label}」") }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.update { it.copy(notice = "保存档案失败：${e.message}") }
            }
        }
    }

    /** 写入档案的 API Key；空字符串表示清除。 */
    fun saveProfileKey(id: String, apiKey: String) {
        viewModelScope.launch {
            try {
                container.settingsRepository.saveProfileKey(id, apiKey)
                _state.update {
                    it.copy(
                        notice = if (apiKey.isBlank()) "已清除该档案的 API Key" else "API Key 已加密保存"
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.update { it.copy(notice = "保存 Key 失败：${e.message}") }
            }
        }
    }

    /** 删除档案（连同 Keystore 里的密钥一起抹掉）。 */
    fun deleteProfile(id: String) {
        viewModelScope.launch {
            try {
                container.settingsRepository.deleteProfile(id)
                _state.update { it.copy(notice = "档案已删除", profileTest = null) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.update { it.copy(notice = "删除失败：${e.message}") }
            }
        }
    }

    /**
     * 测试一个**已保存**档案的连接。成功时顺手把探测到的 tools 支持情况
     * 写回档案 —— 编排的规划请求据此跳过必然失败的 tools 尝试。
     */
    fun testProfile(id: String) {
        if (_state.value.profileTest?.running == true) return
        _state.update { it.copy(profileTest = ProfileTestState(profileId = id, running = true)) }
        viewModelScope.launch {
            val profile = container.settingsRepository.snapshot()
                .profiles.firstOrNull { it.id == id }
            if (profile == null) {
                _state.update {
                    it.copy(
                        profileTest = ProfileTestState(id, ok = false, message = "档案不存在或已被删除")
                    )
                }
                return@launch
            }
            val key = container.settingsRepository.apiKeyForProfile(profile)
            if (key.isNullOrBlank()) {
                _state.update {
                    it.copy(
                        profileTest = ProfileTestState(
                            profileId = id,
                            ok = false,
                            message = "尚未填写 API Key，请先在编辑框里填写并保存"
                        )
                    )
                }
                return@launch
            }
            runDiagnosis(profileId = id, baseUrl = profile.baseUrl, model = profile.model, key = key)
        }
    }

    /** 测试编辑框里的草稿：还没保存也能验证地址 / Key / 模型名是否正确。 */
    fun testDraftProfile(baseUrl: String, model: String, apiKey: String) {
        if (_state.value.profileTest?.running == true) return
        _state.update { it.copy(profileTest = ProfileTestState(profileId = null, running = true)) }
        viewModelScope.launch {
            val key = apiKey.trim().ifBlank {
                container.settingsRepository.apiKey().orEmpty()
            }
            if (key.isBlank()) {
                _state.update {
                    it.copy(
                        profileTest = ProfileTestState(
                            profileId = null,
                            ok = false,
                            message = "请先填写 API Key"
                        )
                    )
                }
                return@launch
            }
            runDiagnosis(profileId = null, baseUrl = baseUrl, model = model, key = key)
        }
    }

    private suspend fun runDiagnosis(
        profileId: String?,
        baseUrl: String,
        model: String,
        key: String
    ) {
        try {
            val diagnosis = container.llmClient.diagnose(
                baseUrl = baseUrl.trim(),
                apiKey = key,
                model = model.trim()
            )
            // 探测成功就把工具支持情况写回档案，省得编排运行时再试错
            if (profileId != null && diagnosis.ok && diagnosis.toolsSupported != null) {
                val profile = container.settingsRepository.snapshot()
                    .profiles.firstOrNull { it.id == profileId }
                if (profile != null && profile.toolsSupported != diagnosis.toolsSupported) {
                    container.settingsRepository.upsertProfile(
                        profile.copy(toolsSupported = diagnosis.toolsSupported)
                    )
                }
            }
            _state.update {
                it.copy(
                    profileTest = ProfileTestState(
                        profileId = profileId,
                        running = false,
                        ok = diagnosis.ok,
                        message = diagnosis.message,
                        toolsSupported = diagnosis.toolsSupported
                    )
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            _state.update {
                it.copy(
                    profileTest = ProfileTestState(
                        profileId = profileId,
                        running = false,
                        ok = false,
                        message = e.message ?: "连接失败"
                    )
                )
            }
        }
    }

    fun dismissProfileTest() = _state.update { it.copy(profileTest = null) }

    // ── REA 远程逆向引擎 ────────────────────────────────────────────────

    fun onReaServerUrlChange(value: String) =
        _state.update { it.copy(reaServerUrl = value, reaTestOk = null, reaTestMessage = null) }

    fun onReaTokenChange(value: String) =
        _state.update { it.copy(reaTokenInput = value, reaTestOk = null, reaTestMessage = null) }

    /** 保存地址与令牌（令牌留空表示只改地址；两者都空则什么都不做）。 */
    fun saveReaConfig() {
        viewModelScope.launch {
            try {
                val current = _state.value
                container.settingsRepository.saveReaServerUrl(current.reaServerUrl)
                if (current.reaTokenInput.isNotBlank()) {
                    container.settingsRepository.saveReaToken(current.reaTokenInput)
                    _state.update { it.copy(reaTokenInput = "", reaHasToken = true) }
                }
                _state.update {
                    it.copy(reaTestOk = null, reaTestMessage = null, notice = "REA 配置已保存")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.update { it.copy(reaTestMessage = "保存失败：${e.message}", reaTestOk = false) }
            }
        }
    }

    fun clearReaToken() {
        viewModelScope.launch {
            container.settingsRepository.clearReaToken()
            _state.update {
                it.copy(
                    reaTokenInput = "",
                    reaHasToken = false,
                    reaTestOk = null,
                    reaTestMessage = null,
                    notice = "已清除 REA 令牌"
                )
            }
        }
    }

    /**
     * 测试 REA 网关连通性：握手 + 拉一次工具清单。
     * 输入框里填了但没保存的令牌也参与测试 —— 用户填完就想马上验，逼他先点保存太绕。
     */
    fun testReaConnection() {
        if (_state.value.reaTesting) return
        _state.update {
            it.copy(reaTesting = true, reaTestOk = null, reaTestMessage = null, reaToolCount = 0)
        }
        viewModelScope.launch {
            try {
                val current = _state.value
                val url = current.reaServerUrl.trim()
                if (url.isBlank()) {
                    _state.update {
                        it.copy(reaTesting = false, reaTestOk = false, reaTestMessage = "请先填写服务器地址")
                    }
                    return@launch
                }
                val token = current.reaTokenInput.takeIf { it.isNotBlank() }
                    ?: container.settingsRepository.reaToken()
                if (token.isNullOrBlank()) {
                    _state.update {
                        it.copy(reaTesting = false, reaTestOk = false, reaTestMessage = "请先填写访问令牌")
                    }
                    return@launch
                }
                val result = withContext(Dispatchers.IO) {
                    val client = ReaClient(baseUrl = url, token = token)
                    val server = client.initialize()
                    val tools = client.listTools()
                    server to tools.size
                }
                val (server, toolCount) = result
                _state.update {
                    it.copy(
                        reaTesting = false,
                        reaTestOk = true,
                        reaToolCount = toolCount,
                        reaTestMessage = "连接成功：${server.name.ifBlank { "REA 网关" }}" +
                            " 在线，报告 $toolCount 个可用工具"
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.update {
                    it.copy(
                        reaTesting = false,
                        reaTestOk = false,
                        reaTestMessage = e.message ?: "连接失败"
                    )
                }
            }
        }
    }

    private fun refreshRoots() {
        viewModelScope.launch {
            container.safPermissionStore.pruneInvalid()
            val entries = container.settingsRepository.snapshot().authorizedUris.toList()
            val roots = entries.mapNotNull { container.safPermissionStore.decode(it) }
            _state.update { it.copy(roots = roots, rootEntries = entries) }
        }
    }

    companion object {
        /** 背景图在私有目录中的子目录名 */
        private const val BACKGROUND_DIR = "background"

        fun factory(container: AppContainer) = viewModelFactory {
            initializer { SettingsViewModel(container) }
        }
    }
}
