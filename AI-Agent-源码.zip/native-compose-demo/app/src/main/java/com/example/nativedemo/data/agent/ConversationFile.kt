package com.example.nativedemo.data.agent

import com.example.nativedemo.data.llm.ChatMessage
import kotlinx.serialization.Serializable

/** 侧边栏列表项。 */
data class ConversationMeta(
    val id: String,
    val title: String,
    val updatedAt: Long,
    val messageCount: Int
)

/**
 * 一个会话的完整落盘结构。
 *
 * 刻意同时保存两份消息：
 * - [uiMessages]：界面回放用（含工具调用的执行状态）
 * - [llmMessages]：继续对话时喂给模型的上下文（OpenAI 消息格式）
 *
 * 两者职责不同，不能互相推导 —— 从 llmMessages 反推会丢掉工具调用卡片的状态。
 */
@Serializable
data class ConversationFile(
    val id: String,
    val title: String = "",
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    val uiMessages: List<UiMessage> = emptyList(),
    val llmMessages: List<ChatMessage> = emptyList()
)
