package com.example.nativedemo.tools.builtin

import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject

/**
 * 创建目录（等价 `mkdir -p`）。
 *
 * 补这个工具的直接原因：模型在整理逆向产物时想按 `code_game/项目名/` 分层落盘，
 * 却发现「子目录似乎都不能再创建子目录」，只能反复试探，把轮次耗光。
 * 文件工具里 file_create 的中间目录虽然也会自动创建，但显式建目录
 * 让模型能把「先建结构、再放东西」这一步表达出来，比让它猜要可靠得多。
 */
class FileMkdirTool : Tool {

    override val spec = ToolSpec(
        name = "file_mkdir",
        description = "在已授权目录中创建目录（多级一次创建，等价 mkdir -p）。" +
            "目录已存在时直接返回成功，可放心重复调用。只在可写的授权目录下生效。",
        category = "文件",
        layer = "L1",
        params = objectSchema {
            string("path", "要创建的目录路径，例如 code_game/逆向笔记/2026")
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val pathArg = try {
            args.requireStr("path")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }

        return withContext(Dispatchers.IO) {
            val directory = runCatching { ctx.uriAccessPolicy.ensureDirectory(pathArg) }.getOrNull()
                ?: return@withContext ToolResult.failure(
                    "无法创建目录「$pathArg」：没有可写的已授权目录，或路径被同名文件占用。" +
                        "可先用 file_list 查看当前授权了哪些目录、是否可写。"
                )

            ctx.uriAccessPolicy.denyReason(directory.uri, write = true)?.let {
                return@withContext ToolResult.failure(it)
            }

            ToolResult.success("目录就绪：${directory.name ?: pathArg}")
        }
    }
}
