package com.example.nativedemo.data.agent

import com.example.nativedemo.data.llm.ChatMessage
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

/** 图片等非文本内容被压平成文字后所用的占位符。 */
const val IMAGE_PLACEHOLDER = "【图片】"

/**
 * 该消息的 `content` 是否为「富文本」形态（数组或对象）。
 *
 * 只有多模态消息才会是这两种形态：文本消息是 JSON 字符串。而**很多 OpenAI
 * 兼容网关只接受字符串**，收到数组会直接 400。
 */
val ChatMessage.hasRichContent: Boolean
    get() = content is JsonArray || content is JsonObject

private fun JsonElement?.primitiveText(): String? = (this as? JsonPrimitive)?.contentOrNull

/** 单个内容分片（part）转成文字：文本取原文，图片给占位符。 */
private fun partToText(element: JsonElement): String = when (element) {
    is JsonPrimitive -> element.contentOrNull.orEmpty()
    is JsonObject -> {
        val text = element["text"].primitiveText()
        val type = element["type"].primitiveText()
        when {
            !text.isNullOrBlank() -> text
            type == "image_url" || element.containsKey("image_url") -> IMAGE_PLACEHOLDER
            else -> ""
        }
    }
    else -> ""
}

/**
 * 把任意形态的 `content` 还原成**单个字符串**。
 *
 * - 字符串原样返回；
 * - 数组按分片拼接（文本取正文、图片转 [IMAGE_PLACEHOLDER]）；
 * - 单个分片对象（「只发了一张图、没有文字」时会走到这里）同样处理。
 *
 * 与 [com.example.nativedemo.data.llm.asTextOrNull] 的区别：那个函数丢掉了非文本
 * 分片（图片会变成空串，用户和模型都不知道这里原本有张图），这里则留下可见占位。
 */
fun JsonElement?.toPlainText(): String? = when (this) {
    null, JsonNull -> null
    is JsonPrimitive -> contentOrNull
    is JsonObject -> partToText(this).ifBlank { null }
    is JsonArray -> joinToString("\n") { partToText(it) }.trim().ifBlank { null }
    else -> null
}

/**
 * 请求体守卫：发送前把历史里「服务端可能不接受」的内容形态降级掉。
 *
 * ## 为什么必须做
 *
 * 用户发过一次带图片的消息后，那条多模态消息（`content` 是数组）会**永久留在
 * 会话历史里**，而历史每轮都要原样回灌。于是只要服务端要求 `content` 必须是
 * 字符串，这个会话从此**每发必 400** —— 用户看到的现象就是「聊几次之后这个
 * 对话就不能用了」，而且重开 App 也修不好，因为历史已经落盘。
 *
 * 具体的报错长这样（Zod 校验器的输出）：
 *
 * ```
 * {"code":"invalid_union","issues":[{"code":"invalid_type","expected":"string",
 *  "received":"array","path":["messages",13,"content"]}]}
 * ```
 *
 * ## 策略
 *
 * 只保留**最后一条 user 消息**的富文本形态（那是用户本轮刚发的图，模型应当看到），
 * 历史里更早的图片一律压平成 [IMAGE_PLACEHOLDER]。这同时顺带解决了第二个问题：
 * 图片 base64 动辄几十万字符，若每轮重传会迅速吃光上下文窗口。
 *
 * 若连「本轮图片」也被拒（说明该端点完全不支持多模态），引擎会把
 * [keepLastUserRich] 置为 false 再试一次 —— 见 AgentEngine 的自愈分支。
 */
object RequestPayloadGuard {

    data class Report(
        val messages: List<ChatMessage>,
        /** 被压平为纯文本的消息数。 */
        val flattened: Int = 0,
        /** 仍以富文本形态保留的消息数（>0 说明还有可降级的空间）。 */
        val richKept: Int = 0
    ) {
        val changed: Boolean get() = flattened > 0
    }

    /**
     * @param keepLastUserRich 是否让最后一条 user 消息保留富文本（多模态）形态。
     */
    fun prepare(messages: List<ChatMessage>, keepLastUserRich: Boolean): Report {
        val lastUserIndex = messages.indexOfLast { it.role == "user" }
        var flattened = 0
        var richKept = 0

        val out = messages.mapIndexed { index, message ->
            if (!message.hasRichContent) return@mapIndexed message
            if (keepLastUserRich && index == lastUserIndex) {
                richKept++
                message
            } else {
                flattened++
                message.copy(content = JsonPrimitive(message.content.toPlainText().orEmpty()))
            }
        }
        return Report(out, flattened, richKept)
    }
}
