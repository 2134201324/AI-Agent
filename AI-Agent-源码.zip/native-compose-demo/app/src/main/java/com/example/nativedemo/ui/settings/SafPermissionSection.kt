package com.example.nativedemo.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nativedemo.tools.saf.AuthorizedRoot
import com.example.nativedemo.ui.common.InfoCard
import com.example.nativedemo.ui.common.SecondaryButton
import com.example.nativedemo.ui.theme.Danger
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.Muted

/**
 * SAF 目录授权管理。授权是「预先授予 + 调用时复核」模型：
 * 用户在这里显式添加目录，工具每次访问前还会再确认系统权限仍然有效。
 */
@Composable
fun SafPermissionSection(
    roots: List<AuthorizedRoot>,
    entries: List<String>,
    onAdd: () -> Unit,
    onRemove: (String) -> Unit
) {
    InfoCard(title = "已授权目录") {
        Text(
            text = "只有列在这里的目录，Agent 才能读写。撤销后立即失效 —— 每次工具调用都会重新校验系统权限。",
            color = Muted,
            fontSize = 11.sp,
            lineHeight = 16.sp
        )
        Spacer(Modifier.height(10.dp))

        if (roots.isEmpty()) {
            Text(
                text = "尚未授权任何目录。Agent 目前无法访问本机文件。",
                color = Muted,
                fontSize = 12.sp
            )
        } else {
            roots.forEachIndexed { index, root ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = root.displayName,
                            color = Fg,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (root.canWrite) "允许读取与写入" else "仅允许读取",
                            color = Muted,
                            fontSize = 11.sp
                        )
                    }
                    TextButton(
                        onClick = {
                            val entry = entries.getOrNull(index)
                            if (entry != null) onRemove(entry)
                        }
                    ) {
                        Text("撤销", color = Danger, fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        SecondaryButton(text = "添加目录", onClick = onAdd)
    }
}
