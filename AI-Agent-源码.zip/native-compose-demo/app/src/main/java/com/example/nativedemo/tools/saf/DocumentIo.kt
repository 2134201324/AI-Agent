package com.example.nativedemo.tools.saf

import androidx.documentfile.provider.DocumentFile
import com.example.nativedemo.tools.ToolContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream

/**
 * SAF 文档的字节级读写与目录操作。
 *
 * 放在 `tools.saf` 而不是某个具体功能包里：文件读写、改包、图片处理都要用它，
 * 谁都不该反向依赖谁。权限判定仍然统一走 [UriAccessPolicy] —— 这里只是把
 * 「路径 → 文档 → 流」这套动作收拢，不自行放宽任何限制。
 */
object DocumentIo {

    const val DEFAULT_LIMIT = 256 * 1024 * 1024

    /** 读取文件全部字节；找不到、是目录、无权访问都返回 null。 */
    suspend fun readBytes(
        ctx: ToolContext,
        path: String,
        limit: Int = DEFAULT_LIMIT
    ): ByteArray? = withContext(Dispatchers.IO) {
        val document = ctx.uriAccessPolicy.resolveDocument(path) ?: return@withContext null
        if (document.isDirectory) return@withContext null
        if (ctx.uriAccessPolicy.denyReason(document.uri, write = false) != null) {
            return@withContext null
        }
        ctx.contentResolver.openInputStream(document.uri)?.use { readLimited(it, limit) }
    }

    /** 读取并在失败时给出可读原因。 */
    suspend fun readBytesOrReason(ctx: ToolContext, path: String): Result<ByteArray> {
        val document = ctx.uriAccessPolicy.resolveDocument(path)
            ?: return Result.failure(DocumentIoException("未找到「$path」"))
        if (document.isDirectory) {
            return Result.failure(DocumentIoException("「$path」是目录，需要具体文件"))
        }
        ctx.uriAccessPolicy.denyReason(document.uri, write = false)?.let {
            return Result.failure(DocumentIoException(it))
        }
        val bytes = readBytes(ctx, path)
            ?: return Result.failure(DocumentIoException("读取「$path」失败（可能文件过大或已被删除）"))
        return Result.success(bytes)
    }

    /** 写入字节；成功返回 null，失败返回可读原因。 */
    suspend fun writeBytes(ctx: ToolContext, path: String, bytes: ByteArray): String? =
        withContext(Dispatchers.IO) {
            // 中间目录不存在时自动创建：否则「写一个新目录下的文件」会失败，
            // 而模型并不知道该先建目录，只能靠试错消耗轮次
            val target = ctx.uriAccessPolicy.resolveOrCreateParent(path)
                ?: return@withContext "无法写入「$path」：没有可写的已授权目录，或路径被同名文件占用。"

            val existing = target.parent.findFile(target.fileName)
            val file = existing
                ?: target.parent.createFile(mimeOf(target.fileName), target.fileName)
                ?: return@withContext "无法在「${target.parent.name}」中创建「${target.fileName}」。"

            ctx.uriAccessPolicy.denyReason(file.uri, write = true)?.let { return@withContext it }

            runCatching {
                // "wt" = 截断写；覆盖同名文件时不截断会残留旧内容的尾巴
                ctx.contentResolver.openOutputStream(file.uri, "wt")?.use { it.write(bytes) }
                    ?: error("无法打开输出流")
            }.exceptionOrNull()?.let { return@withContext "写入「$path」失败：${it.message}" }

            null
        }

    /** 逐级确保目录存在（不存在就创建）。 */
    suspend fun ensureDirectory(ctx: ToolContext, path: String): DocumentFile? =
        withContext(Dispatchers.IO) {
            val segments = normalize(path).split('/').filter { it.isNotBlank() }
            if (segments.isEmpty()) return@withContext null

            var current: DocumentFile? = null
            segments.forEachIndexed { index, segment ->
                val accumulated = segments.take(index + 1).joinToString("/")
                val existing = ctx.uriAccessPolicy.resolveDocument(accumulated)
                current = if (existing != null) {
                    existing
                } else {
                    val parent = current ?: return@withContext null
                    ctx.uriAccessPolicy.denyReason(parent.uri, write = true)
                        ?.let { return@withContext null }
                    parent.createDirectory(segment)
                }
                if (current == null) return@withContext null
            }
            current
        }

    /** 递归收集目录下的文件，值为相对路径（以 `/` 分隔）。 */
    suspend fun walk(
        ctx: ToolContext,
        directory: DocumentFile,
        prefix: String = ""
    ): List<Pair<String, DocumentFile>> = withContext(Dispatchers.IO) {
        val result = mutableListOf<Pair<String, DocumentFile>>()
        val stack = ArrayDeque<Pair<DocumentFile, String>>()
        stack.addLast(directory to prefix)

        while (stack.isNotEmpty()) {
            val (current, path) = stack.removeLast()
            current.listFiles().forEach { child ->
                val name = child.name ?: return@forEach
                val childPath = if (path.isEmpty()) name else "$path/$name"
                if (child.isDirectory) {
                    stack.addLast(child to childPath)
                } else {
                    result += childPath to child
                }
            }
        }
        result
    }

    /** 去掉常见的路径前缀，统一成「相对授权根」的形式。 */
    private fun normalize(path: String): String = path.trim()
        .trimStart('/')
        .removePrefix("storage/emulated/0/")
        .removePrefix("sdcard/")

    /** 读取至多 [limit] 字节；超出即截断（调用方据此判断"太大"）。 */
    fun readLimited(input: InputStream, limit: Int): ByteArray {
        val out = ByteArrayOutputStream(minOf(limit, 1 shl 20))
        val buffer = ByteArray(64 * 1024)
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read == -1) break
            if (total + read >= limit) {
                out.write(buffer, 0, limit - total)
                break
            }
            out.write(buffer, 0, read)
            total += read
        }
        return out.toByteArray()
    }

    private fun mimeOf(fileName: String): String = when {
        fileName.endsWith(".apk", true) -> "application/vnd.android.package-archive"
        fileName.endsWith(".png", true) -> "image/png"
        fileName.endsWith(".jpg", true) || fileName.endsWith(".jpeg", true) -> "image/jpeg"
        fileName.endsWith(".webp", true) -> "image/webp"
        fileName.endsWith(".xml", true) -> "text/xml"
        fileName.endsWith(".json", true) -> "application/json"
        else -> "application/octet-stream"
    }
}

/** 文档读写的业务错误（区别于底层 IO 异常）。 */
class DocumentIoException(message: String) : Exception(message)
