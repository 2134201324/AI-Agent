package com.example.nativedemo.ui.common

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

/**
 * 图片解码 / 导入。
 *
 * 为什么需要这一层：用户相册里的图千奇百怪 ——
 * - **HEIC/HEIF**：小米、OPPO、vivo、华为等国产相册很常见，而 `BitmapFactory`
 *   对 HEIC 直接返回 null，且**不报错**，表现就是"选了图背景一片空白"；
 * - **超大图**：上亿像素直出，全尺寸解码必然 OOM 或超时；
 * - **EXIF 旋转**：竖拍照片的方向信息写在 EXIF 里，`BitmapFactory` 视而不见，
 *   背景会横着躺。
 *
 * 统一策略：API 28+ 走 [ImageDecoder]（原生支持 HEIC、自动应用 EXIF 方向），
 * 更低版本用 [BitmapFactory] + 手写 EXIF 解析兜底；导入时一律**转码成
 * JPEG** 存进应用私有目录，此后渲染只需要面对"我们自己生成的 JPEG"。
 */

/** 计算 inSampleSize：把长边缩到 [maxEdge] 附近，且必须是 2 的幂。maxEdge 非正数表示不限制。 */
internal fun sampleSizeFor(width: Int, height: Int, maxEdge: Int): Int {
    if (maxEdge <= 0) return 1
    var sample = 1
    var longest = maxOf(width, height)
    while (longest / 2 >= maxEdge) {
        sample *= 2
        longest /= 2
    }
    return sample
}

/** 打开图片来源：支持 content:// 、 file:// 与绝对路径三种形式。 */
internal fun openImageStream(context: Context, source: String): InputStream? = runCatching {
    when {
        source.startsWith("content://") || source.startsWith("android.resource://") ->
            context.contentResolver.openInputStream(Uri.parse(source))

        source.startsWith("file://") ->
            Uri.parse(source).path?.let { File(it).inputStream() }

        else -> File(source).inputStream()
    }
}.getOrNull()

private fun imageDecoderSource(context: Context, source: String): ImageDecoder.Source? =
    runCatching {
        when {
            source.startsWith("content://") || source.startsWith("android.resource://") ->
                ImageDecoder.createSource(context.contentResolver, Uri.parse(source))

            source.startsWith("file://") ->
                Uri.parse(source).path?.let { ImageDecoder.createSource(File(it)) }

            else -> ImageDecoder.createSource(File(source))
        }
    }.getOrNull()

/**
 * 从 JPEG 流中读取 EXIF 方向标签（1/3/6/8），读不到返回 1（正常方向）。
 *
 * 只解析到 IFD0 的 Orientation 为止，不引入 androidx.exifinterface 依赖。
 * API 28+ 的 [ImageDecoder] 会自动处理 EXIF 方向，这条路径只给老系统兜底。
 */
internal fun readJpegExifOrientation(input: InputStream): Int = runCatching {
    extractApp1Payload(input)?.let { parseExifOrientation(it) } ?: 1
}.getOrDefault(1)

/** 在 JPEG 标记流里找到 APP1 段，返回其载荷（含 "Exif\0\0" 头）；找不到返回 null。 */
private fun extractApp1Payload(input: InputStream): ByteArray? {
    // SOI：JPEG 必须以 FF D8 开头
    if (input.read() != 0xFF || input.read() != 0xD8) return null

    while (true) {
        // 跳到下一个 marker（跳过对齐用的填充字节与杂散数据）
        var b = input.read()
        while (b != -1 && b != 0xFF) b = input.read()
        if (b == -1) return null
        var marker = input.read()
        while (marker == 0xFF) marker = input.read()
        if (marker == -1) return null

        // 无长度字段的独立 marker
        if (marker == 0xD8 || marker == 0x01 || marker in 0xD0..0xD7) continue
        // EOI：图片已经结束还没找到 EXIF
        if (marker == 0xD9) return null

        val length = (input.read() shl 8) or input.read()
        if (length < 2) return null

        if (marker != 0xE1) {
            // 非 APP1 段：整段跳过
            var skip = (length - 2).toLong()
            while (skip > 0L) {
                val n = input.skip(skip)
                if (n > 0L) skip -= n else if (input.read() == -1) return null else skip -= 1
            }
            continue
        }

        val payload = ByteArray(length - 2)
        var read = 0
        while (read < payload.size) {
            val n = input.read(payload, read, payload.size - read)
            if (n <= 0) break
            read += n
        }
        return payload.takeIf { read == payload.size }
    }
}

/**
 * 在 APP1 载荷（"Exif\0\0" + TIFF）中解析 Orientation。
 *
 * 任何不符合预期的情况都返回 1：老系统上最坏情况是方向不对，
 * 但绝不能因为一张来路不明的图把设置页搞崩。
 */
internal fun parseExifOrientation(payload: ByteArray): Int {
    // "Exif\0\0" + TIFF 头(8) + IFD0(至少 2) 才可能有内容
    if (payload.size < 16) return 1
    if (payload[0].toInt() != 0x45 || payload[1].toInt() != 0x78 ||
        payload[2].toInt() != 0x69 || payload[3].toInt() != 0x66 ||
        payload[4].toInt() != 0 || payload[5].toInt() != 0
    ) return 1

    val tiff = 6
    val little = payload[tiff].toInt() == 0x49 && payload[tiff + 1].toInt() == 0x49 // "II"
    val big = payload[tiff].toInt() == 0x4D && payload[tiff + 1].toInt() == 0x4D    // "MM"
    if (!little && !big) return 1

    fun u16(off: Int): Int =
        if (little) (payload[off].toInt() and 0xFF) or ((payload[off + 1].toInt() and 0xFF) shl 8)
        else ((payload[off].toInt() and 0xFF) shl 8) or (payload[off + 1].toInt() and 0xFF)

    fun u32(off: Int): Int =
        if (little) (payload[off].toInt() and 0xFF) or
                ((payload[off + 1].toInt() and 0xFF) shl 8) or
                ((payload[off + 2].toInt() and 0xFF) shl 16) or
                ((payload[off + 3].toInt() and 0xFF) shl 24)
        else ((payload[off].toInt() and 0xFF) shl 24) or
                ((payload[off + 1].toInt() and 0xFF) shl 16) or
                ((payload[off + 2].toInt() and 0xFF) shl 8) or
                (payload[off + 3].toInt() and 0xFF)

    val ifd0 = tiff + u32(tiff + 4)
    if (ifd0 + 2 > payload.size) return 1

    var entry = ifd0 + 2
    for (i in 0 until u16(ifd0)) {
        if (entry + 12 > payload.size) return 1
        if (u16(entry) == 0x0112) {
            // SHORT 类型的值直接放在 value 字段前两个字节里
            val value = u16(entry + 8)
            return if (value in 1..8) value else 1
        }
        entry += 12
    }
    return 1
}

/** 按 EXIF 方向旋转位图；方向为 1（或无法识别）时原样返回。 */
internal fun applyExifRotation(bitmap: Bitmap, orientation: Int): Bitmap {
    val matrix = Matrix()
    when (orientation) {
        3 -> matrix.setRotate(180f)
        6 -> matrix.setRotate(90f)
        8 -> matrix.setRotate(270f)
        else -> return bitmap
    }
    val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    if (rotated != bitmap) bitmap.recycle()
    return rotated
}

/**
 * API 24-27 的兜底解码路径：BitmapFactory 不解码 HEIC，也不看 EXIF，
 * 所以这里手工补上旋转；采样压缩由 inSampleSize 完成。
 *
 * [opener] 每次调用都应返回一个**全新的流** —— content:// 输入流不支持
 * mark/reset，而这里需要"读尺寸 → 解码 → 读 EXIF"三遍。
 */
private fun decodeViaFactory(opener: () -> InputStream?, maxEdge: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    opener()?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: return null
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

    val options = BitmapFactory.Options().apply {
        inSampleSize = sampleSizeFor(bounds.outWidth, bounds.outHeight, maxEdge)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    val decoded = opener()?.use { BitmapFactory.decodeStream(it, null, options) } ?: return null

    val orientation = opener()?.use { readJpegExifOrientation(it) } ?: 1
    return applyExifRotation(decoded, orientation)
}

/**
 * 解码一张图片，长边不超过 [maxEdge]。
 *
 * 支持 HEIC（API 28+）、超大图（自动采样）、EXIF 旋转。
 * 任何失败都返回 null 而不是抛出 —— 由调用方决定占位与提示。
 */
suspend fun decodeImage(context: Context, source: String, maxEdge: Int = 1600): Bitmap? =
    withContext(Dispatchers.IO) {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val src = imageDecoderSource(context, source) ?: return@runCatching null
                // 尺寸只能在 OnHeaderDecodedListener 里拿（Source 上没有公开的
                // computeSize），此时还没开始全图解码，正好在这里设采样率
                ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    val size = info.size
                    decoder.setTargetSampleSize(sampleSizeFor(size.width, size.height, maxEdge))
                }
            } else {
                decodeViaFactory({ openImageStream(context, source) }, maxEdge)
            }
        }.getOrNull()
    }

/**
 * 把外部图片（相册 URI）转码成私有目录里的 JPEG。
 *
 * 先把原始字节落到 [target] 旁边的临时文件再解码 —— 部分厂商相册的
 * content:// URI **不能重复打开输入流**，只开一次最稳；而且万一解码失败，
 * [target] 不会被写成半张图。
 *
 * @return true 表示 [target] 已是一张可解码的 JPEG。
 */
suspend fun importAsJpeg(context: Context, uri: Uri, target: File, maxEdge: Int = 2000): Boolean =
    withContext(Dispatchers.IO) {
        val raw = File(target.parentFile, "${target.name}.raw.tmp")
        val dumped = runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(raw).use { output -> input.copyTo(output) }
                raw.length() > 0L
            } ?: false
        }.getOrDefault(false)
        if (!dumped) {
            raw.delete()
            return@withContext false
        }

        val ok = runCatching {
            val bitmap = decodeImage(context, raw.absolutePath, maxEdge)
            if (bitmap == null) {
                false
            } else {
                try {
                    FileOutputStream(target).use { out ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                    }
                    target.length() > 0L
                } finally {
                    bitmap.recycle()
                }
            }
        }.getOrDefault(false)

        raw.delete()
        ok
    }
