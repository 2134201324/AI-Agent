package com.example.nativedemo.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.example.nativedemo.data.settings.AppBrand
import com.example.nativedemo.data.settings.BackdropStats
import com.example.nativedemo.data.settings.ColorSlot

/**
 * 配色。
 *
 * 深色方案沿用 DeepSeek 的视觉语言：纯黑底 + 中性灰层级 + 单一品牌色。
 * 纯黑在 OLED 上更省电，层级靠「明度差」而非色相区分，界面更克制。
 *
 * 浅色方案不是简单反色：底色用极浅冷灰而非纯白，避免大面积高亮刺眼；
 * 文字降到 #16181D 而非纯黑，长时间阅读更舒服。
 *
 * 每个字段都可能被用户在「自定义背景」页里单独覆盖 —— 见 [withOverrides]。
 */

/** 品牌色 → 色值。集中在此，数据层不必依赖 Compose。 */
fun AppBrand.color(): Color = when (this) {
    AppBrand.BLUE -> Color(0xFF4D6BFE)
    AppBrand.TEAL -> Color(0xFF12B5A8)
    AppBrand.VIOLET -> Color(0xFF8B5CF6)
    AppBrand.GREEN -> Color(0xFF2FB344)
    AppBrand.AMBER -> Color(0xFFE08700)
    AppBrand.ROSE -> Color(0xFFE5484D)
}

@Immutable
data class AppPalette(
    val isDark: Boolean,
    val bg: Color,
    val cardBg: Color,
    val chipBg: Color,
    val inputBg: Color,
    val fieldBg: Color,
    val lineColor: Color,
    val fg: Color,
    val muted: Color,
    val faint: Color,
    val userBubble: Color,
    val accent: Color,
    val accent2: Color,
    val danger: Color,
    val warn: Color,
    // ── 可独立自定义的区域色 ──
    val topBarBg: Color,
    val topBarFg: Color,
    val inputBarBg: Color,
    val inputBarFg: Color,
    val overlayBg: Color,
    val drawerBg: Color,
    val bannerBg: Color
) {
    /**
     * 逐槽覆盖：用户显式改过的槽位替换预设值，其余跟随主题。
     *
     * 之所以做成「覆盖」而不是「另存一套」，是为了让「切换深浅模式 / 换品牌色」
     * 仍然能整体生效 —— 用户只自定义了标题栏，就不该把其他十几处颜色一起冻住。
     */
    fun withOverrides(overrides: Map<ColorSlot, Long>): AppPalette {
        if (overrides.isEmpty()) return this
        fun pick(slot: ColorSlot, fallback: Color): Color =
            overrides[slot]?.let { Color(it.toInt()) } ?: fallback

        return copy(
            accent = pick(ColorSlot.ACCENT, accent),
            fg = pick(ColorSlot.TEXT, fg),
            muted = pick(ColorSlot.MUTED, muted),
            faint = pick(ColorSlot.FAINT, faint),
            topBarBg = pick(ColorSlot.TOP_BAR_BG, topBarBg),
            topBarFg = pick(ColorSlot.TOP_BAR_FG, topBarFg),
            inputBarBg = pick(ColorSlot.INPUT_BAR_BG, inputBarBg),
            inputBarFg = pick(ColorSlot.INPUT_BAR_FG, inputBarFg),
            bg = pick(ColorSlot.PAGE_BG, bg),
            overlayBg = pick(ColorSlot.OVERLAY_BG, overlayBg),
            cardBg = pick(ColorSlot.CARD_BG, cardBg),
            chipBg = pick(ColorSlot.CHIP_BG, chipBg),
            fieldBg = pick(ColorSlot.FIELD_BG, fieldBg),
            userBubble = pick(ColorSlot.USER_BUBBLE, userBubble),
            lineColor = pick(ColorSlot.LINE_COLOR, lineColor),
            drawerBg = pick(ColorSlot.DRAWER_BG, drawerBg),
            bannerBg = pick(ColorSlot.BANNER_BG, bannerBg)
        )
    }

    /**
     * 智能图文适配层：按背景图统计替换三档文字色。
     *
     * 只动**直接浮在背景图上的文字**（正文 / 次要 / 备注），
     * 不动背景类槽位 —— 那些各有自己的背景色兜底，改错反而更难读。
     * 用户的手动覆盖在这之后套上去（见 [withOverrides]），所以优先级：
     * 手动 > 智能 > 主题预设。
     */
    fun withSmartText(stats: BackdropStats?): AppPalette {
        if (stats == null) return this
        val levels = smartTextLevels(stats)
        return copy(
            fg = grayColor(levels.fg),
            muted = grayColor(levels.muted),
            faint = grayColor(levels.faint)
        )
    }

    companion object {
        fun of(brand: AppBrand, dark: Boolean): AppPalette = if (dark) {
            AppPalette(
                isDark = true,
                bg = Color(0xFF000000),
                cardBg = Color(0xFF1A1A1A),
                chipBg = Color(0xFF1F1F1F),
                inputBg = Color(0xFF2A2A2A),
                fieldBg = Color(0xFF2A2A2A),
                lineColor = Color(0xFF2E2E2E),
                fg = Color(0xFFECECEC),
                muted = Color(0xFF8C8C8C),
                faint = Color(0xFF5C5C5C),
                userBubble = Color(0xFF2F2F2F),
                accent = brand.color(),
                accent2 = Color(0xFF46D6B4),
                danger = Color(0xFFFF6B6B),
                warn = Color(0xFFF5A623),
                topBarBg = Color(0xFF000000),
                topBarFg = Color(0xFFECECEC),
                inputBarBg = Color(0xFF1A1A1A),
                inputBarFg = Color(0xFFECECEC),
                overlayBg = Color(0xFF1F1F1F),
                drawerBg = Color(0xFF0F0F0F),
                bannerBg = Color(0xFF1F1F1F)
            )
        } else {
            AppPalette(
                isDark = false,
                bg = Color(0xFFFFFFFF),
                cardBg = Color(0xFFF7F8FA),
                chipBg = Color(0xFFEDEFF4),
                inputBg = Color(0xFFF1F2F6),
                fieldBg = Color(0xFFF1F2F6),
                lineColor = Color(0xFFE2E5EC),
                fg = Color(0xFF16181D),
                muted = Color(0xFF6B7280),
                faint = Color(0xFF9AA1AE),
                userBubble = Color(0xFFEDEFF4),
                accent = brand.color(),
                accent2 = Color(0xFF0E9E85),
                danger = Color(0xFFD93B3B),
                warn = Color(0xFFB26A00),
                topBarBg = Color(0xFFFFFFFF),
                topBarFg = Color(0xFF16181D),
                inputBarBg = Color(0xFFF7F8FA),
                inputBarFg = Color(0xFF16181D),
                overlayBg = Color(0xFFFFFFFF),
                drawerBg = Color(0xFFF7F8FA),
                bannerBg = Color(0xFFEDEFF4)
            )
        }
    }
}

/** 按槽位取出实际生效的颜色（已含用户覆盖）。 */
fun AppPalette.valueOf(slot: ColorSlot): Color = when (slot) {
    ColorSlot.ACCENT -> accent
    ColorSlot.TEXT -> fg
    ColorSlot.MUTED -> muted
    ColorSlot.FAINT -> faint
    ColorSlot.TOP_BAR_BG -> topBarBg
    ColorSlot.TOP_BAR_FG -> topBarFg
    ColorSlot.INPUT_BAR_BG -> inputBarBg
    ColorSlot.INPUT_BAR_FG -> inputBarFg
    ColorSlot.PAGE_BG -> bg
    ColorSlot.OVERLAY_BG -> overlayBg
    ColorSlot.CARD_BG -> cardBg
    ColorSlot.CHIP_BG -> chipBg
    ColorSlot.FIELD_BG -> fieldBg
    ColorSlot.USER_BUBBLE -> userBubble
    ColorSlot.LINE_COLOR -> lineColor
    ColorSlot.DRAWER_BG -> drawerBg
    ColorSlot.BANNER_BG -> bannerBg
}

/**
 * 全局调色板。
 *
 * 这里刻意用「可变状态 + 顶层 getter」而不是 CompositionLocal：
 * 颜色在这些界面里被引用了一百多处（`Accent` / `Bg` / `Muted` …），
 * 改成 CompositionLocal 意味着上百处机械改动，收益却只是形式更"标准"。
 * 而 Compose 的快照系统记录的是**组合期间的 State 读取** —— 所以下面的
 * getter 同样能驱动重组，引用点一行都不用动。
 */
object Palette {

    var current: AppPalette by mutableStateOf(AppPalette.of(AppBrand.default, dark = true))
        internal set

    fun apply(
        brand: AppBrand,
        dark: Boolean,
        overrides: Map<ColorSlot, Long> = emptyMap(),
        smartStats: BackdropStats? = null
    ) {
        val next = AppPalette.of(brand, dark)
            .withSmartText(smartStats)
            .withOverrides(overrides)
        // AppPalette 是 data class：同值写入不会触发重组
        if (next != current) current = next
    }
}

// ── 供界面直接引用的动态色（读取即订阅）──────────────────────────────
val Bg: Color get() = Palette.current.bg
val CardBg: Color get() = Palette.current.cardBg
val ChipBg: Color get() = Palette.current.chipBg
val InputBg: Color get() = Palette.current.inputBg
val FieldBg: Color get() = Palette.current.fieldBg
val LineColor: Color get() = Palette.current.lineColor
val Fg: Color get() = Palette.current.fg
val Muted: Color get() = Palette.current.muted
val Faint: Color get() = Palette.current.faint
val UserBubble: Color get() = Palette.current.userBubble
val Accent: Color get() = Palette.current.accent
val Accent2: Color get() = Palette.current.accent2
val Danger: Color get() = Palette.current.danger
val Warn: Color get() = Palette.current.warn
val TopBarBg: Color get() = Palette.current.topBarBg
val TopBarFg: Color get() = Palette.current.topBarFg
val InputBarBg: Color get() = Palette.current.inputBarBg
val InputBarFg: Color get() = Palette.current.inputBarFg
val OverlayBg: Color get() = Palette.current.overlayBg
val DrawerBg: Color get() = Palette.current.drawerBg
val BannerBg: Color get() = Palette.current.bannerBg
