package com.example.nativedemo.core

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat

/**
 * Agent 工具链依赖的系统权限。
 *
 * 为什么单独成一层：这些权限**申请方式各不相同** —— 有的是运行时弹窗，
 * 有的是跳系统设置页，有的连设置页都进不去（悬浮窗只能进"应用详情"）。
 * 散落在各处的申请代码很容易漏掉某一类，于是出现"工具明明开着却总是报错"。
 * 这里把「怎么判断」「怎么申请」两件事收在一处，UI 只需遍历即可。
 *
 * 注意：这里**没有**无障碍（Accessibility）权限 —— 本应用刻意不申请它。
 * AI 不得读取屏幕、不得操作用户手机与其他应用的界面，这是不可退让的边界。
 */
enum class ToolPermissionKind {
    /** 运行时弹窗：一次权限，立即知道结果 */
    RUNTIME,

    /** 跳系统设置页：用户手动开启，回来后再查状态 */
    SETTINGS_PAGE
}

/** 权限项在「一键启动」里的推进顺序：先弹窗的、再跳设置的。 */
enum class ToolPermission(val id: String) {
    /** 通知：前台服务进度提示依赖它，没有它服务会退化成"看不见的服务" */
    NOTIFICATION("notification"),

    /** 传统存储读写：仅 Android 10 及以下有效 */
    STORAGE("storage"),

    /** 所有文件访问：Android 11+ 访问 /sdcard 全盘的前提 */
    ALL_FILES("all_files"),

    /** 悬浮窗：部分 ROM 把它与「后台弹出界面」绑定，缺它拉不起 MT 管理器 */
    OVERLAY("overlay"),

    /** 电池优化白名单：让长任务（改包、跑编译）不会被系统掐断 */
    BATTERY("battery");

    val kind: ToolPermissionKind
        get() = when (this) {
            NOTIFICATION, STORAGE -> ToolPermissionKind.RUNTIME
            else -> ToolPermissionKind.SETTINGS_PAGE
        }
}

/** 某一项权限的「标题 / 说明 / 当前状态」快照，供 UI 直接渲染。 */
data class PermissionSnapshot(
    val permission: ToolPermission,
    val title: String,
    val rationale: String,
    val granted: Boolean,
    /** 本机系统版本上该项是否适用（例如 Android 13+ 才需要通知授权） */
    val applicable: Boolean,
    /** 当前状态下的补充说明；为空表示不需要额外提示 */
    val statusNote: String? = null
)

/**
 * 权限状态查询与申请 Intent 构造。
 *
 * 只读，不持状态 —— 每次 UI 刷新重新查一遍即可，避免缓存与实际系统状态不一致
 * （用户完全可能在系统设置里改完权限再切回来）。
 */
object ToolPermissions {

    /** 采集全部权限的当前状态。 */
    fun snapshot(context: Context): List<PermissionSnapshot> = listOf(
        notification(context),
        storage(context),
        allFiles(context),
        overlay(context),
        battery(context)
    )

    /** 尚未授予、且本机适用的项。一键启动的输入。 */
    fun pending(context: Context): List<ToolPermission> =
        snapshot(context)
            .filter { it.applicable && !it.granted }
            .map { it.permission }

    // ── 逐项定义 ──────────────────────────────────────────────────────

    private fun notification(context: Context): PermissionSnapshot {
        val applicable = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
        val granted = !applicable || ContextCompat.checkSelfPermission(
            context, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        return PermissionSnapshot(
            permission = ToolPermission.NOTIFICATION,
            title = "通知权限",
            rationale = "生成期间在通知栏显示进度。没有它，前台服务不显示通知，" +
                "系统会把它当作普通后台进程，长任务更容易被回收。",
            granted = granted,
            applicable = applicable,
            statusNote = if (!applicable) "Android 13 以下无需申请" else null
        )
    }

    private fun storage(context: Context): PermissionSnapshot {
        val applicable = Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q
        val granted = !applicable || (
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
            )
        return PermissionSnapshot(
            permission = ToolPermission.STORAGE,
            title = "存储读写权限",
            rationale = "命令终端读取 /sdcard 下的文件、把产物写到公用目录。",
            granted = granted,
            applicable = applicable,
            statusNote = if (!applicable) "Android 11 起改用「所有文件访问」" else null
        )
    }

    private fun allFiles(context: Context): PermissionSnapshot {
        val applicable = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
        val granted = !applicable || Environment.isExternalStorageManager()
        return PermissionSnapshot(
            permission = ToolPermission.ALL_FILES,
            title = "所有文件访问",
            rationale = "Android 11 起分区存储会挡住 /sdcard 全盘。开这个权限后，" +
                "文件读写、APK 提取、改包产物落地才能覆盖整个共享存储。",
            granted = granted,
            applicable = applicable,
            statusNote = if (!applicable) "Android 10 以下用「存储读写」" else null
        )
    }

    private fun overlay(context: Context): PermissionSnapshot {
        val granted = Settings.canDrawOverlays(context)
        return PermissionSnapshot(
            permission = ToolPermission.OVERLAY,
            title = "悬浮窗权限",
            rationale = "部分机型（MIUI/鸿蒙等）把「后台弹出界面」与悬浮窗权限绑定，" +
                "不开它就无法从后台拉起 MT 管理器。",
            granted = granted,
            applicable = true,
            statusNote = null
        )
    }

    private fun battery(context: Context): PermissionSnapshot {
        val power = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val granted = power?.isIgnoringBatteryOptimizations(context.packageName) ?: false
        return PermissionSnapshot(
            permission = ToolPermission.BATTERY,
            title = "电池优化白名单",
            rationale = "关掉对本应用的电池优化后，跑改包 / 装包 / 长回复这类" +
                "几分钟的任务时，系统不会在息屏后把进程掐掉。",
            granted = granted,
            applicable = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M,
            statusNote = null
        )
    }

    // ── 申请入口 ──────────────────────────────────────────────────────

    /**
     * 取某项权限对应的「跳转 Intent」；返回 null 表示该项用运行时弹窗申请，
     * 由调用方自行 launch 系统权限对话框。
     */
    fun settingsIntent(context: Context, permission: ToolPermission): Intent? = when (permission) {
        ToolPermission.ALL_FILES ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.fromParts("package", context.packageName, null)
                )
            } else {
                null
            }

        ToolPermission.OVERLAY ->
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.fromParts("package", context.packageName, null)
            )

        ToolPermission.BATTERY -> batteryIntent(context)

        ToolPermission.NOTIFICATION, ToolPermission.STORAGE -> null
    }

    /**
     * 电池优化白名单。
     *
     * 优先请求「直接加入白名单」的对话框（[Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS]），
     * 但国内 ROM 大量裁掉了这个 action —— 直接跳会抛 ActivityNotFoundException，
     * 所以先做一次 resolve，不行就退到电池优化设置列表页，让用户自己找。
     */
    private fun batteryIntent(context: Context): Intent {
        val direct = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            .setData(Uri.fromParts("package", context.packageName, null))
        if (context.packageManager.resolveActivity(direct, PackageManager.MATCH_DEFAULT_ONLY) != null) {
            return direct
        }
        return Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
    }

    /** 运行时权限：某项对应的系统权限名数组，空数组表示走设置页。 */
    fun runtimePermissions(permission: ToolPermission): Array<String> = when (permission) {
        ToolPermission.NOTIFICATION ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arrayOf(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                emptyArray()
            }

        ToolPermission.STORAGE ->
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
            } else {
                emptyArray()
            }

        else -> emptyArray()
    }
}
