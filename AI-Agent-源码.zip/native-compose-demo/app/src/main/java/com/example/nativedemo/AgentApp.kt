package com.example.nativedemo

import android.app.Application
import com.example.nativedemo.core.AppContainer

/**
 * 应用入口，持有全局依赖容器。
 */
class AgentApp : Application() {

    val container: AppContainer by lazy { AppContainer(this) }
}
