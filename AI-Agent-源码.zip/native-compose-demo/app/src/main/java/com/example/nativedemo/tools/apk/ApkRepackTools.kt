package com.example.nativedemo.tools.apk

import android.content.Context
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.bool
import com.example.nativedemo.tools.int
import com.example.nativedemo.tools.saf.DocumentIo
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.str
import kotlinx.serialization.json.JsonObject
import java.io.File
import java.util.Locale

/**
 * 重建 APK 的公共部分：把「取密钥 → 重建 → 签名 → 落盘」串起来。
 *
 * 三个改包工具（replace / pack / sign）走的是同一条收尾路径，差别只在中间那一步，
 * 所以抽在这里 —— 尤其是密钥解析与临时文件清理，漏一处就会留下垃圾或签错密钥。
 */
abstract class ApkRepackToolBase(context: Context) : ApkToolBase(context) {

    protected val engine: RepackEngine by lazy { RepackEngine(context) }

    /** 解析签名密钥：给了 keystore 就用它，否则用应用内置的那对。 */
    protected suspend fun resolveSigningKey(
        args: JsonObject,
        ctx: ToolContext
    ): SigningKey {
        val keystorePath = args.str("keystore")
        val alias = args.str("alias")
        val password = args.str("password")

        if (keystorePath.isNullOrBlank()) return engine.resolveKey()

        val bytes = DocumentIo.readBytesOrReason(ctx, keystorePath).getOrElse { throw it }
        val temp = File(engine.workDir(), "user-keystore-${System.currentTimeMillis()}.p12")
        temp.writeBytes(bytes)
        return try {
            engine.resolveKey(temp, alias, password?.toCharArray())
        } finally {
            // 密钥已经加载进内存，临时文件没必要留着
            engine.cleanUp(temp)
        }
    }

    /** 签名说明文案，包含用的是哪把钥匙 —— 用户需要知道能不能覆盖安装。 */
    protected fun signingSummary(key: SigningKey, schemes: String): String =
        "已签名（$schemes）\n密钥来源：${key.origin}\n" +
            "证书主题：${key.material.certificate.subjectX500Principal.name}"

    /** 未指定输出路径时，在源文件同目录生成一个带后缀的名字。 */
    protected fun defaultOutputPath(sourcePath: String, suffix: String): String {
        val cleaned = sourcePath.trim().trimStart('/')
        val directory = cleaned.substringBeforeLast('/', "")
        val fileName = cleaned.substringAfterLast('/')
        val base = fileName.substringBeforeLast('.', fileName)
        val extension = fileName.substringAfterLast('.', "apk")
        val newName = "$base-$suffix.$extension"
        return if (directory.isEmpty()) newName else "$directory/$newName"
    }

    /** 二进制产物的体积描述。 */
    protected fun describeSize(bytes: Int): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
        else -> "%.2f MB".format(bytes / (1024.0 * 1024.0))
    }
}

// ── 替换包内条目（最常用：改图、改配置）────────────────────────────────

class ApkReplaceTool(context: Context) : ApkRepackToolBase(context) {

    override val spec = ToolSpec(
        name = "apk_replace",
        description = "**替换 APK 内的文件并重新打包签名**，一步产出可安装的新 APK。" +
            "典型用途：换掉 res/drawable 里的图片、改 assets 里的配置、替换 so。" +
            "旧签名会被自动剔除，默认用应用内置密钥重新签名（v1+v2）。\n" +
            "用法二选一：① entry + source 替换一个文件；" +
            "② replacements 用「条目=源文件」的多组，以分号分隔。\n" +
            "注意：用内置密钥签名的包**无法覆盖安装原应用**（签名不一致），需先卸载；" +
            "要覆盖安装必须通过 keystore 参数传入原应用的签名密钥。",
        category = "逆向",
        layer = "L2",
        destructive = true,
        params = objectSchema {
            string("path", "源 APK 路径")
            string("entry", "要替换的包内条目，如 res/drawable/a7.png；用 apk_list 可查准确路径", required = false)
            string("source", "新内容的来源文件路径（设备上已授权目录内）", required = false)
            string(
                "replacements",
                "多组替换，格式：条目1=源文件1;条目2=源文件2",
                required = false
            )
            string("output", "输出 APK 路径；缺省为源文件同目录的 <名字>-repacked.apk", required = false)
            boolean("sign", "是否自动签名，默认 true")
            string("keystore", "自定义签名密钥（PKCS12/JKS）；缺省用应用内置密钥", required = false)
            string("alias", "keystore 别名（缺省自动取第一个）", required = false)
            string("password", "keystore 口令", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = requirePath(args) ?: return ToolResult.failure("缺少必填参数 'path'")

        // ── 收集替换关系 ──
        val pairs = mutableListOf<Pair<String, String>>()
        val singleEntry = args.str("entry")
        val singleSource = args.str("source")
        if (!singleEntry.isNullOrBlank() && !singleSource.isNullOrBlank()) {
            pairs += singleEntry to singleSource
        }
        args.str("replacements")?.let { spec ->
            spec.split(';', '\n')
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .forEach { item ->
                    val parts = item.split('=', limit = 2)
                    if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                        pairs += parts[0].trim() to parts[1].trim()
                    }
                }
        }
        if (pairs.isEmpty()) {
            return ToolResult.failure(
                "没有指定要替换的内容。请用 entry + source 指定一个文件，" +
                    "或用 replacements 指定多组（格式：条目=源文件;条目=源文件）。"
            )
        }

        // ── 读入新内容 ──
        val replacements = mutableMapOf<String, ByteArray>()
        pairs.forEach { (entry, source) ->
            val bytes = DocumentIo.readBytesOrReason(ctx, source).getOrElse {
                return ToolResult.failure("读取替换源「$source」失败：${it.message}")
            }
            replacements[entry] = bytes
        }

        val shouldSign = args.bool("sign", true)
        val outputPath = args.str("output") ?: defaultOutputPath(path, "repacked")

        return openAndUse(path, ctx) { archive ->
            val tempFiles = mutableListOf<File>()
            try {
                var current = engine.rebuild(archive, replacements = replacements)
                tempFiles += current

                val key = if (shouldSign) resolveSigningKey(args, ctx) else null
                if (key != null) {
                    current = engine.sign(current, key)
                    tempFiles += current
                }

                val bytes = current.readBytes()
                DocumentIo.writeBytes(ctx, outputPath, bytes)?.let { return@openAndUse it }

                val schemes = ApkSignatureInspector.detectSchemes(current)
                buildString {
                    append("✅ 改包完成\n\n")
                    append("替换 ${replacements.size} 个条目：\n")
                    replacements.keys.forEach { append("  · $it\n") }
                    append("\n输出：$outputPath（${describeSize(bytes.size)}）\n")
                    if (key != null) {
                        append(signingSummary(key, schemes.describe()))
                        append("\n\n")
                        append(
                            if (key.origin.startsWith("应用内置")) {
                                "⚠️ 用内置密钥签名，与原应用签名不同，**无法覆盖安装**；" +
                                    "请先卸载原应用再装，或改用原应用的 keystore 重新签名。"
                            } else {
                                "如果这把密钥就是原应用的签名密钥，可直接覆盖安装。"
                            }
                        )
                    } else {
                        append("未签名：安装前需要先执行 apk_sign。")
                    }
                }
            } finally {
                engine.cleanUp(*tempFiles.toTypedArray())
            }
        }
    }
}

// ── 解包 ──────────────────────────────────────────────────────────────

class ApkUnpackTool(context: Context) : ApkToolBase(context) {

    override val spec = ToolSpec(
        name = "apk_unpack",
        description = "把 APK 内的文件**完整解压到指定目录**，便于批量修改后用 apk_pack 重新打包。" +
            "二进制 XML 会**自动解码成可读 XML**（否则拿到的是乱码），" +
            "可用 decode_xml=false 关闭。适合「要改多个文件」的场景；" +
            "只改一个文件的话用 apk_replace 更省事。",
        category = "逆向",
        layer = "L2",
        destructive = true,
        params = objectSchema {
            string("path", "APK 文件路径")
            string("dest_dir", "解包目标目录（需在已授权目录内），不存在会自动创建")
            string("filter", "只解压路径包含该关键字的条目，如 res/ 或 lib/arm64-v8a", required = false)
            boolean("decode_xml", "是否把二进制 XML 解码为可读 XML，默认 true")
            integer("limit", "最多解压多少个文件，默认 2000", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = requirePath(args) ?: return ToolResult.failure("缺少必填参数 'path'")
        val destDir = args.str("dest_dir")
            ?: return ToolResult.failure("缺少必填参数 'dest_dir'")
        val filter = args.str("filter")?.lowercase(Locale.US)
        val decodeXml = args.bool("decode_xml", true)
        val limit = args.int("limit", 2000).coerceIn(1, 20_000)

        return openAndUse(path, ctx) { archive ->
            val targets = archive.entries
                .filter { !it.isDirectory }
                .filter { filter == null || it.name.lowercase(Locale.US).contains(filter) }
                .take(limit)

            if (targets.isEmpty()) return@openAndUse "没有匹配的条目。"

            var ok = 0
            val failures = mutableListOf<String>()

            targets.forEach { entry ->
                var bytes = archive.read(entry.name)
                if (bytes == null) {
                    failures += "${entry.name}（读取失败）"
                    return@forEach
                }

                // 二进制 XML 解成文本再落盘：否则用户/后续工具面对的是一堆乱码
                if (decodeXml && entry.name.endsWith(".xml", ignoreCase = true)) {
                    runCatching { AxmlParser.decode(bytes!!) }.getOrNull()?.let { document ->
                        bytes = AxmlParser.toXml(document).toByteArray(Charsets.UTF_8)
                    }
                }

                val targetPath = "${destDir.trimEnd('/')}/${entry.name}"
                val problem = DocumentIo.writeBytes(ctx, targetPath, bytes!!)
                if (problem != null) failures += "${entry.name}（$problem）" else ok++
            }

            buildString {
                append("✅ 已解包 $ok 个文件到「$destDir」\n")
                if (decodeXml) append("（其中 XML 已解码为可读文本）\n")
                if (targets.size >= limit && archive.entries.size > limit) {
                    append("（受 limit=$limit 限制，包内共 ${archive.entries.size} 个条目）\n")
                }
                if (failures.isNotEmpty()) {
                    append("\n失败 ${failures.size} 个：\n")
                    failures.take(5).forEach { append("  · $it\n") }
                }
                append("\n改完后用 apk_pack 打包：apk_pack(source_dir=\"$destDir\", output=\"...\")")
            }
        }
    }
}

// ── 打包 ──────────────────────────────────────────────────────────────

class ApkPackTool(context: Context) : ApkRepackToolBase(context) {

    override val spec = ToolSpec(
        name = "apk_pack",
        description = "把**目录**重新打包成 APK 并签名（配合 apk_unpack 使用）。" +
            "目录结构会原样映射为包内路径（相对目录根的路径即条目名）。" +
            "resources.arsc 与 .so 会保持不压缩以满足 Android 的安装要求。",
        category = "逆向",
        layer = "L2",
        destructive = true,
        params = objectSchema {
            string("source_dir", "要打包的目录（需在已授权目录内）")
            string("output", "输出 APK 路径")
            boolean("sign", "是否自动签名，默认 true")
            string("keystore", "自定义签名密钥（PKCS12/JKS）；缺省用应用内置密钥", required = false)
            string("alias", "keystore 别名", required = false)
            string("password", "keystore 口令", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val sourceDir = args.str("source_dir")
            ?: return ToolResult.failure("缺少必填参数 'source_dir'")
        val outputPath = args.str("output")
            ?: return ToolResult.failure("缺少必填参数 'output'")
        val shouldSign = args.bool("sign", true)

        val directory = ctx.uriAccessPolicy.resolveDocument(sourceDir)
            ?: return ToolResult.failure("未找到目录「$sourceDir」")
        if (!directory.isDirectory) return ToolResult.failure("「$sourceDir」不是目录")

        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val files = DocumentIo.walk(ctx, directory)
            if (files.isEmpty()) {
                return@withContext ToolResult.failure("目录「$sourceDir」里没有文件。")
            }

            val tempFiles = mutableListOf<File>()
            try {
                val packed = File(engine.workDir(), "packed-${System.currentTimeMillis()}.apk")
                tempFiles += packed
                java.io.FileOutputStream(packed).use { stream ->
                    val writer = ApkZipWriter(stream)
                    var count = 0
                    files.forEach { (relativePath, document) ->
                        val bytes = ctx.contentResolver.openInputStream(document.uri)?.use {
                            ApkArchive.readLimited(it, RepackEngine.MAX_ENTRY_BYTES)
                        } ?: return@forEach
                        writer.putEntry(
                            name = relativePath,
                            data = bytes,
                            compress = shouldCompressOnPack(relativePath),
                            alignment = RepackEngine.alignmentFor(relativePath)
                        )
                        count++
                    }
                    writer.finish()
                    if (count == 0) {
                        return@withContext ToolResult.failure("目录里的文件都读不出来。")
                    }
                }

                var current = packed
                val key = if (shouldSign) resolveSigningKey(args, ctx) else null
                if (key != null) {
                    current = engine.sign(current, key)
                    tempFiles += current
                }

                val bytes = current.readBytes()
                DocumentIo.writeBytes(ctx, outputPath, bytes)?.let { return@withContext ToolResult.failure(it) }

                ToolResult.success(
                    buildString {
                        append("✅ 打包完成\n\n")
                        append("来源：$sourceDir（${files.size} 个文件）\n")
                        append("输出：$outputPath（${describeSize(bytes.size)}）\n")
                        if (key != null) {
                            append("\n")
                            append(signingSummary(key, ApkSignatureInspector.detectSchemes(current).describe()))
                        } else {
                            append("\n未签名：安装前需要先执行 apk_sign。")
                        }
                    }
                )
            } catch (e: Throwable) {
                ToolResult.failure("打包失败：${e.message ?: e::class.java.simpleName}")
            } finally {
                engine.cleanUp(*tempFiles.toTypedArray())
            }
        }
    }

    /** 已压缩格式不再重复压缩：省时间且几乎不会变大。 */
    private fun shouldCompressOnPack(name: String): Boolean {
        if (RepackEngine.mustStayStored(name)) return false
        val lower = name.lowercase(Locale.US)
        // AndroidManifest.xml 与 resources.arsc 一样，保持不压缩以便系统直接读取
        if (lower == "androidmanifest.xml") return false
        return NO_COMPRESS_SUFFIXES.none { lower.endsWith(it) }
    }

    private companion object {
        val NO_COMPRESS_SUFFIXES = listOf(
            ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp",
            ".mp3", ".mp4", ".m4a", ".ogg", ".oga", ".wav", ".flac", ".aac",
            ".webm", ".mkv", ".3gp", ".amr", ".zip", ".gz", ".jar", ".apk"
        )
    }
}

// ── 仅签名 ────────────────────────────────────────────────────────────

class ApkSignTool(context: Context) : ApkRepackToolBase(context) {

    override val spec = ToolSpec(
        name = "apk_sign",
        description = "给一个未签名（或已改过）的 APK **重新签名**，输出可安装的包。" +
            "默认用应用内置密钥（首次自动生成并持久复用）；也可用 keystore 参数传入" +
            "自己的密钥 —— 想**覆盖安装**已有应用就必须用该应用原本的签名密钥。",
        category = "逆向",
        layer = "L2",
        destructive = true,
        params = objectSchema {
            string("path", "待签名的 APK 路径")
            string("output", "输出路径；缺省为源文件同目录的 <名字>-signed.apk", required = false)
            string("keystore", "自定义签名密钥（PKCS12/JKS）", required = false)
            string("alias", "keystore 别名", required = false)
            string("password", "keystore 口令", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = requirePath(args) ?: return ToolResult.failure("缺少必填参数 'path'")
        val outputPath = args.str("output") ?: defaultOutputPath(path, "signed")

        return openAndUse(path, ctx) { archive ->
            val tempFiles = mutableListOf<File>()
            try {
                // 已签名的包要先剔除旧签名，否则 apksig 会拒绝（不允许包里已有签名块）
                val existing = ApkSignatureInspector.detectSchemes(archive.file)
                val needsRebuild = existing.any

                var current = if (needsRebuild) {
                    engine.rebuild(archive).also { tempFiles += it }
                } else {
                    archive.file
                }

                val key = resolveSigningKey(args, ctx)
                current = engine.sign(current, key)
                tempFiles += current

                val bytes = current.readBytes()
                DocumentIo.writeBytes(ctx, outputPath, bytes)?.let { return@openAndUse it }

                buildString {
                    append("✅ 签名完成\n\n")
                    append("输出：$outputPath（${describeSize(bytes.size)}）\n")
                    if (existing.any) {
                        append("原有签名（${existing.describe()}）已移除并重新签名\n")
                    }
                    append("\n")
                    append(signingSummary(key, ApkSignatureInspector.detectSchemes(current).describe()))
                }
            } finally {
                engine.cleanUp(*tempFiles.toTypedArray())
            }
        }
    }
}
