package com.example.nativedemo.ui.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nativedemo.data.settings.AppBrand
import com.example.nativedemo.data.settings.BackgroundStyle
import com.example.nativedemo.data.settings.BubbleCorner
import com.example.nativedemo.data.settings.FontScaleOption
import com.example.nativedemo.data.settings.ThemeMode
import com.example.nativedemo.data.settings.UiDensity
import com.example.nativedemo.ui.common.ImageLoadState
import com.example.nativedemo.ui.common.InfoCard
import com.example.nativedemo.ui.common.SectionLabel
import com.example.nativedemo.ui.common.rememberImageState
import com.example.nativedemo.ui.theme.Accent
import com.example.nativedemo.ui.theme.Accent2
import com.example.nativedemo.ui.theme.CardBg
import com.example.nativedemo.ui.theme.Faint
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.LineColor
import com.example.nativedemo.ui.theme.Muted
import com.example.nativedemo.ui.theme.Palette
import com.example.nativedemo.ui.theme.UserBubble
import com.example.nativedemo.ui.theme.color

/**
 * 「界面美化」区域。
 *
 * 与「模型连接」是**互相独立的两块**：配置类改动需要点保存，外观类改动即时生效，
 * 混在一条长列表里既难找、语义也混乱。
 *
 * 这里放"整体性"的外观选项（主题色、深浅、字号、密度、圆角），
 * 更细的逐区域配色与背景图在「自定义背景」子页里。
 */
@Composable
fun AppearanceSection(
    brand: AppBrand,
    mode: ThemeMode,
    fontScale: FontScaleOption,
    density: UiDensity,
    corner: BubbleCorner,
    background: BackgroundStyle,
    overrideCount: Int,
    onBrand: (AppBrand) -> Unit,
    onMode: (ThemeMode) -> Unit,
    onFontScale: (FontScaleOption) -> Unit,
    onDensity: (UiDensity) -> Unit,
    onCorner: (BubbleCorner) -> Unit,
    onOpenBackground: () -> Unit
) {
    InfoCard(title = "界面美化") {

        SectionLabel("主题色")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AppBrand.entries.forEach { item ->
                BrandDot(item, item == brand) { onBrand(item) }
            }
        }

        Spacer(Modifier.height(18.dp))
        SectionLabel("显示模式")
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.entries.forEach { item ->
                ChoiceChip(item.label, item == mode) { onMode(item) }
            }
        }

        Spacer(Modifier.height(18.dp))
        SectionLabel("字号")
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FontScaleOption.entries.forEach { item ->
                ChoiceChip(item.label, item == fontScale) { onFontScale(item) }
            }
        }

        Spacer(Modifier.height(18.dp))
        SectionLabel("界面密度")
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            UiDensity.entries.forEach { item ->
                ChoiceChip(item.label, item == density) { onDensity(item) }
            }
        }

        Spacer(Modifier.height(18.dp))
        SectionLabel("消息气泡圆角")
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BubbleCorner.entries.forEach { item ->
                ChoiceChip(item.label, item == corner) { onCorner(item) }
            }
        }

        Spacer(Modifier.height(20.dp))
        SectionLabel("背景与配色")
        Spacer(Modifier.height(8.dp))
        BackgroundEntry(background, overrideCount, onOpenBackground)

        Spacer(Modifier.height(20.dp))
        SectionLabel("效果预览")
        Spacer(Modifier.height(8.dp))
        AppearancePreview(corner)

        Spacer(Modifier.height(10.dp))
        Text(
            text = "本页改动全部立即生效，不需要点「保存」。",
            color = Faint,
            fontSize = 11.sp
        )
    }
}

/** 进入「自定义背景」子页的入口，顺带显示当前背景缩略图与已改色数。 */
@Composable
private fun BackgroundEntry(
    background: BackgroundStyle,
    overrideCount: Int,
    onClick: () -> Unit
) {
    val subtitle = buildString {
        append(
            when {
                background.enabled && background.smartContrast -> "已设置背景图 · 智能图文适配"
                background.enabled && overrideCount > 0 -> "已设置背景图 · 自定义 $overrideCount 处颜色"
                background.enabled -> "已设置背景图"
                overrideCount > 0 -> "自定义 $overrideCount 处颜色"
                else -> "背景图、模糊度、逐区域配色"
            }
        )
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardBg)
            .border(1.dp, LineColor, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Palette.current.chipBg)
                .border(1.dp, LineColor, RoundedCornerShape(10.dp))
        ) {
            if (background.enabled) {
                // 缩略图：加载失败就留空底色，详情在「自定义背景」页里给出提示
                when (val state = rememberImageState(background.uri, maxEdge = 200)) {
                    is ImageLoadState.Ready -> Image(
                        bitmap = state.bitmap,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    else -> Unit
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Palette.current.accent.copy(alpha = 0.16f))
                )
            }
        }

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text("自定义背景", color = Fg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }

        Text("›", color = Faint, fontSize = 20.sp)
    }
}

@Composable
private fun BrandDot(brand: AppBrand, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(brand.color())
            .border(
                width = if (selected) 3.dp else 1.dp,
                color = if (selected) Fg else LineColor,
                shape = CircleShape
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = brand.label,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(if (selected) Accent.copy(alpha = 0.18f) else CardBg)
            .border(
                width = 1.dp,
                color = if (selected) Accent.copy(alpha = 0.65f) else LineColor,
                shape = RoundedCornerShape(999.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Text(
            text = label,
            color = if (selected) Accent else Muted,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

/** 用当前配色与圆角画一段最小聊天，方便直接判断观感。 */
@Composable
private fun AppearancePreview(corner: BubbleCorner) {
    val radius = corner.radiusDp.dp

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Palette.current.bg)
            .border(1.dp, LineColor, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Box(
                modifier = Modifier
                    .background(UserBubble, RoundedCornerShape(radius))
                    .padding(horizontal = 11.dp, vertical = 8.dp)
            ) {
                Text("看下这个目录里有什么", color = Fg, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(10.dp))

        Text(
            text = "好的，我先列一下。",
            color = Fg,
            fontSize = 12.sp,
            lineHeight = 17.sp
        )

        Spacer(Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).background(Accent2, CircleShape))
            Spacer(Modifier.width(7.dp))
            Text("file_list · 已完成", color = Muted, fontSize = 11.sp)
        }

        Spacer(Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .background(Accent, RoundedCornerShape(999.dp))
                    .padding(horizontal = 13.dp, vertical = 6.dp)
            ) {
                Text("发送", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.width(10.dp))
            Text("品牌色用于按钮、选中态与链接", color = Muted, fontSize = 10.sp)
        }
    }
}
