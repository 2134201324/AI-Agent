package com.example.nativedemo.tools.builtin

import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.int
import com.example.nativedemo.tools.net.SafeHttpFetcher
import com.example.nativedemo.tools.net.SearchEngine
import com.example.nativedemo.tools.net.SerpParser
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import com.example.nativedemo.tools.str
import kotlinx.serialization.json.JsonObject
import java.net.URLEncoder
import java.nio.charset.Charset

/**
 * 联网搜索：先搜、再抓。
 *
 * 与 [WebFetchTool] 的分工是：
 * - 不知道具体网址时 → `web_search` 拿到候选链接；
 * - 已经知道网址、只想要正文 → `web_fetch`。
 *
 * ## 免 Key 是怎么做到的
 * 直接把搜索引擎「网页版结果页」的 HTML 抓回来解析（见 [SerpParser]）。
 * 不依赖任何付费 API，也不要求用户再填一个 Key。代价是解析规则会随对方改版失效，
 * 所以这里做了**多引擎自动回退**：一个引擎拿不到结果就换下一个，
 * 用户完全不用关心背后是谁在干活。
 *
 * ## 隐私
 * 查询词会发往搜索引擎 —— 这是搜索本身的定义，无需额外提示，但值得写在这里，
 * 免得日后有人以为"本地搜索"。用 [SearchEngine.DUCKDUCKGO] 相对隐蔽一些。
 */
class WebSearchTool(
    private val fetcher: SafeHttpFetcher
) : Tool {

    override val spec = ToolSpec(
        name = "web_search",
        description = "联网搜索关键词，返回若干条「标题 + 链接 + 摘要」。用于获取最新信息、" +
            "核实事实、找资料出处。免 API Key，内置多个搜索引擎并自动回退。" +
            "需要网页正文时，拿到链接后再调用 web_fetch。",
        category = "网络",
        layer = "L1",
        params = objectSchema {
            string("query", "搜索关键词。支持搜索引擎语法，如 site:github.com、\"精确短语\"、filetype:pdf")
            string(
                "engine",
                "指定搜索引擎。默认 auto（自动回退），也可固定为 bing / 360 / baidu / duckduckgo",
                required = false,
                enumValues = listOf("auto", "bing", "360", "baidu", "duckduckgo")
            )
            integer("max_results", "返回条数，默认 8，最大 20", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val query = try {
            args.requireStr("query")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }
        val requested = SearchEngine.fromId(args.str("engine"))
        val limit = args.int("max_results", 8).coerceIn(1, 20)

        // 指定了引擎就只试它 —— 用户可能是刻意要用百度/DDG 的特定结果；
        // 静默换成别的引擎会让他困惑"为什么我要的结果没出现"。
        val explicit = args.str("engine")?.trim()?.lowercase()
        val order = when {
            explicit == null || explicit == "auto" -> SearchEngine.DEFAULT_ORDER
            requested != null -> listOf(requested)
            else -> return ToolResult.failure(
                "不支持的 engine：'$explicit'。可选 auto / bing / 360 / baidu / duckduckgo。"
            )
        }

        val failures = mutableListOf<String>()

        for (engine in order) {
            val attempt = tryEngine(engine, query, limit)
            if (attempt.isSuccess) {
                val hits = attempt.getOrThrow()
                if (hits.isNotEmpty()) {
                    return ToolResult.success(render(query, engine, hits, order, failures))
                }
                failures += "${engine.label}：页面取到了但没有解析出结果（可能被反爬拦截）"
            } else {
                failures += "${engine.label}：${attempt.exceptionOrNull()?.message ?: "未知错误"}"
            }
        }

        return ToolResult.failure(
            buildString {
                appendLine("搜索「$query」失败，已尝试 ${order.size} 个引擎：")
                failures.forEach { appendLine("· $it") }
                append("可以改用 web_fetch 直接抓取某个已知网址，或换个更短的关键词再试。")
            }
        )
    }

    private suspend fun tryEngine(
        engine: SearchEngine,
        query: String,
        limit: Int
    ): Result<List<com.example.nativedemo.tools.net.SearchHit>> = runCatching {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = when (engine) {
            SearchEngine.BING -> "https://cn.bing.com/search?q=$encoded&ensearch=0&count=20"
            SearchEngine.SO360 -> "https://www.so.com/s?q=$encoded"
            SearchEngine.BAIDU -> "https://www.baidu.com/s?wd=$encoded&rn=20"
            SearchEngine.DUCKDUCKGO -> "https://html.duckduckgo.com/html/?q=$encoded"
        }

        val result = fetcher.fetch(
            rawUrl = url,
            // 结果页动辄 1~2 MB（百度尤其大），给足上限免得最关键的尾部结果被截断
            maxBytes = 4 * 1024 * 1024,
            headers = mapOf(
                "User-Agent" to MOBILE_UA,
                "Referer" to homeOf(engine),
                "Accept-Language" to "zh-CN,zh;q=0.9,en;q=0.8"
            ),
            // 搜索必须快：连打多个引擎时，单点卡住会拖垮整次调用
            timeoutSeconds = 12
        )

        val charset = SerpParser.detectCharset(result.body, result.contentType)
        val html = String(result.body, Charset.forName(charset))
        SerpParser.parse(engine, html, limit)
    }

    private fun homeOf(engine: SearchEngine): String = when (engine) {
        SearchEngine.BING -> "https://cn.bing.com/"
        SearchEngine.SO360 -> "https://www.so.com/"
        SearchEngine.BAIDU -> "https://www.baidu.com/"
        SearchEngine.DUCKDUCKGO -> "https://duckduckgo.com/"
    }

    private fun render(
        query: String,
        engine: SearchEngine,
        hits: List<com.example.nativedemo.tools.net.SearchHit>,
        order: List<SearchEngine>,
        failures: List<String>
    ): String = buildString {
        appendLine("搜索「$query」· 引擎 ${engine.label} · ${hits.size} 条结果")
        if (failures.isNotEmpty()) {
            appendLine("（${order.first().label} 未能返回结果，已自动回退）")
        }
        appendLine("---")
        hits.forEachIndexed { index, hit ->
            appendLine("${index + 1}. ${hit.title}")
            appendLine("   ${hit.url}")
            if (hit.snippet.isNotBlank()) appendLine("   ${hit.snippet.take(300)}")
        }
        append("提示：摘要可能不全，需要正文请对上面的链接调用 web_fetch。")
    }

    private companion object {
        /** 移动端 UA：桌面 UA 更容易被判定为爬虫，也更容易拿到需要 JS 的页面。 */
        const val MOBILE_UA =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/122.0.0.0 Mobile Safari/537.36"
    }
}
