package com.example.nativedemo.ui.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nativedemo.data.settings.BackgroundStyle
import com.example.nativedemo.data.settings.ColorSlot
import com.example.nativedemo.ui.common.Banner
import com.example.nativedemo.ui.common.BannerLevel
import com.example.nativedemo.ui.common.ImageLoadState
import com.example.nativedemo.ui.common.SectionLabel
import com.example.nativedemo.ui.common.SecondaryButton
import com.example.nativedemo.ui.common.rememberImageState
import com.example.nativedemo.ui.theme.Accent
import com.example.nativedemo.ui.theme.CardBg
import com.example.nativedemo.ui.theme.Faint
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.LineColor
import com.example.nativedemo.ui.theme.Muted
import com.example.nativedemo.ui.theme.Palette
import com.example.nativedemo.ui.theme.Warn
import com.example.nativedemo.ui.theme.brightnessLabel
import com.example.nativedemo.ui.theme.busynessLabel
import com.example.nativedemo.ui.theme.grayColor
import com.example.nativedemo.ui.theme.smartScrim
import com.example.nativedemo.ui.theme.smartTextLevels
import com.example.nativedemo.ui.theme.valueOf

/**
 * 「自定义背景」页。
 *
 * 布局参照常见壁纸类 App：顶部是背景预览（点一下换图），下面是模糊度与
 * 不透明度两条滑块，再下面是**逐区域色值**的两列清单 —— 每个色块点开就是
 * HSV 选择器。
 *
 * 改动全部即时生效：调完直接返回即可，不需要「保存」。
 *
 * 「智能图文适配」是可选开关：开启后按背景图统计自动推导三档文字色，
 * 并在预览里如实画出衬底薄纱 —— 用户在这里就能看到最终效果，
 * 而不是返回聊天页才发现不对劲。
 */
@Composable
fun CustomBackgroundScreen(
    background: BackgroundStyle,
    overrides: Map<ColorSlot, Long>,
    notice: String?,
    onPickImage: () -> Unit,
    onClearImage: () -> Unit,
    onBlurChange: (Float) -> Unit,
    onAlphaChange: (Float) -> Unit,
    onSmartContrastChange: (Boolean) -> Unit,
    onSlotCommit: (ColorSlot, Long?) -> Unit,
    onResetColors: () -> Unit
) {
    var editingSlot by remember { mutableStateOf<ColorSlot?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        // ── 背景图 ──
        Column {
            SectionLabel("背景图片")
            Spacer(Modifier.height(8.dp))
            BackgroundPreview(
                style = background,
                onClick = onPickImage
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    SecondaryButton(
                        text = if (background.enabled) "更换图片" else "从相册选择",
                        onClick = onPickImage
                    )
                }
                if (background.enabled) {
                    Box(modifier = Modifier.weight(1f)) {
                        SecondaryButton(text = "清除背景", onClick = onClearImage)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = "从相册选图，图片会转码后复制到应用私有目录，只在本机使用、不会上传。",
                color = Faint,
                fontSize = 11.sp
            )
            // 导入失败（HEIC 损坏、文件无法读取……）在这里明说，
            // 而不是让用户对着一片空白猜原因
            notice?.let { message ->
                Spacer(Modifier.height(10.dp))
                Banner(text = message, level = BannerLevel.WARN)
            }
        }

        // ── 模糊 / 透明度 ──
        if (background.enabled) {
            Column {
                SliderRow(
                    label = "模糊度",
                    value = background.blur,
                    from = 0f,
                    to = BackgroundStyle.MAX_BLUR,
                    display = "${background.blur.toInt()}"
                ) { onBlurChange(it) }

                Spacer(Modifier.height(4.dp))

                SliderRow(
                    label = "不透明度",
                    value = background.alpha,
                    from = BackgroundStyle.MIN_ALPHA,
                    to = 1f,
                    display = "${(background.alpha * 100).toInt()}%"
                ) { onAlphaChange(it) }

                Spacer(Modifier.height(4.dp))
                Text(
                    text = "看不清内容时，把不透明度调低、模糊度调高，让文字更清楚。",
                    color = Faint,
                    fontSize = 11.sp
                )
            }

            Spacer(Modifier.height(4.dp))

            SmartContrastSection(
                background = background,
                onCheckedChange = onSmartContrastChange
            )
        }

        // ── 逐区域颜色 ──
        Column {
            SectionLabel("颜色")
            Spacer(Modifier.height(4.dp))
            Text(
                text = "点色块单独调整某一处的颜色；未调整的跟随主题。",
                color = Faint,
                fontSize = 11.sp
            )
            Spacer(Modifier.height(12.dp))

            // 智能适配驱动的小字槽位：标出来源，用户一眼能看出哪些是自动的
            val smartSlots = if (background.smartContrast) {
                setOf(ColorSlot.TEXT, ColorSlot.MUTED, ColorSlot.FAINT)
            } else {
                emptySet()
            }

            val left = ColorSlot.entries.filter { it.column == 0 }
            val right = ColorSlot.entries.filter { it.column == 1 }

            Row(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    left.forEach { slot ->
                        ColorSlotCell(
                            slot = slot,
                            isCustom = overrides.containsKey(slot),
                            smart = slot in smartSlots && !overrides.containsKey(slot),
                            onClick = { editingSlot = slot }
                        )
                    }
                }
                Spacer(Modifier.width(14.dp))
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    right.forEach { slot ->
                        ColorSlotCell(
                            slot = slot,
                            isCustom = overrides.containsKey(slot),
                            smart = slot in smartSlots && !overrides.containsKey(slot),
                            onClick = { editingSlot = slot }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            SecondaryButton(text = "恢复默认配色", onClick = onResetColors)
        }

        Spacer(Modifier.height(20.dp))
    }

    // 颜色选择器：覆盖层形式，选完即写入
    editingSlot?.let { slot ->
        val palette = Palette.current
        val slotLabel = slot.label
        ColorPickerDialog(
            title = slotLabel,
            initial = overrides[slot] ?: argbOf(palette.valueOf(slot)),
            allowReset = overrides.containsKey(slot),
            onDismiss = { editingSlot = null },
            onConfirm = { argb ->
                onSlotCommit(slot, argb)
                editingSlot = null
            },
            onReset = {
                onSlotCommit(slot, null)
                editingSlot = null
            }
        )
    }
}

/** Compose 的 `Color.value` 是色彩空间编码，不是 ARGB —— 必须走 toArgb()。 */
private fun argbOf(color: Color): Long = color.toArgb().toLong() and 0xFFFFFFFFL

/**
 * 「智能图文适配」区块：开关 + 分析结论 + 推导色小样。
 *
 * 分析结论直接摊开给用户看（亮度、画面繁华度、衬底厚度、三档文字色），
 * 而不是一个黑盒开关 —— 用户得知道它依据什么、改成什么样了，才敢用。
 */
@Composable
private fun SmartContrastSection(
    background: BackgroundStyle,
    onCheckedChange: (Boolean) -> Unit
) {
    Column {
        SectionLabel("智能图文适配")
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("自动优化文字颜色", color = Fg, fontSize = 14.sp)
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "按背景图的明暗与繁忙度搭配文字色，并加一层衬底薄纱，" +
                        "文字与图片无缝衔接、没有割裂感",
                    color = Muted,
                    fontSize = 11.sp
                )
            }
            Spacer(Modifier.width(10.dp))
            Switch(
                checked = background.smartContrast,
                onCheckedChange = onCheckedChange
            )
        }

        if (background.smartContrast) {
            Spacer(Modifier.height(10.dp))
            val stats = background.stats
            if (stats == null) {
                // 导入后分析失败、或老数据没有缓存：ViewModel 会现场补分析，
                // 这里只展示等待态，不给假结论
                Text("正在分析背景图…", color = Muted, fontSize = 11.sp)
            } else {
                val levels = smartTextLevels(stats)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "亮度${stats.brightnessLabel()} · " +
                            "画面${stats.busynessLabel()} · " +
                            "衬底 ${(levels.scrimAlpha * 100).toInt()}%",
                        color = Muted,
                        fontSize = 11.sp,
                        modifier = Modifier.weight(1f)
                    )
                    SmartSwatch("正文", levels.fg)
                    Spacer(Modifier.width(8.dp))
                    SmartSwatch("次要", levels.muted)
                    Spacer(Modifier.width(8.dp))
                    SmartSwatch("备注", levels.faint)
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        Text(
            text = "在下面手动调过的颜色优先于此功能；开关改动即时生效。",
            color = Faint,
            fontSize = 11.sp
        )
    }
}

/** 智能推导色小样：灰度块 + 档位名，让用户看到实际会用的文字色。 */
@Composable
private fun SmartSwatch(label: String, luminance: Float) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(grayColor(luminance))
                .border(1.dp, LineColor, RoundedCornerShape(6.dp))
        )
        Spacer(Modifier.height(3.dp))
        Text(label, color = Muted, fontSize = 9.sp)
    }
}

/** 顶部背景预览：点一下直接进选图，比先找按钮更顺手。 */
@Composable
private fun BackgroundPreview(style: BackgroundStyle, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1.9f)
            .clip(RoundedCornerShape(14.dp))
            .background(CardBg)
            .border(1.dp, LineColor, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (!style.enabled) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = Muted,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(Modifier.height(8.dp))
                Text("点击选择背景图片", color = Muted, fontSize = 12.sp)
            }
            return@Box
        }

        // 预览要如实地把模糊与透明度表现出来，否则调完返回才发现不是想要的
        val imageState = rememberImageState(style.uri, maxEdge = 1200)
        Box(modifier = Modifier.fillMaxSize()) {
            when (imageState) {
                is ImageLoadState.Ready -> Image(
                    bitmap = imageState.bitmap,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    alpha = style.alpha,
                    modifier = Modifier
                        .fillMaxSize()
                        .blur(style.blur.dp)
                )

                is ImageLoadState.Loading -> Text(
                    text = "加载中…",
                    color = Muted,
                    fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.Center)
                )

                // 解码失败（HEIC 不支持、文件损坏……）：明说，别留一片空白
                is ImageLoadState.Failed -> Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.align(Alignment.Center)
                ) {
                    Text("图片加载失败", color = Warn, fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("点击重新选择一张", color = Muted, fontSize = 11.sp)
                }
            }
            // 衬底：智能适配开启时用推导出的薄纱（与全局背景一致），
            // 否则沿用固定黑纱压住画面，方便预览文字效果
            val scrim = style.effectiveStats?.let { smartScrim(it) }
                ?: Color.Black.copy(alpha = 0.10f)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(scrim)
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(10.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text("点击更换", color = Color.White, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    from: Float,
    to: Float,
    display: String,
    onChange: (Float) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Fg, fontSize = 13.sp, modifier = Modifier.width(66.dp))
        Slider(
            value = value.coerceIn(from, to),
            onValueChange = onChange,
            valueRange = from..to,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = display,
            color = Muted,
            fontSize = 11.sp,
            modifier = Modifier.width(42.dp)
        )
    }
}

/**
 * 一个颜色槽：标签 + 色块 + 十六进制值。
 *
 * 色块下方垫一层深灰，这样全透明或深色的值也能看出边界；
 * 被用户改过的槽位用主题色描边标出来，一眼能看出"哪些动过"；
 * 由智能适配驱动的槽位在标签旁标注「自动」—— 改它就会变成手动覆盖。
 */
@Composable
private fun ColorSlotCell(
    slot: ColorSlot,
    isCustom: Boolean,
    smart: Boolean,
    onClick: () -> Unit
) {
    val palette = Palette.current
    val color = palette.valueOf(slot)
    val argb = argbOf(color)

    Column(modifier = Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = slot.label,
                color = if (isCustom) Fg else Muted,
                fontSize = 11.sp,
                fontWeight = if (isCustom) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1
            )
            if (smart) {
                Spacer(Modifier.width(4.dp))
                Text(
                    text = "自动",
                    color = Accent,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF303030))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(8.dp))
                        .background(color)
                        .border(
                            width = if (isCustom) 2.dp else 1.dp,
                            color = if (isCustom) palette.accent else LineColor,
                            shape = RoundedCornerShape(8.dp)
                        )
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                text = toHexRgba(argb),
                color = Muted,
                fontSize = 10.sp,
                maxLines = 1
            )
        }
    }
}
