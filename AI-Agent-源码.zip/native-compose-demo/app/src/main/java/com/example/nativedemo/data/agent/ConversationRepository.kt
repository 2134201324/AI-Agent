package com.example.nativedemo.data.agent

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File

/**
 * 会话本地存储：每个会话一个 JSON 文件，存放在 `filesDir/conversations/<id>.json`。
 *
 * 选文件而不是数据库的理由：会话数量级很小（几十个、每个几十 KB），
 * 整份读写的代价可忽略，却省掉了 schema 迁移的全部负担。
 */
class ConversationRepository(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val dir: File
        get() = File(context.filesDir, "conversations").also { if (!it.exists()) it.mkdirs() }

    private fun fileFor(id: String) = File(dir, "$id.json")

    suspend fun list(): List<ConversationMeta> = withContext(Dispatchers.IO) {
        dir.listFiles { file -> file.isFile && file.extension == "json" }
            ?.mapNotNull { file ->
                runCatching {
                    val data = json.decodeFromString(ConversationFile.serializer(), file.readText())
                    ConversationMeta(
                        id = data.id,
                        title = data.title.ifBlank { "未命名对话" },
                        updatedAt = data.updatedAt,
                        messageCount = data.llmMessages.size
                    )
                }.getOrNull()
            }
            ?.sortedByDescending { it.updatedAt }
            ?: emptyList()
    }

    suspend fun load(id: String): ConversationFile? = withContext(Dispatchers.IO) {
        val file = fileFor(id)
        if (!file.exists()) return@withContext null
        runCatching {
            json.decodeFromString(ConversationFile.serializer(), file.readText())
        }.getOrNull()
    }

    suspend fun save(data: ConversationFile) = withContext(Dispatchers.IO) {
        runCatching {
            fileFor(data.id).writeText(
                json.encodeToString(ConversationFile.serializer(), data)
            )
        }
        Unit
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        runCatching { fileFor(id).delete() }
        Unit
    }
}
