package com.example.nativedemo.data.settings

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * 模型档案：一个 (服务商地址 + 模型名 + API Key) 的组合，多模型编排的基本单位。
 *
 * 为什么需要「档案」而不是沿用单一的 baseUrl/model/key：
 * 编排要求**主模型与多个子模型可以来自不同服务商、用不同 Key**。
 * 一个 Key 能调哪些模型是 Key 自己的权限范围决定的 —— 所以分配逻辑只认
 * 「用户已经配好的档案」，主模型拿到手的候选清单也是如此，不会凭空指定。
 *
 * API Key 的密文直接存在档案里（[keyCipher]），由 [SecureStore] 按别名加解密。
 * 明文永不落盘、也从不进入这个类。
 */
@Serializable
data class ModelProfile(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val baseUrl: String,
    val model: String,
    /** 该档案允许扮演的角色：仅主模型 / 仅子模型 / 两者皆可。 */
    val role: ProfileRole = ProfileRole.BOTH,
    /** 是否参与编排。关闭后主模型看不到它，也不会被分配到。 */
    val enabled: Boolean = true,
    /** API Key 密文（Base64(IV||Ciphertext)）。为空表示尚未填写 Key。 */
    val keyCipher: String? = null,
    /** 测试连接时探测到的工具调用支持情况；null = 未探测。 */
    val toolsSupported: Boolean? = null,
    /** 是否为网页桥接（免 Key、默认不发 tools）。旧数据无此字段时默认 false。 */
    val bridgeMode: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    val hasKey: Boolean get() = !keyCipher.isNullOrBlank()

    /** 能否作为主模型：开着、有 Key、角色允许。 */
    val canOrchestrate: Boolean get() = enabled && hasKey &&
        (role == ProfileRole.ORCHESTRATOR || role == ProfileRole.BOTH)

    /** 能否作为子模型。 */
    val canSub: Boolean get() = enabled && hasKey &&
        (role == ProfileRole.SUB || role == ProfileRole.BOTH)

    /** 界面上显示的不可用原因（主模型视角），null 表示可作主模型。 */
    fun orchestratorUnavailableReason(): String? = when {
        !enabled -> "已停用"
        !hasKey -> "未填写 API Key"
        role == ProfileRole.SUB -> "角色为仅子模型"
        else -> null
    }

    /** 不可用原因（子模型视角），null 表示可作子模型。 */
    fun subUnavailableReason(): String? = when {
        !enabled -> "已停用"
        !hasKey -> "未填写 API Key"
        role == ProfileRole.ORCHESTRATOR -> "角色为仅主模型"
        else -> null
    }

    companion object {
        /**
         * 旧版单模型配置迁移过来的档案 id。
         * 它的密钥别名就是旧的默认别名（见 [SecureStore.aliasForProfile]），
         * 因此密文可以原样搬过来，不需要重新加密。
         */
        const val LEGACY_DEFAULT_ID = "default"
    }
}

@Serializable
enum class ProfileRole(val label: String) {
    ORCHESTRATOR("仅主模型"),
    SUB("仅子模型"),
    BOTH("两者皆可");

    companion object {
        val default = BOTH
        fun parse(raw: String?): ProfileRole =
            entries.firstOrNull { it.name == raw } ?: default
    }
}

/**
 * 从旧的单模型配置生成默认档案。
 *
 * 升级用户不该丢配置：把原有的 baseUrl/model/Key 原样收编成一个档案，
 * 并默认充当主模型。编排开关默认关闭 —— 老行为完全不变，用户主动开启才启用新链路。
 */
fun migrateLegacyProfiles(
    existingJson: String?,
    legacyBaseUrl: String,
    legacyModel: String,
    legacyKeyCipher: String?
): List<ModelProfile> {
    val decoded = ModelProfileCodec.decodeProfiles(existingJson)
    if (decoded.isNotEmpty()) return decoded
    if (legacyBaseUrl.isBlank()) return emptyList()
    return listOf(
        ModelProfile(
            id = ModelProfile.LEGACY_DEFAULT_ID,
            label = "默认模型",
            baseUrl = legacyBaseUrl,
            model = legacyModel.ifBlank { legacyBaseUrl },
            role = ProfileRole.BOTH,
            enabled = true,
            keyCipher = legacyKeyCipher
        )
    )
}

/** 模型档案清单的持久化编码：整份 JSON 数组（保留用户排列顺序）。 */
object ModelProfileCodec {

    private val json = kotlinx.serialization.json.Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun encodeProfiles(profiles: List<ModelProfile>): String =
        json.encodeToString(ListSerializer, profiles)

    fun decodeProfiles(raw: String?): List<ModelProfile> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            sanitize(json.decodeFromString(ListSerializer, raw))
        } catch (t: Throwable) {
            emptyList()
        }
    }

    /** 入库前净化：去掉空 id、按 id 去重、补空标签。坏数据不该让设置页崩。 */
    private fun sanitize(profiles: List<ModelProfile>): List<ModelProfile> {
        val seen = HashSet<String>()
        return profiles.mapNotNull { profile ->
            if (profile.id.isBlank() || !seen.add(profile.id)) null
            else profile.copy(
                label = profile.label.ifBlank { profile.model.ifBlank { "未命名模型" } },
                baseUrl = profile.baseUrl.trim(),
                model = profile.model.trim()
            )
        }
    }

    private val ListSerializer =
        kotlinx.serialization.builtins.ListSerializer(ModelProfile.serializer())
}
