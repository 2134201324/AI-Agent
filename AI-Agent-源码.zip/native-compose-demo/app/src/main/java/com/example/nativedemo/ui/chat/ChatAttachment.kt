package com.example.nativedemo.ui.chat

import android.net.Uri
import java.util.UUID

/**
 * 待发送的附件。来自 SAF 选择器，因此在当前会话内持有临时读权限。
 */
data class ChatAttachment(
    val id: String = UUID.randomUUID().toString(),
    val uri: Uri,
    val name: String,
    val kind: Kind,
    val sizeBytes: Long = 0L,
    val mimeType: String = ""
) {
    enum class Kind { FILE, IMAGE, DIRECTORY }

    val displaySize: String
        get() = when {
            kind == Kind.DIRECTORY -> "文件夹"
            sizeBytes <= 0L -> ""
            sizeBytes < 1024 -> "$sizeBytes B"
            sizeBytes < 1024 * 1024 -> "${sizeBytes / 1024} KB"
            else -> "${"%.1f".format(sizeBytes / 1024.0 / 1024.0)} MB"
        }
}
