package com.example.nativedemo.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nativedemo.ui.theme.Accent
import com.example.nativedemo.ui.theme.Accent2
import com.example.nativedemo.ui.theme.BannerBg
import com.example.nativedemo.ui.theme.CardBg
import com.example.nativedemo.ui.theme.Danger
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.LineColor
import com.example.nativedemo.ui.theme.Muted
import com.example.nativedemo.ui.theme.Warn

/** 圆角胶囊标签。 */
@Composable
fun Pill(text: String) {
    Box(
        modifier = Modifier
            .background(Accent.copy(alpha = 0.14f), RoundedCornerShape(999.dp))
            .border(1.dp, Accent.copy(alpha = 0.35f), RoundedCornerShape(999.dp))
            .padding(horizontal = 11.dp, vertical = 5.dp)
    ) {
        Text(
            text = text,
            color = Accent,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

/** 卡片容器，带小写字距标题。 */
@Composable
fun InfoCard(
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(16.dp))
            .border(1.dp, LineColor, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Text(
            text = title.uppercase(),
            color = Muted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.1.sp
        )
        Spacer(Modifier.height(10.dp))
        content()
    }
}

/** 单行键值展示。 */
@Composable
fun InfoRow(label: String, value: String, highlight: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(label, color = Muted, fontSize = 13.sp)
        Spacer(Modifier.width(12.dp))
        Text(
            text = value,
            color = if (highlight) Accent2 else Fg,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

/** 主操作按钮。 */
@Composable
fun PrimaryButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().height(48.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Accent,
            disabledContainerColor = Accent.copy(alpha = 0.35f)
        )
    ) {
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** 次级操作按钮。 */
@Composable
fun SecondaryButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().height(44.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(text, color = Fg, fontSize = 14.sp)
    }
}

enum class BannerLevel { INFO, WARN, ERROR }

/** 提示条。level 仅影响配色语义。 */
@Composable
fun Banner(
    text: String,
    level: BannerLevel = BannerLevel.INFO,
    modifier: Modifier = Modifier
) {
    val color = when (level) {
        BannerLevel.INFO -> Accent2
        BannerLevel.WARN -> Warn
        BannerLevel.ERROR -> Danger
    }
    Box(
        modifier = modifier
            .fillMaxWidth()
            // 底色用「提示、tips 背景色」槽位，文字保持语义色（信息/警告/错误）
            .background(BannerBg, RoundedCornerShape(10.dp))
            .border(1.dp, color.copy(alpha = 0.30f), RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Text(text, color = color, fontSize = 13.sp, lineHeight = 18.sp)
    }
}

/** 分组小标题。 */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = Muted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp,
        modifier = modifier
    )
}

/**
 * 折叠内容的「收起」控件，统一样式。
 *
 * 存在的理由：收起入口此前是各卡片自己写的，样式五花八门 —— 最暗的备注色、
 * 11sp、没有任何容器，长消息里滚到底部才看得到，用户根本注意不到，
 * 于是反馈「展开之后就收不回去了」。统一成一个有底色、居中的强调色控件，
 * 让「这里可以收起来」一眼可见，同时保证各处外观一致。
 */
@Composable
fun CollapseChip(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Accent.copy(alpha = 0.12f))
            .border(1.dp, Accent.copy(alpha = 0.28f), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}
