package com.example.nativedemo.data.llm

import com.example.nativedemo.core.AppError
import com.example.nativedemo.core.AppErrorCode

/** LLM 调用相关的分类异常，便于上层决定「重试 / 提示 / 终止」。 */
sealed class LlmException(message: String) : Exception(message) {

    /** 401 / 403：API Key 无效或无权限，不应重试。 */
    class Auth(message: String) : LlmException(message)

    /** 429：限流，可带 Retry-After（秒）。 */
    class RateLimited(message: String, val retryAfterSeconds: Long? = null) : LlmException(message)

    /** 5xx：服务端问题，可重试。 */
    class Server(val status: Int, message: String) : LlmException(message)

    /**
     * 其它 4xx：请求本身有问题，不应重试。
     *
     * [serverRaw] 保留服务端原始错误文本 —— 上层需要据此区分
     * 「服务不支持 tools」与「工具参数格式错误」，两者的处置完全不同。
     */
    class BadRequest(
        val status: Int,
        message: String,
        val serverRaw: String = ""
    ) : LlmException(message)

    class Network(message: String) : LlmException(message)

    class Timeout(message: String) : LlmException(message)

    /** 返回体不符合 OpenAI 协议（解析失败）。 */
    class ProtocolViolation(message: String) : LlmException(message)

    fun toAppError(): AppError {
        // Throwable.message 是可空的，这里统一兜底
        val detail = message ?: "未提供错误详情"
        return when (this) {
            is Auth -> AppError(AppErrorCode.AUTH, detail, hint = "请到设置页检查 API Key 是否正确")
            is RateLimited -> AppError(AppErrorCode.RATE_LIMIT, detail, hint = "请求过于频繁，稍后再试")
            is Server -> AppError(AppErrorCode.SERVER, detail, hint = "服务端异常（HTTP $status），可稍后重试")
            is BadRequest -> AppError(AppErrorCode.PROTOCOL, detail, hint = "请检查模型名与 base URL")
            is Network -> AppError(AppErrorCode.NETWORK, detail, hint = "请检查网络连接")
            is Timeout -> AppError(AppErrorCode.TIMEOUT, detail, hint = "可尝试简化问题后重试")
            is ProtocolViolation -> AppError(AppErrorCode.PROTOCOL, detail)
        }
    }

    val retryable: Boolean
        get() = this is RateLimited || this is Server || this is Network || this is Timeout
}

/**
 * 服务端是否在抱怨 `content` 的**类型**：它只接受字符串，却收到了数组/对象。
 *
 * 这只会由多模态消息（用户发了图片）触发。放在 llm 包而不是 agent 包，是为了
 * 让「构造错误提示的客户端」和「决定自愈策略的引擎」共用同一份关键词表 ——
 * 两处各写一份迟早会分叉。
 *
 * 覆盖三类常见方言：
 * 1. Zod 校验器：`"expected":"string","received":"array"` + `invalid_union`；
 * 2. FastAPI/Pydantic：`Input should be a valid string`；
 * 3. 通用网关：`content must be a string`。
 */
fun looksLikeRichContentRejected(rawServerText: String): Boolean {
    val raw = rawServerText.lowercase()
    if (!raw.contains("content")) return false
    if (raw.contains("received array") ||
        raw.contains("received object") ||
        // "expected string" 与 "string expected" 两种语序都会出现，别只认一种
        raw.contains("expected string") ||
        raw.contains("string expected") ||
        raw.contains("must be a string") ||
        raw.contains("should be a valid string") ||
        raw.contains("string, not") ||
        raw.contains("not an array") ||
        raw.contains("does not support array")
    ) {
        return true
    }
    // 校验器只给错误码、不给自然语言时
    return raw.contains("invalid_type") || raw.contains("invalid_union")
}
