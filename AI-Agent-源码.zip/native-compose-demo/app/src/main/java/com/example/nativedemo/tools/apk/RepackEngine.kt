package com.example.nativedemo.tools.apk

import android.content.Context
import com.android.apksig.ApkSigner
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry

/** 签名用的密钥来源。 */
data class SigningKey(
    val material: KeyMaterial,
    /** 描述这次用的是哪把钥匙，用于提示用户。 */
    val origin: String
)

/**
 * 改包引擎：**重建 ZIP → 签名**。
 *
 * 被三个工具共用（replace / pack / sign），把最容易出错的几件事集中在一处：
 *
 * 1. **剔除旧签名**：重建时必须丢掉 `META-INF` 下的 .SF / .RSA / .DSA / .EC。留着它们不仅没意义
 *    （内容已改，签名早已失效），还会让 apksig 直接拒绝签 —— 它不允许包里已有签名块。
 * 2. **保留压缩方式**：原本 STORED 的继续 STORED。`resources.arsc` 一旦被压缩，
 *    Android 11+ 会拒绝安装。
 * 3. **对齐**：`resources.arsc` 与普通条目 4 字节，`.so` 按 16 KB 页对齐。
 */
class RepackEngine(private val context: Context) {

    /** 应用内置的签名密钥位置（应用私有目录，不会随卸载之外的原因丢失）。 */
    private val defaultKeystore: File get() = File(context.filesDir, "repack-signing.p12")

    /**
     * 取签名密钥。
     *
     * 不给 keystore 时用应用内置的一对，**首次生成后持久保存并复用** —— 这一点很关键：
     * 每次换密钥会导致 Android 认为签名不一致，连自己上一版改的包都没法覆盖安装。
     */
    fun resolveKey(
        customKeystore: File? = null,
        alias: String? = null,
        password: CharArray? = null
    ): SigningKey {
        if (customKeystore != null) {
            val keyAlias = alias?.takeIf { it.isNotBlank() }
                ?: runCatching {
                    java.security.KeyStore.getInstance("PKCS12")
                        .also { it.load(customKeystore.inputStream(), password) }
                        .aliases().toList().firstOrNull()
                }.getOrNull()
                ?: "key0"

            val loaded = SelfSignedCert.load(customKeystore, keyAlias, password ?: CharArray(0))
                ?: throw ResParseException(
                    "无法从提供的 keystore 读取密钥「$keyAlias」。" +
                        "请确认别名与口令正确（PKCS12 与 JKS 都支持）。"
                )
            return SigningKey(loaded, "自定义 keystore（${customKeystore.name}）")
        }

        val material = SelfSignedCert.loadOrCreate(
            file = defaultKeystore,
            alias = DEFAULT_ALIAS,
            password = DEFAULT_PASSWORD,
            subject = "CN=AI Agent Repack, O=AI Agent"
        )
        return SigningKey(material, "应用内置密钥（首次自动生成并复用）")
    }

    /**
     * 按 [replacements] 重建 APK。
     *
     * @param replacements 条目名 → 新内容；条目名不存在时会**新增**该条目
     * @param dropEntries 需要删除的条目名
     * @return 重建后的临时文件（调用方负责删除）
     */
    fun rebuild(
        archive: ApkArchive,
        replacements: Map<String, ByteArray> = emptyMap(),
        dropEntries: Set<String> = emptySet(),
        extraEntries: Map<String, ByteArray> = emptyMap()
    ): File {
        val output = File(workDir(), "rebuilt-${System.currentTimeMillis()}.apk")
        FileOutputStream(output).use { stream ->
            val writer = ApkZipWriter(stream)
            val written = mutableSetOf<String>()

            archive.entries.forEach { entry ->
                if (entry.isDirectory) return@forEach
                val name = entry.name

                // 旧签名必须丢掉，否则新的签名块加不进去
                if (isSignatureFile(name) || name in dropEntries) return@forEach

                // 先卡大小：读入内存是有上限的，静默截断会产出"能装但内容坏了"的包，
                // 那比直接报错危险得多
                if (entry.size > MAX_ENTRY_BYTES) {
                    throw ResParseException(
                        "条目「$name」有 ${entry.size / (1024 * 1024)} MB，" +
                            "超过改包上限 ${MAX_ENTRY_BYTES / (1024 * 1024)} MB。"
                    )
                }

                val data = replacements[name]?.also { written += name }
                    ?: archive.read(name, MAX_ENTRY_BYTES)
                    ?: return@forEach   // 读不出来就跳过，不让单个坏条目毁掉整包

                writer.putEntry(
                    name = name,
                    data = data,
                    // 忠实沿用原条目的压缩方式；但 arsc 与 so 必须不压缩
                    compress = if (mustStayStored(name)) false
                    else entry.method != ZipEntry.STORED,
                    alignment = alignmentFor(name),
                    modifiedTime = entry.time.takeIf { it > 0 } ?: System.currentTimeMillis()
                )
            }

            // 替换目标原本不存在时，作为新条目补进去
            replacements.forEach { (name, data) ->
                if (name !in written) {
                    writer.putEntry(name, data, !mustStayStored(name), alignmentFor(name))
                }
            }
            extraEntries.forEach { (name, data) ->
                if (name !in written) {
                    writer.putEntry(name, data, !mustStayStored(name), alignmentFor(name))
                }
            }

            writer.finish()
        }
        return output
    }

    /** 用 [key] 给 [input] 签名，返回新的临时文件。 */
    fun sign(input: File, key: SigningKey): File {
        val output = File(workDir(), "signed-${System.currentTimeMillis()}.apk")
        val config = ApkSigner.SignerConfig.Builder(
            key.material.alias,
            key.material.privateKey,
            listOf(key.material.certificate)
        ).build()

        ApkSigner.Builder(listOf(config))
            .setInputApk(input)
            .setOutputApk(output)
            // v1 覆盖老系统，v2 覆盖 Android 7+，v3 支持密钥轮换；三个都开最稳
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .build()
            .sign()

        return output
    }

    fun workDir(): File = File(context.cacheDir, "repack").apply { mkdirs() }

    /** 把临时文件清理掉，避免缓存越积越大。 */
    fun cleanUp(vararg files: File?) {
        files.forEach { file -> runCatching { file?.delete() } }
    }

    companion object {
        /** 单个条目允许读进内存的上限。 */
        const val MAX_ENTRY_BYTES = 128 * 1024 * 1024

        const val DEFAULT_ALIAS = "aiagent"
        val DEFAULT_PASSWORD = "aiagent".toCharArray()

        /** APK 的签名文件：META-INF 下的 .SF / .RSA / .DSA / .EC。v2+ 的签名块附着在 ZIP 结构上，重建后自然消失。 */
        fun isSignatureFile(name: String): Boolean {
            if (!name.startsWith("META-INF/")) return false
            val upper = name.uppercase(java.util.Locale.US)
            return upper.endsWith(".SF") || upper.endsWith(".RSA") ||
                upper.endsWith(".DSA") || upper.endsWith(".EC") ||
                upper == "META-INF/MANIFEST.MF"
        }

        /**
         * 这些条目**必须**保持未压缩。
         *
         * `resources.arsc`：Android 直接 mmap 它，压缩后 11+ 会拒绝安装；
         * `.so`：需要按页直接映射，压缩了就无法加载。
         */
        fun mustStayStored(name: String): Boolean =
            name == "resources.arsc" || name.endsWith(".so")

        /** 对齐要求：native 库按 16 KB 页，其余 4 字节。 */
        fun alignmentFor(name: String): Int =
            if (name.endsWith(".so")) ApkZipWriter.NATIVE_LIB_ALIGNMENT
            else ApkZipWriter.DEFAULT_ALIGNMENT
    }
}
