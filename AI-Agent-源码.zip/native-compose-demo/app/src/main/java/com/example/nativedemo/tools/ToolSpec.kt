package com.example.nativedemo.tools

import kotlinx.serialization.json.JsonObject

/**
 * 工具元数据。对应参考实现（computer-use/skills registry.py）里的 ActionSpec：
 * name -> 参数 schema -> handler，并携带分层与分类信息。
 */
data class ToolSpec(
    /** OpenAI function.name，需匹配 [a-zA-Z0-9_-]{1,64} */
    val name: String,
    /** 给模型看的用途说明，直接影响模型是否会正确调用 */
    val description: String,
    /** 参数 JSON Schema，唯一事实来源 */
    val params: JsonObject,
    val category: String = "",
    val layer: String = "L3",
    /** 写操作标记：UI 可据此做二次确认 */
    val destructive: Boolean = false,
    /**
     * 用户从未动过「工具权限」开关时，该工具是否默认启用。
     *
     * 能力面越大越要保守：run_command 能执行任意 shell 命令，必须由用户显式打开，
     * 所以它是 false；其余工具保持 true，老用户无感知。
     */
    val defaultEnabled: Boolean = true,
    /** 需要醒目提醒用户的安全说明（如 run_command），UI 展示在开关旁 */
    val securityNote: String? = null
)
