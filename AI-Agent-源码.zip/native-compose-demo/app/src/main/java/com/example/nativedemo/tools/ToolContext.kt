package com.example.nativedemo.tools

import android.content.ContentResolver
import android.content.Context
import com.example.nativedemo.tools.saf.UriAccessPolicy

/**
 * 工具执行上下文。只暴露必要能力，避免工具直接拿到 Activity 之类的重对象。
 */
data class ToolContext(
    val appContext: Context,
    val uriAccessPolicy: UriAccessPolicy
) {
    val contentResolver: ContentResolver get() = appContext.contentResolver
}
