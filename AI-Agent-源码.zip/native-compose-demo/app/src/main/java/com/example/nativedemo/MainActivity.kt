package com.example.nativedemo

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.nativedemo.data.settings.ThemeMode
import com.example.nativedemo.ui.nav.AppNav
import com.example.nativedemo.ui.theme.AppTheme
import com.example.nativedemo.ui.theme.Bg
import com.example.nativedemo.ui.theme.Palette
import kotlinx.coroutines.runBlocking

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 边到边布局：让 IME（软键盘）通过 imePadding 驱动输入区上移，
        // 而不是由系统整体压缩窗口 —— 这是键盘跟随体验的关键。
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val container = (application as AgentApp).container

        // 首帧前同步读一次外观设置。DataStore 是异步的，如果直接进组合，
        // 启动瞬间会先按默认配色画一帧再跳成用户的配色 —— 视觉上就是「闪一下」。
        val initial = runBlocking { container.settingsRepository.snapshot() }
        Palette.apply(
            brand = initial.brand,
            dark = resolveDark(initial.themeMode),
            overrides = initial.colorOverrides,
            smartStats = initial.background.effectiveStats
        )

        setContent {
            // Android 13+ 通知要运行时授权。没有它，前台服务的通知不会显示，
            // 服务就退化成「看不见的服务」，系统依然可以随手回收进程 ——
            // 那正好抵消了加前台服务的意义，所以必须申请。
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val permissionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) { /* 拒绝也不影响功能，只是看不到进度通知 */ }
                LaunchedEffect(Unit) {
                    val granted = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!granted) {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }

            val settings by container.settingsRepository.settings
                .collectAsStateWithLifecycle(initialValue = initial)

            AppTheme(
                brand = settings.brand,
                mode = settings.themeMode,
                fontScale = settings.fontScale,
                colorOverrides = settings.colorOverrides,
                smartStats = settings.background.effectiveStats
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                    AppNav(container)
                }
            }
        }
    }

    private fun resolveDark(mode: ThemeMode): Boolean = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> {
            val night = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
            night == Configuration.UI_MODE_NIGHT_YES
        }
    }
}
