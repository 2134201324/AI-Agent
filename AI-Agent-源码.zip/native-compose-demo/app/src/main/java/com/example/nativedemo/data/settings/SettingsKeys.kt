package com.example.nativedemo.data.settings

import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey

/**
 * DataStore 键定义。注意：API Key 在此只存「密文」，明文永不落盘。
 */
object SettingsKeys {
    val BASE_URL = stringPreferencesKey("base_url")
    val MODEL = stringPreferencesKey("model")
    val API_KEY_CIPHER = stringPreferencesKey("api_key_cipher")
    val TEMPERATURE = floatPreferencesKey("temperature")
    val SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
    val ENABLED_TOOLS = stringSetPreferencesKey("enabled_tools")
    /**
     * 「用户已经见过」的工具名集合。
     *
     * 用来区分「用户主动关掉的工具」与「本版本新增、用户还没见过的工具」——
     * 前者要尊重用户的关闭决定，后者应当在升级后自动按默认值生效。
     * 见 SettingsRepository.resolveEnabledTools。
     */
    val KNOWN_TOOLS = stringSetPreferencesKey("known_tools")
    /** 已持久化授权的 SAF URI，元素格式 `uri|flags` */
    val AUTHORIZED_URIS = stringSetPreferencesKey("authorized_uris")

    // ── 界面外观 ──
    val APPEARANCE_BRAND = stringPreferencesKey("appearance_brand")
    val APPEARANCE_THEME_MODE = stringPreferencesKey("appearance_theme_mode")
    val APPEARANCE_FONT_SCALE = stringPreferencesKey("appearance_font_scale")
    val APPEARANCE_DENSITY = stringPreferencesKey("appearance_density")
    val APPEARANCE_CORNER = stringPreferencesKey("appearance_corner")
    // 自定义背景图
    val APPEARANCE_BG_URI = stringPreferencesKey("appearance_bg_uri")
    val APPEARANCE_BG_BLUR = floatPreferencesKey("appearance_bg_blur")
    val APPEARANCE_BG_ALPHA = floatPreferencesKey("appearance_bg_alpha")
    /** 「智能图文适配」开关 */
    val APPEARANCE_BG_SMART = booleanPreferencesKey("appearance_bg_smart")
    /** 背景图统计缓存，格式见 [BackdropStatsCodec] */
    val APPEARANCE_BG_STATS = stringPreferencesKey("appearance_bg_stats")
    /** 逐槽自定义颜色，元素格式 `SLOT|0xAARRGGBB` */
    val APPEARANCE_SLOTS = stringSetPreferencesKey("appearance_slots")

    // ── 多模型编排 ──
    /** 模型档案清单，整份 JSON 数组（见 [ModelProfileCodec]） */
    val MODEL_PROFILES = stringPreferencesKey("model_profiles")
    /** 主模型档案 id；为空表示未选择（回退到第一个可作主模型的档案） */
    val ORCHESTRATOR_PROFILE_ID = stringPreferencesKey("orchestrator_profile_id")
    /** 多模型编排总开关。关闭时走单模型链路（旧行为） */
    val ORCHESTRATION_ENABLED = booleanPreferencesKey("orchestration_enabled")
    /**
     * 单模型模式下选用的档案 id。
     * 每个档案自带地址 / 模型 / API Key —— 用户可在多个已绑定的 Key 之间
     * 选择性使用；为空表示用传统的「默认配置」（BASE_URL / MODEL / API_KEY_CIPHER）。
     */
    val ACTIVE_PROFILE_ID = stringPreferencesKey("active_profile_id")

    /**
     * 单次请求的最大输出长度（token）。
     *
     * 0 表示「不发送该参数」，由服务端自行决定。
     * 推理模型的**思考 token 与回答 token 共用这一份预算**，值太小会让
     * 长思考的模型「话说到一半就断」。
     */
    val MAX_OUTPUT_TOKENS = intPreferencesKey("max_output_tokens")

    /**
     * 单次任务的工具调用轮次上限。
     *
     * 逆向工程这类任务天然要几十步，8 轮的旧上限会把活儿掐断在半路。
     */
    val MAX_TOOL_ROUNDS = intPreferencesKey("max_tool_rounds")

    /**
     * 「网页桥接」模式。
     *
     * 打开后：不需要 API Key（桥接转发的是网页登录态），且默认不发送 tools
     * （网页桥接基本不支持 function calling，发了容易被服务端拒绝）。
     * 一键连接会把它自动打开。
     */
    val BRIDGE_MODE = booleanPreferencesKey("bridge_mode")

    // ── REA 远程逆向引擎 ──
    /** REA 网关地址（HTTP MCP 服务），如 https://xxxx.app.workbuddy.host */
    val REA_SERVER_URL = stringPreferencesKey("rea_server_url")
    /** REA 网关访问令牌密文（AES-256-GCM，明文永不落盘） */
    val REA_TOKEN_CIPHER = stringPreferencesKey("rea_token_cipher")
}

object SettingsDefaults {
    const val BASE_URL = "https://api.openai.com/v1"
    const val MODEL = "gpt-4o-mini"
    const val TEMPERATURE = 0.7f

    /**
     * 预置的 REA 网关地址（随应用分发时已知的公网部署）。
     * 只预填地址、不预填令牌 —— 令牌仍是用户侧凭据，需要单独配置。
     */
    const val REA_SERVER_URL = "https://a04ef9054265f6b3d.app.workbuddy.host"

    /** 默认输出上限：8192。4096 对推理模型不够用（思考会吃掉大半预算）。 */
    const val MAX_OUTPUT_TOKENS = 8192

    /**
     * 默认工具轮次上限。
     *
     * 直接引用引擎里的常量而不是再写一遍字面量 —— 两处各写一份，
     * 迟早会出现「改了一处、另一处没跟上」的不一致。
     */
    const val MAX_TOOL_ROUNDS = com.example.nativedemo.data.agent.AgentEngine.DEFAULT_MAX_ROUNDS
    const val SYSTEM_PROMPT =
        "你是一个运行在 Android 手机上的 AI 助手。\n" +
            "你可以调用工具来获取信息或操作用户的设备：\n" +
            "- web_search：联网搜索关键词，返回标题/链接/摘要。不知道具体网址时用它。\n" +
            "- web_fetch：抓取一个已知网址的正文。\n" +
            "- file_read / file_write / file_edit / file_list：读写用户已授权目录中的文件。\n" +
            "- run_command：在本机终端沙盒中执行 shell 命令。\n" +
            "- apk_* 系列：在手机本地分析、解包、改包、签名 APK（纯 Kotlin 解析，dex 也能看）。\n" +
            "- rea_* 系列：把文件上传到服务器上的 REA 逆向引擎（Ghidra 12.1.4 / Apktool），" +
            "做 native 层的深度分析。典型链路：rea_upload 上传文件拿到服务器路径 → rea_open 打开" +
            "（或对 APK 直接用 rea_android_resources / rea_android_package）→ rea_overview 看统计 →" +
            "rea_search_functions / rea_decompile / rea_strings 等深入。rea_run 可调用引擎侧全部" +
            "170 个工具（先用 rea_tools 查名称与参数）。注意 REA 打不开 classes.dex，dex 分析用 apk_*。\n" +
            "- mt_open / mt_script：在 MT 管理器中打开指定文件或目录，或把脚本写到共享存储\n" +
            "  并送到 MT 现场。注意：你只能把界面「送到」MT，到那里之后必须由用户自己操作\n" +
            "  —— 你没有读取屏幕、模拟点击的能力，也不得有。\n" +
            "- cloud_pack：把已授权目录里的网页工程（必须含 index.html）打包成可安装的 Android\n" +
            "  APK。用 file_write 把 HTML/CSS/JS 写好后调它即可，服务器上有完整 Android 工具链\n" +
            "  负责编译与签名，产物会自动下载到本机。用户可在「设置 → 云端打包」里看到这个工程、\n" +
            "  修改后重新构建，或直接安装。\n\n" +
            "原则：\n" +
            "1. 需要外部信息或最新事实时主动调用 web_search，不要凭空猜测；拿到链接后再用 web_fetch 读正文。\n" +
            "2. 边界：你不得操作用户的手机，不得尝试控制、读取或操作其他应用的界面。" +
            "凡是需要「点某个按钮」的步骤，明确告诉用户这一步需要他手动完成，不要绕过。\n" +
            "3. 工具返回失败时，阅读错误信息并尝试修正参数，不要重复同样的调用。\n" +
            "4. 用 file_edit 修改已有文件时，old_text 只给一小段能唯一定位的文字，" +
            "不要把整篇文件内容贴进参数 —— 那样容易超出长度被截断导致调用失败。\n" +
            "5. 涉及写入文件、执行命令、改包之前，先用一句话说明你打算做什么。\n" +
            "6. 分析二进制文件时：手机上快速看结构用 apk_*；要反编译 native 代码、追交叉引用、" +
            "调用图等重活用 rea_* 系列（服务器算力，不要怕慢）。\n" +
            "7. 用简体中文回答，简洁直接。\n" +
            "\n" +
            "【高效完成长任务】\n" +
            "逆向分析这类任务天然要几十步，工具调用轮次是最稀缺的资源，务必省着用：\n" +
            "- **一轮里能并行发起的调用就一起发**：比如同时发起多个 rea_decompile、" +
            "一起读多个文件。它们会在同一轮内全部执行完，只占一轮额度。\n" +
            "- **不要反复试探文件路径**：file_list 一次看清结构即可；file_create 与 file_mkdir " +
            "会自动创建中间目录，不必先探测或逐级建目录。路径以已授权目录名开头。\n" +
            "- **边做边留档**：把已经确认的结论（函数作用、关键地址、调用关系）写进笔记文件，" +
            "这样即使中途停下，成果也不会丢在对话里。\n" +
            "- **别重复已完成的工作**：先看当前会话里已经拿到了什么，只推进还没做的部分。\n" +
            "- 如果一轮里既有必须等待结果的调用，也有独立的调用，把独立的那些一起发出去。"
}
