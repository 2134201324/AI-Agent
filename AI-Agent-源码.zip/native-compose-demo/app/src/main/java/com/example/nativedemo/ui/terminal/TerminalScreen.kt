package com.example.nativedemo.ui.terminal

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.nativedemo.ui.theme.Accent
import com.example.nativedemo.ui.theme.Accent2
import com.example.nativedemo.ui.theme.CardBg
import com.example.nativedemo.ui.theme.Faint
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.LineColor
import com.example.nativedemo.ui.theme.Muted
import com.example.nativedemo.ui.theme.Warn

/**
 * 「命令终端」页 —— App 内的沙盒版 Termux。
 *
 * 布局：顶部是工作目录与共享存储授权，中间是等宽输出区（命令回显 + 输出 +
 * 退出码），底部是输入行与快捷命令。输出区长按可选择复制。
 *
 * ViewModel 由调用方（AppNav）用 [TerminalViewModel.factory] 创建后传入 ——
 * Compose 默认参数拿不到 AppContainer，不像别处可以在函数里现造。
 */
@Composable
fun TerminalScreen(viewModel: TerminalViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    val context = LocalContext.current

    // 新输出到达时自动滚到底部
    LaunchedEffect(state.entries.size) {
        if (state.entries.isNotEmpty()) {
            listState.animateScrollToItem(state.entries.lastIndex)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {

        // ── 顶部：工作目录 + 共享存储 + 沙盒说明 ──
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("工作目录", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = state.cwd,
                    color = Fg,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(10.dp))
            StorageAccessRow()

            Spacer(Modifier.height(10.dp))
            Text(
                text = "每条命令经 /system/bin/sh 独立执行，以应用自身权限运行：" +
                    "可读系统信息、读写应用私有目录；无 root，也不能访问其他应用的数据。",
                color = Faint,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }

        Spacer(Modifier.height(10.dp))

        // ── 输出区 ──
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CardBg)
                .border(1.dp, LineColor, RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            if (state.entries.isEmpty()) {
                item {
                    Text(
                        text = "输入命令开始执行，例如：\n" +
                            "  ls -la\n" +
                            "  getprop ro.product.model\n" +
                            "  df -h\n" +
                            "输入 help 查看完整说明",
                        color = Muted,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 19.sp
                    )
                }
            }
            items(state.entries) { entry -> EntryRow(entry) }
        }

        Spacer(Modifier.height(8.dp))

        // ── 快捷命令 ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QUICK_COMMANDS.forEach { command ->
                QuickChip(text = command) { viewModel.onInputChange(command) }
            }
        }

        Spacer(Modifier.height(8.dp))

        // ── 输入行 ──
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = state.input,
                onValueChange = viewModel::onInputChange,
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(
                        text = if (state.running) "命令执行中…" else "输入命令",
                        color = Muted,
                        fontSize = 13.sp
                    )
                },
                textStyle = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    color = Fg
                ),
                singleLine = false,
                maxLines = 3,
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(Modifier.width(6.dp))

            Column {
                MiniAction(text = "↑", enabled = !state.running) { viewModel.historyUp() }
                Spacer(Modifier.height(4.dp))
                MiniAction(text = "↓", enabled = !state.running) { viewModel.historyDown() }
            }

            Spacer(Modifier.width(6.dp))

            if (state.running) {
                TextButton(onClick = viewModel::stop) {
                    Text("停止", color = Warn, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            } else {
                TextButton(
                    onClick = viewModel::submit,
                    enabled = state.input.isNotBlank()
                ) {
                    Text("执行", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(Modifier.height(4.dp))
        Text(
            text = "↑/↓ 翻阅历史 · 单独一行 cd 切换目录 · clear 清屏",
            color = Faint,
            fontSize = 10.sp
        )
    }
}

/** 共享存储授权状态行；页面每次恢复时重新读系统状态（授权在系统设置里完成）。 */
@Composable
private fun StorageAccessRow() {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasStorageAccess(context)) }

    LifecycleResumeEffect(Unit) {
        granted = hasStorageAccess(context)
        onPauseOrDispose { }
    }

    val settingsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { granted = hasStorageAccess(context) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { granted = hasStorageAccess(context) }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("共享存储", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.width(8.dp))
        Text(
            text = if (granted) "已授权（/sdcard 可直接访问）" else "未授权",
            color = if (granted) Accent2 else Faint,
            fontSize = 11.sp
        )
        Spacer(Modifier.weight(1f))
        if (!granted) {
            TextButton(
                onClick = {
                    requestStorageAccess(context, settingsLauncher, permissionLauncher)
                }
            ) {
                Text("授权", color = Accent, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun EntryRow(entry: TerminalViewModel.Entry) {
    when (entry) {
        is TerminalViewModel.Entry.Command -> Text(
            text = "$ ${entry.text}",
            color = Accent,
            fontSize = 13.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp)
        )

        is TerminalViewModel.Entry.Output -> SelectionContainer {
            Text(
                text = entry.text,
                color = Fg,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 17.sp,
                modifier = Modifier.fillMaxWidth()
            )
        }

        is TerminalViewModel.Entry.Info -> Text(
            text = entry.text,
            color = Muted,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp)
        )

        is TerminalViewModel.Entry.Result -> {
            val (icon, color, label) = when {
                entry.error != null -> Triple("✗", Warn, "启动失败：${entry.error}")
                entry.timedOut -> Triple("⏱", Warn, "已超时停止 · ${entry.durationMs} ms")
                entry.code == 0 -> Triple("✓", Accent2, "退出码 0 · ${entry.durationMs} ms")
                else -> Triple("✗", Warn, "退出码 ${entry.code} · ${entry.durationMs} ms")
            }
            Text(
                text = "$icon $label",
                color = color,
                fontSize = 11.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
            )
        }
    }
}

@Composable
private fun QuickChip(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(CardBg)
            .border(1.dp, LineColor, RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            color = Muted,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun MiniAction(text: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (enabled) CardBg else CardBg.copy(alpha = 0.4f))
            .border(1.dp, LineColor, RoundedCornerShape(8.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 5.dp)
    ) {
        Text(
            text = text,
            color = if (enabled) Fg else Faint,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

/** 点一下填入输入框的常用命令。 */
private val QUICK_COMMANDS = listOf(
    "ls -la",
    "pwd",
    "df -h",
    "ps -A",
    "uname -a",
    "getprop ro.product.model",
    "cat /proc/cpuinfo | head -8",
    "id"
)
