package com.example.nativedemo.tools.builtin

import androidx.documentfile.provider.DocumentFile
import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.bool
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject

/**
 * 列出用户已授权目录的内容。
 *
 * 这是「不必再向用户索要 URI」的关键一环：模型可以先看到有哪些目录、哪些文件，
 * 再用 file_read / file_write 按路径操作。
 */
class FileListTool : Tool {

    override val spec = ToolSpec(
        name = "file_list",
        description = "列出用户已授权目录中的文件与子目录。不传 path 时列出全部已授权目录；" +
            "传 path 时列出指定目录的内容（例如 path=\"code_game\"）。无需用户提供 content:// URI。",
        category = "文件",
        layer = "L1",
        params = objectSchema {
            string("path", "目录名或路径；留空表示列出全部已授权目录", required = false)
            boolean("recursive", "是否递归展开子目录（最多 3 层），默认 false", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult =
        withContext(Dispatchers.IO) {
            val path = args.str("path").orEmpty()
            val recursive = args.bool("recursive", false)
            val maxDepth = if (recursive) 3 else 1

            val roots = ctx.uriAccessPolicy.currentRoots()
            if (roots.isEmpty()) {
                return@withContext ToolResult.failure(
                    "用户尚未授权任何本地目录。请让用户到「设置 → 已授权目录」里添加一个文件夹。"
                )
            }

            val sb = StringBuilder()

            if (path.isBlank()) {
                sb.appendLine("已授权目录（共 ${roots.size} 个）：")
                roots.forEach { root ->
                    sb.appendLine()
                    sb.appendLine("▸ ${root.displayName}${if (root.canWrite) "（可读写）" else "（只读）"}")
                    val tree = DocumentFile.fromTreeUri(ctx.appContext, root.uri)
                    if (tree == null || !tree.isDirectory) {
                        sb.appendLine("  （无法打开，可能授权已失效）")
                    } else {
                        appendChildren(sb, tree, "  ", depth = 1, maxDepth = maxDepth)
                    }
                }
            } else {
                val target = ctx.uriAccessPolicy.resolveDocument(path)
                    ?: return@withContext ToolResult.failure(
                        // 把「现有授权目录名」直接写进错误里：模型据此一次就能改对路径，
                        // 否则它只能再花一轮去 file_list 探，而轮次是长任务最稀缺的资源
                        "未找到「$path」。当前已授权目录：" +
                            roots.joinToString("、") { it.displayName } +
                            "。路径请以其中一个名字开头（例如 " +
                            "${roots.first().displayName}/子目录/文件名）。"
                    )
                if (!target.isDirectory) {
                    return@withContext ToolResult.success(
                        "「$path」是一个文件（${formatSize(target.length())}）。直接用 file_read 读取即可。"
                    )
                }
                sb.appendLine("目录「${target.name ?: path}」的内容：")
                appendChildren(sb, target, "  ", depth = 1, maxDepth = maxDepth)
            }

            ToolResult.success(sb.toString().trimEnd())
        }

    private fun appendChildren(
        sb: StringBuilder,
        dir: DocumentFile,
        indent: String,
        depth: Int,
        maxDepth: Int
    ) {
        val children = runCatching { dir.listFiles() }.getOrDefault(emptyArray())
        if (children.isEmpty()) {
            sb.appendLine("$indent（空）")
            return
        }
        val sorted = children.sortedWith(
            compareByDescending<DocumentFile> { it.isDirectory }.thenBy { it.name ?: "" }
        )
        sorted.take(MAX_ENTRIES).forEach { child ->
            val name = child.name ?: "(未命名)"
            if (child.isDirectory) {
                sb.appendLine("$indent[目录] $name")
                if (depth < maxDepth) {
                    appendChildren(sb, child, "$indent  ", depth + 1, maxDepth)
                }
            } else {
                sb.appendLine("$indent[文件] $name  (${formatSize(child.length())})")
            }
        }
        if (sorted.size > MAX_ENTRIES) {
            sb.appendLine("$indent… 另有 ${sorted.size - MAX_ENTRIES} 项未显示")
        }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes < 0 -> "未知大小"
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> "${"%.1f".format(bytes / 1024.0 / 1024.0)} MB"
    }

    private companion object {
        const val MAX_ENTRIES = 200
    }
}
