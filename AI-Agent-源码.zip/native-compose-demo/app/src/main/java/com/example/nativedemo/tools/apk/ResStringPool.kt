package com.example.nativedemo.tools.apk

/**
 * Android 资源字符串池（`ResStringPool`）。
 *
 * AXML 与 `resources.arsc` 都靠它存字符串：前者是整个 XML 的元素名/属性名池，
 * 后者是资源**键名**与资源**值**池。所以解析它是这两条链路共同的地基。
 *
 * 池有两种编码，由 flags 决定：
 * - UTF-16（默认）：长度是 u16，超过 0x7FFF 时用两个 u16 拼；
 * - UTF-8（`UTF8_FLAG`）：长度是 u8，超过 0x7F 时用两个 u8 拼，且**长度写两次**
 *   （先是 UTF-16 字符数，再是 UTF-8 字节数）—— 只读一次会整体错位。
 */
internal class ResStringPool private constructor(private val strings: List<String>) {

    val size: Int get() = strings.size

    operator fun get(index: Int): String = strings.getOrNull(index).orEmpty()

    fun getOrNull(index: Int): String? = strings.getOrNull(index)

    /** 空串与越界都视为「没有这个名字」，调用方据此改用资源 id 表示。 */
    fun nonEmpty(index: Int): String? = strings.getOrNull(index)?.takeIf { it.isNotEmpty() }

    companion object {

        /** 池内字符串上限。畸形文件可能声称有上亿条，这是防 OOM 的闸。 */
        private const val MAX_STRINGS = 2_000_000

        private const val UTF8_FLAG = 1 shl 8

        /** 单条字符串的长度上限（1 MiB），异常值直接判定为数据损坏。 */
        private const val MAX_STRING_BYTES = 1 shl 20

        fun parse(data: ByteArray, chunkOffset: Int): ResStringPool {
            val cursor = ByteCursor(data, chunkOffset)

            val type = cursor.u16()
            if (type != ChunkType.STRING_POOL) {
                throw ResParseException(
                    "期望字符串池（0x0001），实际是 ${ChunkType.name(type)}"
                )
            }
            val headerSize = cursor.u16()
            cursor.i32() // chunk 总长度，按需可跳过

            var stringCount = cursor.i32()
            cursor.i32() // styleCount：样式跨度，解析 XML 用不到
            val flags = cursor.i32()
            val stringsStart = cursor.i32()
            cursor.i32() // stylesStart

            if (stringCount < 0) throw ResParseException("字符串池数量为负（$stringCount）")
            if (stringCount > MAX_STRINGS) stringCount = MAX_STRINGS

            val isUtf8 = flags and UTF8_FLAG != 0
            val offsetsAt = chunkOffset + headerSize
            val dataAt = chunkOffset + stringsStart

            if (stringCount == 0) return ResStringPool(emptyList())

            val cursorOffsets = ByteCursor(data, offsetsAt)
            val result = ArrayList<String>(minOf(stringCount, 4096))
            for (i in 0 until stringCount) {
                val offset = cursorOffsets.i32()
                // 只有 0xFFFFFFFF（i32 下即负数）才表示「这一项没有字符串」。
                // ⚠️ 注意**不能把 0 也当成空串**：偏移 0 是合法的，指向字符串数据区的
                // 第一个字符串。把 0 当空串会让池里第一项永远读不出来 —— 表现出来就是
                // 资源名、类型名集体变成 `entry_0` / `type1` 这种兜底值。
                if (offset < 0) {
                    result += ""
                    continue
                }
                result += runCatching {
                    readAt(data, dataAt + offset, isUtf8)
                }.getOrDefault("")
            }
            return ResStringPool(result)
        }

        private fun readAt(data: ByteArray, offset: Int, isUtf8: Boolean): String {
            val cursor = ByteCursor(data, offset)
            return if (isUtf8) readUtf8(cursor) else readUtf16(cursor)
        }

        private fun readUtf8(cursor: ByteCursor): String {
            readLength8(cursor)          // UTF-16 字符数：这里用不上，但必须读掉
            val byteLength = readLength8(cursor)
            if (byteLength < 0 || byteLength > MAX_STRING_BYTES) {
                throw ResParseException("字符串长度异常：$byteLength")
            }
            val bytes = cursor.bytes(byteLength)
            // 尾部还有一个 0x00 终止符，交给下一条字符串的偏移定位，不必读
            return String(bytes, Charsets.UTF_8)
        }

        private fun readUtf16(cursor: ByteCursor): String {
            val unitLength = readLength16(cursor)
            if (unitLength < 0 || unitLength * 2 > MAX_STRING_BYTES) {
                throw ResParseException("字符串长度异常：$unitLength")
            }
            val bytes = cursor.bytes(unitLength * 2)
            return String(bytes, Charsets.UTF_16LE)
        }

        /**
         * UTF-8 池的长度编码：最高位为 1 表示长度超过 0x7F，需要再读一个字节。
         * 组合方式是**高 7 位在前**——写成 `(b1 shl 8) or b0` 会得到错误长度。
         */
        private fun readLength8(cursor: ByteCursor): Int {
            val first = cursor.u8()
            return if (first and 0x80 != 0) {
                ((first and 0x7F) shl 8) or cursor.u8()
            } else {
                first
            }
        }

        /** UTF-16 池的长度编码：同理，最高位为 1 时用两个 u16 拼。 */
        private fun readLength16(cursor: ByteCursor): Int {
            val first = cursor.u16()
            return if (first and 0x8000 != 0) {
                ((first and 0x7FFF) shl 16) or cursor.u16()
            } else {
                first
            }
        }
    }
}
