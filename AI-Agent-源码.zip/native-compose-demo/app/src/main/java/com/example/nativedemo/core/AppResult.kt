package com.example.nativedemo.core

/**
 * 轻量结果类型，避免在各层之间抛散乱的异常。
 */
sealed interface AppResult<out T> {
    data class Success<T>(val value: T) : AppResult<T>
    data class Failure(val error: AppError) : AppResult<Nothing>

    fun getOrNull(): T? = (this as? Success)?.value
}

data class AppError(
    val code: AppErrorCode,
    val message: String,
    val cause: Throwable? = null,
    /** 面向用户的下一步建议，可为空 */
    val hint: String? = null
)

enum class AppErrorCode {
    NETWORK,
    AUTH,
    RATE_LIMIT,
    TIMEOUT,
    SERVER,
    PROTOCOL,
    PERMISSION,
    IO,
    CONFIG,
    NOT_IMPLEMENTED,
    UNKNOWN
}

/** 与 Skill 参考实现一致：单点失败转为结构化错误，而不是中断整条链路。 */
inline fun <T> runCatchingApp(block: () -> T): AppResult<T> = try {
    AppResult.Success(block())
} catch (e: kotlinx.coroutines.CancellationException) {
    throw e
} catch (e: Throwable) {
    AppResult.Failure(
        AppError(
            code = AppErrorCode.UNKNOWN,
            message = e.message ?: e::class.java.simpleName,
            cause = e
        )
    )
}
