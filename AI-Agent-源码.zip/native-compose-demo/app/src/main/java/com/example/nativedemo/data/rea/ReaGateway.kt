package com.example.nativedemo.data.rea

import com.example.nativedemo.data.settings.SettingsRepository

/**
 * REA 远程引擎的接入门面。
 *
 * 存在的意义：工具在**调用时**才需要知道服务器地址与令牌（用户可能刚在设置里改过），
 * 而 [com.example.nativedemo.tools.Tool] 是启动时注册的单例。所以每次调用才到这里
 * 取钥匙 —— 配置变更即时生效，不需要重启应用。
 *
 * **为什么存的是"取仓库的方式"而不是仓库实例**：启动时存在一个依赖环 ——
 * 设置仓库要读注册表（拿默认启用集），注册表要拿本门面（注册 rea_* 工具），
 * 本门面要读设置仓库。若这里直接持有实例，注册表构造时读到的是尚未赋值的 null，
 * 启动即崩。改存 lambda 后，这个环被推迟到"工具真正被调用"那一刻解开，
 * 那时容器早已构造完毕。
 */
class ReaGateway(
    private val settingsProvider: () -> SettingsRepository
) {

    /** 取仓库。每次都经 provider —— 容器构造期不会被触发。 */
    private val settingsRepository: SettingsRepository get() = settingsProvider()

    /**
     * 取一个可用的客户端；未配置时返回 null。
     *
     * 令牌解密失败（换机恢复等）同样视为未配置 —— 让用户回设置页重填，
     * 比每次调用都静默失败更直观。
     */
    suspend fun client(): ReaClient? {
        val settings = settingsRepository.snapshot()
        if (settings.reaServerUrl.isBlank()) return null
        val token = settingsRepository.reaToken() ?: return null
        return ReaClient(baseUrl = settings.reaServerUrl, token = token)
    }

    /** 未配置时给模型看的指引 —— 它会转述给用户，所以要说清"去哪配、配什么"。 */
    val missingReason: String
        get() = "REA 逆向引擎尚未配置。请用户到「设置 → REA 逆向引擎」填写服务器地址与访问令牌后重试。"
}
