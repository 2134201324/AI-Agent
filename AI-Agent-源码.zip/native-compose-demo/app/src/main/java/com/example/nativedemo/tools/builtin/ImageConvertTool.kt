package com.example.nativedemo.tools.builtin

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.int
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import com.example.nativedemo.tools.saf.DocumentIo
import com.example.nativedemo.tools.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import java.io.ByteArrayOutputStream
import java.util.Locale

/**
 * 图片缩放与格式转换。
 *
 * ## 为什么改包会需要它
 *
 * 替换 APK 里的图片不是「把文件塞进去」这么简单：新图尺寸或格式不对，轻则显示错乱，
 * 重则资源加载失败。典型约束是 —— 目标图片必须是 **PNG**（因为 aapt 用它做 9-patch
 * 或带透明通道），尺寸要匹配原图，体积还不能暴涨。这个工具就是补上这一环：
 *
 * ```
 * 取图 → image_convert 缩放/转格式 → apk_replace 替换 → apk_sign 签名
 * ```
 *
 * 解码走 `inSampleSize` 预采样：手机拍的图动辄 4000×3000，直接整张解码极易 OOM。
 */
class ImageConvertTool : Tool {

    override val spec = ToolSpec(
        name = "image_convert",
        description = "缩放图片、转换格式（PNG / JPEG / WEBP），用于**准备要替换进 APK 的图片**。" +
            "会保持宽高比，并可只指定最大边。也支持反向读取图片的尺寸与格式（action=info），" +
            "用来确认目标图片该用多大。",
        category = "文件",
        layer = "L1",
        destructive = true,
        params = objectSchema {
            string(
                "action",
                "convert（默认，转换/缩放）或 info（只读取图片信息）",
                required = false,
                enumValues = listOf("convert", "info")
            )
            string("source", "输入图片路径")
            string("output", "输出路径（action=convert 时必填）", required = false)
            integer("max_width", "最大宽度（像素），0 表示不限制", required = false)
            integer("max_height", "最大高度（像素），0 表示不限制", required = false)
            string(
                "format",
                "输出格式：png / jpeg / webp，缺省按输出文件扩展名推断",
                required = false,
                enumValues = listOf("png", "jpeg", "webp")
            )
            integer("quality", "JPEG / WEBP 质量 1-100，默认 90", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val source = try {
            args.requireStr("source")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }
        val action = args.str("action") ?: "convert"

        val bytes = DocumentIo.readBytesOrReason(ctx, source).getOrElse {
            return ToolResult.failure("读取图片失败：${it.message}")
        }

        return withContext(Dispatchers.IO) {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                    return@withContext ToolResult.failure(
                        "「$source」不是可识别的图片格式（支持的类型由系统解码器决定）。"
                    )
                }

                if (action.equals("info", ignoreCase = true)) {
                    return@withContext ToolResult.success(
                        buildString {
                            append("图片信息\n")
                            append("路径：$source\n")
                            append("尺寸：${bounds.outWidth} × ${bounds.outHeight}\n")
                            append("MIME：${bounds.outMimeType ?: "未知"}\n")
                            append("体积：${describeSize(bytes.size)}\n")
                        }
                    )
                }

                val output = args.str("output")
                    ?: return@withContext ToolResult.failure("action=convert 时必须提供 output。")

                val maxWidth = args.int("max_width", 0).coerceAtLeast(0)
                val maxHeight = args.int("max_height", 0).coerceAtLeast(0)

                // 目标尺寸：只缩不放，避免把小图拉糊
                val scale = calculateScale(bounds.outWidth, bounds.outHeight, maxWidth, maxHeight)
                val targetWidth = (bounds.outWidth * scale).toInt().coerceAtLeast(1)
                val targetHeight = (bounds.outHeight * scale).toInt().coerceAtLeast(1)

                // 预采样：先按 2 的幂降采样，避免为大图分配整张位图
                val options = BitmapFactory.Options().apply {
                    inSampleSize = calculateInSampleSize(
                        bounds.outWidth, bounds.outHeight, targetWidth, targetHeight
                    )
                }
                val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
                    ?: return@withContext ToolResult.failure("图片解码失败（可能是超大图或格式不受支持）。")

                val scaled = if (decoded.width != targetWidth || decoded.height != targetHeight) {
                    Bitmap.createScaledBitmap(decoded, targetWidth, targetHeight, true)
                        .also { if (it != decoded) decoded.recycle() }
                } else {
                    decoded
                }

                val format = (args.str("format") ?: inferFormat(output)).lowercase(Locale.US)
                val quality = args.int("quality", 90).coerceIn(1, 100)

                val encoded = ByteArrayOutputStream().use { buffer ->
                    val compressFormat = when (format) {
                        "png" -> Bitmap.CompressFormat.PNG
                        "webp" -> Bitmap.CompressFormat.WEBP
                        else -> Bitmap.CompressFormat.JPEG
                    }
                    scaled.compress(compressFormat, quality, buffer)
                    scaled.recycle()
                    buffer.toByteArray()
                }

                if (encoded.isEmpty()) {
                    return@withContext ToolResult.failure("编码失败：产出了空文件。")
                }

                val problem = DocumentIo.writeBytes(ctx, output, encoded)
                if (problem != null) return@withContext ToolResult.failure(problem)

                ToolResult.success(
                    buildString {
                        append("✅ 图片已转换\n\n")
                        append("原图：${bounds.outWidth} × ${bounds.outHeight}（${describeSize(bytes.size)}）\n")
                        append("输出：$targetWidth × $targetHeight（${format.uppercase(Locale.US)}，${describeSize(encoded.size)}）\n")
                        append("路径：$output\n")
                        if (scale < 1f) {
                            append("\n（按比例缩小到 ${"%.0f".format(scale * 100)}%；只缩不放）")
                        }
                    }
                )
            } catch (e: OutOfMemoryError) {
                ToolResult.failure("图片太大，内存不足。请先指定较小的 max_width / max_height。")
            } catch (e: Throwable) {
                ToolResult.failure("处理失败：${e.message ?: e::class.java.simpleName}")
            }
        }
    }

    /** 仅缩小、不放大：返回 1.0 表示保持原尺寸。 */
    internal fun calculateScale(
        width: Int,
        height: Int,
        maxWidth: Int,
        maxHeight: Int
    ): Float {
        val byWidth = if (maxWidth > 0) maxWidth.toFloat() / width else 1f
        val byHeight = if (maxHeight > 0) maxHeight.toFloat() / height else 1f
        return minOf(byWidth, byHeight, 1f)
    }

    /** 先做 2 的幂降采样，减少后续缩放的内存占用。 */
    internal fun calculateInSampleSize(
        width: Int,
        height: Int,
        targetWidth: Int,
        targetHeight: Int
    ): Int {
        var sample = 1
        var w = width
        var h = height
        while (w / 2 >= targetWidth && h / 2 >= targetHeight) {
            w /= 2
            h /= 2
            sample *= 2
        }
        return sample
    }

    private fun inferFormat(output: String): String {
        val lower = output.lowercase(Locale.US)
        return when {
            lower.endsWith(".png") -> "png"
            lower.endsWith(".webp") -> "webp"
            else -> "jpeg"
        }
    }

    private fun describeSize(bytes: Int): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
        else -> "%.2f MB".format(bytes / (1024.0 * 1024.0))
    }
}
