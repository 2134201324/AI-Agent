package com.example.nativedemo.data.agent

import com.example.nativedemo.core.AppError
import com.example.nativedemo.core.AppErrorCode
import com.example.nativedemo.data.llm.ChatMessage
import com.example.nativedemo.data.llm.ChatRequest
import com.example.nativedemo.data.llm.ChatResponse
import com.example.nativedemo.data.llm.FunctionCall
import com.example.nativedemo.data.llm.FunctionDefinition
import com.example.nativedemo.data.llm.LlmClient
import com.example.nativedemo.data.llm.LlmException
import com.example.nativedemo.data.llm.ToolCall
import com.example.nativedemo.data.llm.ToolDefinition
import com.example.nativedemo.data.llm.asTextOrNull
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject

/** 主模型提交拆分计划的工具名。 */
internal const val DELEGATE_TOOL = "delegate_tasks"

/** 子 AI 之间唯一的横向通道：一次性简单问答。 */
internal const val ASK_TOOL = "ask_agent"

/**
 * 运行时用的模型档案：比持久化的 [com.example.nativedemo.data.settings.ModelProfile]
 * 多一份明文 Key（从 Keystore 解出来后直接传，不落盘）。
 */
data class ResolvedProfile(
    val id: String,
    val label: String,
    val baseUrl: String,
    val model: String,
    val apiKey: String,
    /** 测试连接探测到的工具调用支持情况；null = 未探测（先按支持尝试，失败再降级） */
    val toolsSupported: Boolean? = null
)

/** 子 AI 的行为边界。全部由用户侧的编排设置决定，子 AI 无权修改。 */
data class SubAgentRules(
    /** 单个子任务里最多向其他子 AI 提问几次。 */
    val maxAsksPerTask: Int = 3,
    /** 单个子任务的最大工具往返轮次（ask_agent 也算一轮）。 */
    val maxRounds: Int = 4,
    /** 单个子任务的墙钟上限，超时即判失败，不拖死整轮编排。 */
    /**
     * 单个子任务的硬超时。
     *
     * 原为 150 秒 —— 对推理模型（思考阶段动辄几分钟）太短，长思考的子任务
     * 会被中途掐掉，用户看到的就是「已中断」。放宽到 10 分钟，同时保留上限
     * 以免某个子任务永久挂住整轮编排。
     */
    val timeoutMs: Long = 600_000L
)

/** 主模型拆出来的一项子任务。 */
data class PlannedTask(
    val id: String,
    val title: String,
    val instruction: String,
    /** 主模型建议的执行者（档案 id 或名字）；仅供参考，引擎会校验。 */
    val suggestedAgent: String? = null
)

/** 分配结果。[note] 非空表示发生了回退，需要告知用户。 */
data class Assignment(
    val profile: ResolvedProfile,
    val note: String? = null
)

/** 一项子任务的执行结果。 */
data class TaskResult(
    val task: PlannedTask,
    val agentLabel: String,
    val output: String,
    val ok: Boolean
)

/** 规划阶段的两种结局：主模型觉得自己直接答更好，或给出了拆分计划。 */
sealed interface PlanningResult {
    data class Direct(val text: String) : PlanningResult
    data class Split(val tasks: List<PlannedTask>) : PlanningResult
}

sealed interface OrchestratorEvent {
    /** 阶段提示（UI 里是小横幅）。 */
    data class Phase(val text: String) : OrchestratorEvent
    /** 计划就绪：UI 据此渲染任务卡列表。 */
    data class PlanReady(val tasks: List<PlannedTask>) : OrchestratorEvent
    data class TaskStarted(val task: PlannedTask, val agentLabel: String) : OrchestratorEvent
    data class TaskFinished(
        val taskId: String,
        val ok: Boolean,
        val preview: String,
        val output: String = ""
    ) : OrchestratorEvent
    /** 子 AI 向另一个子 AI 发问（UI 里是一条工具卡）。 */
    data class AskIssued(
        val askId: String,
        val fromLabel: String,
        val toLabel: String,
        val question: String
    ) : OrchestratorEvent
    data class AskAnswered(
        val askId: String,
        val fromLabel: String,
        val toLabel: String,
        val answer: String
    ) : OrchestratorEvent
    data class AssistantDelta(val text: String) : OrchestratorEvent
    data class AssistantText(val text: String) : OrchestratorEvent
    data class Failed(val error: AppError) : OrchestratorEvent
    data object Done : OrchestratorEvent
}

/**
 * 多模型编排引擎。
 *
 * 链路：**主模型拆任务 → 多个子模型并行生成 → 主模型整合纠错**。
 *
 * 权限模型（对应用户的要求）：
 * - 用户最高权限：主模型只是「建议」把任务给谁，最终分配由引擎按用户设置
 *   （档案启停、角色、Key 可用性）校验，不可用的建议会被回退并明说；
 * - 子 AI 相互隔离：每个子任务只拿到自己的指令，看不到对话历史与其他任务的产出；
 * - 子 AI 不能互相干预：唯一的横向通道是 [ASK_TOOL] —— 一次性的简单问答，
 *   有次数上限、不递归（被问方不带工具）、只读不影响任何状态。
 *
 * 与单模型模式的关系：编排只把「最终答复」写回会话历史，中间过程不进 LLM
 * 历史（否则下一轮对话会被子任务的噪音撑爆，也混淆了谁在说话）。
 */
class Orchestrator(
    private val llmClient: LlmClient,
    private val conversation: ConversationStore
) {

    companion object {
        private val json = Json {
            ignoreUnknownKeys = true
            isLenient = true
        }
    }

    suspend fun run(
        userContent: JsonElement,
        orchestrator: ResolvedProfile,
        subs: List<ResolvedProfile>,
        rules: SubAgentRules = SubAgentRules(),
        /** 单次请求输出上限；null = 不发送该参数。与单模型链路共用同一设置。 */
        maxOutputTokens: Int? = DEFAULT_MAX_OUTPUT_TOKENS,
        emit: (OrchestratorEvent) -> Unit
    ) {
        // 编排会把同一份内容分别发给主模型与多个子模型。图片 base64 因此会被复制
        // N 份（体积、延迟、失败率都成倍放大），而只接受字符串 content 的服务端
        // 更会直接 400 —— 所以在编排链路统一按**纯文本**传递，并明确告知用户。
        val richInput = userContent is JsonArray || userContent is JsonObject
        val safeContent: JsonElement =
            if (richInput) JsonPrimitive(userContent.toPlainText().orEmpty()) else userContent

        if (richInput) {
            emit(
                OrchestratorEvent.Phase(
                    "📎 多模型编排会把内容分发给多个模型，图片已转为文字占位；" +
                        "需要模型真正看到图片时，请先关闭编排再发送。"
                )
            )
        }

        // 用户消息先进历史：哪怕后面失败，这一轮也不白说
        conversation.add(ChatMessage(role = "user", content = safeContent))

        // ── 1. 主模型规划 ──
        emit(OrchestratorEvent.Phase("🧠 主模型（${orchestrator.label}）正在分析需求、拆分任务…"))
        val plan = try {
            requestPlan(safeContent, orchestrator, subs, maxOutputTokens)
        } catch (e: CancellationException) {
            throw e
        } catch (e: LlmException) {
            emit(OrchestratorEvent.Failed(e.toAppError()))
            return
        } catch (e: Throwable) {
            emit(
                OrchestratorEvent.Failed(
                    AppError(AppErrorCode.UNKNOWN, e.message ?: "规划阶段发生未知错误", e)
                )
            )
            return
        }

        // 主模型认为自己直接答更好：它的文本就是最终答复
        if (plan is PlanningResult.Direct) {
            val text = plan.text
            conversation.add(ChatMessage.assistant(text))
            emit(OrchestratorEvent.AssistantText(text))
            emit(OrchestratorEvent.Done)
            return
        }

        val tasks = (plan as PlanningResult.Split).tasks
        emit(OrchestratorEvent.PlanReady(tasks))

        // ── 2. 子模型并行执行 ──
        emit(
            OrchestratorEvent.Phase(
                "⚙️ ${tasks.size} 个子任务并行执行中" +
                    if (subs.size > 1) "（${subs.size} 个子模型待命）" else ""
            )
        )
        val results = coroutineScope {
            tasks.mapIndexed { index, task ->
                async {
                    runOneTask(task, index, subs, rules, maxOutputTokens, emit)
                }
            }.awaitAll()
        }

        // ── 3. 主模型整合 ──
        emit(OrchestratorEvent.Phase("🧩 主模型正在整合结果、修正错误…"))
        val finalText = try {
            requestIntegration(safeContent, orchestrator, results, maxOutputTokens) { piece ->
                emit(OrchestratorEvent.AssistantDelta(piece))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: LlmException) {
            emit(OrchestratorEvent.Failed(e.toAppError()))
            return
        } catch (e: Throwable) {
            emit(
                OrchestratorEvent.Failed(
                    AppError(AppErrorCode.UNKNOWN, e.message ?: "整合阶段发生未知错误", e)
                )
            )
            return
        }

        conversation.add(ChatMessage.assistant(finalText))
        emit(OrchestratorEvent.AssistantText(finalText))
        emit(OrchestratorEvent.Done)
    }

    // ── 规划 ──────────────────────────────────────────────────────────

    private suspend fun requestPlan(
        userContent: JsonElement,
        orchestrator: ResolvedProfile,
        subs: List<ResolvedProfile>,
        maxOutputTokens: Int?
    ): PlanningResult {
        // toolsSupported 明确为 false 时直接走 JSON 降级，省一次必然失败的请求
        var useTools = orchestrator.toolsSupported != false
        val userMessage = ChatMessage(role = "user", content = userContent)

        while (true) {
            val tools = if (useTools) listOf(delegateTasksTool()) else null
            val response = try {
                llmClient.chat(
                    baseUrl = orchestrator.baseUrl,
                    apiKey = orchestrator.apiKey,
                    request = ChatRequest(
                        model = orchestrator.model,
                        messages = listOf(
                            ChatMessage.system(
                                buildPlanningSystemPrompt(orchestrator, subs, jsonFallback = !useTools)
                            ),
                            userMessage
                        ),
                        tools = tools,
                        toolChoice = if (tools != null) "auto" else null,
                        temperature = 0.3,
                        maxTokens = maxOutputTokens,
                        stream = false
                    )
                )
            } catch (e: LlmException.BadRequest) {
                // 主模型服务不接受 tools：同一次规划内降级为重试（JSON 输出），不整轮失败
                if (useTools && isToolsUnsupportedError(e)) {
                    useTools = false
                    continue
                }
                throw e
            }

            val message = response.firstMessage
                ?: return PlanningResult.Direct("（主模型未返回任何内容）")

            val delegateCall = message.toolCalls
                ?.firstOrNull { it.function.name == DELEGATE_TOOL }
            if (delegateCall != null) {
                val tasks = parsePlanFromToolArguments(delegateCall.function.arguments)
                if (tasks.isNotEmpty()) return PlanningResult.Split(tasks)
            }

            // 没调工具 / 参数解析失败：试一次 JSON 降级，再不行就把它的文本当直接回答
            val text = message.textContent.orEmpty()
            val fromJson = parsePlanFromText(text)
            if (fromJson.isNotEmpty()) return PlanningResult.Split(fromJson)
            return PlanningResult.Direct(text.ifBlank { "（主模型返回了空内容）" })
        }
    }

    // ── 子任务执行 ─────────────────────────────────────────────────────

    private suspend fun runOneTask(
        task: PlannedTask,
        taskIndex: Int,
        subs: List<ResolvedProfile>,
        rules: SubAgentRules,
        maxOutputTokens: Int?,
        emit: (OrchestratorEvent) -> Unit
    ): TaskResult {
        val assignment = resolveAssignment(task.suggestedAgent, subs, taskIndex)
        if (assignment == null) {
            val message = "（没有可用的子模型：请检查档案是否停用、是否缺少 API Key）"
            emit(OrchestratorEvent.TaskStarted(task, "未分配"))
            emit(OrchestratorEvent.TaskFinished(task.id, false, message, message))
            return TaskResult(task, "未分配", message, ok = false)
        }
        emit(OrchestratorEvent.TaskStarted(task, assignment.profile.label))
        assignment.note?.let { emit(OrchestratorEvent.Phase("↩ ${it}")) }

        val output = try {
            withTimeoutOrNull(rules.timeoutMs) {
                runSubTask(task, assignment.profile, subs, rules, maxOutputTokens, emit)
            } ?: "（该子任务在 ${rules.timeoutMs / 1000} 秒内未完成，已跳过并继续整合）"
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            "（子任务异常：${e.message ?: e::class.java.simpleName}）"
        }

        val ok = !output.startsWith("（")
        val preview = output.replace(Regex("\\s+"), " ").trim().take(160)
        emit(OrchestratorEvent.TaskFinished(task.id, ok, preview, output))
        return TaskResult(task, assignment.profile.label, output, ok)
    }

    /**
     * 单个子任务的简化循环。
     *
     * 刻意不做流式、不走完整 [AgentEngine]：子 AI 是「生成者」不是「操作者」，
     * 它唯一的动作通道是 [ASK_TOOL]，一轮非流式请求 + 有限的往返足够，
     * 也更容易把「不能干预其他 AI」的边界收死。
     */
    private suspend fun runSubTask(
        task: PlannedTask,
        agent: ResolvedProfile,
        peers: List<ResolvedProfile>,
        rules: SubAgentRules,
        maxOutputTokens: Int?,
        emit: (OrchestratorEvent) -> Unit
    ): String {
        val messages = mutableListOf(
            ChatMessage.system(buildSubSystemPrompt(agent, peers, rules)),
            ChatMessage.user(task.instruction)
        )
        var asksLeft = rules.maxAsksPerTask
        var askCounter = 0

        var round = 0
        while (round < rules.maxRounds) {
            round++
            val tools = if (peers.size > 1 && asksLeft > 0) listOf(askAgentTool()) else null
            val response = llmClient.chat(
                baseUrl = agent.baseUrl,
                apiKey = agent.apiKey,
                request = ChatRequest(
                    model = agent.model,
                    messages = messages,
                    tools = tools,
                    toolChoice = if (tools != null) "auto" else null,
                    temperature = 0.4,
                    maxTokens = maxOutputTokens,
                    stream = false
                )
            )
            val message = response.firstMessage
                ?: return "（子模型未返回任何内容）"

            val calls = message.toolCalls.orEmpty()
            if (calls.isEmpty()) {
                return message.textContent.orEmpty()
                    .ifBlank { "（子模型返回了空内容）" }
            }

            // 带 tool_calls 的 assistant 消息必须原样回灌，否则下一轮协议不成立
            messages.add(
                ChatMessage(role = "assistant", content = message.content, toolCalls = calls)
            )

            for (call in calls) {
                when (call.function.name) {
                    ASK_TOOL -> {
                        if (asksLeft <= 0) {
                            messages.add(
                                ChatMessage.tool(
                                    call.id,
                                    "（询问次数已用完，请基于已有信息继续完成任务）"
                                )
                            )
                            continue
                        }
                        asksLeft--
                        val askId = "${task.id}-ask${++askCounter}"

                        val args = parseArgs(call.function.arguments)
                        val target = args["agent"]?.let { raw ->
                            resolveAskTarget(raw, peers, selfId = agent.id)
                        }
                        val question = args["question"].orEmpty()
                            .ifBlank { "（未提供具体问题）" }

                        emit(
                            OrchestratorEvent.AskIssued(
                                askId = askId,
                                fromLabel = agent.label,
                                toLabel = target?.label ?: args["agent"].orEmpty(),
                                question = question
                            )
                        )

                        val answer = if (target == null) {
                            "（询问失败：找不到可用的子 AI「${args["agent"].orEmpty()}」。" +
                                "可选项：${peers.filter { it.id != agent.id }
                                    .joinToString { it.label }.ifEmpty { "无" }}）"
                        } else {
                            runCatching { askOnce(target, question, maxOutputTokens) }
                                .getOrElse { e ->
                                    "（询问失败：${e.message ?: e::class.java.simpleName}）"
                                }
                        }

                        emit(
                            OrchestratorEvent.AskAnswered(
                                askId = askId,
                                fromLabel = agent.label,
                                toLabel = target?.label ?: args["agent"].orEmpty(),
                                answer = answer
                            )
                        )
                        messages.add(ChatMessage.tool(call.id, answer))
                    }

                    else -> messages.add(
                        ChatMessage.tool(
                            call.id,
                            "（不允许：子 AI 只能调用 ask_agent 向其他子 AI 提简单问题，" +
                                "不能调用其他工具，也不能干预其他 AI）"
                        )
                    )
                }
            }
        }
        return "（子模型在 ${rules.maxRounds} 轮内未给出最终成果）"
    }

    /**
     * 一次性问答：被询问方**不带任何工具**，因此不可能递归、不可能指挥第三方。
     * 这就是「子 AI 之间只能简单询问」的物理保证。
     */
    private suspend fun askOnce(
        target: ResolvedProfile,
        question: String,
        maxOutputTokens: Int?
    ): String {
        val response = llmClient.chat(
            baseUrl = target.baseUrl,
            apiKey = target.apiKey,
            request = ChatRequest(
                model = target.model,
                messages = listOf(
                    ChatMessage.system(
                        "你是另一个协作团队里的专业子 AI。现在有同伴向你提一个简单问题，" +
                            "请用一两句话直接给出答案。不要反问、不要展开、不要调用任何工具。"
                    ),
                    ChatMessage.user(question)
                ),
                temperature = 0.3,
                maxTokens = maxOutputTokens,
                stream = false
            )
        )
        return response.firstMessage?.textContent?.trim()
            .orEmpty()
            .ifBlank { "（对方没有返回内容）" }
    }

    // ── 整合 ──────────────────────────────────────────────────────────

    private suspend fun requestIntegration(
        userContent: JsonElement,
        orchestrator: ResolvedProfile,
        results: List<TaskResult>,
        maxOutputTokens: Int?,
        onTextDelta: suspend (String) -> Unit
    ): String {
        val response: ChatResponse = llmClient.chatStream(
            baseUrl = orchestrator.baseUrl,
            apiKey = orchestrator.apiKey,
            request = ChatRequest(
                model = orchestrator.model,
                messages = buildIntegrationMessages(userContent, results),
                temperature = 0.4,
                maxTokens = maxOutputTokens,
                stream = true
            ),
            onTextDelta = onTextDelta
        )
        return response.firstMessage?.textContent.orEmpty()
            .ifBlank { "（主模型未返回整合结果）" }
    }

    // ── 工具与提示词 ───────────────────────────────────────────────────

    private fun delegateTasksTool(): ToolDefinition = ToolDefinition(
        function = FunctionDefinition(
            name = DELEGATE_TOOL,
            description = "把用户需求拆成多个可并行的子任务，交给子 AI 执行。" +
                "仅当需求确实可拆分（2 个以上相对独立的子任务）时调用；" +
                "需求单一或需要强上下文连贯时不要调用，直接回答用户。",
            parameters = buildJsonObject {
                put("type", "object")
                putJsonObject("properties") {
                    putJsonObject("tasks") {
                        put("type", "array")
                        put("description", "子任务清单，按依赖无关的并行任务组织")
                        putJsonObject("items") {
                            put("type", "object")
                            putJsonObject("properties") {
                                putJsonObject("id") {
                                    put("type", "string")
                                    put("description", "子任务短 id，如 t1/t2")
                                }
                                putJsonObject("title") {
                                    put("type", "string")
                                    put("description", "一句话标题，界面展示用")
                                }
                                putJsonObject("instruction") {
                                    put("type", "string")
                                    put(
                                        "description",
                                        "给子 AI 的完整指令。子 AI 看不到对话历史，" +
                                            "指令必须自包含：背景、目标、输出格式、约束都要写清"
                                    )
                                }
                                putJsonObject("assignTo") {
                                    put("type", "string")
                                    put(
                                        "description",
                                        "建议的执行者：子 AI 的 id（优先）或名字。可留空由系统分配"
                                    )
                                }
                            }
                            putJsonArray("required") {
                                add(JsonPrimitive("title"))
                                add(JsonPrimitive("instruction"))
                            }
                        }
                    }
                }
                putJsonArray("required") { add(JsonPrimitive("tasks")) }
            }
        )
    )

    private fun askAgentTool(): ToolDefinition = ToolDefinition(
        function = FunctionDefinition(
            name = ASK_TOOL,
            description = "向另一个子 AI 提一个简单问题并获得简短回答。只能询问，" +
                "不能指挥或修改对方；次数有限，谨慎使用。",
            parameters = buildJsonObject {
                put("type", "object")
                putJsonObject("properties") {
                    putJsonObject("agent") {
                        put("type", "string")
                        put("description", "对方子 AI 的 id（优先）或名字")
                    }
                    putJsonObject("question") {
                        put("type", "string")
                        put("description", "一个具体、简单的问题")
                    }
                }
                putJsonArray("required") {
                    add(JsonPrimitive("agent"))
                    add(JsonPrimitive("question"))
                }
            }
        )
    )

    private fun parseArgs(raw: String): Map<String, String> {
        if (raw.isBlank()) return emptyMap()
        return try {
            val obj = json.parseToJsonElement(raw).jsonObject
            obj.mapValues { (_, value) ->
                (value as? JsonPrimitive)?.contentOrNull.orEmpty()
            }
        } catch (t: Throwable) {
            emptyMap()
        }
    }
}

// ── 纯函数：计划解析、分配、提示词构造（可单测）─────────────────────────

private val planJson = Json { ignoreUnknownKeys = true; isLenient = true }

/**
 * 解析 delegate_tasks 的工具参数。
 *
 * 模型生成的 JSON 不能全信：缺 id 自动补、缺 title 用指令截断、
 * 没有 instruction 的任务直接丢弃（空指令跑不出任何东西）。
 */
internal fun parsePlanFromToolArguments(arguments: String): List<PlannedTask> {
    if (arguments.isBlank()) return emptyList()
    return try {
        val root = planJson.parseToJsonElement(arguments).jsonObject
        extractTasks(root)
    } catch (t: Throwable) {
        emptyList()
    }
}

/**
 * JSON 降级路径：主模型服务不支持工具时，要求它输出 ```json 围栏代码块。
 * 找不到围栏就退而找第一个 `{` 开始的 JSON 对象。
 */
internal fun parsePlanFromText(text: String): List<PlannedTask> {
    if (text.isBlank()) return emptyList()
    val fenced = Regex("```(?:json)?\\s*([\\s\\S]*?)```", RegexOption.IGNORE_CASE)
        .find(text)?.groupValues?.get(1)
    val candidate = fenced ?: extractFirstJsonObject(text) ?: return emptyList()
    return try {
        extractTasks(planJson.parseToJsonElement(candidate).jsonObject)
    } catch (t: Throwable) {
        emptyList()
    }
}

/**
 * 从一段文本里抠出第一个**配平**的 JSON 对象。
 *
 * 不能简单地 `parseToJsonElement(text.substring(indexOf('{')))` —— 模型经常在
 * JSON 后面接着解释文字，整串解析会直接失败。这里按花括号深度扫描（字符串与
 * 转义感知，`{"a":"}"}` 这种不会误判），只取第一个完整对象。
 */
internal fun extractFirstJsonObject(text: String): String? {
    val start = text.indexOf('{')
    if (start < 0) return null
    var depth = 0
    var inString = false
    var escaped = false
    for (i in start until text.length) {
        val c = text[i]
        when {
            escaped -> escaped = false
            inString && c == '\\' -> escaped = true
            inString && c == '"' -> inString = false
            !inString && c == '"' -> inString = true
            !inString && c == '{' -> depth++
            !inString && c == '}' -> {
                depth--
                if (depth == 0) return text.substring(start, i + 1)
            }
        }
    }
    return null
}

private fun extractTasks(root: JsonObject): List<PlannedTask> {
    val array = root["tasks"] as? JsonArray ?: return emptyList()
    return array.mapIndexedNotNull { index, element ->
        val obj = element as? JsonObject ?: return@mapIndexedNotNull null
        val instruction = obj.string("instruction").trim()
        if (instruction.isEmpty()) return@mapIndexedNotNull null
        PlannedTask(
            id = obj.string("id").trim().ifEmpty { "t${index + 1}" },
            title = obj.string("title").trim()
                .ifEmpty { instruction.take(24).ifEmpty { "子任务 ${index + 1}" } },
            instruction = instruction,
            suggestedAgent = obj.string("assignTo").trim().ifEmpty { null }
        )
    }
}

private fun JsonObject.string(key: String): String =
    (this[key] as? JsonPrimitive)?.contentOrNull.orEmpty()

/**
 * 把「主模型的分配建议」落实成具体档案。
 *
 * 用户权限高于模型建议：
 * - 建议为空 → 在可用子模型里轮询，天然均衡负载；
 * - 建议给出但不可用（停用 / 缺 Key / 角色不对 / 不存在）→ 回退到第一个可用者，
 *   并带回退说明，让用户看见「模型想给谁、实际给了谁」。
 */
internal fun resolveAssignment(
    suggested: String?,
    subs: List<ResolvedProfile>,
    taskIndex: Int = 0
): Assignment? {
    if (subs.isEmpty()) return null
    val fallback = subs[taskIndex % subs.size]

    if (suggested.isNullOrBlank()) {
        return Assignment(fallback)
    }

    val matched = subs.firstOrNull { it.id == suggested }
        ?: subs.firstOrNull { it.label.equals(suggested, ignoreCase = true) }
        ?: subs.firstOrNull {
            it.label.contains(suggested, ignoreCase = true) ||
                suggested.contains(it.label, ignoreCase = true)
        }
        ?: return Assignment(
            profile = fallback,
            note = "主模型建议的「$suggested」不在可用子模型之列，已回退给「${fallback.label}」"
        )

    return Assignment(matched)
}

/**
 * 解析 ask_agent 的目标：不能是自己（否则成自问自答的无限循环），
 * 匹配规则与任务分配一致（id 优先，其次名字）。
 */
internal fun resolveAskTarget(
    raw: String,
    peers: List<ResolvedProfile>,
    selfId: String
): ResolvedProfile? {
    if (raw.isBlank()) return null
    val candidates = peers.filter { it.id != selfId }
    return candidates.firstOrNull { it.id == raw }
        ?: candidates.firstOrNull { it.label.equals(raw, ignoreCase = true) }
        ?: candidates.firstOrNull {
            it.label.contains(raw, ignoreCase = true) || raw.contains(it.label, ignoreCase = true)
        }
}

/** 规划阶段的系统提示。[jsonFallback] 为 true 时要求输出 JSON 代码块而不是调工具。 */
internal fun buildPlanningSystemPrompt(
    orchestrator: ResolvedProfile,
    subs: List<ResolvedProfile>,
    jsonFallback: Boolean
): String = buildString {
    append("你是主 AI（编排者），负责理解用户需求，并指挥多个子 AI 协作完成。\n\n")
    append("工作流程：\n")
    append("1. 评估需求能否拆成 2 个以上相对独立、可并行的子任务；\n")
    if (jsonFallback) {
        append("2. 能拆分 → 输出一个 ```json 代码块，内容为 " +
            "{\"tasks\":[{\"id\":\"t1\",\"title\":\"…\",\"instruction\":\"…\",\"assignTo\":\"…\"}]}；\n")
        append("3. 不能拆分（需求单一或需要强上下文连贯）→ 直接回答用户，不要输出 JSON；\n")
    } else {
        append("2. 能拆分 → 调用 $DELEGATE_TOOL 提交计划；\n")
        append("3. 不能拆分（需求单一或需要强上下文连贯）→ 直接回答用户，不要调用工具；\n")
    }
    append("4. 子任务完成后你会收到全部结果，届时整合成最终答复。\n\n")

    append("可用子 AI（用户配置，你只能使用这些）：\n")
    subs.forEach { sub ->
        append("- id=${sub.id}｜名字=${sub.label}｜模型=${sub.model}\n")
    }
    append("\n分配规则：\n")
    append("- assignTo 填子 AI 的 id（优先）或名字；留空则由系统均衡分配；\n")
    append("- 你的分配只是建议：被用户停用、缺 Key 或角色不符的会被系统回退；\n")
    append("- 子 AI 之间不能互相干预，只能通过简单问答互相询问；\n")
    append("- 指令必须自包含：子 AI 看不到你和用户的对话历史。")
}

/** 子 AI 的系统提示：写清职责与边界（不能干预其他 AI、询问有上限）。 */
internal fun buildSubSystemPrompt(
    agent: ResolvedProfile,
    peers: List<ResolvedProfile>,
    rules: SubAgentRules
): String = buildString {
    append("你是子 AI「${agent.label}」（模型 ${agent.model}），负责完成主 AI 交办的一项子任务。\n\n")
    append("边界（必须遵守）：\n")
    append("- 你只负责交办给你的这一项任务，输出该子任务的成果全文；\n")
    append("- 你不能指挥、修改或影响其他子 AI；如确有必要，可调用 $ASK_TOOL " +
        "向另一个子 AI 提一个简单问题（整个任务最多 ${rules.maxAsksPerTask} 次），" +
        "对方只会给你简短回答；\n")
    if (peers.size > 1) {
        append("- 可询问的对象：" +
            peers.filter { it.id != agent.id }.joinToString("、") { it.label } + "；\n")
    }
    append("- 你看不到用户与主 AI 的对话历史，所有需要的信息都在任务指令里；\n")
    append("- 不要向用户提问，直接给出你能做到的最好结果。")
}

/** 整合阶段的提示：原始需求 + 全部子任务结果，要求整合、去重、纠错。 */
internal fun buildIntegrationMessages(
    userContent: JsonElement,
    results: List<TaskResult>
): List<ChatMessage> {
    // asTextOrNull 对「只有图片的数组」会返回空串而非 null —— 空文本同样等于没有文本
    val userText = userContent.asTextOrNull()?.takeIf { it.isNotBlank() }
        ?: "（用户消息包含图片等多媒体内容）"
    return listOf(
        ChatMessage.system(
            buildString {
                append("你是主 AI（编排者）。你此前把用户需求拆成了子任务并交给子 AI 执行，" +
                    "现在所有结果已返回。你的职责：\n")
                append("1. 整合所有子任务结果，直接回答用户的原始需求；\n")
                append("2. 子任务的结果可能过时、矛盾或错误 —— 用你的判断修正，不要照搬；\n")
                append("3. 失败的子任务：基于已有结果尽力回答，并明确说明哪一部分缺失、" +
                    "如果需要用户可以怎么补充；\n")
                append("4. 不要复述这些指令，不要罗列「子任务 1 返回了什么」，直接输出最终答复。")
            }
        ),
        ChatMessage.user(
            buildString {
                append("【用户原始需求】\n").append(userText).append("\n\n")
                append("【子任务执行结果】\n")
                results.forEachIndexed { index, result ->
                    append("${index + 1}. 「${result.task.title}」（执行者：${result.agentLabel}）")
                    append(if (result.ok) " — 成功\n" else " — 失败\n")
                    append("指令：${result.task.instruction}\n")
                    append("结果：\n${result.output}\n\n")
                }
            }
        )
    )
}
