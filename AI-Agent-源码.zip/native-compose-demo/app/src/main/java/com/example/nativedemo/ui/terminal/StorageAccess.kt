package com.example.nativedemo.ui.terminal

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.core.content.ContextCompat

/**
 * 共享存储（/sdcard）访问状态与授权入口。
 *
 * 为什么需要单独授权：Android 11+ 的分区存储让应用默认碰不到 /sdcard，
 * 终端的 `ls /sdcard` 会直接 permission denied。两条路：
 * - API 30+：跳系统设置开「所有文件访问」（MANAGE_EXTERNAL_STORAGE）
 * - API 24-29：传统运行时权限 READ/WRITE_EXTERNAL_STORAGE
 *
 * 注意这是**可选增强**：不授权也不影响终端使用应用私有目录与系统信息命令。
 */
fun hasStorageAccess(context: Context): Boolean =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        @Suppress("DEPRECATION")
        val read = ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
        @Suppress("DEPRECATION")
        val write = ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
        read && write
    }

/**
 * 发起授权。系统设置页不带回结果，调用方应在页面恢复时重新调用
 * [hasStorageAccess] 刷新状态。
 */
fun requestStorageAccess(
    context: Context,
    settingsLauncher: ManagedActivityResultLauncher<Intent, *>,
    permissionLauncher: ManagedActivityResultLauncher<Array<String>, *>
) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        val appSpecific = Intent(
            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )
        val fallback = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
        // 部分定制 ROM 没有本应用专属页，退回总列表页
        if (appSpecific.resolveActivity(context.packageManager) != null) {
            settingsLauncher.launch(appSpecific)
        } else {
            settingsLauncher.launch(fallback)
        }
    } else {
        @Suppress("DEPRECATION")
        permissionLauncher.launch(
            arrayOf(
                android.Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        )
    }
}
