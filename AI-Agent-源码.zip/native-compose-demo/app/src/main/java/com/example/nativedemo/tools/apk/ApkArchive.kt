package com.example.nativedemo.tools.apk

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/**
 * 一个已打开的 APK 容器。
 *
 * ## 为什么要先落成临时文件
 *
 * SAF 给出的 `content://` 只能顺序读，而分析 APK 需要**反复随机访问**：
 * 读 manifest、按需读第 2 个 dex、抽取某个 so、检测签名块 —— 每次都从头拉一遍
 * 明显不可行。所以先整包复制到应用私有缓存，再用 [ZipFile] 打开。
 *
 * 缓存按「URI + 大小 + 修改时间」命名：同一个文件重复分析时直接复用，
 * 换了文件则自动重建，不会读到旧内容。
 *
 * ## 不做全量解压
 *
 * APK 内条目按需读取 —— 一个 100 MB 的包不会因为「分析」就被完整展开。
 */
class ApkArchive private constructor(
    private val zip: ZipFile,
    val file: File,
    /** 原始 URI，用于提示信息与缓存键。 */
    val sourceUri: String
) : Closeable {

    val entries: List<ZipEntry> get() = zip.entries().toList()

    val totalBytes: Long get() = file.length()

    /** 所有条目的解压后总大小。 */
    val uncompressedBytes: Long
        get() = entries.sumOf { if (it.size > 0) it.size else 0L }

    fun sizeOf(name: String): Long = zip.getEntry(name)?.size ?: -1L

    fun exists(name: String): Boolean = zip.getEntry(name) != null

    fun openStream(name: String): InputStream? =
        zip.getEntry(name)?.let { zip.getInputStream(it) }

    /**
     * 读取某个条目的字节。
     *
     * [limit] 是硬上限：`classes.dex` 动辄十几 MB，而畸形条目可能声称几十 GB ——
     * 超限时截断并让调用方知道，比 OOM 崩掉好。
     */
    fun read(name: String, limit: Int = MAX_ENTRY_BYTES): ByteArray? {
        val entry = zip.getEntry(name) ?: return null
        return zip.getInputStream(entry).use { input ->
            readLimited(input, limit)
        }
    }

    /** 按后缀/前缀匹配条目名。 */
    fun namesMatching(predicate: (String) -> Boolean): List<String> =
        entries.map { it.name }.filter(predicate)

    override fun close() {
        runCatching { zip.close() }
    }

    companion object {

        /** 单个条目的读取上限（64 MiB）。 */
        const val MAX_ENTRY_BYTES = 64 * 1024 * 1024

        /** 缓存里最多保留几个 APK；超出时按最久未使用淘汰。 */
        private const val MAX_CACHED_APKS = 3

        suspend fun open(context: Context, uri: Uri): ApkArchive = withContext(Dispatchers.IO) {
            val cacheDir = File(context.cacheDir, "apk-inspect").apply { mkdirs() }

            val doc = runCatching { DocumentFile.fromSingleUri(context, uri) }.getOrNull()
            val length = doc?.length() ?: 0L
            val modified = doc?.lastModified() ?: 0L
            val key = "%s-%d-%d".format(
                uri.toString().hashCode().toUInt().toString(16),
                length,
                modified
            )
            val target = File(cacheDir, "$key.apk")

            if (!target.exists() || target.length() == 0L) {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    target.outputStream().use { out -> input.copyTo(out, bufferSize = 64 * 1024) }
                } ?: throw ResParseException("无法打开该文件（可能已被删除或未授权）")
            }

            pruneCache(cacheDir, keep = target)
            target.setLastModified(System.currentTimeMillis())

            ApkArchive(
                zip = ZipFile(target),
                file = target,
                sourceUri = uri.toString()
            )
        }

        private fun pruneCache(cacheDir: File, keep: File) {
            val all = cacheDir.listFiles()?.filter { it.extension == "apk" } ?: return
            if (all.size <= MAX_CACHED_APKS) return
            all.filter { it.absolutePath != keep.absolutePath }
                .sortedByDescending { it.lastModified() }
                .drop(MAX_CACHED_APKS - 1)
                .forEach { runCatching { it.delete() } }
        }

        internal fun readLimited(input: InputStream, limit: Int): ByteArray {
            val out = java.io.ByteArrayOutputStream(minOf(limit, 1 shl 20))
            val buffer = ByteArray(64 * 1024)
            var total = 0
            while (true) {
                val read = input.read(buffer)
                if (read == -1) break
                if (total + read >= limit) {
                    out.write(buffer, 0, limit - total)
                    break
                }
                out.write(buffer, 0, read)
                total += read
            }
            return out.toByteArray()
        }
    }
}
