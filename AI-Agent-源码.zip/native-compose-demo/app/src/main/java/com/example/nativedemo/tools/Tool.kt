package com.example.nativedemo.tools

import kotlinx.serialization.json.JsonObject

/**
 * 一个可被 Agent 调用的能力。
 *
 * 新增能力只需实现本接口并在 [ToolRegistry] 注册，无需改动 Agent 循环 —— 这就是
 * 「可插拔 skill」的落点。
 */
interface Tool {
    val spec: ToolSpec
    suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult
}
