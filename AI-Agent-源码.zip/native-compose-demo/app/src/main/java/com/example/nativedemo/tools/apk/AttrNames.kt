package com.example.nativedemo.tools.apk

/**
 * `android:` 属性的资源 id → 属性名。
 *
 * ## 为什么需要反查
 *
 * 打包后的 AXML 里，`android:name`、`android:versionCode` 这类系统属性**不存名字**：
 * 名字位置被资源化了，只留一个数字 id（如 `versionCode` = `0x0101021b`）。
 * 不做反查，解出来的 XML 会长这样：
 *
 * ```xml
 * <manifest 0x0101021b="1" 0x0101021c="1.8.7">
 * ```
 *
 * 完全没法读，更没法让模型分析。
 *
 * ## 两条来源
 *
 * 1. **反射 `android.R.attr`** —— 在真机/模拟器上最完整也最准确，因为那就是
 *    系统自己的属性表；
 * 2. **内置常用表** —— 反射失败时（例如 JVM 单元测试环境）的兜底，只覆盖分析
 *    APK 时最常打交道的那些属性。
 */
object AttrNames {

    private val reflective: Map<Int, String> by lazy { loadFromAndroidFramework() }

    /** 表里查不到时的占位写法，便于人工拿去 AOSP 查。 */
    fun unknown(id: Int): String = "0x${id.toString(16).padStart(8, '0')}"

    /** 返回不带 `android:` 前缀的属性名；查不到返回 null。 */
    fun name(id: Int): String? = reflective[id] ?: BUILTIN[id]

    private fun loadFromAndroidFramework(): Map<Int, String> = runCatching {
        // android.R.attr 是公开 API，反射读它的常量值不涉及隐藏接口
        val fields = Class.forName("android.R\$attr").fields
        val map = HashMap<Int, String>(fields.size)
        fields.forEach { field ->
            runCatching { map[field.getInt(null)] = field.name }
        }
        map
    }.getOrDefault(emptyMap())

    /**
     * 常用属性兜底表。
     *
     * 刻意只收录「分析 APK 一定会看」的那些（版本、组件、权限、uri 匹配等），
     * 不追求完整 —— 真机上反射给出的表比这里全得多。
     */
    private val BUILTIN: Map<Int, String> = mapOf(
        // ── application / manifest 元信息 ──
        0x01010000 to "theme",
        0x01010001 to "label",
        0x01010002 to "icon",
        0x01010003 to "name",
        0x0101000b to "sharedUserId",
        0x0101000c to "hasCode",
        0x0101000e to "enabled",
        0x0101000f to "debuggable",
        0x01010020 to "description",
        0x0101020c to "minSdkVersion",
        0x0101021b to "versionCode",
        0x0101021c to "versionName",
        0x01010270 to "targetSdkVersion",
        0x01010271 to "maxSdkVersion",
        0x01010280 to "allowBackup",
        0x0101026c to "hardwareAccelerated",
        0x01010281 to "supportsRtl",
        0x010102b7 to "installLocation",
        0x0101028e to "required",
        0x0101035a to "largeHeap",
        0x010103f9 to "banner",
        0x010104ea to "extractNativeLibs",
        0x010104ec to "usesCleartextTraffic",
        0x01010527 to "networkSecurityConfig",
        0x0101052c to "roundIcon",
        0x01010607 to "requestLegacyExternalStorage",

        // ── 组件 ──
        0x01010010 to "exported",
        0x01010011 to "process",
        0x01010012 to "taskAffinity",
        0x01010018 to "authorities",
        0x0101001b to "grantUriPermissions",
        0x0101001c to "priority",
        0x0101001d to "launchMode",
        0x0101001e to "screenOrientation",
        0x0101001f to "configChanges",
        0x01010021 to "targetPackage",
        0x01010022 to "targetActivity",
        0x01010023 to "isDefault",
        0x01010024 to "value",
        0x01010025 to "resource",
        0x01010026 to "mimeType",
        0x0101022d to "allowTaskReparenting",
        0x0101022e to "alwaysRetainTaskState",
        0x01010232 to "noHistory",

        // ── 权限 ──
        0x01010006 to "permission",
        0x01010007 to "readPermission",
        0x01010008 to "writePermission",
        0x01010009 to "protectionLevel",
        0x0101000a to "permissionGroup",
        0x0101000d to "persistent",

        // ── intent-filter / data ──
        0x01010027 to "scheme",
        0x01010028 to "host",
        0x01010029 to "port",
        0x0101002a to "path",
        0x0101002b to "pathPrefix",
        0x0101002c to "pathPattern",
        0x0101002d to "pathAdvancedPattern",
        0x01010030 to "action",
        0x01010031 to "category",
        0x01010032 to "data",
        0x01010033 to "autoVerify",
        0x0101020a to "autoVerify",

        // ── meta-data / uses 相关 ──
        0x01010034 to "targetSdkVersionPlaceholder",
        0x010102de to "glEsVersion",
        0x010102e0 to "requiredFeature",
        0x01010572 to "usesPermissionFlags"
    )
}
