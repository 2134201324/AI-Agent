package com.example.nativedemo.data.agent

import com.example.nativedemo.core.AppError
import com.example.nativedemo.core.AppErrorCode
import com.example.nativedemo.data.llm.ChatMessage
import com.example.nativedemo.data.llm.ChatRequest
import com.example.nativedemo.data.llm.LlmClient
import com.example.nativedemo.data.llm.LlmException
import com.example.nativedemo.data.llm.ToolCall
import com.example.nativedemo.data.llm.looksLikeRichContentRejected
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolRegistry
import com.example.nativedemo.tools.ToolResult
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

data class AgentConfig(
    val baseUrl: String,
    val apiKey: String,
    val model: String,
    val temperature: Float,
    val systemPrompt: String,
    val enabledTools: Set<String> = emptySet(),
    /**
     * 单次请求的输出上限（含推理模型的思考 token）。
     *
     * null = 不发送该参数，由服务端决定（部分服务商对上限有硬性要求，
     * 显式传过大的值会被 400 拒绝，此时引擎会自动去掉该参数重试一次）。
     */
    val maxOutputTokens: Int? = DEFAULT_MAX_OUTPUT_TOKENS,
    /**
     * 单次任务允许的工具调用轮次。
     *
     * 一轮 = 一次「模型请求 → 执行它要的所有工具」。逆向分析这类任务天然要
     * 几十步（上传 → 打开 → 总览 → 搜函数 → 反编译 → 追交叉引用 → 逐个函数…），
     * 原先写死 8 轮的结果就是「活儿干到一半被掐断」，用户看到
     * 「已达到最大工具调用轮次」。所以做成可配置，并把默认值放宽到 30。
     */
    val maxToolRounds: Int = AgentEngine.DEFAULT_MAX_ROUNDS
)

/**
 * Agent 核心循环：请求 → 解析 → 执行工具 → 回灌 → 再请求，直到模型不再调用工具。
 *
 * 关键设计：
 * - 单个工具失败**不中断**整轮，而是转成结构化错误回灌，让模型自行修正
 * - 工具参数是模型生成的字符串，可能非法，必须容错
 * - 设最大轮次，避免模型陷入工具死循环烧 token
 */
/**
 * 默认输出上限。
 *
 * 原先是 4096。但推理模型（deepseek-reasoner、GLM/Qwen 的思考模式等）
 * **思考 token 与回答 token 共用这一份预算** —— 思考强度一大，思考还没结束
 * 预算就耗尽了，用户看到的就是「说到一半突然停住」，也就是所谓「中断」。
 * 提到 8192 显著减少这种截断，同时仍低于多数服务商的硬上限。
 */
const val DEFAULT_MAX_OUTPUT_TOKENS = 8192

/** 工具轮次预算的判定结果。 */
internal sealed interface RoundBudgetDecision {
    /** 还在额度内，继续跑。 */
    data object Proceed : RoundBudgetDecision

    /** 额度用尽但允许延长，[extensions] 是延长后的次数，[newLimit] 是新的总上限。 */
    data class Extend(val extensions: Int, val newLimit: Int) : RoundBudgetDecision

    /** 延长次数已用尽，必须把控制权交回用户。 */
    data class Exhausted(val totalRounds: Int) : RoundBudgetDecision
}

/**
 * 判断第 [round] 轮（从 1 开始计数）是否还在工具调用预算内。
 *
 * 独立成纯函数是为了能直接单测：这段逻辑决定了「一次任务最多能做多少步」，
 * 算错的表现是任务被莫名其妙掐断，而在真机上复现要跑几十轮工具调用。
 */
internal fun decideRoundBudget(
    round: Int,
    budget: Int,
    extensions: Int
): RoundBudgetDecision {
    val safeBudget = budget.coerceAtLeast(1)
    val limit = safeBudget * (1 + extensions)
    if (round <= limit) return RoundBudgetDecision.Proceed
    if (extensions < AgentEngine.MAX_ROUND_EXTENSIONS) {
        val next = extensions + 1
        return RoundBudgetDecision.Extend(next, safeBudget * (1 + next))
    }
    return RoundBudgetDecision.Exhausted(safeBudget * (1 + AgentEngine.MAX_ROUND_EXTENSIONS))
}

class AgentEngine(
    private val llmClient: LlmClient,
    private val registry: ToolRegistry,
    private val conversation: ConversationStore
) {

    companion object {
        /**
         * 默认工具轮次上限。
         *
         * 原先是 8。但 8 轮对「程序逆向」这类任务远远不够：上传目标 → 打开 →
         * 整体总览 → 搜函数 → 反编译 → 追调用关系 → 逐个函数细看，随便就是几十步。
         * 结果是活儿干到一半被掐断，用户只能重来。
         */
        const val DEFAULT_MAX_ROUNDS = 30

        /** 额度用尽但任务仍在推进时，自动延长的次数（每次再给一整份额度）。 */
        const val MAX_ROUND_EXTENSIONS = 2

        /** 设置在界面上允许的最大值，防止填个天文数字把 token 烧光。 */
        const val MAX_ROUNDS_CEILING = 200

        /** 兼容旧调用点。 */
        const val MAX_TOKENS = DEFAULT_MAX_OUTPUT_TOKENS

        /** 因长度上限 / 断流自动续写的最大次数。 */
        const val MAX_CONTINUATIONS = 2

        /** `finish_reason` 取该值，表示输出被上限截断（而非自然结束）。 */
        const val FINISH_LENGTH = "length"

        /**
         * 续写指令。要点是「接着写、别重头写」——否则模型会把已经输出的内容
         * 再输出一遍，用户看到重复段落。
         */
        const val CONTINUE_PROMPT = "上一条回复被中途截断了。请**紧接着**从中断处继续，" +
            "不要重复已经写过的内容，也不要重新开头；如果已经写完，只回复「已完成」。"
    }

    sealed interface Event {
        /** 流式文本增量：UI 收到后应立即追加显示，实现「逐字输出」。 */
        data class AssistantDelta(val text: String) : Event

        /** 推理模型的思考增量：与正式回答分开显示，不写入对话历史。 */
        data class ThinkingDelta(val text: String) : Event

        /**
         * 过程提示（自动续写、自动降级等）。
         *
         * 单独一类事件而不是塞进助手正文：正文正在流式输出时，
         * 「整段文本」事件只会用来收尾，提示文字会被吞掉。
         */
        data class Notice(val text: String) : Event
        data class AssistantText(val text: String) : Event
        data class ToolStarted(val callId: String, val name: String, val arguments: String) : Event
        data class ToolFinished(val callId: String, val ok: Boolean, val preview: String) : Event

        /**
         * 失败。[resumable] 为 true 表示「只是暂时停下来，接着做就能继续」——
         * 比如工具轮次额度用尽。界面据此给出「继续」按钮，而不是让用户自己组织语言。
         */
        data class Failed(val error: AppError, val resumable: Boolean = false) : Event

        data object Done : Event
    }

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    suspend fun run(
        userContent: JsonElement,
        config: AgentConfig,
        toolContext: ToolContext,
        emit: (Event) -> Unit
    ) {
        conversation.add(ChatMessage(role = "user", content = userContent))
        var tools = registry.toOpenAiTools(config.enabledTools)
        var toolsDowngraded = false
        var sanitizeNotified = false
        // 服务商拒绝我们给的上限时，去掉该参数重试（只降级一次）
        var maxTokens = config.maxOutputTokens
        var maxTokensDowngraded = false
        var continuations = 0
        // 是否允许富文本 content（多模态数组）。被服务端拒绝一次后永久关闭，
        // 后续每轮直接把图片压平成文字占位 —— 否则该会话每轮都要多失败一次。
        var richContentAllowed = true

        var round = 0
        var extensions = 0
        val budget = config.maxToolRounds.coerceIn(1, MAX_ROUNDS_CEILING)

        while (true) {
            round++
            when (val decision = decideRoundBudget(round, budget, extensions)) {
                RoundBudgetDecision.Proceed -> Unit

                is RoundBudgetDecision.Extend -> {
                    // 额度用尽，但模型上一轮还在调工具 —— 说明任务没做完，只是步数超了。
                    // 直接判失败等于前面的活儿全白干，所以先自动延长；真跑不完才把控制权
                    // 交回用户，并给出「继续」的出口。
                    extensions = decision.extensions
                    emit(
                        Event.Notice(
                            "工具调用已达 $budget 轮，任务仍在推进，自动延长额度到 ${decision.newLimit} 轮" +
                                "（第 ${decision.extensions}/$MAX_ROUND_EXTENSIONS 次）…"
                        )
                    )
                }

                is RoundBudgetDecision.Exhausted -> {
                    emit(
                        Event.Failed(
                            AppError(
                                code = AppErrorCode.UNKNOWN,
                                message = "已连续执行 ${decision.totalRounds} 轮工具调用仍未收尾",
                                hint = "任务规模比预期大。回复「继续」可以让它接着做（已完成的进度都保留着）；" +
                                    "也可以到「设置 → 模型参数」调高「工具调用轮次上限」。"
                            ),
                            resumable = true
                        )
                    )
                    return
                }
            }

            // 发送前净化历史。残留的非法 tool_calls 会让服务端每一轮都返回 400，
            // 且因为是持久化会话，用户重开 App 也修不好 —— 只能在这里自愈。
            // 顺序有讲究：先按「user 边界」裁掉超长历史，再净化工具配对。
            // 反过来的话，裁剪可能切出半截工具对，又得靠 sanitize 补一遍。
            val pruned = ConversationSanitizer.prune(conversation.snapshot())
            val cleaned = ConversationSanitizer.analyze(pruned.messages)
            if (pruned.changed || cleaned.changed) {
                conversation.replaceAll(cleaned.messages)
                if (!sanitizeNotified) {
                    sanitizeNotified = true
                    val notes = buildList {
                        if (pruned.changed) {
                            add(
                                "会话已很长，最早的 ${pruned.dropped} 条历史已不再发给模型" +
                                    "（界面上的聊天记录不受影响）。"
                            )
                        }
                        if (cleaned.changed) {
                            add(
                                "历史中有 ${cleaned.droppedToolCalls} 处格式损坏的工具调用记录，" +
                                    "已自动清理后继续。"
                            )
                        }
                    }
                    emit(Event.AssistantText("提示：${notes.joinToString("")}"))
                }
            }

            // 内容形态降级：历史里的多模态消息（content 是数组）会让只接受字符串的
            // 服务端每轮都返回 400。这里只保留最后一条 user 消息的富文本形态
            // —— 那是用户本轮刚发的图，模型应当看到；更早的一律压平。
            val payload = RequestPayloadGuard.prepare(
                messages = cleaned.messages,
                keepLastUserRich = richContentAllowed
            )

            val messages = buildList {
                add(
                    ChatMessage.system(
                        buildSystemPrompt(
                            config = config,
                            ctx = toolContext,
                            // 每轮都按当前生效的工具集判断：模型只会看到启用了的工具
                            terminalEnabled = tools.any { it.function.name == "run_command" }
                        )
                    )
                )
                addAll(payload.messages)
            }

            val response = try {
                llmClient.chatStream(
                    baseUrl = config.baseUrl,
                    apiKey = config.apiKey,
                    request = ChatRequest(
                        model = config.model,
                        messages = messages,
                        tools = tools.ifEmpty { null },
                        toolChoice = if (tools.isEmpty()) null else "auto",
                        temperature = config.temperature.toDouble(),
                        maxTokens = maxTokens,
                        stream = true
                    ),
                    onTextDelta = { piece -> emit(Event.AssistantDelta(piece)) },
                    onReasoningDelta = { piece -> emit(Event.ThinkingDelta(piece)) }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: LlmException) {
                // 服务商不接受我们给的上限（超出它的硬上限等）→ 去掉该参数重试一次。
                // 对推理模型来说，「由服务端决定输出长度」远好过整轮请求失败。
                if (e is LlmException.BadRequest &&
                    maxTokens != null &&
                    !maxTokensDowngraded &&
                    isMaxTokensRejectedError(e)
                ) {
                    maxTokensDowngraded = true
                    maxTokens = null
                    round--
                    emit(
                        Event.Notice(
                            "该服务不接受 max_tokens 上限设置，已改为由服务端自行决定输出长度，正在重试…"
                        )
                    )
                    continue
                }
                // 服务端要求 content 必须是字符串，而我们还带着多模态数组
                // （用户发过图片）→ 关掉富文本、把图片压成文字占位后重试。
                //
                // 这条自愈很关键：多模态消息会永久留在历史里，不自动降级的话
                // 这个会话从此每发必 400，用户只能新建对话才恢复。
                if (e is LlmException.BadRequest &&
                    richContentAllowed &&
                    payload.richKept > 0 &&
                    isRichContentRejectedError(e)
                ) {
                    richContentAllowed = false
                    round--
                    emit(
                        Event.Notice(
                            "该服务只接受纯文本 content（不支持图片等多模态消息），" +
                                "已把历史中的图片转为文字占位后重试。"
                        )
                    )
                    continue
                }
                // 只有在服务端**明确**表示不接受 tools 时才降级。
                // 早先把任何 400 都当作「不支持工具」，会把「历史参数损坏」
                // 误报成服务不支持工具，既误导用户也掩盖真因。
                if (e is LlmException.BadRequest &&
                    tools.isNotEmpty() &&
                    !toolsDowngraded &&
                    isToolsUnsupported(e)
                ) {
                    toolsDowngraded = true
                    tools = emptyList()
                    emit(
                        Event.Notice("该服务未接受工具参数（tools），已自动降级为纯对话模式。")
                    )
                    continue
                }
                emit(Event.Failed(e.toAppError()))
                return
            } catch (e: Throwable) {
                emit(Event.Failed(AppError(AppErrorCode.UNKNOWN, e.message ?: "未知错误", e)))
                return
            }

            val assistant = response.firstMessage
            if (assistant == null) {
                emit(Event.Failed(AppError(AppErrorCode.PROTOCOL, "服务端未返回任何消息")))
                return
            }

            val calls = assistant.toolCalls.orEmpty()
            if (calls.isEmpty()) {
                val text = assistant.textContent.orEmpty()

                // 「答到一半停住」的两种成因，都在这里自动续写：
                //   · response.incomplete —— 流在传输层被掐断（长思考最容易被网关掐）
                //   · finish_reason = length —— 输出预算耗尽（推理模型的思考也吃这份预算）
                // 不续写的话，用户已经看到的几百字就白写了，而且必须手动喊「继续」。
                val truncated = response.incomplete || response.finishReason == FINISH_LENGTH

                if (shouldAutoContinue(
                        incomplete = response.incomplete,
                        finishReason = response.finishReason,
                        continuations = continuations
                    )
                ) {
                    continuations++
                    // 把已生成部分作为助手历史回灌，再要求它接着写
                    if (text.isNotBlank()) conversation.add(ChatMessage.assistant(text))
                    conversation.add(ChatMessage.user(CONTINUE_PROMPT))
                    val why = if (response.incomplete) "连接被中断" else "输出达到长度上限"
                    emit(
                        Event.Notice(
                            "$why，正在自动续写（第 $continuations/$MAX_CONTINUATIONS 次）…"
                        )
                    )
                    // 续写不算工具轮次，避免长回答把轮次额度耗光
                    round--
                    continue
                }

                val finalText = text.ifBlank { "（模型返回了空内容）" }
                conversation.add(ChatMessage.assistant(finalText))
                if (text.isNotBlank()) {
                    // 流式已经逐字显示过，这里只负责收尾
                    emit(Event.AssistantText(text))
                } else {
                    emit(Event.AssistantText(finalText))
                }
                if (truncated) {
                    emit(
                        Event.Notice(
                            "已续写 $MAX_CONTINUATIONS 次仍未写完。回复「继续」可以让它接着写；" +
                                "也可以到「设置 → 模型参数」把「最大输出长度」调大。"
                        )
                    )
                }
                emit(Event.Done)
                return
            }

            // 必须把带 tool_calls 的 assistant 消息原样回灌，否则下一轮协议不成立
            conversation.add(
                ChatMessage(role = "assistant", content = assistant.content, toolCalls = calls)
            )
            assistant.textContent?.takeIf { it.isNotBlank() }?.let { emit(Event.AssistantText(it)) }

            for (call in calls) {
                emit(Event.ToolStarted(call.id, call.function.name, call.function.arguments))
                val (payload, ok, preview) = executeTool(call, toolContext)
                conversation.add(ChatMessage.tool(call.id, payload))
                emit(Event.ToolFinished(call.id, ok, preview))
            }
        }
    }

    /**
     * 把「当前已授权的本地目录」注入系统提示。
     *
     * 不这样做的话，模型不知道用户授权过什么，只能反过来找用户要 content:// URI
     * —— 这正是本地文件用起来别扭的根因。
     */
    private suspend fun buildSystemPrompt(
        config: AgentConfig,
        ctx: ToolContext,
        terminalEnabled: Boolean
    ): String = buildString {
        append(config.systemPrompt)
        append("\n\n【本地文件访问】")
        val roots = ctx.uriAccessPolicy.currentRoots()
        if (roots.isEmpty()) {
            append("用户当前没有授权任何本地目录，因此你无法读写本机文件。")
            append("若任务需要访问文件，请提示用户到「设置 → 已授权目录」里添加文件夹，不要反复索要 URI。")
        } else {
            append("用户已授权以下本地目录：\n")
            roots.forEach { root ->
                append("- ").append(root.displayName)
                append(if (root.canWrite) "（可读写）" else "（只读）")
                append('\n')
            }
            append("可用工具：\n")
            append("- file_list：查看目录里有什么\n")
            append("- file_read：读取文件内容\n")
            append("- file_edit：把文件中某段文字替换成另一段；new_text 留空即为删除。" +
                "**old_text 只写一小段能唯一定位的文字（一两行足矣），绝不要把整篇文件贴进来**" +
                "—— 参数过长会被截断，导致调用失败。大范围改写请改用 file_write\n")
            append("- file_write：整体覆盖已有文件（原内容会被截断替换）\n")
            append("- file_create：新建文件\n")
            append("- file_delete：删除文件或文件夹（不可撤销）\n")
            append("路径直接写「目录名/文件名」即可，例如 path=\"")
                .append(roots.first().displayName)
                .append("/readme.md\"。\n")
            append("注意：Android 分区存储禁止使用 /storage/emulated/0/... 这类绝对路径，")
            append("但上面的写法已经可用，**不要向用户索要 content:// URI**。")
        }

        // run_command 打开时才注入终端说明：模型需要知道这条命令通道的存在与边界
        if (terminalEnabled) {
            append("\n\n【命令终端】")
            append("你可以用 run_command 执行 shell 命令（sh -c），以应用自身权限运行，无 root。\n")
            append("- 适合：查看系统信息（getprop/uname/ps/df）、处理应用私有目录里的文件、" +
                "跑组合命令（grep/find/sed/toybox 全家桶）\n")
            append("- 共享存储（/sdcard）需要用户已授权「所有文件访问」，否则会 permission denied；" +
                "遇到拒绝时提示用户去终端页授权，不要反复重试\n")
            append("- 每条命令都是独立进程，cd 不跨命令保留；需要先切目录就写 `cd x && y`\n")
            append("- 输出超 8000 字符会被截断，需要全文时用 head/tail/grep 收窄\n")
            append("- 有黑名单拦截（rm -rf /、mkfs、reboot 等）；被拦截时告诉用户可去终端页手动执行")
        }
    }

    private suspend fun executeTool(
        call: ToolCall,
        ctx: ToolContext
    ): Triple<String, Boolean, String> {
        val toolName = call.function.name
        val tool = registry.get(toolName)
            ?: return Triple(
                errorJson("未知工具 '$toolName'。可用工具：${registry.names().joinToString(", ")}"),
                false,
                "未知工具 $toolName"
            )

        val argsObject: JsonObject = try {
            val raw = call.function.arguments.trim()
            if (raw.isEmpty()) {
                JsonObject(emptyMap())
            } else {
                (json.parseToJsonElement(raw) as? JsonObject)
                    ?: return Triple(errorJson("arguments 必须是 JSON 对象"), false, "参数格式错误")
            }
        } catch (e: Throwable) {
            return Triple(errorJson("arguments 不是合法 JSON：${e.message}"), false, "参数解析失败")
        }

        val result = try {
            tool.invoke(argsObject, ctx)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            ToolResult.failure("工具执行异常：${e.message ?: e::class.java.simpleName}")
        }

        val preview = result.text.replace(Regex("\\s+"), " ").trim().take(160)
        return if (result.ok) {
            Triple(result.text, true, preview)
        } else {
            Triple(errorJson(result.text), false, preview)
        }
    }

    private fun errorJson(message: String): String = JsonObject(
        mapOf(
            "ok" to JsonPrimitive(false),
            "error" to JsonPrimitive(message)
        )
    ).toString()

    /**
     * 判断这个 400 是否真的是「服务端不接受 tools」。
     *
     * 必须和服务端原文挂钩。像阿里云那条
     * `The "function.arguments" parameter ... must be in JSON format`
     * 也含 "function"，但它说的是**参数格式**问题，不是不支持工具调用 ——
     * 误判成后者会降级成纯对话，问题依旧存在，排查方向也被带偏。
     *
     * 提为包内可见：[Orchestrator] 的规划请求也要做同样的降级判断。
     */
    internal fun isToolsUnsupported(e: LlmException.BadRequest): Boolean =
        isToolsUnsupportedError(e)
}

/**
 * [AgentEngine.isToolsUnsupported] 的实现，供编排引擎复用。
 *
 * 服务端原文里出现 tools/tool_choice/tool_calls/function calling/functions
 * 且带有明确的「不支持」措辞时，才认定为「不接受 tools」；
 * 只要提到 arguments / json format，就一律认为是参数格式问题（自愈路径不同）。
 */
internal fun isToolsUnsupportedError(e: LlmException.BadRequest): Boolean {
    val raw = (e.serverRaw.ifBlank { e.message.orEmpty() }).lowercase()
    val mentionsTools = raw.contains("tools") ||
        raw.contains("tool_choice") ||
        raw.contains("tool_calls") ||
        raw.contains("function calling") ||
        raw.contains("functions")
    if (!mentionsTools) return false

    // 参数本身格式错误 ≠ 不支持工具
    if (raw.contains("arguments") || raw.contains("json format")) return false

    return raw.contains("not support") ||
        raw.contains("unsupported") ||
        raw.contains("不支持") ||
        raw.contains("unknown parameter") ||
        raw.contains("unrecognized") ||
        raw.contains("extra fields") ||
        raw.contains("not allowed")
}

/**
 * 判断 400 是否在说「max_tokens 这个上限不合法」。
 *
 * 各家措辞不一，常见有：
 * - `max_tokens` / `max tokens` / `max_output_tokens` 直接点名；
 * - `maximum context length`、`exceeds the maximum` 这类间接说法。
 *
 * 命中时引擎会去掉该参数重试一次 —— 对推理模型来说，宁可让服务端自己
 * 决定输出长度，也比整轮请求失败强。
 */
internal fun isMaxTokensRejectedError(e: LlmException.BadRequest): Boolean {
    val raw = (e.serverRaw.ifBlank { e.message.orEmpty() }).lowercase()
    if (raw.contains("max_tokens") ||
        raw.contains("max tokens") ||
        raw.contains("max_output_tokens") ||
        raw.contains("maxtokens")
    ) {
        return true
    }
    val aboutLength = raw.contains("maximum") || raw.contains("exceed") || raw.contains("too large")
    val aboutTokens = raw.contains("token") || raw.contains("length") || raw.contains("上下文")
    return aboutLength && aboutTokens
}

/**
 * 判断 400 是否在说「`content` 的类型不对」—— 即服务端只接受字符串，
 * 而我们发了数组（多模态消息）。
 *
 * 关键词表在 [looksLikeRichContentRejected]，与客户端构造错误提示时共用，
 * 避免两处分叉。命中后引擎会关掉富文本并把历史里的图片压成文字占位重试。
 */
internal fun isRichContentRejectedError(e: LlmException.BadRequest): Boolean =
    looksLikeRichContentRejected(e.serverRaw.ifBlank { e.message.orEmpty() })

/**
 * 是否应当自动续写。
 *
 * 触发条件（二者其一）：
 * - 流在传输层被掐断（[incomplete]）—— 长思考期间连接最容易被中间网关掉；
 * - 服务端明确回 `finish_reason = "length"`，即输出被上限截断。
 *
 * 次数上限由 [AgentEngine.MAX_CONTINUATIONS] 控制：续写本身也可能再次被截断，
 * 不设上限会变成无限循环烧 token。
 *
 * 抽成纯函数是为了能单测 —— 这段判断直接决定「答到一半停住」会不会被自动救回来。
 */
internal fun shouldAutoContinue(
    incomplete: Boolean,
    finishReason: String?,
    continuations: Int,
    maxContinuations: Int = AgentEngine.MAX_CONTINUATIONS
): Boolean {
    if (continuations >= maxContinuations) return false
    return incomplete || finishReason == AgentEngine.FINISH_LENGTH
}
