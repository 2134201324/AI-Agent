package com.example.nativedemo.tools.saf

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

/**
 * 文件访问的准入判定：**双重校验**。
 *
 * 1. 静态 —— 目标 URI 是否等于某个已授权 tree，或落在该 tree 之下；
 * 2. 动态 —— 复核 ContentResolver 当前是否仍持有该权限（系统可能已回收，
 *    用户也可能在系统设置里撤销）。
 *
 * 任一条不满足即拒绝，并给出可操作的提示。
 */
class UriAccessPolicy(
    private val context: Context,
    private val store: SafPermissionStore
) {

    /** 返回 null 表示允许；否则返回面向用户的拒绝原因。 */
    suspend fun denyReason(uri: Uri, write: Boolean): String? {
        val target = uri.toString()
        val roots = store.currentRoots()

        val matched = roots.firstOrNull { root ->
            val base = root.uri.toString()
            target == base || target.startsWith("$base/")
        } ?: return "该路径未被授权。请到「设置 → 已授权目录」中添加它所在的文件夹后再试。"

        if (write && !matched.canWrite) {
            return "该目录仅授予了读取权限。如需写入，请在「设置 → 已授权目录」中移除后重新添加并勾选可写。"
        }

        val stillGranted = context.contentResolver.persistedUriPermissions.any { permission ->
            permission.uri.toString() == matched.uri.toString() &&
                permission.isReadPermission &&
                (!write || permission.isWritePermission)
        }
        if (!stillGranted) {
            return "系统已撤销对「${matched.displayName}」的访问权限（可能因卸载重装或手动撤销）。请重新添加该目录。"
        }
        return null
    }

    suspend fun isAllowed(uri: Uri, write: Boolean): Boolean = denyReason(uri, write) == null

    suspend fun currentRoots(): List<AuthorizedRoot> = store.currentRoots()

    /** 「父目录 + 文件名 + 扩展名」，供创建文件用。 */
    data class CreationTarget(
        val parent: DocumentFile,
        val fileName: String,
        val extension: String
    )

    /**
     * 为「尚不存在的文件」解析出父目录 + 文件名 + 扩展名。
     *
     * [resolveDocument] 只能找到已存在的项，创建场景需要单独一条路径。
     */
    suspend fun resolveParentForCreation(pathOrUri: String): CreationTarget? {
        val segments = normalizePathSegments(pathOrUri) ?: return null
        if (segments.size < 2) return null

        val fileName = segments.last()
        val directoryPath = segments.dropLast(1).joinToString("/")
        val directory = resolveDocument(directoryPath) ?: return null
        if (!directory.isDirectory) return null

        return CreationTarget(
            parent = directory,
            fileName = fileName,
            extension = fileName.substringAfterLast('.', "")
        )
    }

    /**
     * 同 [resolveParentForCreation]，但**缺失的中间目录会自动创建**。
     *
     * 为什么必须有它：`file_create("code_game/notes/2026/plan.md")` 只要有一级
     * 父目录不存在就失败，而模型根本不知道用户磁盘上现成的结构 —— 只能反复
     * file_list 试探，把本就紧张的对话轮次白白烧光（用户看到的就是
     * 「已达到最大工具调用轮次」）。按需建目录后，一次调用即可落地。
     *
     * 只在可写的授权目录下建，读-only 授权一律跳过。
     */
    suspend fun resolveOrCreateParent(pathOrUri: String): CreationTarget? {
        val segments = normalizePathSegments(pathOrUri) ?: return null
        if (segments.size < 2) return null

        val fileName = segments.last()
        val dirSegments = segments.dropLast(1)

        for (root in store.currentRoots()) {
            val tree = DocumentFile.fromTreeUri(context, root.uri) ?: continue
            if (!tree.canWrite()) continue

            val rest = relativeToRoot(dirSegments, tree.name.orEmpty())
            var cursor: DocumentFile = tree
            var blocked = false

            for (segment in rest) {
                val existing = runCatching { cursor.findFile(segment) }.getOrNull()
                val next = when {
                    existing == null -> runCatching { cursor.createDirectory(segment) }.getOrNull()
                    existing.isDirectory -> existing
                    else -> null // 同名文件占位，这个根目录走不通
                }
                if (next == null) {
                    blocked = true
                    break
                }
                cursor = next
            }
            if (blocked) continue

            return CreationTarget(
                parent = cursor,
                fileName = fileName,
                extension = fileName.substringAfterLast('.', "")
            )
        }
        return null
    }

    /**
     * 创建目录链（相当于 `mkdir -p`）。返回创建/已存在的目录，全部失败返回 null。
     */
    suspend fun ensureDirectory(pathOrUri: String): DocumentFile? {
        val segments = normalizePathSegments(pathOrUri) ?: return null

        for (root in store.currentRoots()) {
            val tree = DocumentFile.fromTreeUri(context, root.uri) ?: continue
            if (!tree.canWrite()) continue

            val rest = relativeToRoot(segments, tree.name.orEmpty())
            if (rest.isEmpty()) return tree // 指的就是授权目录本身

            var cursor: DocumentFile = tree
            var blocked = false
            for (segment in rest) {
                val existing = runCatching { cursor.findFile(segment) }.getOrNull()
                val next = when {
                    existing == null -> runCatching { cursor.createDirectory(segment) }.getOrNull()
                    existing.isDirectory -> existing
                    else -> null
                }
                if (next == null) {
                    blocked = true
                    break
                }
                cursor = next
            }
            if (!blocked) return cursor
        }
        return null
    }

    /**
     * 把「人类可读路径」或 content:// URI 解析为 DocumentFile。
     *
     * 支持三种写法：
     * - `content://com.android.externalstorage.documents/...`（完整 URI）
     * - `code_game/readme.md`（带根目录名）
     * - `readme.md`（不带根目录名，会在所有已授权目录中查找）
     *
     * 这样模型和用户都不必再手写 content:// URI。
     */
    suspend fun resolveDocument(pathOrUri: String): DocumentFile? {
        val raw = pathOrUri.trim()
        if (raw.isEmpty()) return null

        if (raw.startsWith("content://")) {
            val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return null
            return DocumentFile.fromSingleUri(context, uri)
                ?: DocumentFile.fromTreeUri(context, uri)
        }

        val segments = normalizePathSegments(raw) ?: return null

        for (root in store.currentRoots()) {
            val tree = DocumentFile.fromTreeUri(context, root.uri) ?: continue
            val rest = relativeToRoot(segments, tree.name.orEmpty())

            // 路径第一段就是授权目录名时，rest 可能为空 —— 那指的正是这个目录本身。
            // 模型在 file_list 里看到的就是这个名字，file_list("code_game") 是最自然的
            // 写法；旧实现只会把根名当子目录去找，于是必然找不到、报「未找到目录」。
            if (rest.isEmpty()) return tree

            resolveUnder(tree, rest)?.let { return it }
            // 兜底：路径没带根名，但根名本身可能是路径中的一段（少数设备不暴露根名）
            resolveUnder(tree, listOf(tree.name.orEmpty()).filter { it.isNotBlank() } + rest)
                ?.let { return it }
        }
        return null
    }

    /** 沿 [segments] 从 [base] 逐级向下查找；任一级缺失即返回 null。 */
    private fun resolveUnder(base: DocumentFile, segments: List<String>): DocumentFile? {
        var cursor: DocumentFile = base
        for (segment in segments) {
            cursor = runCatching { cursor.findFile(segment) }.getOrNull() ?: return null
        }
        return cursor.takeIf { it.exists() }
    }
}

/**
 * 把路径规整成段列表：去掉前导斜杠与常见的存储前缀，过滤空段。
 *
 * 抽成纯函数是为了能直接单测 —— 路径解析出错的表现是「明明存在的文件说找不到」，
 * 现场排查成本很高，值得用测试锁住。
 */
internal fun normalizePathSegments(raw: String): List<String>? {
    val cleaned = raw.trim()
        .trimStart('/')
        .removePrefix("storage/emulated/0/")
        .removePrefix("storage/emulated/0")
        .removePrefix("sdcard/")
        .removePrefix("sdcard")
        .trimStart('/')
    val segments = cleaned.split('/').filter { it.isNotBlank() && it != "." }
    return segments.takeIf { it.isNotEmpty() && it.none { s -> s == ".." } }
}

/**
 * 若路径首段正好是授权目录名，返回相对该目录的剩余段；否则原样返回。
 *
 * 返回空列表是合法且有意义的：表示「就是这个授权目录本身」。
 */
internal fun relativeToRoot(segments: List<String>, rootName: String): List<String> =
    if (rootName.isNotBlank() && segments.firstOrNull() == rootName) segments.drop(1) else segments
