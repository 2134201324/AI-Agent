package com.example.nativedemo.data.agent

import com.example.nativedemo.data.llm.ChatMessage
import java.util.UUID

/**
 * 当前会话的 LLM 上下文（内存态）。
 *
 * 刻意保持纯同步、不含 IO —— AgentEngine 的多轮循环会频繁调用它，
 * 加锁或挂起会让循环难以推理。落盘由 ChatViewModel 在合适时机取快照完成。
 */
class ConversationStore {

    private val messages = mutableListOf<ChatMessage>()

    var conversationId: String = UUID.randomUUID().toString()
        private set

    var createdAt: Long = System.currentTimeMillis()
        private set

    fun snapshot(): List<ChatMessage> = messages.toList()

    fun add(message: ChatMessage) {
        messages += message
    }

    /**
     * 用净化后的历史整体替换。
     *
     * 供 ConversationSanitizer 收尾：把 arguments 非法或配不成对的
     * tool_call 从**内存上下文**里也清掉，避免每轮都重复净化。
     */
    fun replaceAll(history: List<ChatMessage>) {
        messages.clear()
        messages.addAll(history)
    }

    /** 切换到已有会话：整体替换上下文。 */
    fun restore(id: String, createdAt: Long, history: List<ChatMessage>) {
        this.conversationId = id
        this.createdAt = createdAt
        messages.clear()
        messages.addAll(history)
    }

    /** 开启全新会话。 */
    fun reset() {
        conversationId = UUID.randomUUID().toString()
        createdAt = System.currentTimeMillis()
        messages.clear()
    }

    fun clear() {
        messages.clear()
    }

    fun size(): Int = messages.size
}
