package com.example.nativedemo.data.agent

import com.example.nativedemo.data.llm.ChatMessage
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

/**
 * 会话历史净化器。
 *
 * ## 为什么需要它
 *
 * 模型生成的 `tool_calls.function.arguments` 是**字符串**，天然可能不合法：
 * 参数过长被 max_tokens 截断、转义写错、多分片归并错位都会产生残缺 JSON。
 *
 * 按 OpenAI 协议，带 tool_calls 的 assistant 消息必须原样回灌历史（否则多轮
 * 工具调用不成立），于是一条残缺的 tool_call 会**永远留在上下文里**。而
 * OpenAI 兼容服务在收到请求时会校验 `function.arguments` 必须是合法 JSON ——
 * 结果是这个会话之后的每一轮请求都返回 400，且**重开 App 也恢复不了**，
 * 因为历史已经落盘。
 *
 * 所以发送前必须净化。净化有两个作用：让已中毒的会话自愈；防止新产生的
 * 坏记录扩散到下一轮。
 *
 * ## 顺带清理的两类「孤儿」记录
 *
 * - 有 tool 响应、但没有对应 assistant tool_call 的（协议同样不合法）
 * - 有 assistant tool_call、但没有 tool 响应的（用户点「停止」时会留下这种）
 */
object ConversationSanitizer {

    private val json = Json {
        isLenient = true
        ignoreUnknownKeys = true
    }

    data class Report(
        val messages: List<ChatMessage>,
        /** 被剔除的 tool_call 数量（arguments 非法或缺少响应） */
        val droppedToolCalls: Int = 0,
        /** 被整体丢弃的消息数量（孤儿 tool 消息、只剩调用的 assistant 消息） */
        val droppedMessages: Int = 0
    ) {
        val changed: Boolean get() = droppedToolCalls > 0 || droppedMessages > 0
    }

    fun sanitize(messages: List<ChatMessage>): List<ChatMessage> = analyze(messages).messages

    /** arguments 必须是合法的 JSON **对象**。空串同样视为非法。 */
    fun isValidArguments(raw: String?): Boolean {
        val text = raw?.trim().orEmpty()
        if (text.isEmpty()) return false
        return runCatching { json.parseToJsonElement(text) is JsonObject }.getOrDefault(false)
    }

    fun analyze(messages: List<ChatMessage>): Report {
        if (messages.isEmpty()) return Report(messages)

        // ① 找出 arguments 非法的 tool_call
        val badCallIds = mutableSetOf<String>()
        messages.forEach { message ->
            message.toolCalls?.forEach { call ->
                if (!isValidArguments(call.function.arguments)) badCallIds += call.id
            }
        }

        // ② 哪些 tool_call 有对应的 tool 响应（没有响应的不能保留，协议不允许）
        val answeredIds = messages
            .asSequence()
            .filter { it.role == "tool" }
            .mapNotNull { it.toolCallId }
            .toSet()

        // ③ 重建 assistant 消息，只保留「合法且已响应」的调用
        val keptCallIds = mutableSetOf<String>()
        var droppedToolCalls = 0
        var droppedMessages = 0
        val intermediate = ArrayList<ChatMessage>(messages.size)

        messages.forEach { message ->
            val calls = message.toolCalls
            if (calls == null) {
                intermediate += message
                return@forEach
            }

            val kept = calls.filter { call ->
                val ok = call.id !in badCallIds && call.id in answeredIds
                if (!ok) droppedToolCalls++
                ok
            }
            kept.forEach { keptCallIds += it.id }

            if (kept.isNotEmpty()) {
                intermediate += message.copy(toolCalls = kept)
            } else {
                // 调用全被剔除：还有正文就降级成普通文本，否则整条丢弃
                val text = message.textContent
                if (!text.isNullOrBlank()) {
                    intermediate += ChatMessage.assistant(text)
                } else {
                    droppedMessages++
                }
            }
        }

        // ④ 丢掉孤儿 tool 消息（其 tool_call_id 已不在保留集合里）
        val result = intermediate.filter { message ->
            val keep = message.role != "tool" ||
                (message.toolCallId != null && message.toolCallId in keptCallIds)
            if (!keep) droppedMessages++
            keep
        }

        return Report(result, droppedToolCalls, droppedMessages)
    }

    /**
     * 历史超过多少条就裁剪。
     *
     * 定得偏高是有意的：正常使用到不了这里，只有「聊了很多轮」才会触发。
     * 裁剪会丢记忆，宁可晚点裁 —— 但必须有这道闸，否则总有一天会撞上服务端的
     * 上下文上限，届时**整个会话每轮都 400**，比丢几轮旧记忆严重得多。
     */
    const val DEFAULT_MAX_HISTORY_MESSAGES = 120

    data class PruneReport(val messages: List<ChatMessage>, val dropped: Int) {
        val changed: Boolean get() = dropped > 0
    }

    /**
     * 裁掉最早的若干轮，给新消息腾出上下文空间。
     *
     * 落点**必须选在 user 消息上**：直接按条数切断会把「assistant 的 tool_calls」
     * 和「tool 的响应」劈开，而两者配不成对本身就是协议违规，会引发新的 400。
     * 调用方在裁剪之后仍应再跑一次 [analyze] 兜底。
     */
    fun prune(
        messages: List<ChatMessage>,
        maxMessages: Int = DEFAULT_MAX_HISTORY_MESSAGES
    ): PruneReport {
        if (maxMessages <= 0 || messages.size <= maxMessages) {
            return PruneReport(messages, 0)
        }

        var start = messages.size - maxMessages
        while (start < messages.size && messages[start].role != "user") start++
        // 找不到 user 边界（极端情况）：宁可不裁，也不要切出半截工具对
        if (start >= messages.size) return PruneReport(messages, 0)

        return PruneReport(messages.subList(start, messages.size).toList(), start)
    }
}
