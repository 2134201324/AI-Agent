package com.example.nativedemo.tools.apk

import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater

/**
 * 最小 ZIP 写入器：专为「重建 APK」而生。
 *
 * ## 为什么不用 `java.util.zip.ZipOutputStream`
 *
 * 它不给对齐留任何余地 —— 而 APK 有硬性对齐要求：
 *
 * - **`resources.arsc` 必须未压缩且 4 字节对齐**。Android 11+ 对 `targetSdkVersion >= 30`
 *   的包会直接拒绝安装未对齐的 arsc；
 * - **`.so` 要按页对齐**（16 KB），否则在 Android 15 的 16 KB 页设备上无法直接映射。
 *
 * 对齐的做法是在**本地文件头的 extra field 里补白**，把数据区的绝对偏移顶到边界上。
 * 这要求写入时能精确知道"当前已写多少字节"，所以这里自己拼接字节流。
 *
 * ## 保留压缩方式
 *
 * 重建时**沿用原条目的压缩方法**：原本 STORED 的（arsc、部分资源）继续不压缩，
 * 原本 DEFLATED 的继续压缩。一律压缩会破坏 mmap 语义，一律不压缩则包体暴涨。
 */
internal class ApkZipWriter(private val out: OutputStream) {

    /** 对齐用的 extra field id：Android 官方 zipalign 用的就是这个值。 */
    private val alignmentExtraId = byteArrayOf(0x35.toByte(), 0xD9.toByte())

    private class Record(
        val name: ByteArray,
        val method: Int,
        val crc: Long,
        val compressedSize: Long,
        val uncompressedSize: Long,
        val localHeaderOffset: Long,
        val dosTime: Int,
        val dosDate: Int,
        val utf8: Boolean
    )

    private val records = mutableListOf<Record>()
    private var written = 0L
    private var finished = false

    /**
     * 写入一个条目。
     *
     * @param compress false 时用 STORED（不压缩）
     * @param alignment 数据区需要对齐到的字节边界；1 表示不对齐
     */
    fun putEntry(
        name: String,
        data: ByteArray,
        compress: Boolean,
        alignment: Int = DEFAULT_ALIGNMENT,
        modifiedTime: Long = System.currentTimeMillis()
    ) {
        check(!finished) { "已经 finish，不能再写条目" }

        val nameBytes = name.toByteArray(Charsets.UTF_8)
        val utf8 = nameBytes.size != name.length

        val method = if (compress) METHOD_DEFLATED else METHOD_STORED
        val payload = if (compress) deflate(data) else data

        val crc = CRC32().apply { update(data) }.value
        val (dosTime, dosDate) = toDosDateTime(modifiedTime)

        val align = if (alignment > 1) alignment else 1
        val baseLength = LOCAL_HEADER_SIZE + nameBytes.size

        // 计算补白：让「本地头 + 文件名 + extra」之后的数据区落在对齐边界上
        var extraLength = ((align - ((written + baseLength) % align)) % align).toInt()
        // extra field 自身有 4 字节头，小于 4 的补白放不下，索性再加一整轮
        if (extraLength in 1..3) extraLength += align
        val extra = if (extraLength >= 4) buildAlignmentExtra(extraLength) else EMPTY

        val header = localHeader(
            method = method,
            dosTime = dosTime,
            dosDate = dosDate,
            crc = crc,
            compressedSize = payload.size.toLong(),
            uncompressedSize = data.size.toLong(),
            nameLength = nameBytes.size,
            extraLength = extra.size,
            utf8 = utf8
        )

        val localHeaderOffset = written
        out.write(header)
        out.write(nameBytes)
        out.write(extra)
        out.write(payload)
        written += header.size + nameBytes.size + extra.size + payload.size

        records += Record(
            name = nameBytes,
            method = method,
            crc = crc,
            compressedSize = payload.size.toLong(),
            uncompressedSize = data.size.toLong(),
            localHeaderOffset = localHeaderOffset,
            dosTime = dosTime,
            dosDate = dosDate,
            utf8 = utf8
        )
    }

    /** 写中央目录与 EOCD，收尾。 */
    fun finish() {
        if (finished) return
        finished = true

        val centralDirectoryOffset = written
        var centralSize = 0L
        records.forEach { record ->
            val header = centralHeader(record)
            out.write(header)
            out.write(record.name)
            written += header.size + record.name.size
            centralSize += header.size + record.name.size
        }

        val eocd = eocd(
            entryCount = records.size,
            centralSize = centralSize,
            centralOffset = centralDirectoryOffset
        )
        out.write(eocd)
        written += eocd.size
        out.flush()
    }

    /** 已写入的字节数（调试与对齐校验用）。 */
    val bytesWritten: Long get() = written

    // ── 各段结构的拼装 ────────────────────────────────────────────────

    private fun buildAlignmentExtra(totalLength: Int): ByteArray {
        val extra = ByteArray(totalLength)
        extra[0] = alignmentExtraId[0]
        extra[1] = alignmentExtraId[1]
        val payloadSize = totalLength - 4
        extra[2] = (payloadSize and 0xFF).toByte()
        extra[3] = ((payloadSize ushr 8) and 0xFF).toByte()
        // 其余字节保持 0，纯占位
        return extra
    }

    private fun localHeader(
        method: Int,
        dosTime: Int,
        dosDate: Int,
        crc: Long,
        compressedSize: Long,
        uncompressedSize: Long,
        nameLength: Int,
        extraLength: Int,
        utf8: Boolean
    ): ByteArray {
        val buffer = ByteArray(LOCAL_HEADER_SIZE)
        var p = 0
        p = writeInt(buffer, p, 0x04034B50)                       // 本地文件头签名
        p = writeShort(buffer, p, if (method == METHOD_STORED) 10 else 20)  // 解压所需版本
        p = writeShort(buffer, p, if (utf8) 0x0800 else 0)        // 通用标志位
        p = writeShort(buffer, p, method)
        p = writeShort(buffer, p, dosTime)
        p = writeShort(buffer, p, dosDate)
        p = writeInt(buffer, p, crc)
        p = writeInt(buffer, p, compressedSize)
        p = writeInt(buffer, p, uncompressedSize)
        p = writeShort(buffer, p, nameLength)
        writeShort(buffer, p, extraLength)
        return buffer
    }

    private fun centralHeader(record: Record): ByteArray {
        val buffer = ByteArray(CENTRAL_HEADER_SIZE)
        var p = 0
        p = writeInt(buffer, p, 0x02014B50)                       // 中央目录头签名
        p = writeShort(buffer, p, 20)                              // 创建版本
        p = writeShort(buffer, p, if (record.method == METHOD_STORED) 10 else 20)
        p = writeShort(buffer, p, if (record.utf8) 0x0800 else 0)
        p = writeShort(buffer, p, record.method)
        p = writeShort(buffer, p, record.dosTime)
        p = writeShort(buffer, p, record.dosDate)
        p = writeInt(buffer, p, record.crc)
        p = writeInt(buffer, p, record.compressedSize)
        p = writeInt(buffer, p, record.uncompressedSize)
        p = writeShort(buffer, p, record.name.size)
        p = writeShort(buffer, p, 0)                               // extra 长度
        p = writeShort(buffer, p, 0)                               // 注释长度
        p = writeShort(buffer, p, 0)                               // 起始磁盘号
        p = writeShort(buffer, p, 0)                               // 内部属性
        p = writeInt(buffer, p, 0)                                 // 外部属性
        writeInt(buffer, p, record.localHeaderOffset)
        return buffer
    }

    private fun eocd(entryCount: Int, centralSize: Long, centralOffset: Long): ByteArray {
        val buffer = ByteArray(EOCD_SIZE)
        var p = 0
        p = writeInt(buffer, p, 0x06054B50)
        p = writeShort(buffer, p, 0)
        p = writeShort(buffer, p, 0)
        p = writeShort(buffer, p, entryCount)
        p = writeShort(buffer, p, entryCount)
        p = writeInt(buffer, p, centralSize)
        writeInt(buffer, p, centralOffset)
        return buffer
    }

    private fun deflate(data: ByteArray): ByteArray {
        if (data.isEmpty()) return data
        val deflater = Deflater(Deflater.DEFAULT_COMPRESSION, true)
        return try {
            deflater.setInput(data)
            deflater.finish()
            val out = java.io.ByteArrayOutputStream(data.size / 2 + 64)
            val buffer = ByteArray(64 * 1024)
            while (!deflater.finished()) {
                val n = deflater.deflate(buffer)
                if (n <= 0) break
                out.write(buffer, 0, n)
            }
            out.toByteArray()
        } finally {
            deflater.end()
        }
    }

    private fun writeInt(buffer: ByteArray, at: Int, value: Long): Int {
        buffer[at] = (value and 0xFF).toByte()
        buffer[at + 1] = ((value ushr 8) and 0xFF).toByte()
        buffer[at + 2] = ((value ushr 16) and 0xFF).toByte()
        buffer[at + 3] = ((value ushr 24) and 0xFF).toByte()
        return at + 4
    }

    private fun writeShort(buffer: ByteArray, at: Int, value: Int): Int {
        buffer[at] = (value and 0xFF).toByte()
        buffer[at + 1] = ((value ushr 8) and 0xFF).toByte()
        return at + 2
    }

    /** JDK 的 DOS 时间格式（ZIP 用的是 1980 纪元的打包日期时间）。 */
    private fun toDosDateTime(millis: Long): Pair<Int, Int> {
        val calendar = java.util.Calendar.getInstance()
        calendar.timeInMillis = millis
        val year = calendar.get(java.util.Calendar.YEAR)
        // 1980 年之前的日期在 ZIP 里无法表示，夹到下限
        val dosYear = (year - 1980).coerceAtLeast(0)
        val month = calendar.get(java.util.Calendar.MONTH) + 1
        val day = calendar.get(java.util.Calendar.DAY_OF_MONTH)
        val hour = calendar.get(java.util.Calendar.HOUR_OF_DAY)
        val minute = calendar.get(java.util.Calendar.MINUTE)
        val second = calendar.get(java.util.Calendar.SECOND)

        val time = (hour shl 11) or (minute shl 5) or (second / 2)
        val date = (dosYear shl 9) or (month shl 5) or day
        return time to date
    }

    companion object {
        const val METHOD_STORED = 0
        const val METHOD_DEFLATED = 8

        /** 普通条目对齐 4 字节。 */
        const val DEFAULT_ALIGNMENT = 4

        /** native 库按页对齐（16 KB，兼容 Android 15 的 16 KB 页设备）。 */
        const val NATIVE_LIB_ALIGNMENT = 16 * 1024

        private const val LOCAL_HEADER_SIZE = 30
        private const val CENTRAL_HEADER_SIZE = 46
        private const val EOCD_SIZE = 22
        private val EMPTY = ByteArray(0)
    }
}
