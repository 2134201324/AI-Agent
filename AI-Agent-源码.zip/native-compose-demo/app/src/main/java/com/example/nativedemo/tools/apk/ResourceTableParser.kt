package com.example.nativedemo.tools.apk

/** 资源表里的一条资源项。 */
data class ResEntry(
    val packageId: Int,
    val packageName: String,
    /** 类型名，如 `string` / `drawable` / `layout`。 */
    val typeName: String,
    /** 资源键名，如 `app_name`。 */
    val entryName: String,
    /** 完整资源 id，如 `0x7f010001`。 */
    val resId: Int,
    /** 已格式化好的值（字符串直出、引用显示为 `@0x...`）。 */
    val value: String,
    /** 是否属于默认配置（不带语言/分辨率等限定）。 */
    val isDefaultConfig: Boolean
) {
    val resIdHex: String get() = "0x${resId.toUInt().toString(16).padStart(8, '0')}"
}

class ResourceTable(
    /** 包名列表（通常只有一个，如 `com.example.app`）。 */
    val packages: List<String>,
    val entries: List<ResEntry>,
    val valueStringCount: Int
) {
    val typeCount: Int get() = entries.map { it.typeName }.distinct().size

    /** 按类型名分组统计，供总览展示。 */
    fun countByType(): Map<String, Int> =
        entries.groupingBy { it.typeName }.eachCount()
            .toList().sortedByDescending { it.second }.toMap()
}

/**
 * `resources.arsc` 解析器。
 *
 * ## 它是干什么的
 *
 * 这个文件是 APK 的**资源字典**：把 `app_name`、`ic_launcher` 这类名字映射到实际的值
 * 或资源 id，并附带每种配置（语言、分辨率、夜间模式…）下的不同取值。
 * 逆向分析时它有两个关键用途：
 *
 * 1. **看得懂字符串**：manifest 与 XML 里的 `@string/xxx`、`@drawable/xxx` 只有靠它
 *    才能还原成人类可读的内容（比如某个界面的标题原文）；
 * 2. **定位关键资源**：改图标、找硬编码密钥、识别混淆后的资源名，都以这张表为索引。
 *
 * ## 结构
 *
 * ```
 * TABLE (0x0002)
 * ├── STRING_POOL          所有资源**值**的字符串池
 * └── TABLE_PACKAGE (0x0200)  每个包一个
 *     ├── typeStrings 池    类型名（string / drawable / layout …）
 *     ├── keyStrings 池     资源键名（app_name / ic_launcher …）
 *     ├── TABLE_TYPE_SPEC    每种类型的条目数声明
 *     └── TABLE_TYPE         实际条目；每个条目可能有多份配置变体
 * ```
 *
 * 同一条目在不同配置下重复出现，这里**优先保留默认配置**（不带任何限定）的那份，
 * 并把它标记出来 —— 否则列表里会塞满几十种语言变体，反而看不清主线。
 */
object ResourceTableParser {

    /** 单包条目数上限，防畸形文件把内存吃满。 */
    private const val MAX_ENTRIES = 500_000

    private const val NO_ENTRY = 0xFFFFFFFFL

    fun parse(data: ByteArray): ResourceTable {
        val cursor = ByteCursor(data, 0)

        val rootType = cursor.u16()
        cursor.u16() // headerSize
        cursor.i32() // 总长度
        if (rootType != ChunkType.TABLE) {
            throw ResParseException(
                "不是资源表（chunk 类型 ${ChunkType.name(rootType)}）"
            )
        }
        cursor.i32() // packageCount：实际以遍历为准

        var values: ResStringPool? = null
        val packages = mutableListOf<String>()
        val entries = mutableListOf<ResEntry>()

        while (!cursor.atEnd() && entries.size < MAX_ENTRIES) {
            val chunkStart = cursor.pos
            if (cursor.remaining < 8) break

            val chunkType = cursor.u16()
            val headerSize = cursor.u16()
            val chunkSize = cursor.i32()
            if (chunkSize < 8 || chunkStart + chunkSize > data.size) break
            if (headerSize < 8 || headerSize > chunkSize) break

            when (chunkType) {
                ChunkType.STRING_POOL ->
                    values = ResStringPool.parse(data, chunkStart)

                ChunkType.TABLE_PACKAGE -> {
                    if (values == null) {
                        throw ResParseException("资源表缺少全局字符串池，文件已损坏")
                    }
                    val pkg = parsePackage(data, chunkStart, headerSize, chunkSize, values, entries)
                    packages += pkg
                }

                else -> Unit // 库表、overlay 等与逐条资源无关，跳过
            }

            cursor.seek(chunkStart + chunkSize)
        }

        return ResourceTable(
            packages = packages,
            entries = entries,
            valueStringCount = values?.size ?: 0
        )
    }

    /**
     * 解析一个 `TABLE_PACKAGE`，返回包名。
     *
     * 包名存在头部固定长度的 UTF-16 数组里（128 个码元，以 0 结尾），
     * 不是字符串池引用 —— 这一点和包里其它字符串不一样。
     */
    private fun parsePackage(
        data: ByteArray,
        chunkStart: Int,
        headerSize: Int,
        chunkSize: Int,
        values: ResStringPool,
        out: MutableList<ResEntry>
    ): String {
        val head = ByteCursor(data, chunkStart + 8)
        val pkgId = head.i32()

        val nameBytes = head.bytes(256)
        val pkgName = decodeUtf16Z(nameBytes)

        val typeStringsOffset = head.i32()
        head.i32() // lastPublicType
        val keyStringsOffset = head.i32()

        // 类型名池与键名池缺一不可：没有它们就只能拿到一堆数字索引，解析没意义
        val typeNames = runCatching {
            ResStringPool.parse(data, chunkStart + typeStringsOffset)
        }.getOrNull() ?: return pkgName
        val keyNames = runCatching {
            ResStringPool.parse(data, chunkStart + keyStringsOffset)
        }.getOrNull() ?: return pkgName

        // 逐条候选：同一 (type, entry) 可能出现多份配置变体
        val best = HashMap<Int, ResEntry>()

        var pos = chunkStart + headerSize
        val packageEnd = chunkStart + chunkSize

        while (pos + 8 <= packageEnd) {
            val c = ByteCursor(data, pos)
            val type = c.u16()
            val headerSz = c.u16()
            val size = c.i32()
            if (size < 8 || pos + size > packageEnd || headerSz < 8 || headerSz > size) break

            if (type == ChunkType.TABLE_TYPE) {
                runCatching {
                    collectType(data, pos, headerSz, size, pkgId, pkgName, typeNames, keyNames, values, best)
                }
            }
            pos += size
        }

        // 保持稳定顺序：先按类型名，再按键名
        out += best.values.sortedWith(
            compareBy({ resTypeSortKey(it.typeName) }, { it.entryName })
        )
        return pkgName
    }

    private fun collectType(
        data: ByteArray,
        chunkStart: Int,
        headerSize: Int,
        chunkSize: Int,
        pkgId: Int,
        pkgName: String,
        typeNames: ResStringPool,
        keyNames: ResStringPool,
        values: ResStringPool,
        best: HashMap<Int, ResEntry>
    ) {
        val c = ByteCursor(data, chunkStart + 8)
        val typeId = c.u8()
        c.u8()                    // res0
        c.u16()                   // res1
        val entryCount = c.i32()
        val entriesStart = c.i32()
        // headerSize 之后紧跟 entryCount 个 4 字节偏移；config 也包含在 headerSize 里

        if (entryCount <= 0 || entryCount > MAX_ENTRIES) return
        // typeId 从 1 开始计数，池索引要减一
        val typeName = typeNames.nonEmpty(typeId - 1) ?: "type$typeId"

        val isDefault = isDefaultConfig(data, chunkStart + 20, chunkStart + headerSize)
        val entriesAt = chunkStart + entriesStart
        val offsetsAt = chunkStart + headerSize

        val offsetCursor = ByteCursor(data, offsetsAt)
        for (index in 0 until entryCount) {
            val entryOffset = offsetCursor.i32().toLong() and 0xFFFFFFFFL
            if (entryOffset == NO_ENTRY) continue

            val entryAt = entriesAt + entryOffset.toInt()
            if (entryAt + 8 > chunkStart + chunkSize) continue

            val entryCursor = ByteCursor(data, entryAt)
            entryCursor.u16() // entry 结构长度
            val flags = entryCursor.u16()
            val keyIdx = entryCursor.i32()

            val entryName = keyNames.nonEmpty(keyIdx) ?: "entry_$index"
            val resId = (pkgId shl 24) or (typeId shl 16) or index

            val isComplex = flags and 0x0001 != 0
            val valueText = if (isComplex) {
                // bag 类型（style / array / attr 的多值集合）：只报条目数，逐个展开价值不大
                val parent = entryCursor.i32()
                val count = entryCursor.i32()
                val parentNote = if (parent != 0) "，父级 @${AttrNames.unknown(parent)}" else ""
                "（复合值：$count 项$parentNote）"
            } else {
                entryCursor.u16() // Res_value.size
                entryCursor.u8()  // res0
                val dataType = entryCursor.u8()
                val valueData = entryCursor.i32()
                AxmlParser.formatTypedValue(dataType, valueData, values)
            }

            val existing = best[resId]
            // 默认配置优先；没有默认配置时保留最先遇到的
            if (existing == null || (!existing.isDefaultConfig && isDefault)) {
                best[resId] = ResEntry(
                    packageId = pkgId,
                    packageName = pkgName,
                    typeName = typeName,
                    entryName = entryName,
                    resId = resId,
                    value = valueText,
                    isDefaultConfig = isDefault
                )
            }
        }
    }

    /**
     * 判断某份配置是否「默认」（不限定语言、密度、方向等任何维度）。
     *
     * config 结构前 4 字节是它自身的大小，跳过；其余位全 0 即表示不做任何限定。
     */
    private fun isDefaultConfig(data: ByteArray, start: Int, endExclusive: Int): Boolean {
        if (endExclusive <= start) return true
        for (i in start + 4 until endExclusive) {
            if (data[i].toInt() != 0) return false
        }
        return true
    }

    private fun decodeUtf16Z(bytes: ByteArray): String {
        var end = 0
        while (end + 1 < bytes.size) {
            if (bytes[end].toInt() == 0 && bytes[end + 1].toInt() == 0) break
            end += 2
        }
        return if (end == 0) "" else String(bytes, 0, end, Charsets.UTF_16LE)
    }

    /** 让常见类型排在前面，模型的注意力优先落在它们身上。 */
    private fun resTypeSortKey(typeName: String): Int = when (typeName) {
        "string" -> 0
        "drawable" -> 1
        "mipmap" -> 2
        "layout" -> 3
        "xml" -> 4
        "color" -> 5
        "style" -> 6
        "array" -> 7
        "id" -> 8
        else -> 100
    }
}
