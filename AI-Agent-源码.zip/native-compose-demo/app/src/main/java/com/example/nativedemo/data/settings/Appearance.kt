package com.example.nativedemo.data.settings

/**
 * 界面外观的可选项。
 *
 * 放在数据层而不是 UI 层，是因为它们既要被 DataStore 持久化，
 * 又要被主题渲染消费 —— 放中间层两边都不用反向依赖。
 * 具体色值由 `ui.theme` 映射，这里只描述「可选值域」。
 */

/** 品牌色。 */
enum class AppBrand(val label: String) {
    BLUE("深海蓝"),
    TEAL("青碧"),
    VIOLET("紫罗兰"),
    GREEN("松绿"),
    AMBER("琥珀"),
    ROSE("玫红");

    companion object {
        val default = BLUE
        fun parse(raw: String?): AppBrand = entries.firstOrNull { it.name == raw } ?: default
    }
}

/** 深浅模式。 */
enum class ThemeMode(val label: String) {
    SYSTEM("跟随系统"),
    DARK("深色"),
    LIGHT("浅色");

    companion object {
        val default = SYSTEM
        fun parse(raw: String?): ThemeMode = entries.firstOrNull { it.name == raw } ?: default
    }
}

/** 字号档位。以倍数缩放全局 fontScale，所有 sp 尺寸随之变化。 */
enum class FontScaleOption(val label: String, val value: Float) {
    SMALL("小", 0.88f),
    NORMAL("标准", 1.0f),
    LARGE("大", 1.16f);

    companion object {
        val default = NORMAL
        fun parse(raw: String?): FontScaleOption = entries.firstOrNull { it.name == raw } ?: default
    }
}

/** 界面密度：影响消息列表与卡片的纵向留白。 */
enum class UiDensity(val label: String, val value: Float) {
    COMPACT("紧凑", 0.72f),
    STANDARD("标准", 1.0f),
    RELAXED("宽松", 1.32f);

    companion object {
        val default = STANDARD
        fun parse(raw: String?): UiDensity = entries.firstOrNull { it.name == raw } ?: default
    }
}

/**
 * 消息气泡圆角。
 *
 * 属性刻意叫 [radiusDp] 而不是 `dp`：后者会与 Compose 的 `Int.dp` 扩展同名，
 * `corner.dp` 会取到裸 Int，而 `RoundedCornerShape(Int)` 恰好是**百分比**重载 ——
 * 圆角会被静默画成百分比，很难发现。
 */
enum class BubbleCorner(val label: String, val radiusDp: Int) {
    SHARP("直角", 4),
    SMALL("小", 10),
    MEDIUM("中", 16),
    LARGE("大", 22);

    companion object {
        val default = MEDIUM
        fun parse(raw: String?): BubbleCorner = entries.firstOrNull { it.name == raw } ?: default
    }
}

/**
 * 可自定义的颜色槽。
 *
 * [column] 决定在「自定义背景」页里排在左列(0)还是右列(1)——参考截图的两列布局，
 * 按界面上「由外到内」的顺序排：先整体（主题/文字），再逐层（标题栏 → 输入区 → 页面 → 卡片 → 导航）。
 *
 * [MUTED] / [FAINT] 是两档「小字」色：次要说明与备注时间戳用的就是它们，
 * 亮度太低时在背景图上几乎看不见 —— 既可以在这里手动指定，
 * 也可以交给「智能图文适配」按背景图自动推导（见 [BackdropStats]）。
 */
enum class ColorSlot(val label: String, val column: Int) {
    ACCENT("主题色", 0),
    TEXT("正文文字颜色", 1),
    MUTED("次要文字颜色", 1),
    FAINT("备注小字颜色", 0),
    TOP_BAR_BG("标题栏背景色", 0),
    TOP_BAR_FG("标题栏文字颜色", 1),
    INPUT_BAR_BG("输入栏背景色", 0),
    INPUT_BAR_FG("输入栏文字颜色", 1),
    PAGE_BG("页面背景色", 0),
    OVERLAY_BG("弹窗、浮层背景色", 1),
    CARD_BG("卡片背景色", 0),

    /**
     * 内层卡片背景色。
     *
     * 用在「卡片里的卡片」上：工具调用卡、思考卡、代码块、模型档案卡、
     * 终端与日志的底衬等。此前这些位置直接取调色板的 chipBg，而 chipBg
     * 没有对应槽位 —— 用户把卡片背景色改了个遍，这些内层卡片纹丝不动。
     */
    CHIP_BG("内层卡片背景色", 0),
    FIELD_BG("输入框背景色", 1),

    /** 用户消息气泡。同样曾经没有槽位，改了主题色也不跟着变。 */
    USER_BUBBLE("用户气泡背景色", 0),

    /** 分割线与描边。卡片、输入框、列表行的轮廓都取它。 */
    LINE_COLOR("分割线、描边颜色", 1),

    DRAWER_BG("导航栏背景色", 0),
    BANNER_BG("提示、tips 背景色", 1);

    companion object {
        fun parse(raw: String?): ColorSlot? = entries.firstOrNull { it.name == raw }
    }
}

/**
 * 自定义背景图。
 *
 * [uri] 为空表示不使用背景图（走纯色背景）。
 * [blur] 单位 dp；[alpha] 是背景图**不透明度**，1 表示完全不透明。
 * [MIN_ALPHA] 是不透明度下限：低于这个值背景几乎不可见，用户会以为
 * 「图片没有显示」，所以滑块不允许拖到这里。
 *
 * [smartContrast] 是「智能图文适配」开关：开启后按背景图的明暗与繁忙度
 * 自动推导文字颜色（见 [BackdropStats]），让浮在图片上的文字无缝衔接、没有割裂感；
 * 用户在颜色槽里手动调过的值始终优先于此功能。
 * [stats] 是导入背景图时顺手缓存的分析结果，开关切换时不必重新解码图片。
 */
data class BackgroundStyle(
    val uri: String? = null,
    val blur: Float = 0f,
    val alpha: Float = 1f,
    val smartContrast: Boolean = false,
    val stats: BackdropStats? = null
) {
    val enabled: Boolean get() = !uri.isNullOrBlank()

    /** 智能适配实际生效时使用的背景统计；未开启或未分析过时为 null。 */
    val effectiveStats: BackdropStats? get() = stats.takeIf { smartContrast }

    companion object {
        const val MAX_BLUR = 30f
        const val MIN_ALPHA = 0.15f
        val default = BackgroundStyle()
    }
}

/**
 * 背景图的统计特征，「智能图文适配」据此推导文字颜色。
 *
 * [luminance] 是整图的平均相对亮度（WCAG 定义，0 = 纯黑、1 = 纯白）；
 * [busyness] 是画面的「繁忙程度」（相邻像素亮度差的归一化均值）——
 * 越繁忙，文字直接压在图上的割裂感越强，需要的衬底薄纱越厚。
 */
data class BackdropStats(
    val luminance: Float = 0.5f,
    val busyness: Float = 0.3f
) {
    companion object {
        val default = BackdropStats()
    }
}

/** 背景统计的持久化编码：`亮度|繁忙度`，两项都是 0..1 的浮点数。 */
object BackdropStatsCodec {

    fun encode(stats: BackdropStats): String = "${stats.luminance}|${stats.busyness}"

    fun decode(raw: String?): BackdropStats? {
        if (raw.isNullOrBlank()) return null
        val parts = raw.split('|')
        if (parts.size != 2) return null
        val luminance = parts[0].toFloatOrNull() ?: return null
        val busyness = parts[1].toFloatOrNull() ?: return null
        return BackdropStats(
            luminance = luminance.coerceIn(0f, 1f),
            busyness = busyness.coerceIn(0f, 1f)
        )
    }
}

/** 颜色槽的持久化编码：`SLOT|0xAARRGGBB`。 */
object ColorSlotCodec {

    fun encode(slot: ColorSlot, argb: Long): String = "${slot.name}|$argb"

    fun decodeAll(entries: Set<String>): Map<ColorSlot, Long> = buildMap {
        entries.forEach { entry ->
            val parts = entry.split('|')
            if (parts.size != 2) return@forEach
            val slot = ColorSlot.parse(parts[0]) ?: return@forEach
            val value = parts[1].toLongOrNull() ?: return@forEach
            put(slot, value)
        }
    }
}
