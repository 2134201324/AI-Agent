package com.example.nativedemo.ui.chat

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.nativedemo.data.agent.ToolInvocation
import com.example.nativedemo.data.agent.UiMessage
import com.example.nativedemo.data.agent.UiRole
import com.example.nativedemo.ui.common.Banner
import com.example.nativedemo.ui.common.BannerLevel
import com.example.nativedemo.ui.common.CollapseChip
import com.example.nativedemo.ui.theme.Accent
import com.example.nativedemo.ui.theme.Accent2
import com.example.nativedemo.ui.theme.ChipBg
import com.example.nativedemo.ui.theme.Danger
import com.example.nativedemo.ui.theme.Faint
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.InputBarBg
import com.example.nativedemo.ui.theme.InputBarFg
import com.example.nativedemo.ui.theme.LineColor
import com.example.nativedemo.ui.theme.Muted
import com.example.nativedemo.ui.theme.UserBubble

@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    densityScale: Float = 1f,
    bubbleCornerDp: androidx.compose.ui.unit.Dp = 16.dp,
    currentId: String = ""
) {
    val context = LocalContext.current
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val running by viewModel.running.collectAsStateWithLifecycle()

    var input by rememberSaveable { mutableStateOf("") }
    var attachments by remember { mutableStateOf<List<ChatAttachment>>(emptyList()) }

    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { attachments = attachments + resolveAttachment(context, it, ChatAttachment.Kind.FILE) } }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> uri?.let { attachments = attachments + resolveAttachment(context, it, ChatAttachment.Kind.IMAGE) } }

    val folderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> uri?.let { attachments = attachments + resolveAttachment(context, it, ChatAttachment.Kind.DIRECTORY) } }

    // ── 滚动跟随策略 ──
    // follow = 是否自动跟上最新消息。规则：
    // 1. 默认跟随；只有用户主动滑离底部才暂停，滑回底部立即恢复；
    // 2. 生成过程中上翻历史不会被拽回，停下来慢慢看；
    // 3. 滚到「底部锚点」而不是最后一条消息本身 —— 长回复可能比屏幕还高，
    //    scrollToItem(lastIndex) 只会露出它的开头，最新文字永远在屏幕外。
    var follow by remember { mutableStateOf(true) }
    var userActive by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    // 用户滑回底部（含自动滚动结束停在底部）→ 恢复跟随。
    // 注意只对「变为可前滚=false」响应：新内容让列表变长也会翻转 canScrollForward，
    // 但那是 false→true，不碰 follow。
    LaunchedEffect(listState) {
        snapshotFlow { listState.canScrollForward }
            .collect { canForward -> if (!canForward) follow = true }
    }

    // 用户手指按在列表上期间：一离开底部就退出跟随
    LaunchedEffect(userActive) {
        if (userActive) {
            snapshotFlow { listState.canScrollForward }
                .collect { canForward -> if (canForward) follow = false }
        }
    }

    val lastLength = messages.lastOrNull()?.text?.length ?: 0
    val lastToolLength = messages.lastOrNull()?.toolInvocations?.lastOrNull()?.resultPreview?.length ?: 0
    LaunchedEffect(messages.size, lastLength, lastToolLength) {
        if (!follow || messages.isEmpty()) return@LaunchedEffect
        // 锚点是 items 之后的第 messages.size 个（0 基下标），无需读 layoutInfo
        listState.scrollToItem(messages.size)
    }

    // 手动「回到底部」的触发计数。
    //
    // 只把 follow 置回 true 是不够的：上面那个跟随协程的键是「内容长度」，
    // 用户在静止状态下点按钮时这三个键都不会变，协程根本不会重跑 ——
    // 表现就是「点了没反应，还在原地」。用一个自增计数单独触发一次滚动。
    var jumpTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(jumpTick) {
        if (jumpTick == 0 || messages.isEmpty()) return@LaunchedEffect
        // 手动触发时给一段动画，让用户看到「确实滚过去了」，而不是瞬间跳变
        listState.animateScrollToItem(messages.size)
    }

    // 切换会话（打开历史 / 新建 / 删除当前）→ 恢复跟随，让新会话从最新消息开始展示
    LaunchedEffect(currentId) {
        follow = true
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                // 只观测用户手势、不消费：列表自身的滚动手势完全不受影响。
                // 用来区分「用户在翻历史」和「内容自己变长」—— 后者不该暂停跟随。
                .pointerInput(Unit) {
                    while (true) {
                        val startIndex = listState.firstVisibleItemIndex
                        val startOffset = listState.firstVisibleItemScrollOffset
                        // 一次完整手势：按下 → 移动 → 全部手指抬起
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            userActive = true
                            while (true) {
                                val event = awaitPointerEvent(PointerEventPass.Initial)
                                if (event.changes.none { it.pressed }) break
                            }
                        }
                        // 抬手后列表可能还在抛掷：userActive 继续保持，
                        // 等位置稳定（连续两帧不变）再判定最终停在哪
                        var lastIndex = -1
                        while (true) {
                            withFrameNanos { }
                            val now = listState.firstVisibleItemIndex
                            if (now == lastIndex) break
                            lastIndex = now
                        }
                        userActive = false
                        val moved = listState.firstVisibleItemIndex != startIndex ||
                            listState.firstVisibleItemScrollOffset != startOffset
                        // 真的滑过、且没停在底部 → 退出跟随；单击（没移动）不退出
                        if (moved && listState.canScrollForward) follow = false
                    }
                }
        ) {
            if (messages.isEmpty()) {
                EmptyState()
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        horizontal = 16.dp,
                        vertical = (14 * densityScale).dp
                    )
                ) {
                    itemsIndexed(messages, key = { _, message -> message.id }) { index, message ->
                        // 同一轮助手的输出会被拆成多条消息：一段文字、若干工具卡，
                        // 流式过程中还会继续追加。它们属于同一条时间线，不是两个对话轮次 ——
                        // 用轮次间距（18dp）会把碎片之间撑出大片留白，看起来就是
                        // 「输出了一堆无意义的空行」。这里按归属收紧到 4dp。
                        val previous = messages.getOrNull(index - 1)
                        val sameTurn = previous?.role == UiRole.ASSISTANT &&
                            message.role == UiRole.ASSISTANT
                        val gap = if (sameTurn) 4.dp else (18 * densityScale).dp

                        MessageItem(
                            message = message,
                            cornerDp = bubbleCornerDp,
                            // 最新一条始终展开 —— 那正是用户要看的
                            collapsible = message.id != messages.lastOrNull()?.id,
                            onContinue = { viewModel.continueTask() },
                            topSpacing = gap
                        )
                    }
                    // 底部锚点：滚到它就等于看到最新内容。
                    // 长回复可能比视口还高，只滚到最后一条消息会停在它的开头。
                    item(key = "bottom-anchor") {
                        Spacer(Modifier.height(1.dp))
                    }
                }
            }

            // 翻历史时给一个「回到最新」入口：长对话里滑回底部要费不少劲
            if (!follow && messages.isNotEmpty()) {
                JumpToLatestButton(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 14.dp, bottom = 10.dp),
                    onClick = {
                        follow = true
                        jumpTick++ // 显式触发一次滚动，见上面 jumpTick 的说明
                    }
                )
            }
        }

        InputArea(
            value = input,
            running = running,
            attachments = attachments,
            onValueChange = { input = it },
            onRemoveAttachment = { target -> attachments = attachments.filterNot { it.id == target.id } },
            onPickFile = { filePicker.launch(arrayOf("*/*")) },
            onPickImage = { imagePicker.launch("image/*") },
            onPickFolder = { folderPicker.launch(null) },
            onSend = {
                val text = input
                val files = attachments
                input = ""
                attachments = emptyList()
                viewModel.send(text, files)
            },
            onStop = { viewModel.stop() },
            cornerDp = bubbleCornerDp
        )
    }
}

/** 正在生成的消息超过这个长度就自动收起，避免过程叙述刷满屏幕。 */
private const val STREAMING_COLLAPSE_CHARS = 900

@Composable
private fun EmptyState() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        SelectionContainer {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Accent),
                    contentAlignment = Alignment.Center
                ) {
                    Text("A", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(24.dp))
                Text(
                    text = "今天有什么可以帮到你？",
                    color = Fg,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "可以上传文件、图片或整个文件夹让我分析",
                    color = Faint,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun MessageItem(
    message: UiMessage,
    cornerDp: androidx.compose.ui.unit.Dp,
    /** 是否可折叠：历史消息为 true，最新一条为 false。 */
    collapsible: Boolean = false,
    /** 可续跑失败上的「继续执行」回调。 */
    onContinue: () -> Unit = {},
    /**
     * 与上一条之间的间距。
     *
     * 由调用方按「是否属于同一轮助手输出」决定：同一轮内收紧，跨轮才用大间距。
     * 见 ChatScreen 里 LazyColumn 处的说明。
     */
    topSpacing: androidx.compose.ui.unit.Dp = 0.dp
) {
    // ── 历史长消息折叠 ──
    // 对话一长，满屏都是历史回复与代码块，想回到之前某一轮得滑很久。
    // 这里把「较早、够长」的助手消息压成一行摘要：一屏能扫过十几轮，
    // 找历史靠看标题，而不是逐条重读。最新一条与正在流式输出的永不折叠。
    val digest = remember(message.text) { digestMessage(message.text) }
    var expanded by rememberSaveable(message.id) { mutableStateOf(false) }

    // 两种情况收起：
    // ① 历史消息（非最新一条）且内容够长 —— 便于回看旧内容；
    // ② **正在生成但已经很长** —— 有些模型不返回 reasoning_content，而是把大段
    //    "过程叙述"（"让我先看看…""换个思路…"）直接写进正文，思考卡收不到东西，
    //    不折叠就会把屏幕刷满，正在写的结论反而看不见。
    val streamingTooLong = message.streaming && message.text.length >= STREAMING_COLLAPSE_CHARS
    val shouldCollapse = message.role == UiRole.ASSISTANT && if (message.streaming) {
        streamingTooLong
    } else {
        collapsible && digest.worthCollapsing
    }

    // 历史长消息收起态。它整个放在选区容器之外：折叠卡本身是可点击的，
    // 而选区容器会吞掉点击（详见下方说明），套进去就会出现「点不开/点不回去」。
    if (shouldCollapse && !expanded) {
        // 生成中取**末尾**一段做预览：用户关心的是"它现在写到哪了"
        val tail = if (message.streaming) message.text.takeLast(200).trim() else null
        Box(modifier = Modifier.fillMaxWidth().padding(top = topSpacing)) {
            CollapsedMessageCard(
                digest = digest,
                streaming = message.streaming,
                tail = tail
            ) { expanded = true }
        }
        return
    }

    // ── 全局文字可选，但**可点击的卡片必须留在选区容器之外** ──
    //
    // SelectionContainer 为了「点击空白处取消选区」会拦截容器内的点击事件，
    // 于是放在它里面的 clickable 卡片（思考卡、工具卡、代码块）会出现
    // 「展开之后点不回去」：手势被选区层吃掉，卡片的点击回调根本收不到。
    // 早先版本把整条消息连卡片一起包进一个选区容器，就是这个毛病。
    //
    // 现在的分法：只把**纯文本**包进选区容器（文字照样长按可选中复制），
    // 所有交互卡片作为兄弟节点渲染在容器外，两套手势各管各的。
    when (message.role) {
        UiRole.USER -> SelectionContainer(modifier = Modifier.padding(top = topSpacing)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Box(
                    modifier = Modifier
                        .widthIn(max = 300.dp)
                        .background(UserBubble, RoundedCornerShape(cornerDp))
                        .padding(horizontal = 15.dp, vertical = 11.dp)
                ) {
                    Text(message.text, color = Fg, fontSize = 15.sp, lineHeight = 22.sp)
                }
            }
        }

        UiRole.ASSISTANT -> Column(modifier = Modifier.fillMaxWidth().padding(top = topSpacing)) {
            // 思考过程折叠收集：推理模型的思考可能很长，默认收起不挤占对话流。
            // 同时它也是「模型在动」的可见证据 —— 长思考期间界面不再一片死寂。
            message.thinking?.takeIf { it.isNotBlank() }?.let { thinking ->
                ThinkingBlockCard(
                    thinking = thinking,
                    streaming = message.streaming,
                    stateKey = message.id
                )
                Spacer(Modifier.height(8.dp))
            }

            // 代码块折叠收集：长串代码不铺满对话流，按需展开
            val segments = remember(message.text) { parseMessageSegments(message.text) }
            var codeIndex = 0
            segments.forEachIndexed { position, segment ->
                when (segment) {
                    is MsgSegment.Text -> {
                        // 流式光标只加在最后的文本段；未闭合代码块自带「生成中」标识
                        val cursor =
                            if (message.streaming && position == segments.lastIndex) " ▍" else ""
                        if (segment.text.isNotBlank() || cursor.isNotEmpty()) {
                            // 每段正文各包一个选区容器，而不是整条消息共用一个：
                            // 这样穿插其中的代码块、工具卡就落在容器之外了。
                            // 文本先做一次换行规整：模型常吐一串换行，直接渲染就是大片空行。
                            SelectionContainer {
                                Text(
                                    text = normalizeDisplayText(segment.text) + cursor,
                                    color = Fg,
                                    fontSize = 15.sp,
                                    lineHeight = 23.sp
                                )
                            }
                        }
                    }

                    is MsgSegment.Code -> {
                        if (codeIndex > 0) Spacer(Modifier.height(10.dp))
                        CollapsibleCodeBlock(
                            segment = segment,
                            index = codeIndex,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        codeIndex++
                    }
                }
            }
            // 刚开始生成、还没有任何内容时，给一个光标表明正在输出
            if (segments.isEmpty() && message.streaming) {
                Text(" ▍", color = Fg, fontSize = 15.sp, lineHeight = 23.sp)
            }
            message.toolInvocations.forEach { invocation ->
                if (message.text.isNotBlank()) Spacer(Modifier.height(10.dp))
                ToolCallCard(invocation)
            }

            // 历史长消息展开后给一个收起入口。用的是统一的强调色控件而不是
            // 一行备注色小字 —— 后者在长消息底部几乎不可见，用户会以为收不回去。
            if (shouldCollapse) {
                Spacer(Modifier.height(8.dp))
                CollapseChip(text = "▴ 收起这条回复") { expanded = false }
            }
        }

        UiRole.ERROR -> Column(modifier = Modifier.fillMaxWidth().padding(top = topSpacing)) {
            SelectionContainer {
                Banner(text = message.text, level = BannerLevel.ERROR)
            }
            // 「可以接着做」的失败给一个一键继续：用户不必自己想提示词。
            // 进度都在会话里，再发一句话就等于从断点续跑。
            // 注意它同样要留在选区容器之外，否则按钮会被选区手势吞掉。
            if (message.resumable) {
                Spacer(Modifier.height(8.dp))
                CollapseChip(text = "▶ 继续执行（从断点接着做）", onClick = onContinue)
            }
        }

        UiRole.SYSTEM -> SelectionContainer(modifier = Modifier.padding(top = topSpacing)) {
            Banner(text = message.text, level = BannerLevel.INFO)
        }
    }
}

/**
 * 工具调用卡：参考图同款折叠块。
 *
 * 折叠态只占一行（状态图标 + 工具名 + 状态 + 参数摘要），展开才看参数与结果。
 * 展开态遵循「执行中自动展开、完成后自动收起」：执行时用户要看到实时进展，
 * 完成后收回一行，长对话里十几二十次调用也不会把屏幕糊满。
 * 用户手动点过的以用户的为准（[manual] 非空时不再自动变）。
 */
@Composable
private fun ToolCallCard(invocation: ToolInvocation) {
    var manual by rememberSaveable(invocation.callId) { mutableStateOf<Boolean?>(null) }
    val expanded = manual ?: (invocation.state == ToolInvocation.State.RUNNING)

    val color = when (invocation.state) {
        ToolInvocation.State.RUNNING -> Accent
        ToolInvocation.State.SUCCESS -> Accent2
        ToolInvocation.State.FAILED -> Danger
    }
    val statusText = when (invocation.state) {
        ToolInvocation.State.RUNNING -> "执行中"
        ToolInvocation.State.SUCCESS -> "已完成"
        ToolInvocation.State.FAILED -> "失败"
    }
    val statusIcon = when (invocation.state) {
        ToolInvocation.State.RUNNING -> "●"
        ToolInvocation.State.SUCCESS -> "✓"
        ToolInvocation.State.FAILED -> "✗"
    }
    val hasDetail = invocation.arguments.isNotBlank() || !invocation.resultPreview.isNullOrBlank()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ChipBg, RoundedCornerShape(12.dp))
            .border(1.dp, LineColor, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        // 开关区 = 标题行 + 折叠态的摘要行。展开后的参数/结果文本要能长按选中，
        // 所以它们各自带选区容器，反过来就不能再让整张卡做 clickable ——
        // 否则又回到「点不动」的老问题。
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .then(if (hasDetail) Modifier.clickable { manual = !expanded } else Modifier)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = statusIcon,
                    color = color,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = invocation.name,
                    color = color,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.width(8.dp))
                Text(statusText, color = Faint, fontSize = 11.sp)
                if (hasDetail) {
                    Spacer(Modifier.weight(1f))
                    Text(
                        text = if (expanded) "收起" else "展开",
                        color = Faint,
                        fontSize = 11.sp
                    )
                }
            }

            // 折叠态：一行参数摘要，让用户不看详情也知道这步在干什么
            if (!expanded && invocation.arguments.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = invocation.arguments.replace('\n', ' ').trim().take(80),
                    color = Muted,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
        }

        if (expanded) {
            if (invocation.arguments.isNotBlank()) {
                Spacer(Modifier.height(7.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 120.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(Fg.copy(alpha = 0.05f))
                        .verticalScroll(rememberScrollState())
                        .padding(9.dp)
                ) {
                    SelectionContainer {
                        Text(
                            text = invocation.arguments,
                            color = Muted,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            invocation.resultPreview?.takeIf { it.isNotBlank() }?.let { preview ->
                Spacer(Modifier.height(7.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 160.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(Fg.copy(alpha = 0.05f))
                        .verticalScroll(rememberScrollState())
                        .padding(9.dp)
                ) {
                    SelectionContainer {
                        Text(preview, color = Fg, fontSize = 11.sp, lineHeight = 16.sp)
                    }
                }
            }

            if (hasDetail) {
                Spacer(Modifier.height(6.dp))
                CollapseChip(text = "▴ 收起") { manual = false }
            }
        }
    }
}

@Composable
private fun InputArea(
    value: String,
    running: Boolean,
    attachments: List<ChatAttachment>,
    onValueChange: (String) -> Unit,
    onRemoveAttachment: (ChatAttachment) -> Unit,
    onPickFile: () -> Unit,
    onPickImage: () -> Unit,
    onPickFolder: () -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    cornerDp: androidx.compose.ui.unit.Dp
) {
    val canSend = (value.isNotBlank() || attachments.isNotEmpty()) && !running

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .imePadding()
            .padding(horizontal = 10.dp)
            .padding(top = 4.dp, bottom = 10.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(InputBarBg, RoundedCornerShape(cornerDp + 6.dp))
                .padding(start = 12.dp, end = 10.dp, top = 6.dp, bottom = 8.dp)
        ) {
            if (attachments.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    attachments.forEach { attachment ->
                        AttachmentChip(attachment) { onRemoveAttachment(attachment) }
                    }
                }
            }

            TextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("发消息…", color = Faint, fontSize = 15.sp) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    cursorColor = Accent,
                    focusedTextColor = InputBarFg,
                    unfocusedTextColor = InputBarFg,
                    disabledTextColor = Muted
                ),
                maxLines = 5,
                enabled = !running
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AttachmentButton(
                    enabled = !running,
                    onPickFile = onPickFile,
                    onPickImage = onPickImage,
                    onPickFolder = onPickFolder
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = if (running) "生成中…" else "工具已就绪",
                    color = Muted,
                    fontSize = 12.sp
                )
                Spacer(Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                running -> ChipBg
                                canSend -> Accent
                                else -> ChipBg
                            }
                        )
                        .clickable(enabled = running || canSend) {
                            if (running) onStop() else onSend()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (running) Icons.Default.Close else Icons.Default.Send,
                        contentDescription = if (running) "停止" else "发送",
                        tint = when {
                            running -> Danger
                            canSend -> Color.White
                            else -> Faint
                        },
                        modifier = Modifier.size(17.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun AttachmentButton(
    enabled: Boolean,
    onPickFile: () -> Unit,
    onPickImage: () -> Unit,
    onPickFolder: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(ChipBg)
                .clickable(enabled = enabled) { expanded = true },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "添加附件",
                tint = if (enabled) Fg else Faint,
                modifier = Modifier.size(18.dp)
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            DropdownMenuItem(
                text = { Text("上传文件", fontSize = 14.sp) },
                onClick = { expanded = false; onPickFile() }
            )
            DropdownMenuItem(
                text = { Text("上传图片", fontSize = 14.sp) },
                onClick = { expanded = false; onPickImage() }
            )
            DropdownMenuItem(
                text = { Text("上传文件夹", fontSize = 14.sp) },
                onClick = { expanded = false; onPickFolder() }
            )
        }
    }
}

@Composable
private fun AttachmentChip(attachment: ChatAttachment, onRemove: () -> Unit) {
    val icon = when (attachment.kind) {
        ChatAttachment.Kind.FILE -> "📎"
        ChatAttachment.Kind.IMAGE -> "🖼"
        ChatAttachment.Kind.DIRECTORY -> "📁"
    }

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(ChipBg)
            .border(1.dp, LineColor, RoundedCornerShape(10.dp))
            .padding(start = 10.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = icon, fontSize = 12.sp)
        Spacer(Modifier.width(6.dp))
        Column {
            Text(
                text = attachment.name,
                color = Fg,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 130.dp)
            )
            if (attachment.displaySize.isNotBlank()) {
                Text(attachment.displaySize, color = Faint, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.width(6.dp))
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .clickable(onClick = onRemove),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "移除附件",
                tint = Faint,
                modifier = Modifier.size(13.dp)
            )
        }
    }
}

/** 从 content URI 解析出文件名、大小与 MIME。 */
private fun resolveAttachment(
    context: Context,
    uri: Uri,
    kind: ChatAttachment.Kind
): ChatAttachment {
    var name = uri.lastPathSegment?.substringAfterLast('/') ?: "未命名"
    var size = 0L
    var mime = ""

    runCatching {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0) {
                    cursor.getString(nameIndex)?.takeIf { it.isNotBlank() }?.let { name = it }
                }
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                    size = cursor.getLong(sizeIndex)
                }
            }
        }
        mime = context.contentResolver.getType(uri).orEmpty()
    }

    return ChatAttachment(uri = uri, name = name, kind = kind, sizeBytes = size, mimeType = mime)
}

/**
 * 折叠态的历史助手消息。
 *
 * 刻意做得像一张"卡片"而不是普通文字：它其实是**被收起的内容**，
 * 外观上要让用户一眼看出「这里可以点开」，而不是以为消息丢了。
 */
@Composable
private fun CollapsedMessageCard(
    digest: MessageDigest,
    streaming: Boolean = false,
    /** 生成中的末尾预览；历史消息传 null，改用摘要。 */
    tail: String? = null,
    onExpand: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ChipBg)
            .border(1.dp, LineColor, RoundedCornerShape(10.dp))
            .clickable { onExpand() }
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(
            text = (tail ?: digest.preview).ifBlank { "（等待模型输出…）" },
            color = Muted,
            fontSize = 13.sp,
            lineHeight = 19.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = buildString {
                append("▸ 展开全文")
                append(" · ${digest.textLength} 字")
                if (digest.codeBlocks > 0) {
                    append(" · ${digest.codeBlocks} 段代码（${digest.codeLines} 行）")
                }
                if (streaming) append(" · 生成中…")
            },
            color = Accent,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

/** 「回到最新」浮动按钮，只在用户翻离底部时出现。 */
@Composable
private fun JumpToLatestButton(modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(ChipBg)
            .border(1.dp, LineColor, CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text("↓", color = Accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}
