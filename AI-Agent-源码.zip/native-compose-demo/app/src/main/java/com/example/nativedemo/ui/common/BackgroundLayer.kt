package com.example.nativedemo.ui.common

import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.nativedemo.data.settings.BackgroundStyle
import com.example.nativedemo.ui.theme.smartScrim

/**
 * 图片加载状态。
 *
 * Failed 是显式状态而不是"什么都没有"：解码失败（HEIC、文件损坏、超大图
 * OOM……）时 UI 必须给出"点击更换"的提示，不能让用户对着一片空白猜原因。
 */
sealed interface ImageLoadState {
    data object Loading : ImageLoadState
    data class Ready(val bitmap: ImageBitmap) : ImageLoadState
    data object Failed : ImageLoadState
}

/** 按来源异步加载位图，来源变化时自动重新加载。 */
@Composable
fun rememberImageState(source: String?, maxEdge: Int = 1600): ImageLoadState {
    val context = LocalContext.current
    var state by remember { mutableStateOf<ImageLoadState>(ImageLoadState.Loading) }

    LaunchedEffect(source) {
        state = if (source.isNullOrBlank()) {
            ImageLoadState.Failed
        } else {
            decodeImage(context, source, maxEdge)
                ?.let { ImageLoadState.Ready(it.asImageBitmap()) }
                ?: ImageLoadState.Failed
        }
    }
    return state
}

/**
 * 背景图层。
 *
 * 模糊用 Compose 的 blur modifier，它依赖 Android 12+ 的 RenderEffect；
 * 在更低的系统上该 modifier 是空操作，所以额外用「降低不透明度」来软化背景，
 * 避免老机型上壁纸太抢眼、把正文压得看不清。
 *
 * 解码失败时静默返回（不画），由「自定义背景」页的预览负责提示用户换图 ——
 * 全局背景上弹错误没有合适的落点。
 *
 * 「智能图文适配」开启时，图上再盖一层与文字极性相反的薄纱：
 * 画面越繁忙薄纱越厚，文字像融在图上而不是贴在图上，没有割裂感。
 */
@Composable
fun BackgroundLayer(style: BackgroundStyle, modifier: Modifier = Modifier) {
    if (!style.enabled) return
    val state = rememberImageState(style.uri, maxEdge = 1400)
    if (state !is ImageLoadState.Ready) return

    val supportsBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val blurRadius = if (supportsBlur) style.blur.dp else 0.dp
    val alpha = if (supportsBlur) style.alpha else style.alpha * 0.65f
    val scrim = style.effectiveStats?.let { smartScrim(it) }

    Box(modifier = modifier.fillMaxSize()) {
        Image(
            bitmap = state.bitmap,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alpha = alpha,
            modifier = Modifier
                .fillMaxSize()
                .blur(blurRadius)
        )
        if (scrim != null) {
            Box(modifier = Modifier.fillMaxSize().background(scrim))
        }
    }
}
