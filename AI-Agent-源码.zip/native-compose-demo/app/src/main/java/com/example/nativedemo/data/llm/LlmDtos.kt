package com.example.nativedemo.data.llm

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive

/** OpenAI 兼容 /chat/completions 的请求与响应模型。 */

@Serializable
data class ChatMessage(
    val role: String,
    /**
     * 刻意用 JsonElement 而不是 String：
     * 纯文本时是 JSON 字符串，多模态（图片）时是内容数组 —— 两者共用同一个字段名 `content`，
     * 无法用单一 String 类型表达。
     */
    val content: JsonElement? = null,
    @SerialName("tool_calls") val toolCalls: List<ToolCall>? = null,
    @SerialName("tool_call_id") val toolCallId: String? = null,
    val name: String? = null
) {
    /** 提取纯文本部分（多模态内容会拼接其中的 text 段）。 */
    val textContent: String? get() = content.asTextOrNull()

    companion object {
        fun system(text: String) = ChatMessage(role = "system", content = JsonPrimitive(text))
        fun user(text: String) = ChatMessage(role = "user", content = JsonPrimitive(text))
        fun assistant(text: String) = ChatMessage(role = "assistant", content = JsonPrimitive(text))
        fun tool(callId: String, text: String) = ChatMessage(
            role = "tool",
            content = JsonPrimitive(text),
            toolCallId = callId
        )

        /**
         * 多模态用户消息：文本 + 图片混排。
         *
         * 即使只有一个分片也仍然包成**数组**。早先图省事地把单分片直接取出来，
         * 结果是「只发一张图、不写字」时 content 变成**对象**——既不是字符串也不是
         * 数组，比数组更容易被服务端拒绝，而且错误信息更难懂。
         */
        fun userWithParts(parts: List<JsonElement>) = ChatMessage(
            role = "user",
            content = JsonArray(parts)
        )
    }
}

/** 从可能为 null / 字符串 / 内容数组的 content 中还原出可读文本。 */
fun JsonElement?.asTextOrNull(): String? = when (this) {
    null, JsonNull -> null
    is JsonPrimitive -> contentOrNull
    is JsonArray -> joinToString("") { element ->
        when (element) {
            is JsonObject -> element["text"]?.jsonPrimitive?.contentOrNull ?: ""
            is JsonPrimitive -> element.contentOrNull ?: ""
            else -> ""
        }
    }
    else -> null
}

@Serializable
data class ToolCall(
    val id: String,
    val type: String = "function",
    val function: FunctionCall
)

@Serializable
data class FunctionCall(
    val name: String,
    val arguments: String = ""
)

/** 发送给模型的工具声明。parameters 即 JSON Schema。 */
@Serializable
data class ToolDefinition(
    val type: String = "function",
    val function: FunctionDefinition
)

@Serializable
data class FunctionDefinition(
    val name: String,
    val description: String,
    val parameters: JsonElement
)

@Serializable
data class ChatRequest(
    val model: String,
    val messages: List<ChatMessage>,
    val tools: List<ToolDefinition>? = null,
    @SerialName("tool_choice") val toolChoice: String? = null,
    val temperature: Double? = null,
    /**
     * 显式给足输出上限。
     *
     * 不设的话服务端默认值往往偏小，而**工具调用的参数也算在 completion tokens 里** ——
     * 参数一长就会在生成中途被截断，产出残缺 JSON。这是「参数解析失败」的头号成因。
     */
    @SerialName("max_tokens") val maxTokens: Int? = null,
    val stream: Boolean = false
)

@Serializable
data class ChatResponse(
    val id: String? = null,
    val model: String? = null,
    val choices: List<Choice> = emptyList(),
    val usage: Usage? = null,
    /**
     * 流式响应**非正常结束**（连接被中途掐断）时置 true。
     *
     * 此时 [choices] 里仍带着断流前已收到的内容 —— 上层据此自动续写，
     * 而不是把几百字已经生成好、用户也已经看到的回答整段丢掉。
     */
    @kotlinx.serialization.Transient val incomplete: Boolean = false
) {
    val firstMessage: ChatMessage? get() = choices.firstOrNull()?.message
    val finishReason: String? get() = choices.firstOrNull()?.finishReason
}

@Serializable
data class Choice(
    val index: Int = 0,
    val message: ChatMessage? = null,
    val delta: ChatMessage? = null,
    @SerialName("finish_reason") val finishReason: String? = null
)

@Serializable
data class Usage(
    @SerialName("prompt_tokens") val promptTokens: Int = 0,
    @SerialName("completion_tokens") val completionTokens: Int = 0,
    @SerialName("total_tokens") val totalTokens: Int = 0
)

/** 服务端错误响应体。 */
@Serializable
data class ApiErrorEnvelope(val error: ApiError? = null)

@Serializable
data class ApiError(
    val message: String = "",
    val type: String? = null,
    val code: String? = null
)

// ── SSE 流式分片模型 ───────────────────────────────────────────────────

@Serializable
data class StreamChunk(
    val id: String? = null,
    val model: String? = null,
    val choices: List<StreamChoice> = emptyList()
)

@Serializable
data class StreamChoice(
    val index: Int = 0,
    val delta: StreamDelta? = null,
    @SerialName("finish_reason") val finishReason: String? = null
)

@Serializable
data class StreamDelta(
    val role: String? = null,
    val content: String? = null,
    /**
     * 推理模型的思考内容。
     *
     * 各家字段名不统一：DeepSeek / 智谱 / 百炼多用 `reasoning_content`，
     * 部分网关用 `reasoning`。两者都收，否则「思考强度大」时客户端会长时间
     * 收不到任何可见内容，看起来就像卡住或中断。
     */
    @SerialName("reasoning_content") val reasoningContent: String? = null,
    val reasoning: String? = null,
    @SerialName("tool_calls") val toolCalls: List<StreamToolCall>? = null
)

/** 流式下 tool_calls 会分片下发，靠 index 归并、arguments 逐段拼接。 */
@Serializable
data class StreamToolCall(
    val index: Int? = null,
    val id: String? = null,
    val type: String? = null,
    val function: StreamFunction? = null
)

@Serializable
data class StreamFunction(
    val name: String? = null,
    val arguments: String? = null
)

/**
 * GET /models 的响应（OpenAI 兼容）。
 *
 * 各家实现并不统一：标准形态是 `{"data":[{"id":"..."}]}`，也有网关直接返回
 * 模型名字符串数组、或包一层 `{"models":[...]}`。所以解析必须容错 ——
 * 见 [com.example.nativedemo.data.llm.parseModelIds]。
 */
@Serializable
data class ModelListResponse(
    val data: List<ModelEntry>? = null,
    val models: List<ModelEntry>? = null
)

@Serializable
data class ModelEntry(
    val id: String = "",
    val objectType: String? = null,
    val ownedBy: String? = null
)

/**
 * 从 GET /models 的响应体里提取模型 id 清单（容错解析，纯函数）。
 *
 * 兼容三种常见形态：
 * 1. 标准 OpenAI：`{"object":"list","data":[{"id":"gpt-4o"},…]}`；
 * 2. 部分网关：`{"models":[{"id":"…"},…]}` 或 `{"models":["…",…]}`；
 * 3. 裸数组：`[{"id":"…"},…]` / `["…",…]`。
 *
 * 任何不认识的形态都返回空列表而不是抛异常 —— 调用方（含局域网扫描）
 * 用「空」判断「这不是一个模型清单端点」，比崩溃友好得多。
 */
fun parseModelIds(raw: String): List<String> {
    if (raw.isBlank()) return emptyList()
    val element = try {
        Json.parseToJsonElement(raw.trim())
    } catch (t: Throwable) {
        return emptyList()
    }
    val items: JsonArray? = when (element) {
        is JsonArray -> element
        is JsonObject -> (element["data"] ?: element["models"]) as? JsonArray
        else -> null
    }
    return items?.mapNotNull { item ->
        when (item) {
            // 模型 id 必然是字符串：数字 / 布尔一律不认，
            // 否则随便一个带 data 数组的 JSON 接口都会被误判成模型服务
            is JsonPrimitive -> item.contentOrNull.takeIf { item.isString }
            is JsonObject -> item["id"]?.jsonPrimitive?.takeIf { it.isString }?.contentOrNull
            else -> null
        }
    }?.filter { it.isNotBlank() }?.distinct() ?: emptyList()
}
