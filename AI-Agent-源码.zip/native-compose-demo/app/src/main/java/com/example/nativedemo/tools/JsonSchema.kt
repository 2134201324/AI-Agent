package com.example.nativedemo.tools

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * 极简 JSON Schema 构造 DSL。
 *
 * 以 kotlinx 的 JsonObject 作为唯一载体，直接嵌入 OpenAI tools 的 `parameters` 字段，
 * 避免自造类型再转换。
 */
fun objectSchema(block: ObjectSchemaBuilder.() -> Unit): JsonObject =
    ObjectSchemaBuilder().apply(block).build()

class ObjectSchemaBuilder {

    private val properties = linkedMapOf<String, JsonElement>()
    private val requiredNames = mutableListOf<String>()

    private fun add(name: String, schema: JsonElement, required: Boolean) {
        properties[name] = schema
        if (required) requiredNames += name
    }

    fun string(
        name: String,
        description: String,
        required: Boolean = true,
        enumValues: List<String>? = null
    ) {
        val map = mutableMapOf<String, JsonElement>(
            "type" to JsonPrimitive("string"),
            "description" to JsonPrimitive(description)
        )
        if (!enumValues.isNullOrEmpty()) {
            map["enum"] = JsonArray(enumValues.map { JsonPrimitive(it) })
        }
        add(name, JsonObject(map), required)
    }

    fun integer(name: String, description: String, required: Boolean = true) {
        add(
            name,
            JsonObject(
                mapOf(
                    "type" to JsonPrimitive("integer"),
                    "description" to JsonPrimitive(description)
                )
            ),
            required
        )
    }

    fun boolean(name: String, description: String, required: Boolean = false) {
        add(
            name,
            JsonObject(
                mapOf(
                    "type" to JsonPrimitive("boolean"),
                    "description" to JsonPrimitive(description)
                )
            ),
            required
        )
    }

    fun build(): JsonObject = JsonObject(
        linkedMapOf(
            "type" to JsonPrimitive("object"),
            "properties" to JsonObject(properties),
            "required" to JsonArray(requiredNames.map { JsonPrimitive(it) })
        )
    )
}
