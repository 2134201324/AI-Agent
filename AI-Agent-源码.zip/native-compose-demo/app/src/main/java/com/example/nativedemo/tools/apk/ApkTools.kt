package com.example.nativedemo.tools.apk

import android.content.Context
import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.int
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import com.example.nativedemo.tools.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import java.util.Locale

/**
 * APK 逆向工具集的公共部分。
 *
 * 所有工具都遵循同一条准入链：**路径 → 已授权目录校验 → 复制到私有缓存 → 分析**。
 * 放进基类而不是各写一遍，是为了保证「任何一个工具都不会绕过授权检查」——
 * 安全约束集中在一处才守得住。
 */
abstract class ApkToolBase(protected val context: Context) : Tool {

    protected val analyzer: ApkAnalyzer by lazy { ApkAnalyzer(context) }

    /**
     * 打开 APK 并在其上执行 [block]。
     *
     * 失败一律转成 [ToolResult.Failure] 而不是抛异常：工具失败不该中断整条 Agent 链路，
     * 让模型拿到原因后自行调整（比如换个路径、先 list 一下）才是正确的处理方式。
     */
    protected suspend fun openAndUse(
        pathArg: String,
        ctx: ToolContext,
        block: suspend (ApkArchive) -> String
    ): ToolResult {
        val document = ctx.uriAccessPolicy.resolveDocument(pathArg)
            ?: return ToolResult.failure(
                "未找到「$pathArg」。请确认路径正确，或用 file_list 查看已授权目录里有哪些文件。"
            )
        if (document.isDirectory) {
            return ToolResult.failure("「$pathArg」是一个目录，请给出具体的 .apk 文件路径。")
        }
        ctx.uriAccessPolicy.denyReason(document.uri, write = false)?.let {
            return ToolResult.failure(it)
        }

        return withContext(Dispatchers.IO) {
            try {
                ApkArchive.open(ctx.appContext, document.uri).use { archive ->
                    ToolResult.success(block(archive))
                }
            } catch (e: ResParseException) {
                ToolResult.failure("解析失败：${e.message}")
            } catch (e: SecurityException) {
                ToolResult.failure("权限不足：${e.message}")
            } catch (e: Throwable) {
                ToolResult.failure("分析失败：${e.message ?: e::class.java.simpleName}")
            }
        }
    }

    /** 统一取 path 参数并处理缺参。 */
    protected fun requirePath(args: JsonObject): String? =
        runCatching { args.requireStr("path") }.getOrNull()
}

// ── 1. 总览 ────────────────────────────────────────────────────────────

class ApkInfoTool(context: Context) : ApkToolBase(context) {
    override val spec = ToolSpec(
        name = "apk_info",
        description = "对设备上的一个 APK 文件做**整体分析**：包名、版本、SDK 版本、权限、" +
            "四大组件（含哪些被导出）、签名方案、dex 与 native 库结构、资源规模，" +
            "并在末尾列出值得注意的风险点（可调试、明文流量、加固特征等）。" +
            "**分析 APK 的第一步就用它**，之后再按需深入 manifest / dex / 资源。",
        category = "逆向",
        layer = "L2",
        params = objectSchema {
            string("path", "APK 文件路径，例如 Download/app.apk")
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = requirePath(args) ?: return ToolResult.failure("缺少必填参数 'path'")
        return openAndUse(path, ctx) { analyzer.overview(it) }
    }
}

// ── 2. Manifest ────────────────────────────────────────────────────────

class ApkManifestTool(context: Context) : ApkToolBase(context) {
    override val spec = ToolSpec(
        name = "apk_manifest",
        description = "把 APK 里的 AndroidManifest.xml **解码成可读 XML**（包内是二进制格式，" +
            "直接读是乱码）。想看清某个 activity 的全部属性、intent-filter 的 action/data、" +
            "provider 的 authorities 或权限声明时用它。",
        category = "逆向",
        layer = "L2",
        params = objectSchema {
            string("path", "APK 文件路径")
            integer("max_chars", "最多返回的字符数，默认 60000", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = requirePath(args) ?: return ToolResult.failure("缺少必填参数 'path'")
        val maxChars = args.int("max_chars", 60_000).coerceIn(2_000, 400_000)
        return openAndUse(path, ctx) { analyzer.manifestXml(it, maxChars) }
    }
}

// ── 3. 条目浏览 ────────────────────────────────────────────────────────

class ApkListTool(context: Context) : ApkToolBase(context) {
    override val spec = ToolSpec(
        name = "apk_list",
        description = "列出 APK 内部的所有文件条目（类似 unzip -l），可按路径关键字过滤、" +
            "按大小排序 —— 用来找大文件、找 native 库、确认某个资源是否存在。" +
            "**在使用 apk_read 之前，建议先用它确认准确路径**。",
        category = "逆向",
        layer = "L2",
        params = objectSchema {
            string("path", "APK 文件路径")
            string("pattern", "路径关键字过滤，如 lib/ 或 .so 或 res/raw", required = false)
            string(
                "sort_by",
                "排序方式：name（按名）、size（按大小降序）、none（原始顺序，默认）",
                required = false,
                enumValues = listOf("name", "size", "none")
            )
            integer("limit", "最多返回条数，默认 200", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = requirePath(args) ?: return ToolResult.failure("缺少必填参数 'path'")
        val pattern = args.str("pattern")
        val sortBy = args.str("sort_by") ?: "none"
        val limit = args.int("limit", 200).coerceIn(1, 5_000)
        return openAndUse(path, ctx) { analyzer.listEntries(it, pattern, sortBy, limit) }
    }
}

// ── 4. 读取条目 ────────────────────────────────────────────────────────

class ApkReadTool(context: Context) : ApkToolBase(context) {
    override val spec = ToolSpec(
        name = "apk_read",
        description = "读取 APK 内某个文件的**内容**。会按类型自动处理：二进制 XML 自动解码、" +
            "dex 给出结构统计、resources.arsc 给出资源概况、文本文件直出内容、" +
            "其它二进制给十六进制文件头（可用于识别真实类型）。",
        category = "逆向",
        layer = "L2",
        params = objectSchema {
            string("path", "APK 文件路径")
            string("entry", "包内条目路径，如 res/raw/config.json 或 lib/arm64-v8a/libx.so")
            integer("max_chars", "文本内容最多返回的字符数，默认 20000", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = requirePath(args) ?: return ToolResult.failure("缺少必填参数 'path'")
        val entry = args.str("entry") ?: return ToolResult.failure("缺少必填参数 'entry'")
        val maxChars = args.int("max_chars", 20_000).coerceIn(500, 200_000)
        return openAndUse(path, ctx) { analyzer.readEntry(it, entry, maxChars) }
    }
}

// ── 5. DEX 查询 ────────────────────────────────────────────────────────

class ApkDexTool(context: Context) : ApkToolBase(context) {
    override val spec = ToolSpec(
        name = "apk_dex",
        description = "查询 APK 的**代码结构**（classes.dex）。四种模式：" +
            "stat 总体统计；classes 列类（含父类与成员数量）；" +
            "methods 列方法；strings 列字符串池里的字面量。" +
            "逆向里最常用的入口：用 classes 看有没有加固/混淆（类名是否退化成 a/a/a）、" +
            "用 methods 搜索敏感 API、用 strings 找硬编码的 URL 与密钥。",
        category = "逆向",
        layer = "L2",
        params = objectSchema {
            string("path", "APK 文件路径")
            string(
                "mode",
                "查询模式：stat（统计，默认）/ classes（类列表）/ methods（方法列表）/ strings（字符串）",
                required = false,
                enumValues = listOf("stat", "classes", "methods", "strings")
            )
            string("dex", "指定 dex 文件名，如 classes2.dex；缺省则查全部", required = false)
            string("keyword", "过滤关键字（类名 / 方法名 / 字符串内容，子串匹配）", required = false)
            integer("limit", "最多返回条数，默认 100", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = requirePath(args) ?: return ToolResult.failure("缺少必填参数 'path'")
        val mode = args.str("mode") ?: "stat"
        val dex = args.str("dex")
        val keyword = args.str("keyword")
        val limit = args.int("limit", 100).coerceIn(1, 3_000)
        return openAndUse(path, ctx) { analyzer.dexQuery(it, mode, dex, keyword, limit) }
    }
}

// ── 6. 资源表 ──────────────────────────────────────────────────────────

class ApkResourcesTool(context: Context) : ApkToolBase(context) {
    override val spec = ToolSpec(
        name = "apk_resources",
        description = "查询 APK 的资源表（resources.arsc）：按类型（string / drawable / layout …）" +
            "或关键字列出资源项及其取值。用途：还原 manifest 里 @string/xxx 的真实文案、" +
            "定位界面标题、找出硬编码在资源里的地址或提示语。",
        category = "逆向",
        layer = "L2",
        params = objectSchema {
            string("path", "APK 文件路径")
            string("type", "资源类型过滤，如 string / drawable / layout / color", required = false)
            string("keyword", "在资源名与值里做子串匹配", required = false)
            integer("limit", "最多返回条数，默认 200", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = requirePath(args) ?: return ToolResult.failure("缺少必填参数 'path'")
        val type = args.str("type")
        val keyword = args.str("keyword")
        val limit = args.int("limit", 200).coerceIn(1, 3_000)
        return openAndUse(path, ctx) { analyzer.resources(it, type, keyword, limit) }
    }
}

// ── 7. 全局搜索 ────────────────────────────────────────────────────────

class ApkSearchTool(context: Context) : ApkToolBase(context) {
    override val spec = ToolSpec(
        name = "apk_search",
        description = "在 APK 内部**跨来源搜索一个关键字**：DEX 字符串池、资源表、" +
            "AndroidManifest、assets 与各类文本文件。用于定位硬编码域名、上报地址、" +
            "密钥、埋点事件名，或确认某个字符串是否存在于包内。" +
            "注意：字符串池存的是**编译后的字面量**，代码拼接出来的串不会整体出现。",
        category = "逆向",
        layer = "L2",
        params = objectSchema {
            string("path", "APK 文件路径")
            string("keyword", "要搜索的关键字（大小写不敏感）")
            string(
                "scope",
                "搜索范围：all（默认）/ dex / resources / manifest / assets",
                required = false,
                enumValues = listOf("all", "dex", "resources", "manifest", "assets")
            )
            integer("limit", "每个来源最多返回条数，默认 30", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = requirePath(args) ?: return ToolResult.failure("缺少必填参数 'path'")
        val keyword = args.str("keyword") ?: return ToolResult.failure("缺少必填参数 'keyword'")
        val scope = args.str("scope") ?: "all"
        val limit = args.int("limit", 30).coerceIn(1, 300)
        return openAndUse(path, ctx) { analyzer.search(it, keyword, scope, limit) }
    }
}

// ── 8. 签名 ────────────────────────────────────────────────────────────

class ApkSignatureTool(context: Context) : ApkToolBase(context) {
    override val spec = ToolSpec(
        name = "apk_signature",
        description = "检查 APK 的**签名**：用了哪几种签名方案（v1/v2/v3/v3.1）、" +
            "证书的主题与颁发者、有效期、SHA-256 / SHA-1 指纹、是否为调试证书。" +
            "判断是否被重打包、是否官方原版时用它 —— 指纹与官方版本不一致即为改包。",
        category = "逆向",
        layer = "L2",
        params = objectSchema {
            string("path", "APK 文件路径")
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = requirePath(args) ?: return ToolResult.failure("缺少必填参数 'path'")
        return openAndUse(path, ctx) { analyzer.signature(it) }
    }
}

// ── 9. 提取文件 ────────────────────────────────────────────────────────

class ApkExtractTool(context: Context) : ApkToolBase(context) {
    override val spec = ToolSpec(
        name = "apk_extract",
        description = "把 APK 内的文件**提取到用户已授权的目录**，便于后续用 file_read 等工具" +
            "逐个查看，或交给其它工具处理。可通过 entries 指定要提取的条目（逗号分隔的子串，" +
            "如 lib/arm64-v8a,assets/config.json）；缺省则提取全部（受 limit 限制）。",
        category = "逆向",
        layer = "L2",
        destructive = true,
        params = objectSchema {
            string("path", "APK 文件路径")
            string("dest_dir", "目标目录（需在已授权目录内），如 extracted/app")
            string("entries", "要提取的条目子串，逗号分隔；缺省提取全部", required = false)
            integer("limit", "最多提取多少个文件，默认 100", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = requirePath(args) ?: return ToolResult.failure("缺少必填参数 'path'")
        val destDir = args.str("dest_dir")
            ?: return ToolResult.failure("缺少必填参数 'dest_dir'")
        val filters = (args.str("entries") ?: "")
            .split(',')
            .map { it.trim().lowercase(Locale.US) }
            .filter { it.isNotEmpty() }
        val limit = args.int("limit", 100).coerceIn(1, 1_000)

        return openAndUse(path, ctx) { archive ->
            // 目标目录：先按「已存在的目录」解析，没有再尝试创建
            val directory = ctx.uriAccessPolicy.resolveDocument(destDir)
                ?: return@openAndUse "目标目录「$destDir」不存在。请先在已授权目录中创建它，或换一个已存在的目录。"

            if (!directory.isDirectory) {
                return@openAndUse "「$destDir」不是目录。"
            }
            ctx.uriAccessPolicy.denyReason(directory.uri, write = true)?.let {
                return@openAndUse it
            }

            val targets = archive.entries
                .filter { !it.isDirectory }
                .filter { entry ->
                    filters.isEmpty() || filters.any { f -> entry.name.lowercase(Locale.US).contains(f) }
                }
                .take(limit)

            if (targets.isEmpty()) {
                return@openAndUse "没有匹配的条目可提取。"
            }

            var ok = 0
            val failed = mutableListOf<String>()
            targets.forEach { entry ->
                val fileName = entry.name.substringAfterLast('/')
                runCatching {
                    val created = directory.createFile("application/octet-stream", fileName)
                        ?: throw IllegalStateException("无法创建文件")
                    ctx.contentResolver.openOutputStream(created.uri)?.use { out ->
                        archive.openStream(entry.name)?.use { input ->
                            input.copyTo(out, bufferSize = 64 * 1024)
                        } ?: throw IllegalStateException("读取源条目失败")
                    }
                }.onSuccess { ok++ }
                    .onFailure { failed += "${entry.name}（${it.message}）" }
            }

            buildString {
                append("已提取 $ok 个文件到「${directory.name}」")
                val all = archive.entries.count { !it.isDirectory }
                if (targets.size >= limit && all > limit) {
                    append("\n（受 limit=$limit 限制，包内共 $all 个文件；可用 entries 精确指定或用更大的 limit）")
                }
                if (failed.isNotEmpty()) {
                    append("\n失败 ${failed.size} 个：\n")
                    failed.take(5).forEach { append("  - $it\n") }
                }
            }
        }
    }
}
