package com.example.nativedemo.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.nativedemo.data.llm.LOCAL_BRIDGE_PLACEHOLDER_KEY
import com.example.nativedemo.data.llm.LlmPreset
import com.example.nativedemo.data.llm.LlmPresets
import com.example.nativedemo.data.llm.isLocalEndpoint
import com.example.nativedemo.data.settings.ModelProfile
import com.example.nativedemo.data.settings.ProfileRole
import com.example.nativedemo.ui.common.Banner
import com.example.nativedemo.ui.common.BannerLevel
import com.example.nativedemo.ui.common.InfoCard
import com.example.nativedemo.ui.common.PrimaryButton
import com.example.nativedemo.ui.common.SecondaryButton
import com.example.nativedemo.ui.common.SectionLabel
import com.example.nativedemo.ui.theme.Accent
import com.example.nativedemo.ui.theme.Accent2
import com.example.nativedemo.ui.theme.CardBg
import com.example.nativedemo.ui.theme.ChipBg
import com.example.nativedemo.ui.theme.Danger
import com.example.nativedemo.ui.theme.Faint
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.LineColor
import com.example.nativedemo.ui.theme.Muted
import com.example.nativedemo.ui.theme.Warn
import java.util.UUID

/**
 * 多模型编排设置页。
 *
 * 这一页回答三个问题，全部由用户决定（用户权限高于任何模型）：
 * 1. **要不要编排** —— 总开关，关闭时聊天走单模型链路；
 * 2. **谁是主模型** —— 主模型负责拆任务与最终整合；
 * 3. **谁是子模型** —— 档案里开着、有 Key、角色允许且不是主模型本人的，自动进池子。
 *
 * 档案是编排的基本单位：每个档案 = 一个 (地址 + 模型 + Key) 组合，
 * 主模型与子模型可以来自不同服务商、用不同的 Key。
 */
@Composable
fun OrchestrationPage(viewModel: SettingsViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    var editing by rememberSaveable { mutableStateOf<String?>(null) }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf<String?>(null) }

    val orchestrator = state.profiles.firstOrNull { it.id == state.orchestratorId }
        ?: state.profiles.firstOrNull { it.canOrchestrate }
    val subPool = state.profiles.filter { it.canSub && it.id != orchestrator?.id }

    PageColumn {
        // ── 链路说明 ──
        InfoCard(title = "多模型编排") {
            Text(
                text = "开启后，每条消息这样处理：",
                color = Fg,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "🧠 主模型理解需求并拆成多个子任务\n" +
                    "⚙️ 多个子模型并行生成各自的部分\n" +
                    "🧩 主模型整合全部结果、修正矛盾与错误，给出最终答复",
                color = Muted,
                fontSize = 12.sp,
                lineHeight = 20.sp
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "权限模型：\n" +
                    "· 你（用户）拥有最高权限 —— 主模型只能「建议」任务给谁，" +
                    "被停用、缺 Key 或角色不符的档案会被系统自动回退并明说；\n" +
                    "· 子 AI 相互隔离：每个子任务只拿到自己的指令；\n" +
                    "· 子 AI 不能互相干预：只能通过简单问答互相询问（有次数上限，只读）。",
                color = Faint,
                fontSize = 11.sp,
                lineHeight = 17.sp
            )
        }

        // ── 总开关与自检 ──
        InfoCard(title = "编排开关") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "启用多模型编排",
                        color = Fg,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = if (state.orchestrationEnabled) "已开启" else "已关闭（单模型对话）",
                        color = Faint,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = state.orchestrationEnabled,
                    onCheckedChange = viewModel::setOrchestrationEnabled
                )
            }

            Spacer(Modifier.height(10.dp))
            val ready = state.orchestrationEnabled &&
                orchestrator != null && subPool.isNotEmpty()
            val checkLevel = when {
                !state.orchestrationEnabled -> BannerLevel.INFO
                ready -> BannerLevel.INFO
                else -> BannerLevel.WARN
            }
            val checkText = when {
                !state.orchestrationEnabled ->
                    "当前为单模型模式：所有消息由「模型连接」页配置的那一个模型处理。"
                orchestrator == null ->
                    "还无法启用：没有可用的主模型。请在下方的档案里添加一个，" +
                        "并确认它已启用、填了 Key、角色不是「仅子模型」。"
                subPool.isEmpty() ->
                    "还无法启用：没有可用的子模型。请再添加至少一个档案，" +
                        "并确认它已启用、填了 Key、角色不是「仅主模型」。"
                else ->
                    "配置就绪：主模型「${orchestrator.label}」+ ${subPool.size} 个子模型" +
                        "（${subPool.joinToString("、") { it.label }}）。"
            }
            Banner(text = checkText, level = checkLevel)
        }

        // ── 主模型选择 ──
        InfoCard(title = "主模型") {
            Text(
                text = "主模型负责理解需求、拆解任务，并在子模型完成后整合结果。" +
                    "只有「已启用 + 有 Key + 角色允许」的档案会出现在这里。",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
            Spacer(Modifier.height(6.dp))
            if (state.profiles.isEmpty()) {
                Text(
                    text = "还没有任何档案。先到「模型连接」页配置，或点击下方「新增档案」。",
                    color = Faint,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
            state.profiles.forEach { profile ->
                val reason = profile.orchestratorUnavailableReason()
                val selected = orchestrator?.id == profile.id
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .then(
                            if (reason == null) {
                                Modifier.clickable { viewModel.setOrchestratorId(profile.id) }
                            } else {
                                Modifier
                            }
                        )
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selected,
                        onClick = null,
                        enabled = reason == null
                    )
                    Spacer(Modifier.width(4.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = profile.label,
                            color = if (reason == null) Fg else Faint,
                            fontSize = 13.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                        )
                        Text(
                            text = if (reason != null) {
                                "不可用：$reason"
                            } else {
                                "${profile.model} · ${roleLabel(profile.role)}"
                            },
                            color = if (reason != null) Warn else Faint,
                            fontSize = 11.sp
                        )
                    }
                    if (selected) {
                        Text("主模型", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // ── 子模型池 ──
        InfoCard(title = "子模型池") {
            Text(
                text = "自动汇集：已启用、有 Key、角色允许、且不是主模型本人的档案。" +
                    "任务默认在池内轮询均衡分配；主模型可以建议人选，但建议不了的那些会回退。",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
            Spacer(Modifier.height(8.dp))
            if (subPool.isEmpty()) {
                Text(
                    text = "池子是空的 —— 编排需要至少一个子模型。",
                    color = Warn,
                    fontSize = 12.sp
                )
            } else {
                subPool.forEach { profile ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(Accent2)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(profile.label, color = Fg, fontSize = 13.sp)
                            Text(
                                text = "${profile.model} · ${roleLabel(profile.role)}",
                                color = Faint,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // ── 档案管理 ──
        InfoCard(title = "模型档案") {
            Text(
                text = "每个档案是一组「服务商地址 + 模型名 + API Key」。" +
                    "Key 经 Android Keystore 加密后随档案保存，明文不落盘。",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
            Spacer(Modifier.height(10.dp))

            state.profiles.forEach { profile ->
                val test = state.profileTest
                ProfileCard(
                    profile = profile,
                    isOrchestrator = orchestrator?.id == profile.id,
                    testing = test != null && test.profileId == profile.id && test.running,
                    onEdit = { editing = profile.id },
                    onTest = { viewModel.testProfile(profile.id) },
                    onDelete = { confirmDelete = profile.id }
                )
                Spacer(Modifier.height(10.dp))
            }

            PrimaryButton(text = "＋ 新增档案", onClick = { showAdd = true })
        }

        state.notice?.let { notice ->
            Banner(text = notice, level = BannerLevel.INFO)
        }
    }

    // ── 编辑 / 新增对话框 ──
    val draftProfile = editing?.let { id -> state.profiles.firstOrNull { it.id == id } }
    if (editing != null && draftProfile != null) {
        ProfileEditDialog(
            initial = draftProfile,
            testState = if (state.profileTest?.profileId == draftProfile.id) {
                state.profileTest
            } else {
                null
            },
            modelFetchState = if (state.modelFetch?.targetProfileIdOrNull() == draftProfile.id) {
                state.modelFetch
            } else {
                null
            },
            onDismiss = { editing = null },
            onSave = { profile, key ->
                viewModel.saveProfile(profile)
                if (key.isNotBlank()) viewModel.saveProfileKey(profile.id, key)
                editing = null
            },
            onTest = { baseUrl, model, key ->
                viewModel.testDraftProfile(baseUrl, model, key)
            },
            onFetchModels = { baseUrl, key ->
                // 编辑已存档案：Key 输入框留空时允许回退到已保存的 Key
                viewModel.fetchModelList(baseUrl, key, draftProfile.id, allowStoredFallback = true)
            },
            onDismissModelFetch = viewModel::dismissModelFetch
        )
    }

    if (showAdd) {
        ProfileEditDialog(
            initial = null,
            testState = if (state.profileTest?.profileId == null) state.profileTest else null,
            modelFetchState = if (state.modelFetch?.targetProfileIdOrNull() == null) {
                state.modelFetch
            } else {
                null
            },
            onDismiss = { showAdd = false },
            onSave = { profile, key ->
                viewModel.saveProfile(profile)
                if (key.isNotBlank()) viewModel.saveProfileKey(profile.id, key)
                showAdd = false
            },
            onTest = { baseUrl, model, key ->
                viewModel.testDraftProfile(baseUrl, model, key)
            },
            onFetchModels = { baseUrl, key ->
                // 新档案没有已保存的 Key 可回退，必须用输入框里刚填的
                viewModel.fetchModelList(baseUrl, key, null, allowStoredFallback = false)
            },
            onDismissModelFetch = viewModel::dismissModelFetch
        )
    }

    // ── 删除确认 ──
    val deleteTarget = confirmDelete?.let { id ->
        state.profiles.firstOrNull { it.id == id }
    }
    if (confirmDelete != null && deleteTarget != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("删除档案「${deleteTarget.label}」？") },
            text = {
                Text(
                    "该档案的 API Key 也会从设备密钥库中抹掉，此操作不可恢复。" +
                        if (orchestrator?.id == deleteTarget.id) {
                            "\n它当前是主模型，删除后主模型将回退为第一个可用的档案。"
                        } else {
                            ""
                        }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteProfile(deleteTarget.id)
                    confirmDelete = null
                }) {
                    Text("删除", color = Danger)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = null }) { Text("取消") }
            }
        )
    }
}

/** 档案卡片：一眼看清 地址 / 模型 / Key / 角色 / 工具支持，附编辑、测试、删除。 */
@Composable
private fun ProfileCard(
    profile: ModelProfile,
    isOrchestrator: Boolean,
    testing: Boolean,
    onEdit: () -> Unit,
    onTest: () -> Unit,
    onDelete: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ChipBg)
            .border(
                1.dp,
                if (isOrchestrator) Accent.copy(alpha = 0.5f) else LineColor,
                RoundedCornerShape(12.dp)
            )
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = profile.label,
                color = Fg,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            if (isOrchestrator) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(Accent.copy(alpha = 0.16f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text("主模型", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        Text(
            text = "${profile.model} · ${roleLabel(profile.role)}",
            color = Muted,
            fontSize = 11.sp
        )
        Text(
            text = profile.baseUrl,
            color = Faint,
            fontSize = 11.sp,
            maxLines = 1
        )

        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(ok = profile.hasKey)
            Spacer(Modifier.width(6.dp))
            Text(
                text = if (profile.hasKey) "Key 已保存" else "未填写 Key",
                color = if (profile.hasKey) Accent2 else Warn,
                fontSize = 11.sp
            )
            Spacer(Modifier.width(12.dp))
            StatusDot(ok = profile.toolsSupported != false)
            Spacer(Modifier.width(6.dp))
            Text(
                text = when (profile.toolsSupported) {
                    true -> "支持工具调用"
                    false -> "不支持工具调用"
                    null -> "工具支持未探测"
                },
                color = Faint,
                fontSize = 11.sp
            )
        }

        if (!profile.enabled) {
            Spacer(Modifier.height(6.dp))
            Text("已停用：不参与编排", color = Warn, fontSize = 11.sp)
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallAction(text = "编辑", onClick = onEdit)
            SmallAction(
                text = if (testing) "测试中…" else "测试",
                enabled = !testing,
                onClick = onTest
            )
            SmallAction(text = "删除", onClick = onDelete, danger = true)
        }
    }
}

@Composable
private fun StatusDot(ok: Boolean) {
    Box(
        modifier = Modifier
            .size(7.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(if (ok) Accent2 else Warn)
    )
}

@Composable
private fun SmallAction(
    text: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    danger: Boolean = false
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(CardBg)
            .border(
                1.dp,
                if (danger) Danger.copy(alpha = 0.4f) else LineColor,
                RoundedCornerShape(8.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        if (text == "测试中…") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    modifier = Modifier.size(11.dp),
                    color = Muted,
                    strokeWidth = 1.5.dp
                )
                Spacer(Modifier.width(6.dp))
                Text(text, color = Muted, fontSize = 12.sp)
            }
        } else {
            Text(
                text = text,
                color = when {
                    !enabled -> Faint
                    danger -> Danger
                    else -> Fg
                },
                fontSize = 12.sp
            )
        }
    }
}

/**
 * 档案编辑对话框（新增与编辑共用）。
 *
 * 服务商预设 chips 一键填好地址与模型；「测试连接」测的是当前草拟值，
 * 保存前就能验证地址 / Key / 模型名是否正确。
 */
@Composable
private fun ProfileEditDialog(
    initial: ModelProfile?,
    testState: ProfileTestState?,
    modelFetchState: ModelFetchState?,
    onDismiss: () -> Unit,
    onSave: (ModelProfile, String) -> Unit,
    onTest: (String, String, String) -> Unit,
    onFetchModels: (String, String) -> Unit,
    onDismissModelFetch: () -> Unit
) {
    var label by rememberSaveable { mutableStateOf(initial?.label.orEmpty()) }
    var baseUrl by rememberSaveable { mutableStateOf(initial?.baseUrl.orEmpty()) }
    var model by rememberSaveable { mutableStateOf(initial?.model.orEmpty()) }
    var apiKey by rememberSaveable { mutableStateOf("") }
    var role by rememberSaveable {
        mutableStateOf(initial?.role ?: ProfileRole.BOTH)
    }
    var enabled by rememberSaveable { mutableStateOf(initial?.enabled ?: true) }

    val canSave = label.isNotBlank() && baseUrl.isNotBlank() && model.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "新增档案" else "编辑档案") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                SectionLabel("服务商预设（点一下自动填好）")
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LlmPresets.all.forEach { preset ->
                        DialogChip(
                            label = preset.label,
                            selected = LlmPresets.match(baseUrl) == preset
                        ) {
                            if (preset.baseUrl.isNotBlank()) baseUrl = preset.baseUrl
                            if (preset.defaultModel.isNotBlank()) model = preset.defaultModel
                            if (label.isBlank()) label = preset.label
                            // 网页桥接不需要 Key：自动补占位值，省去「随便编一个」
                            if (!preset.requiresApiKey && apiKey.isBlank()) {
                                apiKey = LOCAL_BRIDGE_PLACEHOLDER_KEY
                            }
                        }
                    }
                }

                val matched = LlmPresets.match(baseUrl)
                if (matched != null && matched.modelSuggestions.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    SectionLabel("推荐模型")
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        matched.modelSuggestions.forEach { name ->
                            DialogChip(
                                label = name,
                                selected = model == name
                            ) { model = name }
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                DialogField(
                    label = "名称（界面展示用）",
                    value = label,
                    placeholder = "例如：主力模型 / 备用 Key",
                    onValueChange = { label = it }
                )
                Spacer(Modifier.height(10.dp))
                DialogField(
                    label = "Base URL",
                    value = baseUrl,
                    placeholder = "https://api.openai.com/v1",
                    onValueChange = { baseUrl = it }
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "实际请求：${baseUrl.trim().trimEnd('/')}/chat/completions",
                    color = Accent2,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(10.dp))
                DialogField(
                    label = "模型名",
                    value = model,
                    placeholder = "gpt-4o-mini",
                    onValueChange = { model = it }
                )
                Spacer(Modifier.height(8.dp))
                // 与其猜模型名，直接问服务端要这份 Key 能用的模型清单
                ModelListFetchRow(
                    loading = modelFetchState is ModelFetchState.Loading,
                    onFetch = { onFetchModels(baseUrl, apiKey) }
                )
                when (modelFetchState) {
                    is ModelFetchState.Success -> {
                        Spacer(Modifier.height(10.dp))
                        SectionLabel("服务端可用模型（${modelFetchState.models.size} 个，点选）")
                        Spacer(Modifier.height(6.dp))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 200.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            modelFetchState.models.forEach { name ->
                                val selected = name == model
                                Text(
                                    text = name,
                                    color = if (selected) Accent else Fg,
                                    fontSize = 13.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { model = name }
                                        .padding(vertical = 7.dp, horizontal = 4.dp)
                                )
                            }
                        }
                    }

                    is ModelFetchState.Failure -> {
                        Spacer(Modifier.height(8.dp))
                        Banner(text = modelFetchState.message, level = BannerLevel.ERROR)
                    }

                    else -> Unit
                }
                Spacer(Modifier.height(10.dp))
                val keyOptional = isLocalEndpoint(baseUrl)
                DialogField(
                    label = when {
                        keyOptional -> "API Key（网页桥接不需要，留空即可）"
                        initial?.hasKey == true -> "API Key（已保存，留空则不修改）"
                        else -> "API Key"
                    },
                    value = apiKey,
                    placeholder = if (keyOptional) "留空即可" else "sk-…",
                    onValueChange = { apiKey = it },
                    isSecret = true
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = if (keyOptional) {
                        "本地 / 局域网地址：桥接用网页登录态，令牌由 App 自动补占位值，无需填写。"
                    } else {
                        "Key 仅保存在本机，经 Android Keystore 加密；换机恢复后需要重新填写。"
                    },
                    color = Muted,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )

                Spacer(Modifier.height(14.dp))
                SectionLabel("角色")
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProfileRole.entries.forEach { option ->
                        DialogChip(
                            label = roleLabel(option),
                            selected = role == option
                        ) { role = option }
                    }
                }

                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("参与编排", color = Fg, fontSize = 13.sp)
                        Text(
                            text = "关闭后主模型看不到它，也不会被分配到",
                            color = Faint,
                            fontSize = 11.sp
                        )
                    }
                    Switch(checked = enabled, onCheckedChange = { enabled = it })
                }

                // 测试结果
                if (testState?.running == true) {
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            color = Accent,
                            strokeWidth = 1.5.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Text("正在向服务端发起探测…", color = Muted, fontSize = 12.sp)
                    }
                }
                testState?.message?.let { message ->
                    Spacer(Modifier.height(14.dp))
                    Banner(
                        text = buildString {
                            append(message)
                            testState.toolsSupported?.let { supported ->
                                append(
                                    if (supported) {
                                        "\n该服务支持工具调用（编排的规划请求会走工具通道）"
                                    } else {
                                        "\n该服务不支持工具调用（编排将改用 JSON 文本降级）"
                                    }
                                )
                            }
                        },
                        level = if (testState.ok == true) BannerLevel.INFO else BannerLevel.ERROR
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = canSave,
                onClick = {
                    onSave(
                        ModelProfile(
                            id = initial?.id ?: UUID.randomUUID().toString(),
                            label = label.trim(),
                            baseUrl = baseUrl.trim(),
                            model = model.trim(),
                            role = role,
                            enabled = enabled,
                            keyCipher = initial?.keyCipher,
                            toolsSupported = initial?.toolsSupported,
                            createdAt = initial?.createdAt ?: System.currentTimeMillis()
                        ),
                        apiKey
                    )
                }
            ) {
                Text("保存")
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { onTest(baseUrl, model, apiKey) }) {
                    Text("测试连接")
                }
                TextButton(onClick = onDismiss) { Text("取消") }
            }
        }
    )
}

@Composable
private fun DialogChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(
                if (selected) Accent.copy(alpha = 0.18f) else CardBg,
                RoundedCornerShape(999.dp)
            )
            .border(
                1.dp,
                if (selected) Accent.copy(alpha = 0.65f) else LineColor,
                RoundedCornerShape(999.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(
            text = label,
            color = if (selected) Accent else Muted,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun DialogField(
    label: String,
    value: String,
    placeholder: String,
    onValueChange: (String) -> Unit,
    isSecret: Boolean = false
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(label, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(5.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(placeholder, color = Muted, fontSize = 13.sp) },
            singleLine = true,
            visualTransformation = if (isSecret) {
                PasswordVisualTransformation()
            } else {
                VisualTransformation.None
            }
        )
    }
}

private fun roleLabel(role: ProfileRole): String = role.label

/** 子页统一的外层：可滚动 + 统一内边距。 */
@Composable
private fun PageColumn(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        content()
    }
}
