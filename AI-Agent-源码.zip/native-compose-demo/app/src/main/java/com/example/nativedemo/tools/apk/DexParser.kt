package com.example.nativedemo.tools.apk

/** DEX 里的一个类。 */
data class DexClass(
    /** 可读类名，如 `com.example.app.MainActivity`。 */
    val name: String,
    /** 原始描述符，如 `Lcom/example/app/MainActivity;`。 */
    val descriptor: String,
    val accessFlags: Int,
    val superClass: String?,
    val methodCount: Int,
    val fieldCount: Int,
    val sourceFile: String?,
    /** 该类在 DEX 里的索引，用于按需展开方法列表。 */
    val index: Int
) {
    val isInterface: Boolean get() = accessFlags and 0x200 != 0
    val isAbstract: Boolean get() = accessFlags and 0x400 != 0
    val isEnum: Boolean get() = accessFlags and 0x4000 != 0
    val isSynthetic: Boolean get() = accessFlags and 0x1000 != 0

    /** 简洁的修饰符摘要，比原始位掩码好读得多。 */
    val modifiers: String
        get() = buildList {
            if (accessFlags and 0x1 != 0) add("public")
            if (accessFlags and 0x2 != 0) add("private")
            if (accessFlags and 0x4 != 0) add("protected")
            if (accessFlags and 0x8 != 0) add("static")
            if (accessFlags and 0x10 != 0) add("final")
            if (isInterface) add("interface")
            if (isAbstract && !isInterface) add("abstract")
            if (isEnum) add("enum")
            if (isSynthetic) add("synthetic")
        }.joinToString(" ")
}

/** DEX 里的一个方法。 */
data class DexMethod(
    /** 声明它的类（可读名）。 */
    val owner: String,
    val name: String,
    /** 简要签名，如 `(ILjava/lang/String;)V` 的 shorty 形式。 */
    val shorty: String,
    val accessFlags: Int
) {
    val isConstructor: Boolean
        get() = name == "<init>" || name == "<clinit>"
}

/**
 * 已解析的 DEX 文件。
 *
 * 类的**方法列表按需解析**：一个稍大的 App 就有几十万个方法，全部展开既慢又占内存，
 * 而多数查询只看类名。所以这里只预解析头部统计与类定义，方法详情留到真正要用的那一刻。
 */
class DexFile internal constructor(
    private val data: ByteArray,
    val version: String,
    val stringCount: Int,
    val typeCount: Int,
    val protoCount: Int,
    val fieldCount: Int,
    val methodCount: Int,
    private val strings: List<String>,
    private val types: List<String>,
    private val methodNames: List<String>,
    /** 每个方法对应的 shorty **字符串池索引**（不是类型索引，两者别混）。 */
    private val methodShorties: IntArray,
    val classes: List<DexClass>,
    private val classDataOffsets: IntArray
) {

    /** 按关键字过滤字符串池（子串匹配，大小写不敏感）。 */
    fun searchStrings(keyword: String?, limit: Int): List<String> {
        val needle = keyword?.lowercase()
        val out = ArrayList<String>(minOf(limit, 4096))
        for (s in strings) {
            if (needle != null && !s.lowercase().contains(needle)) continue
            out += s
            if (out.size >= limit) break
        }
        return out
    }

    fun classByNameOrDescriptor(keyword: String): List<DexClass> {
        val needle = keyword.lowercase()
        return classes.filter { it.name.lowercase().contains(needle) }
    }

    /** 展开某个类的方法列表（惰性）。 */
    fun methodsOf(classIndex: Int, limit: Int = 500): List<DexMethod> {
        val dexClass = classes.getOrNull(classIndex) ?: return emptyList()
        val classDataOff = classDataOffsets.getOrNull(classIndex) ?: 0
        if (classDataOff == 0) return emptyList()

        return runCatching {
            val cursor = ByteCursor(data, classDataOff)
            val staticFields = cursor.uleb128()
            val instanceFields = cursor.uleb128()
            val directMethods = cursor.uleb128()
            val virtualMethods = cursor.uleb128()

            // 字段排在方法前面，必须先跳过（每项是 uleb128 + uleb128）
            repeat(staticFields + instanceFields) {
                cursor.uleb128()
                cursor.uleb128()
            }

            val out = ArrayList<DexMethod>(minOf(directMethods + virtualMethods, limit))
            for (group in 0 until 2) {
                val count = if (group == 0) directMethods else virtualMethods
                var methodIdx = 0
                repeat(count) {
                    methodIdx += cursor.uleb128()   // diff 编码：累加得到真实索引
                    val accessFlags = cursor.uleb128()
                    cursor.uleb128()                // code_off，反汇编用得上，这里不需要

                    if (out.size < limit && methodIdx in methodNames.indices) {
                        val shortyIdx = methodShorties.getOrNull(methodIdx) ?: -1
                        out += DexMethod(
                            owner = dexClass.name,
                            name = methodNames[methodIdx],
                            shorty = strings.getOrNull(shortyIdx).orEmpty(),
                            accessFlags = accessFlags
                        )
                    }
                }
            }
            out
        }.getOrDefault(emptyList())
    }

    /** 遍历所有类的方法（受 [limit] 限制），用于「全局按方法名/类名搜索」。 */
    fun collectMethods(keyword: String?, limit: Int): List<DexMethod> {
        val needle = keyword?.lowercase()
        val out = ArrayList<DexMethod>(minOf(limit, 1024))
        classes.forEachIndexed { index, _ ->
            if (out.size >= limit) return@forEachIndexed
            methodsOf(index, limit).forEach { method ->
                if (out.size >= limit) return@forEach
                val hit = needle == null ||
                    method.name.lowercase().contains(needle) ||
                    method.owner.lowercase().contains(needle)
                if (hit) out += method
            }
        }
        return out
    }
}

/**
 * DEX 解析器。
 *
 * ## 为什么逆向 APK 一定要有它
 *
 * `classes.dex` 是 APK 里真正的代码。不做解析，AI 对目标应用的全部认知就只剩
 * manifest 里那几个声明；一旦能读到类名、方法名与字符串池，它立刻就能做这些事：
 *
 * - 判断用了什么框架（包名前缀）、有没有加固/混淆（类名是否退化成 `a/a/a`）；
 * - 找敏感行为：`getDeviceId`、`getSimSerialNumber`、动态加载、反射调用；
 * - 从字符串池里捞硬编码的 URL、密钥、上报域名、埋点事件名。
 *
 * ## 只读解析，不做反汇编
 *
 * 这里只读 DEX 的索引结构（类 / 方法 / 字段 / 字符串），**不反汇编字节码**——
 * 那需要完整的指令解码器，体积与复杂度都不合适塞进 App。索引本身已经能回答
 * 逆向分析里绝大多数「有什么」的问题。
 *
 * 结构（均为小端）：
 * ```
 * header_item (112B) → string_ids / type_ids / proto_ids / field_ids / method_ids / class_defs
 * class_def_item (32B) → class_data_item（uleb128 变长编码的字段与方法表）
 * ```
 */
object DexParser {

    private const val HEADER_SIZE = 112
    private const val NO_INDEX = 0xFFFFFFFFL
    private const val MAX_IDS = 500_000

    fun isDex(data: ByteArray): Boolean =
        data.size >= 8 &&
            data[0] == 'd'.code.toByte() &&
            data[1] == 'e'.code.toByte() &&
            data[2] == 'x'.code.toByte()

    fun parse(data: ByteArray): DexFile {
        if (!isDex(data)) throw ResParseException("不是 DEX 文件（magic 不匹配）")
        if (data.size < HEADER_SIZE) throw ResParseException("DEX 文件过短（${data.size} 字节）")

        val version = runCatching {
            String(data, 4, 3, Charsets.US_ASCII)
        }.getOrDefault("???")

        val head = ByteCursor(data, 32)
        head.i32()                    // file_size
        head.i32()                    // header_size
        head.i32()                    // endian_tag
        head.i32()                    // link_size
        head.i32()                    // link_off
        head.i32()                    // map_off

        val stringIdsSize = head.i32().coerceIn(0, MAX_IDS)
        val stringIdsOff = head.i32()
        val typeIdsSize = head.i32().coerceIn(0, MAX_IDS)
        val typeIdsOff = head.i32()
        val protoIdsSize = head.i32().coerceIn(0, MAX_IDS)
        val protoIdsOff = head.i32()
        val fieldIdsSize = head.i32().coerceIn(0, MAX_IDS)
        head.i32()                    // field_ids_off
        val methodIdsSize = head.i32().coerceIn(0, MAX_IDS)
        val methodIdsOff = head.i32()
        val classDefsSize = head.i32().coerceIn(0, MAX_IDS)
        val classDefsOff = head.i32()

        // ── 字符串池：string_ids 表里存的是偏移，真正的数据在 data 区，以 0x00 结尾 ──
        val strings = ArrayList<String>(minOf(stringIdsSize, 65536))
        runCatching {
            val c = ByteCursor(data, stringIdsOff)
            repeat(stringIdsSize) {
                val offset = c.i32()
                strings += if (offset in 0 until data.size - 1) {
                    readMutf8String(data, offset)
                } else {
                    ""
                }
            }
        }

        // ── 类型描述符（type_ids → 字符串索引） ──
        val types = ArrayList<String>(minOf(typeIdsSize, 65536))
        runCatching {
            val c = ByteCursor(data, typeIdsOff)
            repeat(typeIdsSize) {
                val strIdx = c.i32()
                types += strings.getOrNull(strIdx).orEmpty()
            }
        }

        // ── 方法表：class_idx / proto_idx / name_idx ──
        val methodNames = ArrayList<String>(minOf(methodIdsSize, 65536))
        val methodShorties = IntArray(methodIdsSize)
        runCatching {
            val c = ByteCursor(data, methodIdsOff)
            for (i in 0 until methodIdsSize) {
                c.u16()                  // class_idx：owner 由 class_def 反查，这里不需要
                val protoIdx = c.u16()
                val nameIdx = c.i32()
                methodNames += strings.getOrNull(nameIdx).orEmpty()

                // proto_id_item 的第一个字段就是 shorty_idx（指向字符串池）
                methodShorties[i] = if (protoIdx in 0 until protoIdsSize) {
                    runCatching {
                        ByteCursor(data, protoIdsOff + protoIdx * 12).i32()
                    }.getOrDefault(-1)
                } else {
                    -1
                }
            }
        }

        // ── 类定义（32 字节/项） ──
        val classes = ArrayList<DexClass>(minOf(classDefsSize, 16384))
        val classDataOffsets = IntArray(classDefsSize)
        runCatching {
            val c = ByteCursor(data, classDefsOff)
            for (i in 0 until classDefsSize) {
                val classIdx = c.i32()
                val accessFlags = c.i32()
                val superIdx = c.i32()
                c.i32()               // interfaces_off
                val sourceIdx = c.i32()
                c.i32()               // annotations_off
                val classDataOff = c.i32()
                c.i32()               // static_values_off

                classDataOffsets[i] = classDataOff
                val descriptor = types.getOrNull(classIdx).orEmpty()
                val (methodCount, fieldCount) = countMembers(data, classDataOff)

                classes += DexClass(
                    name = descriptorToReadable(descriptor),
                    descriptor = descriptor,
                    accessFlags = accessFlags,
                    superClass = types.getOrNull(superIdx)?.let { descriptorToReadable(it) },
                    methodCount = methodCount,
                    fieldCount = fieldCount,
                    sourceFile = strings.getOrNull(sourceIdx)?.takeIf { it.isNotEmpty() },
                    index = i
                )
            }
        }

        return DexFile(
            data = data,
            version = version,
            stringCount = strings.size,
            typeCount = types.size,
            protoCount = protoIdsSize,
            fieldCount = fieldIdsSize,
            methodCount = methodNames.size,
            strings = strings,
            types = types,
            methodNames = methodNames,
            methodShorties = methodShorties,
            classes = classes,
            classDataOffsets = classDataOffsets
        )
    }

    /** 只读 class_data 头部拿到字段/方法**数量**，不展开细节。 */
    private fun countMembers(data: ByteArray, classDataOff: Int): Pair<Int, Int> {
        if (classDataOff <= 0 || classDataOff >= data.size) return 0 to 0
        return runCatching {
            val c = ByteCursor(data, classDataOff)
            val sf = c.uleb128()
            val inf = c.uleb128()
            val dm = c.uleb128()
            val vm = c.uleb128()
            (dm + vm) to (sf + inf)
        }.getOrDefault(0 to 0)
    }

    /**
     * 读取 MUTF-8 编码的字符串。
     *
     * DEX 用的是 **Modified UTF-8**：U+0000 被编码成两字节的 `C0 80`（这样字节流里
     * 就不会出现真正的 0，可以拿 0 当终止符）。用标准 UTF-8 解码器读这种序列会得到
     * 替换字符，所以这里手工解码。
     */
    private fun readMutf8String(data: ByteArray, offset: Int): String {
        val cursor = ByteCursor(data, offset)
        cursor.uleb128()          // utf16 长度，实际以 0x00 终止为准

        val sb = StringBuilder()
        var i = cursor.pos
        while (i < data.size) {
            val b0 = data[i].toInt() and 0xFF
            if (b0 == 0) break
            when {
                b0 and 0x80 == 0 -> {
                    sb.append(b0.toChar())
                    i += 1
                }
                b0 and 0xE0 == 0xC0 && i + 1 < data.size -> {
                    val b1 = data[i + 1].toInt() and 0xFF
                    sb.append((((b0 and 0x1F) shl 6) or (b1 and 0x3F)).toChar())
                    i += 2
                }
                b0 and 0xF0 == 0xE0 && i + 2 < data.size -> {
                    val b1 = data[i + 1].toInt() and 0xFF
                    val b2 = data[i + 2].toInt() and 0xFF
                    sb.append(
                        (((b0 and 0x0F) shl 12) or ((b1 and 0x3F) shl 6) or (b2 and 0x3F)).toChar()
                    )
                    i += 3
                }
                else -> {
                    i += 1   // 非法起始字节：跳过，不让一条坏数据毁掉整个字符串池
                }
            }
        }
        return sb.toString()
    }

    /** `Lcom/example/Foo;` → `com.example.Foo`；基本类型保持简短名。 */
    internal fun descriptorToReadable(descriptor: String): String {
        if (descriptor.isEmpty()) return ""
        if (descriptor.length == 1) {
            return when (descriptor[0]) {
                'V' -> "void"
                'Z' -> "boolean"
                'B' -> "byte"
                'S' -> "short"
                'C' -> "char"
                'I' -> "int"
                'J' -> "long"
                'F' -> "float"
                'D' -> "double"
                else -> descriptor
            }
        }
        // 数组：[[I → int[][]
        if (descriptor[0] == '[') {
            return descriptorToReadable(descriptor.substring(1)) + "[]"
        }
        if (descriptor.startsWith("L") && descriptor.endsWith(";")) {
            return descriptor.substring(1, descriptor.length - 1).replace('/', '.')
        }
        return descriptor
    }
}
