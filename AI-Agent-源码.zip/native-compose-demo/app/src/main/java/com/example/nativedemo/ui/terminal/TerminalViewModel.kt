package com.example.nativedemo.ui.terminal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.nativedemo.core.AppContainer
import com.example.nativedemo.data.terminal.TerminalEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

/**
 * 「命令终端」页状态。
 *
 * 每条命令是独立进程（sh -c 不保留状态），所以 shell 的 `cd` 在这里**自己跟踪**：
 * 单独一行 `cd xxx` 只改 [cwd] 不起进程；`cd xxx && ls` 里的 cd 只在那一条命令内有效，
 * 跟踪不到 —— 这是有意为之的取舍，UI 上有说明。
 */
class TerminalViewModel(
    private val engine: TerminalEngine,
    private val workDir: File
) : ViewModel() {

    sealed interface Entry {
        /** 用户输入的命令回显。 */
        data class Command(val text: String) : Entry

        /** 一条输出（stdout/stderr 已合并，按行切分）。 */
        data class Output(val text: String) : Entry

        /** 终端自身的提示（cd 结果、内置命令说明等）。 */
        data class Info(val text: String) : Entry

        /** 命令结束。 */
        data class Result(
            val code: Int?,
            val timedOut: Boolean,
            val durationMs: Long,
            val error: String? = null
        ) : Entry
    }

    data class UiState(
        val entries: List<Entry> = emptyList(),
        val input: String = "",
        val cwd: String = "",
        val running: Boolean = false
    )

    private val _state = MutableStateFlow(UiState(cwd = workDir.absolutePath))
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var cwdFile: File = workDir
    private var runJob: Job? = null

    private val history = mutableListOf<String>()
    private var historyIndex = -1
    fun onInputChange(value: String) = _state.update { it.copy(input = value) }

    /** 提交当前输入执行。运行中忽略新输入，避免两条命令抢同一个输出区。 */
    fun submit() {
        val current = _state.value
        val command = current.input.trim()
        if (command.isEmpty() || current.running) return

        if (history.lastOrNull() != command) history += command
        historyIndex = -1
        _state.update { it.copy(input = "", entries = it.entries + Entry.Command(command)) }

        when {
            command == "clear" || command == "cls" ->
                _state.update { it.copy(entries = emptyList()) }

            command == "help" || command == "?" ->
                append(Entry.Info(HELP_TEXT))

            command == "cd" || command.startsWith("cd ") -> changeDir(command)

            else -> execute(command)
        }
    }

    /**
     * 停止当前命令。
     *
     * 只杀进程、**不取消收集**：进程一死管道就关，读取循环自然结束，
     * Exit 事件照常发出，输出区会留下「退出码 137」的一行 —— 用户看得见
     * 命令是被杀掉的，而不是莫名消失。
     */
    fun stop() {
        engine.stop()
    }

    fun clear() = _state.update { it.copy(entries = emptyList()) }

    /** 历史上的上一条（更早）。 */
    fun historyUp() {
        if (history.isEmpty()) return
        historyIndex = when (historyIndex) {
            -1 -> history.lastIndex
            else -> (historyIndex - 1).coerceAtLeast(0)
        }
        _state.update { it.copy(input = history[historyIndex]) }
    }

    /** 历史上的下一条（更新）；越过最新一条则回到空白输入行。 */
    fun historyDown() {
        if (historyIndex == -1) return
        historyIndex = if (historyIndex >= history.lastIndex) -1 else historyIndex + 1
        _state.update { it.copy(input = history.getOrNull(historyIndex).orEmpty()) }
    }

    private fun execute(command: String) {
        runJob = viewModelScope.launch {
            _state.update { it.copy(running = true) }
            try {
                engine.run(command = command, cwd = cwdFile).collect { event ->
                    when (event) {
                        is TerminalEngine.Event.Output -> append(Entry.Output(event.text))
                        is TerminalEngine.Event.Exit -> append(
                            Entry.Result(
                                code = event.code,
                                timedOut = event.timedOut,
                                durationMs = event.durationMs,
                                error = event.error
                            )
                        )
                    }
                }
            } finally {
                _state.update { it.copy(running = false) }
            }
        }
    }

    private fun changeDir(command: String) {
        val arg = command.removePrefix("cd").trim().trim('"', '\'')
        val target = when {
            arg.isEmpty() || arg == "~" -> workDir
            arg.startsWith("/") -> File(arg)
            else -> File(cwdFile, arg)
        }
        val canonical = runCatching { target.canonicalFile }.getOrNull()
        if (canonical != null && canonical.isDirectory) {
            cwdFile = canonical
            _state.update {
                it.copy(cwd = canonical.path, entries = it.entries + Entry.Info("→ ${canonical.path}"))
            }
        } else {
            append(Entry.Info("cd: 目录不存在或不可读：$arg"))
        }
    }

    private fun append(entry: Entry) = _state.update { state ->
        // 输出封顶：find / 之类的命令能刷出几万行，全留着会把内存吃光
        val capped = if (state.entries.size >= MAX_ENTRIES) {
            state.entries.drop(state.entries.size - MAX_ENTRIES + 1)
        } else {
            state.entries
        }
        state.copy(entries = capped + entry)
    }

    companion object {
        /** 输出区最多保留的行数。 */
        const val MAX_ENTRIES = 1_500

        private val HELP_TEXT = """
            这是一个沙盒终端：每条命令经 /system/bin/sh -c 独立执行，以应用自身权限运行。

            · 可以：toybox 命令（ls/cat/grep/find/ps/df/getprop/uname…）、读写应用私有目录
            · 不可以：root、访问其他应用私有数据、apt 装包
            · 单独一行 cd 可切换工作目录（跨命令保留）；cd x && y 里的 cd 只在当条有效
            · clear 清屏，↑/↓ 翻阅历史
            · 共享存储需在上方授权「所有文件访问」后才能直接 ls /sdcard
        """.trimIndent()

        fun factory(container: AppContainer) = viewModelFactory {
            initializer {
                TerminalViewModel(
                    engine = container.terminalEngine,
                    workDir = File(container.appContext.filesDir, "terminal")
                )
            }
        }
    }
}
