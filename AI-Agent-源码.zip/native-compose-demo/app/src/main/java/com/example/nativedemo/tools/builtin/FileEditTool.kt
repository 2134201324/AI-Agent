package com.example.nativedemo.tools.builtin

import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import com.example.nativedemo.tools.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject

/**
 * 精确编辑：把文件中的某段文本替换为另一段。
 *
 * 相比整体覆盖（file_write）的两点优势：
 * 1. 模型不必重写整篇内容 —— 省 token，也不容易把无关部分改坏
 * 2. `new_text` 留空即为**删除**这段内容
 *
 * 安全性：old_text 必须唯一匹配，否则拒绝执行，避免误改多处。
 */
class FileEditTool : Tool {

    override val spec = ToolSpec(
        name = "file_edit",
        description = "精确修改文件内容：把 old_text 替换成 new_text。old_text 必须在文件中唯一出现，" +
            "否则会拒绝执行以免误改。把 new_text 留空即可**删除**这段内容。" +
            "这是修改已有文件的首选方式，不必重写全文。",
        category = "文件",
        layer = "L1",
        destructive = true,
        params = objectSchema {
            string("path", "目标文件路径，例如 code_game/readme.md")
            string("old_text", "要被替换的原文，需与文件内容完全一致（含空格与换行），且在文件中唯一")
            string("new_text", "替换后的内容；留空表示删除 old_text", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val pathArg = try {
            args.requireStr("path")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }
        val oldText = try {
            args.requireStr("old_text")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }
        val newText = args.str("new_text").orEmpty()

        val document = ctx.uriAccessPolicy.resolveDocument(pathArg)
            ?: return ToolResult.failure("未找到「$pathArg」，可先用 file_list 查看可用文件。")
        if (document.isDirectory) {
            return ToolResult.failure("「$pathArg」是目录，无法编辑。")
        }
        val uri = document.uri

        ctx.uriAccessPolicy.denyReason(uri, write = true)?.let { return ToolResult.failure(it) }

        return withContext(Dispatchers.IO) {
            try {
                val original = ctx.contentResolver.openInputStream(uri)?.use { input ->
                    input.readBytes().toString(Charsets.UTF_8)
                } ?: return@withContext ToolResult.failure("无法读取该文件")

                when (val occurrences = countOccurrences(original, oldText)) {
                    0 -> return@withContext ToolResult.failure(
                        "文件里找不到这段原文（空格或换行可能不完全一致）。建议先用 file_read 查看当前内容。"
                    )
                    1 -> Unit
                    else -> return@withContext ToolResult.failure(
                        "这段原文在文件中出现了 $occurrences 次，不唯一。请提供更长、更独特的片段。"
                    )
                }

                val updated = original.replace(oldText, newText)
                // 与 file_write 保持一致：覆盖必须用 rwt 才会截断文件
                ctx.contentResolver.openOutputStream(uri, "rwt")?.use { output ->
                    output.write(updated.toByteArray(Charsets.UTF_8))
                    output.flush()
                } ?: return@withContext ToolResult.failure("无法写入该文件")

                val action = if (newText.isEmpty()) "已删除指定内容" else "已替换指定内容"
                ToolResult.success(
                    "$action（${oldText.length} 字符 → ${newText.length} 字符，文件现为 ${updated.length} 字符）"
                )
            } catch (e: SecurityException) {
                ToolResult.failure("权限不足：${e.message}")
            } catch (e: Throwable) {
                ToolResult.failure("编辑失败：${e.message ?: e::class.java.simpleName}")
            }
        }
    }

    private fun countOccurrences(source: String, target: String): Int {
        if (target.isEmpty()) return 0
        var count = 0
        var index = source.indexOf(target)
        while (index >= 0) {
            count++
            index = source.indexOf(target, index + target.length)
        }
        return count
    }
}
