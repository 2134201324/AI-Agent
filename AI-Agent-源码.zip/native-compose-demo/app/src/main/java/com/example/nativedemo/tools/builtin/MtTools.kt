package com.example.nativedemo.tools.builtin

import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.bool
import com.example.nativedemo.tools.mt.MtBridge
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import com.example.nativedemo.tools.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import java.io.File

private const val MT_SECURITY_NOTE =
    "会跳转到 MT 管理器界面。本身不修改文件；进入 MT 之后的操作由用户自己完成，" +
        "AI 不会（也不能）代他点击界面。"

// ── mt_open ───────────────────────────────────────────────────────────────

/**
 * 在 MT 管理器中打开一个文件或目录。
 *
 * 这是**唯一**被 MT 官方（社区逆向）支持的对外动作：让它把自己停在某个路径上。
 * 它的定位是"把人送到操作现场"——真正要干活时由用户自己点。
 * 本应用刻意不提供读取屏幕/模拟点击能力，AI 不得操作用户的手机。
 */
class MtOpenTool : Tool {

    override val spec = ToolSpec(
        name = "mt_open",
        description = "在 MT 管理器中打开指定的文件或目录，让它停在那个位置。" +
            "适合把用户直接送达现场（例如打开刚改好的 APK 让他签名安装）。" +
            "注意：进入 MT 之后的操作需要用户自己完成，你无法代他点击界面。",
        category = "自动化",
        layer = "L2",
        securityNote = MT_SECURITY_NOTE,
        params = objectSchema {
            string("path", "要打开的文件或目录的绝对路径，如 /sdcard/Download/app.apk")
            string(
                "mode",
                "打开方式：locate 定位并选中（默认，通用）；goto 直接进入目录；" +
                    "view 走系统打开方式（个别机型对目录更有效）",
                required = false,
                enumValues = listOf("locate", "goto", "view")
            )
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val path = try {
            args.requireStr("path")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }.trim()

        if (!path.startsWith("/")) {
            return ToolResult.failure("path 需要是绝对路径（以 / 开头），收到：$path")
        }

        val mode = args.str("mode")?.lowercase() ?: "locate"
        val pkg = MtBridge.installedPackage(ctx.appContext)
            ?: return ToolResult.failure(
                "本机没有安装 MT 管理器（已检查 ${MtBridge.PACKAGES.joinToString(" / ")}）。" +
                    "请从 https://mt2.cn 安装。"
            )

        val intent = when (mode) {
            "view" -> MtBridge.viewIntent(path, isDirectory = !File(path).extension.contains('.'), packageName = pkg)
            "goto" -> MtBridge.openIntent(path, operation = "goto", packageName = pkg)
            else -> MtBridge.openIntent(path, operation = "locate", packageName = pkg)
        }

        val error = MtBridge.launch(ctx.appContext, intent, pkg)
        if (error != null) return ToolResult.failure(error)

        val exists = File(path).exists()
        return ToolResult.success(
            buildString {
                appendLine("已请求 MT 管理器打开：$path")
                appendLine("方式：$mode　MT 版本：${MtBridge.versionName(ctx.appContext) ?: "未知"}")
                if (!exists) {
                    appendLine("注意：该路径在当前权限下不存在或不可读 —— " +
                        "MT 可能因此停在上级目录。若确需访问共享存储，请先授予「所有文件访问」。")
                }
                append("已切换到 MT 界面，后续操作（如反编译、签名）请用户自己完成。")
            }
        )
    }
}

// ── mt_script ─────────────────────────────────────────────────────────────

/**
 * 把一段脚本交给 MT 执行。
 *
 * ## 为什么不让 `run_command` 直接跑
 * App 自身只有 Android 自带的 `sh`，命令集很窄（没有 curl/sed/python…）。
 * MT 装了终端扩展包后自带 busybox 全家桶和 Python 运行环境，
 * 同一段脚本在那边能跑通、在这边会报 `command not found` —— 这就是本工具存在的理由。
 *
 * ## 为什么只是"打开"而不是"执行"
 * 调研（MT 官方论坛 / GitHub）结论：MT **没有**对外开放"执行这个脚本"的 intent
 * 入口 —— 免 root 可用的只有用户在 MT 里「长按文件 → 打开方式 → 脚本执行器」
 * 这条手动路径；往 `/data/data/bin.mt.plus/tome/term/` 塞脚本让 MT 终端加载的
 * 方案则需要 root。所以本工具的策略是：**写好脚本 → 让 MT 停在它上面 → 由用户点一下**。
 * 与其假装能一步到位，不如把最后一步明确交出去。
 */
class MtScriptTool : Tool {

    override val spec = ToolSpec(
        name = "mt_script",
        description = "把一段 shell 脚本写入共享存储，并在 MT 管理器中打开它，" +
            "以便借助 MT 的终端扩展包环境（自带 busybox / python / curl 等命令）执行。" +
            "适合 App 自带 sh 跑不动、但装了 MT 终端扩展包的手机。" +
            "注意：脚本的**执行**必须由用户在 MT 里手动确认（长按 → 打开方式 → 脚本执行器），" +
            "你无法代他执行。",
        category = "自动化",
        layer = "L2",
        defaultEnabled = false,
        destructive = true,
        securityNote = "会把脚本写入共享存储并跳转到 MT。脚本内容由模型生成，请自行过目后再执行。",
        params = objectSchema {
            string("script", "完整脚本内容（不要包含 shebang 以外的解释性文字）")
            string("filename", "脚本文件名，默认自动生成", required = false)
            string(
                "directory",
                "保存目录，默认 /sdcard/Download",
                required = false
            )
            boolean("open_in_mt", "是否立即在 MT 中打开该脚本，默认 true", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val script = try {
            args.requireStr("script")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }

        val directory = args.str("directory")?.trim()?.ifEmpty { null } ?: "/sdcard/Download"
        val name = args.str("filename")?.trim()?.ifEmpty { null }
            ?: "auto_${System.currentTimeMillis() % 100000}.sh"
        val openInMt = args.bool("open_in_mt", true)

        val target = File(directory, name)

        return withContext(Dispatchers.IO) {
            try {
                target.parentFile?.mkdirs()
                val body = if (script.startsWith("#!")) script else "#!/system/bin/sh\n$script"
                target.writeText(body + "\n", Charsets.UTF_8)
            } catch (e: SecurityException) {
                return@withContext ToolResult.failure(
                    "没有写入 $directory 的权限。请到「设置 → 工具权限 → 一键启动」" +
                        "开启「所有文件访问」，然后重试。"
                )
            } catch (t: Throwable) {
                return@withContext ToolResult.failure(
                    "写入脚本失败：${t.message ?: t::class.java.simpleName}"
                )
            }

            val result = StringBuilder()
            result.appendLine("脚本已写入：${target.absolutePath}（${target.length()} 字节）")

            if (openInMt) {
                val pkg = MtBridge.installedPackage(ctx.appContext)
                if (pkg == null) {
                    result.appendLine("未检测到 MT 管理器，未能打开。脚本已保存，可自行用其他方式执行。")
                } else {
                    val error = MtBridge.launch(
                        ctx.appContext,
                        MtBridge.openIntent(target.absolutePath, "locate", pkg),
                        pkg
                    )
                    if (error != null) {
                        result.appendLine("打开 MT 失败：$error")
                    } else {
                        result.appendLine("已在 MT 中定位到该脚本。")
                        result.appendLine(
                            "请在 MT 里长按该文件 → 打开方式 → 脚本执行器 运行它；" +
                                "这一步必须由用户手动完成。"
                        )
                    }
                }
            }

            result.append("提示：需要脚本的执行结果时，可先用 run_command 在本机跑一遍试试 —— 能跑通就不必绕道 MT。")
            ToolResult.success(result.toString())
        }
    }
}
