package com.example.nativedemo.tools.builtin

import android.os.Build
import android.text.Html
import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.int
import com.example.nativedemo.tools.net.SafeHttpFetcher
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import kotlinx.serialization.json.JsonObject

/**
 * 抓取公开网页并返回正文纯文本。
 * 所有安全校验都下沉在 [SafeHttpFetcher] 里（协议白名单 / SSRF 拦截 / 重定向复检 / 大小上限）。
 */
class WebFetchTool(
    private val fetcher: SafeHttpFetcher
) : Tool {

    override val spec = ToolSpec(
        name = "web_fetch",
        description = "抓取一个公开网页并返回其正文纯文本。仅支持 http/https 公网地址，内网与本机地址会被拦截。",
        category = "网络",
        layer = "L1",
        params = objectSchema {
            string("url", "要抓取的完整网址，必须以 http:// 或 https:// 开头")
            integer("max_chars", "返回正文的最大字符数，默认 8000", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val url = try {
            args.requireStr("url")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }
        val maxChars = args.int("max_chars", 8000).coerceIn(200, 60_000)

        return try {
            val result = fetcher.fetch(url)
            val raw = result.body.toString(Charsets.UTF_8)
            val text = if (result.contentType.contains("html", ignoreCase = true)) {
                htmlToText(raw)
            } else {
                raw
            }
            val header = buildString {
                appendLine("来源：${fetcher.redact(result.finalUrl)}")
                appendLine("类型：${result.contentType.ifBlank { "未知" }}")
                appendLine("SHA-256：${result.sha256}")
                if (result.truncated) appendLine("提示：响应体超过上限，内容已截断")
                append("---\n")
            }
            ToolResult.success(header + text.take(maxChars))
        } catch (e: SecurityException) {
            ToolResult.failure("安全拦截：${e.message}")
        } catch (e: Throwable) {
            ToolResult.failure("抓取失败：${e.message ?: e::class.java.simpleName}")
        }
    }

    @Suppress("DEPRECATION")
    private fun htmlToText(html: String): String {
        val plain = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString()
        } else {
            Html.fromHtml(html).toString()
        }
        return plain
            .replace('\u00A0', ' ')
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\n\\s*\\n\\s*\\n+"), "\n\n")
            .trim()
    }
}
