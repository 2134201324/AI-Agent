package com.example.nativedemo.tools.builtin

import android.net.Uri
import com.example.nativedemo.tools.Tool
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolResult
import com.example.nativedemo.tools.ToolSpec
import com.example.nativedemo.tools.int
import com.example.nativedemo.tools.objectSchema
import com.example.nativedemo.tools.requireStr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import java.io.ByteArrayOutputStream

/**
 * 读取用户已授权目录中的文本文件。
 * 访问前必须通过 [com.example.nativedemo.tools.saf.UriAccessPolicy] 的双重校验。
 */
class FileReadTool : Tool {

    override val spec = ToolSpec(
        name = "file_read",
        description = "读取用户已授权目录中某个文本文件的内容。path 可以是相对路径（如 code_game/readme.md），" +
            "也可以是 content:// URI —— 直接用路径即可，无需向用户索要 URI。",
        category = "文件",
        layer = "L1",
        params = objectSchema {
            string("path", "文件路径，例如 code_game/readme.md，或完整 content:// URI")
            integer("max_bytes", "最多读取的字节数，默认 200000", required = false)
        }
    )

    override suspend fun invoke(args: JsonObject, ctx: ToolContext): ToolResult {
        val pathArg = try {
            args.requireStr("path")
        } catch (e: IllegalArgumentException) {
            return ToolResult.failure(e.message ?: "参数错误")
        }

        val document = ctx.uriAccessPolicy.resolveDocument(pathArg)
            ?: return ToolResult.failure(
                "未找到「$pathArg」。可以先调用 file_list 查看已授权目录里有哪些文件。"
            )
        if (document.isDirectory) {
            return ToolResult.failure("「$pathArg」是一个目录，请改用 file_list 列出它的内容。")
        }
        val uri = document.uri

        ctx.uriAccessPolicy.denyReason(uri, write = false)?.let { return ToolResult.failure(it) }

        val limit = args.int("max_bytes", 200_000).coerceIn(1024, 2_000_000)

        return withContext(Dispatchers.IO) {
            try {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { input ->
                    val out = ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    var total = 0
                    var truncated = false
                    while (true) {
                        val read = input.read(buffer)
                        if (read == -1) break
                        if (total + read > limit) {
                            out.write(buffer, 0, limit - total)
                            truncated = true
                            break
                        }
                        out.write(buffer, 0, read)
                        total += read
                    }
                    out.toByteArray() to truncated
                } ?: return@withContext ToolResult.failure("无法打开该文件（可能已被删除或无权访问）")

                val (data, truncated) = bytes
                if (data.isEmpty()) {
                    return@withContext ToolResult.success("（文件为空）")
                }
                val text = String(data, Charsets.UTF_8)
                val note = if (truncated) "\n\n（注意：文件较大，仅返回前 $limit 字节）" else ""
                ToolResult.success(text + note)
            } catch (e: SecurityException) {
                ToolResult.failure("权限不足：${e.message}")
            } catch (e: Throwable) {
                ToolResult.failure("读取失败：${e.message ?: e::class.java.simpleName}")
            }
        }
    }
}
