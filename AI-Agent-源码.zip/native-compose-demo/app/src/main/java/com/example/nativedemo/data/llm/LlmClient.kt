package com.example.nativedemo.data.llm

import com.example.nativedemo.core.AppErrorCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlin.math.min

/**
 * OpenAI 兼容协议的 LLM 客户端（非流式）。
 *
 * 可重试错误（限流 / 5xx / 网络 / 超时）按指数退避重试，最多 [MAX_ATTEMPTS] 次。
 */
class LlmClient {

    companion object {
        private const val MAX_ATTEMPTS = 3
        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    }

    val json: Json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        encodeDefaults = true
        isLenient = true
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /**
     * 由 base URL 推出真正的接口地址。
     *
     * Base URL 只需填到**版本层**（例如 `https://api.openai.com/v1`），
     * 本方法负责拼接 `/chat/completions`。若用户把完整路径也填进来会重复拼接，
     * 导致 404 —— 设置页会实时展示拼接结果以便自查。
     */
    fun chatUrl(baseUrl: String): String = baseUrl.trim().trimEnd('/') + "/chat/completions"

    /**
     * 计算 `Authorization` 头的取值。
     *
     * 本地桥接（DSH 等）不校验令牌，但协议要求该头存在 —— 留空时给占位值，
     * 用户就不必为了「让按钮亮起来」随便编一个 Key。
     */
    private fun bearer(apiKey: String): String =
        apiKey.trim().takeIf { it.isNotEmpty() } ?: LOCAL_BRIDGE_PLACEHOLDER_KEY

    suspend fun chat(
        baseUrl: String,
        apiKey: String,
        request: ChatRequest
    ): ChatResponse = withContext(Dispatchers.IO) {
        var attempt = 0
        var lastError: LlmException? = null
        while (attempt < MAX_ATTEMPTS) {
            attempt++
            try {
                return@withContext executeOnce(baseUrl, apiKey, request)
            } catch (e: LlmException) {
                lastError = e
                if (!e.retryable || attempt >= MAX_ATTEMPTS) throw e
                val backoffMs = when (e) {
                    is LlmException.RateLimited ->
                        (e.retryAfterSeconds?.times(1000)) ?: (1000L shl (attempt - 1))
                    else -> 1000L shl (attempt - 1)
                }
                delay(min(backoffMs, 8000L) + (0..250L).random())
            }
        }
        throw lastError ?: LlmException.Network("未知网络错误")
    }

    /**
     * 流式对话：文本增量通过 [onTextDelta] 实时回调，思考内容通过 [onReasoningDelta]，
     * 返回时给出完整响应（含按 index 归并好的 tool_calls）。
     *
     * 关键点：
     * - 流式下 tool_calls 的 arguments 是**分段**下发的，必须按 index 累积拼接后再整体
     *   解析 JSON —— 对单个分片解析必然失败；
     * - 推理模型「思考强度大」时会先长时间只发 reasoning_content。若不解析它，
     *   界面在整段思考期间没有任何可见变化，看起来就像卡死；解析并展示才是正解；
     * - **中途断流不再丢掉已有内容**：已收到文本时把响目标记为 [ChatResponse.incomplete]，
     *   让上层自动续写，而不是把用户已经看到的几百字整段作废。
     */
    suspend fun chatStream(
        baseUrl: String,
        apiKey: String,
        request: ChatRequest,
        /**
         * 思考增量回调。
         *
         * 刻意放在**尾随 lambda 之前**并带默认值：这样既有的
         * `chatStream(...) { piece -> }` 写法仍然绑定到 [onTextDelta]，
         * 不会因为新增参数而悄悄绑错。
         */
        onReasoningDelta: (suspend (String) -> Unit)? = null,
        onTextDelta: suspend (String) -> Unit
    ): ChatResponse = withContext(Dispatchers.IO) {
        val url = chatUrl(baseUrl)
        val payload = json.encodeToString(
            ChatRequest.serializer(),
            request.copy(stream = true)
        )
        val httpRequest = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer ${bearer(apiKey)}")
            .header("Content-Type", "application/json")
            .header("Accept", "text/event-stream")
            .post(payload.toRequestBody(JSON_MEDIA))
            .build()

        // 流式响应不能设读超时，否则长回复会被中途掐断
        val streamingClient = client.newBuilder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .build()

        val textBuffer = StringBuilder()
        val reasoningBuffer = StringBuilder()
        val toolCalls = linkedMapOf<Int, ToolCallAccumulator>()
        var nextCallIndex = 0
        var activeCallIndex = -1
        var finishReason: String? = null
        var responseId: String? = null
        var responseModel: String? = null
        var incomplete = false

        try {
            streamingClient.newCall(httpRequest).execute().use { response ->
                val body = response.body
                    ?: throw LlmException.ProtocolViolation("流式响应没有内容体")

                if (!response.isSuccessful) {
                    throw mapHttpError(
                        response.code,
                        body.string(),
                        response.header("Retry-After"),
                        url
                    )
                }

                body.source().use { source ->
                    while (true) {
                        val line = source.readUtf8Line() ?: break
                        if (line.isBlank() || !line.startsWith("data:")) continue

                        val data = line.removePrefix("data:").trim()
                        if (data.isEmpty()) continue
                        if (data == "[DONE]") break

                        val chunk = runCatching {
                            json.decodeFromString(StreamChunk.serializer(), data)
                        }.getOrNull() ?: continue

                        chunk.id?.let { responseId = it }
                        chunk.model?.let { responseModel = it }

                        val choice = chunk.choices.firstOrNull() ?: continue
                        choice.finishReason?.let { finishReason = it }

                        val delta = choice.delta

                        // 思考内容：与正式回答分开累积，避免污染历史（推理模型
                        // 通常不允许把 reasoning 再回传，否则下一轮直接 400）
                        (delta?.reasoningContent ?: delta?.reasoning)
                            ?.takeIf { it.isNotEmpty() }
                            ?.let { piece ->
                                reasoningBuffer.append(piece)
                                onReasoningDelta?.invoke(piece)
                            }

                        delta?.content?.takeIf { it.isNotEmpty() }?.let { piece ->
                            textBuffer.append(piece)
                            onTextDelta(piece)
                        }

                        delta?.toolCalls?.forEach { piece ->
                            // 有些服务端在流式下不回 index。若盲目归到 0，同一轮的多个
                            // 调用会把各自的 arguments 拼成一坨，产出非法 JSON —— 所以：
                            // 带 index 就信任它；不带的按「是否出现新 id」切分。
                            val index = piece.index ?: run {
                                val id = piece.id
                                val isNewCall = !id.isNullOrBlank() &&
                                    toolCalls.values.none { it.id == id }
                                if (isNewCall || activeCallIndex < 0) {
                                    activeCallIndex = nextCallIndex++
                                }
                                activeCallIndex
                            }
                            activeCallIndex = index

                            val accumulator = toolCalls.getOrPut(index) { ToolCallAccumulator() }
                            piece.id?.takeIf { it.isNotBlank() }?.let { accumulator.id = it }
                            piece.function?.name?.takeIf { it.isNotBlank() }?.let { accumulator.name = it }
                            piece.function?.arguments?.let { accumulator.arguments.append(it) }
                        }
                    }
                }
            }
        } catch (e: LlmException) {
            throw e
        } catch (e: SocketTimeoutException) {
            incomplete = markIncompleteOrThrow(textBuffer, reasoningBuffer) {
                LlmException.Timeout("流式连接超时：${e.message ?: "无详情"}")
            }
        } catch (e: UnknownHostException) {
            incomplete = markIncompleteOrThrow(textBuffer, reasoningBuffer) {
                LlmException.Network("无法解析域名：${e.message ?: url}")
            }
        } catch (e: IOException) {
            incomplete = markIncompleteOrThrow(textBuffer, reasoningBuffer) {
                LlmException.Network("连接中断：${e.message ?: e::class.java.simpleName}")
            }
        }

        val assembled = ChatMessage(
            role = "assistant",
            content = textBuffer.toString().takeIf { it.isNotEmpty() }?.let { JsonPrimitive(it) },
            toolCalls = toolCalls.takeIf { it.isNotEmpty() }?.map { (index, acc) ->
                ToolCall(
                    id = acc.id.ifBlank { "call_$index" },
                    function = FunctionCall(
                        name = acc.name,
                        arguments = acc.arguments.toString()
                    )
                )
            }
        )

        ChatResponse(
            id = responseId,
            model = responseModel,
            choices = listOf(Choice(index = 0, message = assembled, finishReason = finishReason)),
            incomplete = incomplete
        )
    }

    /**
     * 中途断流时的处置：**已经收到内容就别丢**。
     *
     * 返回 true 表示「标记为不完整，交给上层续写」；什么都没收到时才抛异常，
     * 让用户看到真正的错误而不是一段空白。
     */
    private fun markIncompleteOrThrow(
        textBuffer: StringBuilder,
        reasoningBuffer: StringBuilder,
        error: () -> LlmException
    ): Boolean {
        if (textBuffer.isEmpty() && reasoningBuffer.isEmpty()) throw error()
        return true
    }

    private class ToolCallAccumulator {
        var id: String = ""
        var name: String = ""
        val arguments = StringBuilder()
    }

    private fun executeOnce(
        baseUrl: String,
        apiKey: String,
        request: ChatRequest
    ): ChatResponse {
        val url = chatUrl(baseUrl)
        val payload = json.encodeToString(ChatRequest.serializer(), request)
        val httpRequest = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer ${bearer(apiKey)}")
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .post(payload.toRequestBody(JSON_MEDIA))
            .build()

        try {
            client.newCall(httpRequest).execute().use { response ->
                val bodyText = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw mapHttpError(response.code, bodyText, response.header("Retry-After"), url)
                }
                if (bodyText.isBlank()) {
                    throw LlmException.ProtocolViolation("服务端返回空响应体")
                }
                return try {
                    json.decodeFromString(ChatResponse.serializer(), bodyText)
                } catch (t: Throwable) {
                    throw LlmException.ProtocolViolation(
                        "无法解析响应（可能不是 OpenAI 兼容接口）：${t.message}\n实际请求地址：$url"
                    )
                }
            }
        } catch (e: LlmException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw LlmException.Timeout("请求超时：${e.message ?: "无详情"}\n实际请求地址：$url")
        } catch (e: UnknownHostException) {
            throw LlmException.Network("无法解析域名：${e.message ?: url}")
        } catch (e: IOException) {
            throw LlmException.Network("网络错误：${e.message ?: e::class.java.simpleName}")
        }
    }

    private fun mapHttpError(
        status: Int,
        bodyText: String,
        retryAfter: String?,
        url: String
    ): LlmException {
        val serverMessage = extractMessage(bodyText)
        return when (status) {
            401, 403 -> LlmException.Auth(
                "鉴权失败（HTTP $status）：$serverMessage\n" +
                    "说明地址是通的，问题出在 API Key 或它的权限范围。"
            )

            429 -> LlmException.RateLimited(
                "触发限流（HTTP 429）：$serverMessage",
                retryAfter?.toLongOrNull()
            )

            404 -> LlmException.BadRequest(
                status,
                "接口地址不存在（HTTP 404）：$serverMessage\n" +
                    "实际请求地址：$url\n" +
                    "请检查 Base URL —— 它应是「版本层」地址，不含 /chat/completions。\n" +
                    "参考：OpenAI → https://api.openai.com/v1 ；" +
                    "阿里云百炼 → https://dashscope.aliyuncs.com/compatible-mode/v1",
                serverRaw = serverMessage
            )

            400 -> {
                // 400 的成因差别极大，提示必须和服务端原文对上号，否则会把
                // 排查方向带偏（历史上就把「历史损坏」误报成「不支持工具」过）。
                val lower = serverMessage.lowercase()
                val argumentsBroken = "function.arguments" in lower ||
                    ("arguments" in lower && "json" in lower)
                val hint = if (looksLikeRichContentRejected(serverMessage)) {
                    "这条错误说的是**消息内容的类型**：该服务只接受字符串形式的 content，\n" +
                        "而历史里有图片等多模态消息（content 是数组）—— 所以从发图那一轮起，\n" +
                        "这个会话每轮都会失败。\n" +
                        "本版会自动把历史中的图片转成文字占位后重试，**直接再发一次即可**。"
                } else if (argumentsBroken) {
                    "这条错误说的是**工具参数格式**问题，并不代表服务不支持工具调用。\n" +
                        "常见成因：历史里残留了一条参数被截断的工具调用记录（长参数生成到一半被截断）。\n" +
                        "本版会在每次发送前自动清理这类记录，直接重试即可；若仍失败，新建一个对话。"
                } else {
                    "常见原因：模型名在该服务不存在、该服务不支持 function calling（tools），" +
                        "或参数不被接受。可先在设置页关闭全部工具再试。"
                }
                LlmException.BadRequest(
                    status,
                    "请求被拒绝（HTTP 400）：$serverMessage\n实际请求地址：$url\n$hint",
                    serverRaw = serverMessage
                )
            }

            in 500..599 -> LlmException.Server(
                status,
                "服务端错误（HTTP $status）：$serverMessage"
            )

            else -> LlmException.BadRequest(
                status,
                "请求被拒绝（HTTP $status）：$serverMessage\n实际请求地址：$url"
            )
        }
    }

    private fun extractMessage(bodyText: String): String {
        if (bodyText.isBlank()) return "无响应内容"

        val trimmed = bodyText.trimStart()

        // 服务端返回 HTML（网关 / 反向代理的错误页）时，不要把整页塞进提示里
        if (trimmed.startsWith("<!") || trimmed.startsWith("<html", ignoreCase = true)) {
            val title = Regex("<title[^>]*>(.*?)</title>", RegexOption.DOT_MATCHES_ALL)
                .find(trimmed)
                ?.groupValues?.get(1)
                ?.replace(Regex("\\s+"), " ")
                ?.trim()
                ?.take(120)
            return buildString {
                append("服务端返回的是 HTML 页面，而不是 API 的 JSON 响应")
                if (!title.isNullOrBlank()) append("（页面标题：$title）")
                append("。这通常说明请求打到了错误的地址或网关。")
            }
        }

        return try {
            json.decodeFromString(ApiErrorEnvelope.serializer(), bodyText)
                .error?.message?.takeIf { it.isNotBlank() }
                ?: bodyText.take(300)
        } catch (t: Throwable) {
            bodyText.take(300)
        }
    }

    data class Diagnosis(
        val ok: Boolean,
        val message: String,
        val toolsSupported: Boolean? = null,
        val requestUrl: String = ""
    )

    /**
     * 两步诊断，用来分清「地址/Key/模型名」与「工具支持」这两类问题：
     * 1. 发一条最小请求 —— 验证鉴权、地址、模型名是否都对；
     * 2. 再带 tools 发一条 —— 探测服务端是否支持 function calling。
     */
    suspend fun diagnose(baseUrl: String, apiKey: String, model: String): Diagnosis {
        val url = chatUrl(baseUrl)

        val firstResponse = try {
            chat(
                baseUrl = baseUrl,
                apiKey = apiKey,
                request = ChatRequest(
                    model = model,
                    messages = listOf(ChatMessage.user("ping")),
                    temperature = 0.0,
                    stream = false
                )
            )
        } catch (e: LlmException) {
            val error = e.toAppError()
            return Diagnosis(
                ok = false,
                message = listOfNotNull(error.message, error.hint).joinToString("\n"),
                toolsSupported = null,
                requestUrl = url
            )
        } catch (e: Throwable) {
            return Diagnosis(
                ok = false,
                message = e.message ?: "未知错误",
                toolsSupported = null,
                requestUrl = url
            )
        }

        val reply = firstResponse.firstMessage?.textContent?.trim().orEmpty()

        val toolsSupported: Boolean? = try {
            chat(
                baseUrl = baseUrl,
                apiKey = apiKey,
                request = ChatRequest(
                    model = model,
                    messages = listOf(ChatMessage.user("ping")),
                    tools = listOf(probeToolDefinition()),
                    toolChoice = "auto",
                    temperature = 0.0,
                    stream = false
                )
            )
            true
        } catch (e: LlmException.BadRequest) {
            false
        } catch (e: LlmException) {
            null
        } catch (e: Throwable) {
            null
        }

        val summary = buildString {
            append("服务已连通")
            if (reply.isNotEmpty()) append("，模型回复：${reply.take(40)}")
            append('\n')
            when (toolsSupported) {
                true -> append("工具调用：正常 —— Agent 可以抓网页、读写已授权文件")
                false -> append("工具调用：该服务不接受 tools 参数，将自动降级为纯对话模式")
                null -> append("工具调用：探测未完成（不影响基础对话）")
            }
            append("\n实际请求地址：$url")
        }
        return Diagnosis(ok = true, message = summary, toolsSupported = toolsSupported, requestUrl = url)
    }

    private fun probeToolDefinition(): ToolDefinition = ToolDefinition(
        function = FunctionDefinition(
            name = "probe",
            description = "Connectivity probe. Never actually invoked.",
            parameters = JsonObject(
                mapOf(
                    "type" to JsonPrimitive("object"),
                    "properties" to JsonObject(emptyMap())
                )
            )
        )
    )

    /**
     * 拉取该 API Key 在服务端可用的模型清单（GET /models）。
     *
     * 这是「按 Key 选模型」的基础：一个 Key 能调哪些模型由它自己的权限范围决定，
     * 与其在输入框里猜名字，不如直接问服务端要清单。
     *
     * 容错：用户可能把 Base URL 填成不带版本层的形式（如 http://127.0.0.1:8000），
     * 此时 `/models` 会 404 —— 自动回退再试一次 `/v1/models`。
     */
    suspend fun listModels(baseUrl: String, apiKey: String): List<String> =
        withContext(Dispatchers.IO) {
            val root = baseUrl.trim().trimEnd('/')
            val urls = if (root.endsWith("/v1", ignoreCase = true)) {
                listOf("$root/models")
            } else {
                listOf("$root/models", "$root/v1/models")
            }
            var lastError: String? = null
            for (url in urls) {
                try {
                    val models = fetchModelsOnce(url, apiKey)
                    if (models.isNotEmpty()) return@withContext models
                    lastError = "服务端返回了空的模型清单（$url）"
                } catch (e: LlmException.BadRequest) {
                    // 只有 404 才值得换下一个候选地址；参数错误、鉴权失败等直接抛出
                    if (e.status != 404) throw e
                    lastError = e.message
                }
            }
            throw LlmException.ProtocolViolation(
                lastError ?: "无法获取模型清单：服务端没有返回可识别的模型列表"
            )
        }

    private fun fetchModelsOnce(url: String, apiKey: String): List<String> {
        val httpRequest = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer ${bearer(apiKey)}")
            .header("Accept", "application/json")
            .get()
            .build()

        try {
            client.newCall(httpRequest).execute().use { response ->
                val bodyText = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw mapHttpError(response.code, bodyText, response.header("Retry-After"), url)
                }
                return parseModelIds(bodyText)
            }
        } catch (e: LlmException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw LlmException.Timeout("请求超时：${e.message ?: "无详情"}\n实际请求地址：$url")
        } catch (e: UnknownHostException) {
            throw LlmException.Network("无法解析域名：${e.message ?: url}")
        } catch (e: IOException) {
            throw LlmException.Network("网络错误：${e.message ?: e::class.java.simpleName}")
        }
    }
}

/** 便于把 LlmException 的 code 映射到 UI 层。 */
internal fun LlmException.codeName(): String = toAppError().code.name

internal fun Throwable.toAppErrorCode(): AppErrorCode = when (this) {
    is LlmException -> toAppError().code
    is SecurityException -> AppErrorCode.PERMISSION
    is IOException -> AppErrorCode.IO
    else -> AppErrorCode.UNKNOWN
}
