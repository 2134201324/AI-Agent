package com.example.nativedemo.core

import android.content.Context
import com.example.nativedemo.data.agent.AgentEngine
import com.example.nativedemo.data.agent.ChatSession
import com.example.nativedemo.data.agent.ConversationRepository
import com.example.nativedemo.data.agent.ConversationStore
import com.example.nativedemo.data.agent.Orchestrator
import com.example.nativedemo.data.llm.BridgeDiscovery
import com.example.nativedemo.data.llm.LlmClient
import com.example.nativedemo.build.BuildProjectStore
import com.example.nativedemo.build.CloudBuildGateway
import com.example.nativedemo.build.CloudBuildProvider
import com.example.nativedemo.data.rea.ReaGateway
import com.example.nativedemo.data.settings.SecureStore
import com.example.nativedemo.data.settings.SettingsRepository
import com.example.nativedemo.data.terminal.TerminalEngine
import com.example.nativedemo.tools.ToolContext
import com.example.nativedemo.tools.ToolRegistry
import com.example.nativedemo.tools.apk.ApkDexTool
import com.example.nativedemo.tools.apk.ApkExtractTool
import com.example.nativedemo.tools.apk.ApkInfoTool
import com.example.nativedemo.tools.apk.ApkListTool
import com.example.nativedemo.tools.apk.ApkManifestTool
import com.example.nativedemo.tools.apk.ApkPackTool
import com.example.nativedemo.tools.apk.ApkReadTool
import com.example.nativedemo.tools.apk.ApkReplaceTool
import com.example.nativedemo.tools.apk.ApkSignTool
import com.example.nativedemo.tools.apk.ApkUnpackTool
import com.example.nativedemo.tools.apk.ApkResourcesTool
import com.example.nativedemo.tools.apk.ApkSearchTool
import com.example.nativedemo.tools.apk.ApkSignatureTool
import com.example.nativedemo.tools.builtin.CommandTool
import com.example.nativedemo.tools.builtin.FileCreateTool
import com.example.nativedemo.tools.builtin.FileDeleteTool
import com.example.nativedemo.tools.builtin.FileEditTool
import com.example.nativedemo.tools.builtin.FileListTool
import com.example.nativedemo.tools.builtin.FileMkdirTool
import com.example.nativedemo.tools.builtin.FileReadTool
import com.example.nativedemo.tools.builtin.FileWriteBinaryTool
import com.example.nativedemo.tools.builtin.FileWriteTool
import com.example.nativedemo.tools.builtin.ImageConvertTool
import com.example.nativedemo.tools.builtin.MtOpenTool
import com.example.nativedemo.tools.builtin.MtScriptTool
import com.example.nativedemo.tools.builtin.WebFetchTool
import com.example.nativedemo.tools.builtin.WebSearchTool
import com.example.nativedemo.tools.build.CloudPackTool
import com.example.nativedemo.tools.net.SafeHttpFetcher
import com.example.nativedemo.tools.rea.reaToolSet
import com.example.nativedemo.tools.saf.SafPermissionStore
import com.example.nativedemo.tools.saf.UriAccessPolicy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File

/**
 * 手写依赖容器（本项目规模不需要 Hilt/Koin）。
 *
 * 工具在这里集中注册 —— 想加新能力，只需实现 [com.example.nativedemo.tools.Tool]
 * 并加进下面的 registerAll。
 */
class AppContainer(context: Context) {

    val appContext: Context = context.applicationContext

    /**
     * 应用级协程作用域。
     *
     * 生成任务挂在这里而不是 ViewModel 的 scope：ViewModel 会随 Activity 销毁而取消，
     * 而一轮生成可能要跑几分钟 —— 那样「切后台/转屏」就等于中断。
     */
    private val applicationScope: CoroutineScope =
        CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /**
     * 当前对话的运行态（消息列表、是否在跑、进度文案）。
     *
     * 提升到单例的收益：界面重建后订阅的还是同一份状态，消息与运行标志都不会丢。
     */
    val chatSession: ChatSession = ChatSession()

    val secureStore: SecureStore = SecureStore()
    val llmClient: LlmClient = LlmClient()
    val safeHttpFetcher: SafeHttpFetcher = SafeHttpFetcher()

    /** 命令终端引擎：UI 终端页与 run_command 工具共用同一个实现。 */
    val terminalEngine: TerminalEngine = TerminalEngine(File(appContext.filesDir, "terminal"))

    /**
     * REA 远程引擎门面。
     *
     * 注意这里是「注册表构造期就会读到」的属性，所以**不能**让它在此刻去碰
     * settingsRepository（仓库声明在下方，此刻还是 null）。给 ReaGateway 传一个
     * 取值 lambda，把这个环推迟到工具真正被调用时才解开 —— 那时两者都已就绪。
     *
     * 早期版本写成 `by lazy { ReaGateway(settingsRepository) }`，但下面
     * `reaToolSet(reaGateway)` 会在构造注册表时**读取**该属性，等于立刻强制执行
     * lazy 初始化体，启动即 NPE。改存 lambda 后不再有强制求值时机。
     */
    val reaGateway: ReaGateway = ReaGateway(settingsProvider = { settingsRepository })

    /**
     * 云构建门面。与 [reaGateway] 同一个道理：注册表构造期就会读到本属性，
     * 所以存的是取值 lambda，而不是此刻还不存在的 settingsRepository。
     */
    val cloudBuildGateway: CloudBuildGateway =
        CloudBuildGateway(settingsProvider = { settingsRepository })

    /** 云打包工程的本地存储（工程清单 / 图标 / 已下载的 APK）。 */
    val buildProjectStore: BuildProjectStore = BuildProjectStore(appContext)

    /** 云构建实现：提交、轮询、下载，全程走服务器算力。 */
    val cloudBuildProvider: CloudBuildProvider =
        CloudBuildProvider(cloudBuildGateway, buildProjectStore)

    val toolRegistry: ToolRegistry = ToolRegistry().apply {
        registerAll(
            // 联网：搜（不知道网址） + 抓（已知道网址）
            WebSearchTool(safeHttpFetcher),
            WebFetchTool(safeHttpFetcher),

            FileListTool(),
            FileReadTool(),
            FileWriteTool(),
            FileEditTool(),
            FileCreateTool(),
            FileMkdirTool(),
            FileDeleteTool(),
            CommandTool(terminalEngine),

            // APK 逆向工具集：内置解析引擎，无需任何外部二进制
            ApkInfoTool(appContext),
            ApkManifestTool(appContext),
            ApkListTool(appContext),
            ApkReadTool(appContext),
            ApkDexTool(appContext),
            ApkResourcesTool(appContext),
            ApkSearchTool(appContext),
            ApkSignatureTool(appContext),
            ApkExtractTool(appContext),

            // 改包链路：替换 / 解包 / 打包 / 签名
            ApkReplaceTool(appContext),
            ApkUnpackTool(appContext),
            ApkPackTool(appContext),
            ApkSignTool(appContext),

            // 配合改包使用的通用能力：写二进制、处理图片
            FileWriteBinaryTool(),
            ImageConvertTool(),

            // MT 管理器桥接：把用户送到操作现场（mt_open 打开路径）。
            // 刻意不提供"读取屏幕/模拟点击"类工具 —— AI 不得操作用户手机与其他
            // 应用的界面，这是不可退让的安全边界；到 MT 界面后由用户自己接手。
            MtOpenTool(),
            MtScriptTool(),

            // REA 远程逆向引擎：手机发起、服务器上的 Ghidra/Apktool 干活。
            // reaGateway 已在上方声明；它内部存的是取值 lambda，构造期不会被触发，
            // 因此此处读取它是安全的（不会反向依赖尚未建好的 settingsRepository）。
            *reaToolSet(reaGateway).toTypedArray(),

            // 云打包：把网页工程编译成可安装的 APK（服务器算力，见 build-service.js）。
            // AI 写网页 → 直接变成应用，是这条链路最自然的用法。
            CloudPackTool(cloudBuildGateway, cloudBuildProvider, buildProjectStore)
        )
    }

    // 仓库要知道「默认启用哪些工具」，否则工具开关在全默认状态下失灵；
    // 所以注册表必须先于仓库建好。
    val settingsRepository: SettingsRepository = SettingsRepository(
        context = appContext,
        secureStore = secureStore,
        defaultEnabledToolNames = toolRegistry.all()
            .filter { it.spec.defaultEnabled }
            .map { it.spec.name }
            .toSet(),
        // 注册表全量工具名：仓库据此识别"本版本新增、用户还没见过"的工具，
        // 让升级后新增的 web_search / mt_open 直接可用，而不用用户去翻开关。
        allToolNames = toolRegistry.names()
    )

    val safPermissionStore: SafPermissionStore = SafPermissionStore(appContext, settingsRepository)
    val uriAccessPolicy: UriAccessPolicy = UriAccessPolicy(appContext, safPermissionStore)

    val conversationStore: ConversationStore = ConversationStore()
    val conversationRepository: ConversationRepository = ConversationRepository(appContext)
    val agentEngine: AgentEngine = AgentEngine(llmClient, toolRegistry, conversationStore)

    /**
     * 多模型编排引擎：主模型拆任务 → 子模型并行生成 → 主模型整合。
     * 与 [agentEngine] 共用会话存储，但两条链路同一时刻只有一条在跑
     * （由设置里的编排开关决定走哪条）。
     */
    val orchestrator: Orchestrator = Orchestrator(llmClient, conversationStore)

    /** 局域网桥接服务自动发现：解决「不知该填哪个 IP」的问题。 */
    val bridgeDiscovery: BridgeDiscovery = BridgeDiscovery()

    init {
        // 终端的默认工作目录：随建随用，避免首次执行命令时目录不存在
        File(appContext.filesDir, "terminal").mkdirs()

        // 把运行态映射到前台服务与通知栏：只要 chatSession 说"在跑"，
        // 通知就会一直挂着，进程也就不会被系统随手回收
        ChatNotifier(appContext, chatSession, applicationScope)

        // 记下"这些工具用户已经见过了"。必须启动时就做一次：
        // 否则新增工具会在每次读设置时都被当成"没见过"而自动补进启用集，
        // 用户一旦把它关掉，下次启动又会被顶开 —— 表现为开关失灵。
        applicationScope.launch {
            runCatching { settingsRepository.markToolsSeen(toolRegistry.names()) }
        }
    }

    fun newToolContext(): ToolContext = ToolContext(appContext, uriAccessPolicy)

    /**
     * 在应用级作用域里启动一个后台任务。
     *
     * 与 `viewModelScope.launch` 的关键差别：**它不随界面销毁而取消**。
     * 生成回复这种"跑几分钟、期间用户可能切走"的任务必须用它，
     * 否则转屏或切后台就等于中断。
     */
    fun launchInBackground(block: suspend CoroutineScope.() -> Unit): Job =
        applicationScope.launch(block = block)
}
