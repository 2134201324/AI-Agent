package com.example.nativedemo.data.llm

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** 扫描发现的一个桥接服务。[models] 为空且 [needsKey] 为 true 表示「像个 API 但需要 Key」。 */
data class DiscoveredBridge(
    val baseUrl: String,
    val models: List<String> = emptyList(),
    val needsKey: Boolean = false
)

/**
 * 局域网桥接服务自动发现。
 *
 * 要解决的问题：用户把 DSH 一类网页桥接工具跑在电脑上，却**不知道自己该填什么 IP**。
 * 这里从本机 IP 推出所在网段（/24），并发探测常见端口上的 `/v1/models` 与 `/models`，
 * 命中「能解析出模型清单」或「返回 401/403（像个要 Key 的 API）」的主机即报告。
 *
 * 两个边界必须说清楚：
 * - **只覆盖同一局域网（WiFi）**。手机走移动数据时拿到的是运营商内网 IP，
 *   与电脑不在一个可达网段，扫不到是正常的 —— 界面会给出对应指引；
 * - 探测是「尽力而为」：连接超时的静默丢弃，绝不影响正常使用。
 */
class BridgeDiscovery {

    companion object {
        /**
         * 要探测的端口。
         *
         * 8000 是 DSH 等网页桥接的默认；其余是各类本地推理服务的常用端口，
         * 顺手一起探能显著提高「一次就找到」的概率：
         * 8080 / 3000 / 5000 常见反代与自建服务，1234 是 LM Studio，
         * 11434 是 Ollama。
         */
        val DEFAULT_PORTS: List<Int> = listOf(8000, 8001, 8080, 3000, 5000, 1234, 11434)

        /**
         * 本机与模拟器宿主地址。
         *
         * 优先探这几个：桥接跑在手机自己身上（Termux 等）或模拟器里时，
         * 这是唯一可达的地址，而且**瞬间出结果**，不必等全网段扫描。
         * 10.0.2.2 是 Android 模拟器访问宿主机的固定地址。
         */
        val LOCAL_HOSTS: List<String> = listOf("127.0.0.1", "localhost", "10.0.2.2")

        /** 整个扫描的硬上限：移动数据网段下大量连接会静默超时，不能无限等。 */
        private const val TOTAL_TIMEOUT_MS = 20_000L

        /** 单次探测的连接 / 读取超时。局域网内响应以毫秒计，宁短勿长。 */
        private const val CONNECT_TIMEOUT_MS = 600L
        private const val READ_TIMEOUT_MS = 1_500L
        private const val CONCURRENCY = 64
    }

    // 扫描专用客户端：不重试、短超时。重试会让一次扫描放大成多次无效连接。
    private val scanClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .readTimeout(READ_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .callTimeout(READ_TIMEOUT_MS + CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .retryOnConnectionFailure(false)
        .build()

    /**
     * 扫描结果。[scanned] 是已探测的地址数，[total] 是计划总数 ——
     * 即使超时提前结束，也带着已完成的部分返回，界面上能说清「扫到哪了」。
     */
    data class ScanResult(
        val bridges: List<DiscoveredBridge>,
        val scanned: Int,
        val total: Int,
        val timedOut: Boolean
    )

    /**
     * 并发扫描。取消（调用方协程取消）时立即返回已找到的结果。
     *
     * @param ownIp 本机 IPv4 地址，为空则无从推导网段，直接返回空结果。
     * @param onProgress 每探测完一个地址回调一次（scanned, total）。
     */
    suspend fun scan(
        ownIp: String?,
        ports: List<Int> = DEFAULT_PORTS,
        onProgress: (scanned: Int, total: Int) -> Unit = { _, _ -> }
    ): ScanResult = scanHosts(subnetCandidates(ownIp), ports, onProgress)

    /**
     * 只探本机与模拟器宿主（21 个地址，毫秒级）。
     *
     * 一键连接先跑这个：手机自建桥接 / 模拟器场景下立刻命中，
     * 不用等局域网扫描。
     */
    suspend fun scanLocal(ports: List<Int> = DEFAULT_PORTS): List<DiscoveredBridge> =
        scanHosts(LOCAL_HOSTS, ports) { _, _ -> }.bridges

    private suspend fun scanHosts(
        hosts: List<String>,
        ports: List<Int>,
        onProgress: (scanned: Int, total: Int) -> Unit = { _, _ -> }
    ): ScanResult {
        val total = hosts.size * ports.size
        if (total == 0) {
            return ScanResult(bridges = emptyList(), scanned = 0, total = 0, timedOut = false)
        }

        val found = CopyOnWriteArrayList<DiscoveredBridge>()
        val scanned = AtomicInteger(0)
        val gate = Semaphore(CONCURRENCY)

        val completedNormally = withTimeoutOrNull(TOTAL_TIMEOUT_MS) {
            coroutineScope {
                for (host in hosts) {
                    for (port in ports) {
                        launch {
                            gate.withPermit {
                                val result = probe(host, port)
                                val done = scanned.incrementAndGet()
                                onProgress(done, total)
                                when (result) {
                                    is ProbeResult.Hit -> found.add(result.bridge)
                                    is ProbeResult.NeedsKey ->
                                        found.add(DiscoveredBridge(result.baseUrl, needsKey = true))
                                    else -> Unit
                                }
                            }
                        }
                    }
                }
            }
            true
        } != null

        return ScanResult(
            bridges = found.sortedBy { it.baseUrl },
            scanned = scanned.get(),
            total = total,
            timedOut = !completedNormally
        )
    }

    private sealed interface ProbeResult {
        data class Hit(val bridge: DiscoveredBridge) : ProbeResult
        data class NeedsKey(val baseUrl: String) : ProbeResult

        /** 该前缀下没有这个端点，换下一个候选前缀（如 /v1 → 根路径）再试。 */
        data object NotFound : ProbeResult

        /** 确认未命中（超时 / 拒连 / 非 JSON 响应），不再试其他前缀。 */
        data object Miss : ProbeResult
    }

    private suspend fun probe(ip: String, port: Int): ProbeResult = withContext(Dispatchers.IO) {
        val prefixes = listOf("http://$ip:$port/v1", "http://$ip:$port")

        // 第一优先：要模型清单 —— 能解析出清单就一定是 OpenAI 兼容服务，最可靠
        for (prefix in prefixes) {
            val result = probeUrl("$prefix/models")
            if (result !is ProbeResult.NotFound) return@withContext result
        }

        // 退回：有些桥接只实现了对话接口、没有 /models。
        // 用 OPTIONS 探路径是否存在 —— 405（方法不允许）、400、401 都说明
        // 「这个路径上确实有服务」，只有 404 才算不存在。
        for (prefix in prefixes) {
            if (endpointExists("$prefix/chat/completions")) {
                return@withContext ProbeResult.Hit(
                    DiscoveredBridge(baseUrl = prefix, models = emptyList())
                )
            }
        }
        ProbeResult.Miss
    }

    /** 该路径上是否存在一个 HTTP 服务（不关心方法是否被允许）。 */
    private fun endpointExists(url: String): Boolean {
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .method("OPTIONS", null)
            .build()
        return try {
            scanClient.newCall(request).execute().use { response ->
                response.code != 404
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            false
        }
    }

    private fun probeUrl(url: String): ProbeResult {
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .get()
            .build()
        return try {
            scanClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                when {
                    response.isSuccessful -> {
                        val ids = parseModelIds(body)
                        if (ids.isNotEmpty()) {
                            // 从 URL 反推 baseUrl：去掉尾部的 /models
                            ProbeResult.Hit(
                                DiscoveredBridge(baseUrl = url.removeSuffix("/models"), models = ids)
                            )
                        } else {
                            ProbeResult.Miss
                        }
                    }

                    response.code == 401 || response.code == 403 -> ProbeResult.NeedsKey(
                        url.removeSuffix("/models")
                    )

                    response.code == 404 -> ProbeResult.NotFound
                    else -> ProbeResult.Miss
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            // 连接超时 / 拒绝 / 协议错误一律视为未命中：扫不到比误报好
            ProbeResult.Miss
        }
    }
}

/**
 * 由本机 IP 推导同网段候选主机（/24，纯函数）。
 *
 * 排除自身、网段地址（.0）与广播地址（.255）。ownIp 为空或不是合法
 * IPv4 点分地址时返回空列表 —— 例如飞行模式下无从扫描。
 */
fun subnetCandidates(ownIp: String?): List<String> {
    if (ownIp.isNullOrBlank()) return emptyList()
    val octets = ownIp.split(".")
    if (octets.size != 4) return emptyList()
    val values = octets.map { it.toIntOrNull() ?: return emptyList() }
    if (values.any { it !in 0..255 }) return emptyList()
    val prefix = "${values[0]}.${values[1]}.${values[2]}"
    val self = values[3]
    return (1..254).filter { it != self }.map { "$prefix.$it" }
}

/**
 * 取本机 IPv4 地址（无需任何权限）。
 *
 * 走 [NetworkInterface] 枚举而不是 WifiManager：后者在高版本 Android 上
 * 既被废弃又受限于「只能拿到自己的地址」，且需要位置权限才能反推 SSID。
 * 移动数据下返回的是运营商内网地址 —— 扫不到局域网服务属预期，界面另有指引。
 */
fun localIpv4Address(): String? = runCatching {
    NetworkInterface.getNetworkInterfaces()?.asSequence()
        ?.filter { it.isUp && !it.isLoopback }
        ?.flatMap { it.inetAddresses.asSequence() }
        ?.filterIsInstance<Inet4Address>()
        ?.firstOrNull { !it.isLoopbackAddress && it.hostAddress?.contains(':') == false }
        ?.hostAddress
}.getOrNull()
