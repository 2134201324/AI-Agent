package com.example.nativedemo.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nativedemo.ui.common.CollapseChip
import com.example.nativedemo.ui.theme.Accent
import com.example.nativedemo.ui.theme.ChipBg
import com.example.nativedemo.ui.theme.Faint
import com.example.nativedemo.ui.theme.Fg
import com.example.nativedemo.ui.theme.LineColor
import com.example.nativedemo.ui.theme.Muted

/** 折叠态预览多少行代码。 */
private const val PREVIEW_LINES = 2

/** 展开态代码区的高度上限，超了内部纵滚，不把对话流撑爆。 */
private val EXPANDED_MAX_HEIGHT = 220.dp

/**
 * 可折叠的代码块卡片。
 *
 * 折叠时只露出一行摘要（语言 / 行数 / 首行预览），展开才是等宽代码区。
 * 流式生成中（[MsgSegment.Code.closed] 为 false）默认保持折叠并标注「生成中」——
 * 否则代码会随每个 token 向上顶，把对话冲得七零八落。
 *
 * 折叠入口与思考卡保持一致：**整行摘要可点**，展开后底部再给一个「收起代码」。
 * 代码文本自带选区容器，长按可选中复制；它只覆盖文本区，不挡点击。
 *
 * @param index 该代码块在消息内的序号，用作展开状态的记忆键（重组时保持）
 */
@Composable
fun CollapsibleCodeBlock(
    segment: MsgSegment.Code,
    index: Int,
    modifier: Modifier = Modifier
) {
    var expanded by rememberSaveable(index) { mutableStateOf(false) }
    val preview = remember(segment.code) {
        segment.code.lineSequence().filter { it.isNotBlank() }.take(PREVIEW_LINES)
            .joinToString(" / ") { it.trim() }
            .take(90)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ChipBg)
            .border(1.dp, LineColor, RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        // ── 摘要行（即开关）──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (expanded) "▾" else "▸",
                color = Accent,
                fontSize = 11.sp
            )
            Spacer(Modifier.width(7.dp))
            Text(
                text = "代码",
                color = Accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            if (segment.lang.isNotBlank()) {
                Spacer(Modifier.width(7.dp))
                Text(
                    text = segment.lang,
                    color = Faint,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(Modifier.width(7.dp))
            Text(
                text = "${segment.lineCount} 行",
                color = Faint,
                fontSize = 11.sp
            )
            if (!segment.closed) {
                Spacer(Modifier.width(7.dp))
                Text(
                    text = "生成中…",
                    color = Accent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(Modifier.weight(1f))
            Text(
                text = if (expanded) "收起" else "展开",
                color = Accent,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        // ── 折叠态预览 ──
        if (!expanded && preview.isNotBlank()) {
            Spacer(Modifier.height(5.dp))
            Text(
                text = preview,
                color = Muted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
        }

        // ── 展开态代码区 ──
        if (expanded) {
            Spacer(Modifier.height(7.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = EXPANDED_MAX_HEIGHT)
                    .clip(RoundedCornerShape(7.dp))
                    .background(Fg.copy(alpha = 0.05f))
                    .verticalScroll(rememberScrollState())
                    .padding(9.dp)
            ) {
                SelectionContainer {
                    Text(
                        text = segment.code.ifBlank { "（空代码块）" },
                        color = Fg,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    )
                }
            }
            if (!segment.closed) {
                Spacer(Modifier.height(5.dp))
                Text(
                    text = "代码仍在生成中，收起可避免画面跳动",
                    color = Faint,
                    fontSize = 10.sp
                )
            }
            Spacer(Modifier.height(6.dp))
            CollapseChip(text = "▴ 收起代码") { expanded = false }
        }
    }
}
