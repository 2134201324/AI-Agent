package com.example.nativedemo.tools.apk

/**
 * 一个已解码的 XML 属性。
 *
 * [name] 已经还原成可读写法（如 `android:exported`）—— 原始 AXML 里系统属性的
 * 名字是资源化的，只剩一个数字 id，必须反查（见 [AttrNames]）才能读。
 */
data class AxmlAttribute(
    val namespace: String?,
    val name: String,
    val value: String,
    /**
     * 属性对应的系统资源 id（如 `versionCode` = `0x0101021b`）；0 表示不是系统属性。
     *
     * 名字是「反查」来的，反查表可能不全（真机上靠反射系统表补齐）。把 id 一并留下，
     * 上层就能按 id 做精确匹配，不受反查成败影响。
     */
    val resourceId: Int = 0
)

data class AxmlNode(
    val name: String,
    val attributes: List<AxmlAttribute> = emptyList(),
    val children: List<AxmlNode> = emptyList(),
    val text: String? = null
) {
    /** 按「本地名」查属性，忽略命名空间前缀差异（`android:name` 与 `name` 都能查到）。 */
    fun attr(localName: String): String? = attributes.firstOrNull {
        it.name == localName || it.name.endsWith(":$localName")
    }?.value

    /**
     * 先按资源 id 查，再退回按名字查。
     *
     * 顺序不能反：名字依赖反查表，表缺项时名字会退化成 `android:attr/0x…`，
     * 而 id 是文件里原本就有的，永远准确。
     */
    fun attrById(resourceId: Int, localName: String): String? =
        attributes.firstOrNull { it.resourceId == resourceId }?.value
            ?: attr(localName)

    fun childrenNamed(childName: String): List<AxmlNode> = children.filter { it.name == childName }

    /** 深度优先遍历（含自身）。 */
    fun walk(): Sequence<AxmlNode> = sequence {
        yield(this@AxmlNode)
        children.forEach { yieldAll(it.walk()) }
    }
}

class AxmlDocument(
    val root: AxmlNode?,
    /** uri → prefix，如 `http://schemas.android.com/apk/res/android` → `android`。 */
    val namespaces: Map<String, String>,
    val stringCount: Int,
    val resourceMapSize: Int
)

/**
 * Android 二进制 XML（AXML）解析器。
 *
 * ## 为什么自己写
 *
 * APK 里的 `AndroidManifest.xml` 与 `res/` 目录下的所有 XML 都不是文本，而是 aapt 编译出的
 * 二进制格式：字符串去重成池、属性名资源化成数字 id、结构按 chunk 对齐。
 * 直接当文本读是一堆乱码，而放着不解，AI 就只能靠 `PackageManager` 拿到的那点
 * 二手信息 —— 连 `debuggable`、`usesCleartextTraffic` 这类安全相关的原始属性都看不到。
 *
 * ## 结构
 *
 * ```
 * XML chunk (0x0003)
 * ├── STRING_POOL     元素名 / 属性名的字符串池
 * ├── RESOURCE_MAP    属性名索引 → 系统属性资源 id
 * ├── START_NAMESPACE / END_NAMESPACE
 * ├── START_ELEMENT   含属性数组（每项 20 字节）
 * ├── END_ELEMENT
 * └── CDATA
 * ```
 *
 * 各 chunk 的偏移都是**相对各自起点**，所以遍历时每一步都要按 `size` 前进。
 */
object AxmlParser {

    private const val RES_XML_TYPE = 0x0003

    /** 单个属性的结构长度（固定 20 字节）；文件里也带这个值，这里作为兜底。 */
    private const val DEFAULT_ATTRIBUTE_SIZE = 20

    /** 解析出的节点数上限，防畸形文件把栈撑爆。 */
    private const val MAX_NODES = 200_000

    /** 解码成节点树。 */
    fun decode(data: ByteArray): AxmlDocument {
        val cursor = ByteCursor(data, 0)

        val type = cursor.u16()
        cursor.u16() // headerSize
        cursor.i32() // size

        if (type != RES_XML_TYPE) {
            throw ResParseException(
                "不是二进制 XML（chunk 类型 ${ChunkType.name(type)}）；" +
                    "可能这个文件是普通文本 XML，直接按文本读即可"
            )
        }

        var strings: ResStringPool? = null
        var resourceMap: IntArray = IntArray(0)
        val namespaces = LinkedHashMap<String, String>()
        val nsByUri = HashMap<String, String>()

        // 用显式栈而不是递归：畸形文件可能出现极深的嵌套
        val stack = ArrayDeque<MutableNode>()
        var rootNode: MutableNode? = null
        var nodeCount = 0

        while (!cursor.atEnd()) {
            val chunkStart = cursor.pos
            if (cursor.remaining < 8) break

            val chunkType = cursor.u16()
            val headerSize = cursor.u16()
            val chunkSize = cursor.i32()

            // chunkSize 不可信时（0 或越界）立即停止，避免死循环
            if (chunkSize < 8 || chunkStart + chunkSize > data.size) break
            if (headerSize < 8 || headerSize > chunkSize) break

            when (chunkType) {
                ChunkType.STRING_POOL -> {
                    strings = ResStringPool.parse(data, chunkStart)
                    cursor.seek(chunkStart + chunkSize)
                }

                ChunkType.XML_RESOURCE_MAP -> {
                    val count = (chunkSize - headerSize) / 4
                    val map = IntArray(count)
                    cursor.seek(chunkStart + headerSize)
                    for (i in 0 until count) map[i] = cursor.i32()
                    resourceMap = map
                    cursor.seek(chunkStart + chunkSize)
                }

                ChunkType.XML_START_NAMESPACE -> {
                    cursor.seek(chunkStart + headerSize)
                    val prefixIdx = cursor.i32()
                    val uriIdx = cursor.i32()
                    val pool = strings
                    if (pool != null) {
                        val prefix = pool.nonEmpty(prefixIdx)
                        val uri = pool.nonEmpty(uriIdx)
                        if (prefix != null && uri != null) {
                            namespaces[uri] = prefix
                            nsByUri[uri] = prefix
                        }
                    }
                    cursor.seek(chunkStart + chunkSize)
                }

                ChunkType.XML_START_ELEMENT -> {
                    nodeCount++
                    if (nodeCount > MAX_NODES) throw ResParseException("节点数超过上限，疑似畸形文件")

                    val pool = strings ?: throw ResParseException("XML 先于字符串池出现，文件已损坏")
                    // ⚠️ 这里不能再读 lineNumber / comment：ResXMLTree_node 的 headerSize
                    // 已经把这两个字段算在内了（8 字节 chunk 头 + 4 行号 + 4 注释 = 16），
                    // 多读一次会让后面所有字段整体后移 8 字节，元素名与属性名全部错位。
                    cursor.seek(chunkStart + headerSize)

                    val nsIdx = cursor.i32()
                    val nameIdx = cursor.i32()
                    val attributeStart = cursor.u16()
                    val attributeSize = cursor.u16()
                    val attributeCount = cursor.u16()
                    cursor.skip(6) // idIndex / classIndex / styleIndex

                    val elementName = pool.nonEmpty(nameIdx) ?: "未知元素"

                    // 属性数组的位置：header 起点 + attributeStart（相对 node 结构）
                    val attrsAt = chunkStart + headerSize + attributeStart
                    val step = if (attributeSize >= 20) attributeSize else DEFAULT_ATTRIBUTE_SIZE
                    val attrs = ArrayList<AxmlAttribute>(minOf(attributeCount, 64))

                    for (i in 0 until attributeCount) {
                        val base = attrsAt + i * step
                        if (base + 20 > chunkStart + chunkSize) break
                        attrs += readAttribute(data, base, pool, resourceMap, nsByUri)
                    }

                    val node = MutableNode(elementName, attrs)
                    if (stack.isEmpty()) {
                        if (rootNode == null) rootNode = node
                    } else {
                        stack.last().children += node
                    }
                    stack.addLast(node)
                    cursor.seek(chunkStart + chunkSize)
                }

                ChunkType.XML_END_ELEMENT -> {
                    if (stack.isNotEmpty()) {
                        val finished = stack.removeLast()
                        // 根节点在建树时已挂上引用，这里把可变结构固化
                        if (stack.isEmpty()) rootNode = finished
                    }
                    cursor.seek(chunkStart + chunkSize)
                }

                ChunkType.XML_CDATA -> {
                    // 同样地，headerSize 已含 lineNumber / comment
                    cursor.seek(chunkStart + headerSize)
                    val dataIdx = cursor.i32()
                    val text = strings?.nonEmpty(dataIdx)
                    if (!text.isNullOrEmpty() && stack.isNotEmpty()) {
                        val top = stack.last()
                        top.text = (top.text.orEmpty() + text)
                    }
                    cursor.seek(chunkStart + chunkSize)
                }

                else -> cursor.seek(chunkStart + chunkSize)
            }
        }

        // 兜底：文件被截断而没有 END_ELEMENT 时，栈里可能还留着节点
        if (rootNode == null && stack.isNotEmpty()) rootNode = stack.first()

        return AxmlDocument(
            root = rootNode?.freeze(),
            namespaces = namespaces,
            stringCount = strings?.size ?: 0,
            resourceMapSize = resourceMap.size
        )
    }

    private fun readAttribute(
        data: ByteArray,
        offset: Int,
        pool: ResStringPool,
        resourceMap: IntArray,
        nsByUri: Map<String, String>
    ): AxmlAttribute {
        val cursor = ByteCursor(data, offset)
        val nsIdx = cursor.i32()
        val nameIdx = cursor.i32()
        val rawValueIdx = cursor.i32()
        cursor.u16() // typedValue.size（固定 8）
        cursor.u8()  // res0
        val dataType = cursor.u8()
        val valueData = cursor.i32()

        val nsUri = pool.nonEmpty(nsIdx)
        val prefix = nsUri?.let { nsByUri[it] }

        // ① 属性名：优先用池里现成的名字；系统属性在池中是空串，改用资源 id 反查
        val rawName = pool.nonEmpty(nameIdx)
        val attrId = if (nameIdx in resourceMap.indices) resourceMap[nameIdx] else 0
        val localName = rawName
            ?: AttrNames.name(attrId)
            ?: "attr/${AttrNames.unknown(attrId)}"

        val displayName = if (prefix != null) "$prefix:$localName" else localName

        // ② 值：rawValue 是原始文本（最忠实）；缺失时按类型解释
        val rawValue = pool.nonEmpty(rawValueIdx)
        val value = rawValue ?: formatTypedValue(dataType, valueData, pool)

        return AxmlAttribute(
            namespace = nsUri ?: prefix,
            name = displayName,
            value = value,
            resourceId = attrId
        )
    }

    /**
     * 把 `Res_value` 解释成文本。
     *
     * 有原始字符串时不会走到这里；只有内联常量（布尔、整数、尺寸、资源引用）
     * 才是纯类型化的 —— 也正是这些最容易读错，所以逐类显式处理。
     */
    internal fun formatTypedValue(dataType: Int, data: Int, pool: ResStringPool?): String =
        when (dataType) {
            ResValueType.STRING -> pool?.getOrNull(data).orEmpty()
            ResValueType.INT_DEC -> data.toString()
            ResValueType.INT_HEX -> "0x${data.toUInt().toString(16)}"
            ResValueType.INT_BOOLEAN -> if (data != 0) "true" else "false"
            ResValueType.REFERENCE -> "@${AttrNames.unknown(data)}"
            ResValueType.DYNAMIC_REFERENCE -> "@dynamic/${AttrNames.unknown(data)}"
            ResValueType.ATTRIBUTE -> "?${AttrNames.unknown(data)}"
            ResValueType.FLOAT -> Float.fromBits(data).toString()
            ResValueType.NULL -> ""
            ResValueType.DIMENSION, ResValueType.FRACTION ->
                "0x${data.toUInt().toString(16)}（复合值，含单位）"
            else -> "0x${data.toUInt().toString(16)}（类型 0x${dataType.toString(16)}）"
        }

    /** 序列化成可读 XML 文本。 */
    fun toXml(document: AxmlDocument, indentUnit: String = "    "): String {
        val root = document.root ?: return "（未解析出任何 XML 节点）"
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n")
        appendNode(sb, root, 0, indentUnit, isRoot = true, namespaces = document.namespaces)
        return sb.toString()
    }

    private fun appendNode(
        sb: StringBuilder,
        node: AxmlNode,
        depth: Int,
        indentUnit: String,
        isRoot: Boolean = false,
        namespaces: Map<String, String> = emptyMap()
    ) {
        val pad = indentUnit.repeat(depth)
        sb.append(pad).append('<').append(node.name)

        if (isRoot) {
            // 命名空间声明挂到根元素上，否则 `android:` 前缀无法解释
            namespaces.forEach { (uri, prefix) ->
                sb.append("\n").append(pad).append(indentUnit)
                    .append("xmlns:").append(prefix).append("=\"").append(escape(uri)).append('"')
            }
        }

        node.attributes.forEach { attr ->
            sb.append("\n").append(pad).append(indentUnit)
                .append(attr.name).append("=\"").append(escape(attr.value)).append('"')
        }

        val hasBody = node.children.isNotEmpty() || !node.text.isNullOrEmpty()
        if (!hasBody) {
            sb.append("/>\n")
            return
        }

        sb.append(">\n")
        node.text?.takeIf { it.isNotBlank() }?.let { sb.append(pad).append(indentUnit).append(it).append('\n') }
        node.children.forEach { appendNode(sb, it, depth + 1, indentUnit) }
        sb.append(pad).append("</").append(node.name).append(">\n")
    }

    private fun escape(text: String): String = buildString(text.length + 8) {
        text.forEach { c ->
            when (c) {
                '&' -> append("&amp;")
                '<' -> append("&lt;")
                '>' -> append("&gt;")
                '"' -> append("&quot;")
                else -> append(c)
            }
        }
    }

    /**
     * 建树期间的可变节点。
     *
     * 用独立的可变结构而不是直接拼不可变对象，是因为 AXML 是**流式**的：
     * 元素开始时还不知道后面有多少子节点。
     */
    private class MutableNode(
        val name: String,
        val attributes: List<AxmlAttribute>
    ) {
        val children = mutableListOf<MutableNode>()
        var text: String? = null

        fun freeze(): AxmlNode = AxmlNode(
            name = name,
            attributes = attributes,
            children = children.map { it.freeze() },
            text = text
        )
    }
}
