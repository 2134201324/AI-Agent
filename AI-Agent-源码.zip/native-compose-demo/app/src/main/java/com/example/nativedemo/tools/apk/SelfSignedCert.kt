package com.example.nativedemo.tools.apk

import java.io.ByteArrayOutputStream
import java.io.File
import java.math.BigInteger
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** 一对可用的签名材料。 */
data class KeyMaterial(
    val alias: String,
    val privateKey: PrivateKey,
    val certificate: X509Certificate
)

/**
 * 自签名证书生成与 keystore 读写。
 *
 * ## 为什么需要它
 *
 * 改包之后必须重新签名才能安装，而签名需要**私钥 + 证书**。用户手上通常没有原应用的
 * 私钥（那正是无法「覆盖安装」的原因），所以必须能**就地造一对**出来。
 *
 * Android 上没有 `sun.security.x509` 这类能"生成证书"的 API（`CertificateFactory`
 * 只能解析不能签发），因此这里**自己拼 DER** 构造一个最小但完全合法的 X.509 证书，
 * 再用 `CertificateFactory` 解析回来 —— 顺便也验证了拼接结果确实合规。
 *
 * ## 关于「覆盖安装」
 *
 * Android 要求**同包名的新旧 APK 签名一致**才能覆盖安装。所以：
 * - 用本工具自动生成的密钥签名的包，**不能**覆盖安装原应用，需先卸载；
 * - 想覆盖安装，只有一条路：拿到**原应用的签名密钥**（`apk_sign` 支持传入
 *   用户自己的 keystore）。
 *
 * 也正因为如此，自动生成的密钥会**持久化到 keystore 文件**并复用：否则每次改包
 * 都换密钥，连"上一版自己改的包"都无法覆盖安装。
 */
object SelfSignedCert {

    private const val KEY_ALGORITHM = "RSA"
    private const val KEY_SIZE = 2048
    private const val SIGNATURE_ALGORITHM = "SHA256withRSA"

    /** 证书默认有效期：20 年。自用签名密钥没必要频繁轮换。 */
    private const val DEFAULT_VALID_DAYS = 365 * 20

    private const val DAY_MILLIS = 24 * 60 * 60 * 1000L

    /**
     * 私钥**可导出**的 provider 候选，按优先级排列。
     *
     * ⚠️ `AndroidKeyStore` 绝不允许出现在这个列表里：它的私钥在硬件/TEE 里，
     * `getEncoded()` 返回 null，持久化到 keystore 文件必然失败（v1.12.0 真机事故）。
     * 单测里有专门的断言守着这个列表（[RepackSignTest]），别手改。
     */
    internal val EXPORTABLE_KEY_PROVIDERS = listOf("AndroidOpenSSL", "BC")

    /**
     * UTCTime 能表示的最大时刻：2049-12-31 23:59:59 UTC。
     *
     * ⚠️ UTCTime 只编码两位年份（1950–2049）。超出这个范围必须换 GeneralizedTime，
     * 否则 2056 会被写成 "56" 并被解读成 **1956 年** —— 证书直接变成"早已过期"，
     * 而签名工具、系统都不会报错，只在安装时莫名其妙失败。
     */
    private val UTC_TIME_LIMIT: Long = java.util.Calendar.getInstance(
        TimeZone.getTimeZone("UTC")
    ).apply {
        clear()
        set(2049, java.util.Calendar.DECEMBER, 31, 23, 59, 59)
    }.timeInMillis

    /**
     * 打开 keystore；不存在则生成一对密钥并写回。
     *
     * @param file keystore 文件（PKCS12）
     * @param alias 别名
     * @param password keystore 与密钥共用的口令
     * @param subject 证书主体名，如 `CN=MyRepack, O=AI Agent`
     */
    fun loadOrCreate(
        file: File,
        alias: String,
        password: CharArray,
        subject: String
    ): KeyMaterial {
        load(file, alias, password)?.let { return it }
        val created = create(alias, password, subject)
        runCatching { save(file, created, password) }.getOrElse { cause ->
            throw ResParseException(
                "生成签名密钥成功，但写入 keystore 文件「${file.name}」失败：" +
                    "${cause.message ?: cause::class.java.simpleName}。" +
                    "（密钥只在内存中存在，本次仍可用，但下次会换一把新密钥；" +
                    "覆盖安装自己改过的包前请先解决写入问题）",
                cause
            )
        }
        return created
    }

    /** 读取已有 keystore；文件不存在或口令不对时返回 null。 */
    fun load(file: File, alias: String, password: CharArray): KeyMaterial? {
        if (!file.exists() || file.length() == 0L) return null
        return runCatching {
            val store = KeyStore.getInstance(guessStoreType(file))
            file.inputStream().use { store.load(it, password) }
            val key = store.getKey(alias, password) as? PrivateKey ?: return null
            val cert = store.getCertificate(alias) as? X509Certificate ?: return null
            KeyMaterial(alias, key, cert)
        }.getOrNull()
    }

    /** 生成一对新的自签名密钥。 */
    fun create(alias: String, password: CharArray, subject: String): KeyMaterial {
        val keyPair = newExportableKeyPair()
        val certificate = generateCertificate(keyPair, subject, DEFAULT_VALID_DAYS)
        return KeyMaterial(alias, keyPair.private, certificate)
    }

    /**
     * 生成一对**私钥可导出**的 RSA 密钥。
     *
     * ⚠️ 这里踩过一个真实的坑（v1.12.0，用户侧 apk_sign 全线报「密钥不可用」）：
     * Android 上 `KeyPairGenerator.getInstance("RSA")` 会解析到 **AndroidKeyStore**
     * provider —— 那是硬件/TEE 里的密钥，私钥**不可导出**（getEncoded() 返回 null）。
     * 后续 `save()` 把它塞进 PKCS12 keystore 时必然失败，整个内置签名链路从第一次
     * 调用就挂。而纯 JVM 单测跑在桌面 JDK 上（SunRsaSign，私钥可导出），永远绿，
     * 所以这个坑只有真机才暴露。
     *
     * 解法：显式要软件实现的 provider —— AndroidOpenSSL（Conscrypt，API 23+ 必有）
     * 优先，BC 兜底，都拿不到才回退到默认（桌面 JVM 走这条，单测环境不受影响）。
     */
    private fun newExportableKeyPair(): KeyPair {
        val generator = EXPORTABLE_KEY_PROVIDERS
            .firstNotNullOfOrNull { name -> runCatching { KeyPairGenerator.getInstance(KEY_ALGORITHM, name) }.getOrNull() }
            ?: KeyPairGenerator.getInstance(KEY_ALGORITHM)
        generator.initialize(KEY_SIZE)
        return generator.generateKeyPair().also {
            // 防御性断言：私钥拿不到编码就说明 provider 选错了，宁可在这里炸，
            // 也不要等到 save() 时抛一句看不懂的 KeyStoreException
            check(it.private.encoded != null) {
                "生成的 RSA 私钥不可导出（provider=${generator.provider.name}），" +
                    "无法持久化到 keystore 文件。"
            }
        }
    }

    /** 把密钥写入 keystore 文件（PKCS12，Android 与桌面工具都能读）。 */
    fun save(file: File, material: KeyMaterial, password: CharArray) {
        file.parentFile?.mkdirs()
        val store = KeyStore.getInstance("PKCS12")
        store.load(null, null)
        store.setKeyEntry(
            material.alias,
            material.privateKey,
            password,
            arrayOf(material.certificate)
        )
        file.outputStream().use { store.store(it, password) }
    }

    private fun guessStoreType(file: File): String =
        if (file.extension.equals("jks", ignoreCase = true)) "JKS" else "PKCS12"

    /**
     * 按 X.509 结构拼出一张自签名证书。
     *
     * 生成的是 **v1 证书**（不写 version 字段、不带扩展）：Android 对应用签名证书
     * 不做链路校验，也不要求扩展字段，v1 完全够用，而且省掉一整块 ASN.1 扩展编码。
     */
    fun generateCertificate(
        keyPair: KeyPair,
        subject: String,
        validDays: Int = DEFAULT_VALID_DAYS
    ): X509Certificate {
        val publicKey = keyPair.public as RSAPublicKey
        val now = System.currentTimeMillis()

        val algorithmIdentifier = Der.sequence(
            Der.oid(OID_SHA256_WITH_RSA),
            Der.nullValue()
        )

        val name = encodeName(subject)

        // 生效时间往前留 1 小时，避开设备时钟偏差；失效时间夹在 UTCTime 的上限内
        val notAfter = minOf(now + validDays.toLong() * DAY_MILLIS, UTC_TIME_LIMIT)
        val validity = Der.sequence(
            Der.utcTime(Date(now - 60 * 60 * 1000L)),
            Der.utcTime(Date(notAfter))
        )

        val subjectPublicKeyInfo = Der.sequence(
            Der.sequence(Der.oid(OID_RSA), Der.nullValue()),
            Der.bitString(encodeRsaPublicKey(publicKey))
        )

        val tbsCertificate = Der.sequence(
            Der.integer(BigInteger.valueOf(now)),                            // 序列号：用时间戳保证不重复
            algorithmIdentifier,
            name,                                                            // issuer == subject，即自签名
            validity,
            name,
            subjectPublicKeyInfo
        )

        val signature = Signature.getInstance(SIGNATURE_ALGORITHM).apply {
            initSign(keyPair.private)
            update(tbsCertificate)
        }.sign()

        val certificate = Der.sequence(
            tbsCertificate,
            algorithmIdentifier,
            Der.bitString(signature)
        )

        // 交给 JDK 解析：能解析出来就说明 DER 拼对了
        return CertificateFactory.getInstance("X.509")
            .generateCertificate(certificate.inputStream()) as X509Certificate
    }

    /** `CN=Foo, O=Bar` → X.501 Name。只支持最常见的几个属性。 */
    private fun encodeName(subject: String): ByteArray {
        val rdns = subject.split(',')
            .mapNotNull { part ->
                val key = part.substringBefore('=').trim()
                val value = part.substringAfter('=', "").trim()
                if (key.isEmpty() || value.isEmpty()) return@mapNotNull null
                val oid = when (key.uppercase(Locale.US)) {
                    "CN" -> OID_COMMON_NAME
                    "O" -> OID_ORGANIZATION
                    "OU" -> OID_ORGANIZATIONAL_UNIT
                    "C" -> OID_COUNTRY
                    "L" -> OID_LOCALITY
                    "ST" -> OID_STATE
                    else -> OID_COMMON_NAME
                }
                Der.set(Der.sequence(Der.oid(oid), Der.utf8String(value)))
            }
            .ifEmpty { listOf(Der.set(Der.sequence(Der.oid(OID_COMMON_NAME), Der.utf8String("Self Signed")))) }
        return Der.sequence(*rdns.toTypedArray())
    }

    /** `RSAPublicKey ::= SEQUENCE { modulus INTEGER, publicExponent INTEGER }` */
    private fun encodeRsaPublicKey(key: RSAPublicKey): ByteArray =
        Der.sequence(
            Der.integer(key.modulus),
            Der.integer(key.publicExponent)
        )

    // ── OID 常量 ──────────────────────────────────────────────────────
    private const val OID_SHA256_WITH_RSA = "1.2.840.113549.1.1.11"
    private const val OID_RSA = "1.2.840.113549.1.1.1"
    private const val OID_COMMON_NAME = "2.5.4.3"
    private const val OID_ORGANIZATION = "2.5.4.10"
    private const val OID_ORGANIZATIONAL_UNIT = "2.5.4.11"
    private const val OID_COUNTRY = "2.5.4.6"
    private const val OID_LOCALITY = "2.5.4.7"
    private const val OID_STATE = "2.5.4.8"

    /**
     * 极简 DER（ASN.1 的二进制编码）拼装器。
     *
     * 只实现构造证书需要的几种类型。DER 的规则是 TLV：先一个字节的 tag，
     * 再变长编码的长度，最后是内容。
     */
    private object Der {

        fun sequence(vararg parts: ByteArray): ByteArray = tlv(0x30, concat(parts))

        fun set(vararg parts: ByteArray): ByteArray = tlv(0x31, concat(parts))

        fun nullValue(): ByteArray = byteArrayOf(0x05, 0x00)

        /** INTEGER：内容就是 BigInteger 的大端补码表示，最高位为 1 时它会自动多带一个 0x00。 */
        fun integer(value: BigInteger): ByteArray = tlv(0x02, value.toByteArray())

        fun utf8String(value: String): ByteArray = tlv(0x0C, value.toByteArray(Charsets.UTF_8))

        /** BIT STRING：首字节表示"未使用位数"，签名与公钥都是整字节，所以是 0。 */
        fun bitString(content: ByteArray): ByteArray =
            tlv(0x03, byteArrayOf(0) + content)

        /** UTCTime：`YYMMDDHHMMSSZ`，只覆盖 1950–2049；本用途完全够。 */
        fun utcTime(date: Date): ByteArray {
            val format = SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            return tlv(0x17, format.format(date).toByteArray(Charsets.US_ASCII))
        }

        fun oid(dotted: String): ByteArray = tlv(0x06, encodeOid(dotted))

        private fun tlv(tag: Int, content: ByteArray): ByteArray {
            val out = ByteArrayOutputStream(content.size + 6)
            out.write(tag)
            writeLength(out, content.size)
            out.write(content)
            return out.toByteArray()
        }

        /** DER 的长度编码：短格式(<128)一字节，长格式首字节给出后续字节数。 */
        private fun writeLength(out: ByteArrayOutputStream, length: Int) {
            when {
                length < 0x80 -> out.write(length)
                length < 0x100 -> {
                    out.write(0x81)
                    out.write(length)
                }
                length < 0x10000 -> {
                    out.write(0x82)
                    out.write((length ushr 8) and 0xFF)
                    out.write(length and 0xFF)
                }
                else -> {
                    out.write(0x83)
                    out.write((length ushr 16) and 0xFF)
                    out.write((length ushr 8) and 0xFF)
                    out.write(length and 0xFF)
                }
            }
        }

        /**
         * OID 的内容编码：第一个字节是 `40 * 一级 + 二级`，
         * 之后每个分量用 base-128 变长表示（除最后一段外，每段最高位置 1）。
         */
        private fun encodeOid(dotted: String): ByteArray {
            val parts = dotted.split('.').map { it.toLong() }
            require(parts.size >= 2) { "OID 至少需要两段：$dotted" }

            val out = ByteArrayOutputStream()
            out.write((40 * parts[0] + parts[1]).toInt())
            for (i in 2 until parts.size) {
                var value = parts[i]
                val stack = ArrayDeque<Int>()
                stack.addFirst((value and 0x7F).toInt())
                value = value shr 7
                while (value > 0) {
                    stack.addFirst(((value and 0x7F) or 0x80).toInt())
                    value = value shr 7
                }
                stack.forEach { out.write(it) }
            }
            return out.toByteArray()
        }

        private fun concat(parts: Array<out ByteArray>): ByteArray {
            val out = ByteArrayOutputStream(parts.sumOf { it.size })
            parts.forEach { out.write(it) }
            return out.toByteArray()
        }
    }
}
