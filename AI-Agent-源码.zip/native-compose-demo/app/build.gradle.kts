plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.example.nativedemo"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.nativedemo"
        minSdk = 24
        targetSdk = 36
        // 版本迭代：每次交付都向前推进，见项目根目录的 bump-version.sh
        // 1.9.3 三项（一键授权 + 联网搜索 + MT 自动化）：
        // ① 权限中心 / 一键启动 —— 此前六项系统权限散落在各处按需申请，
        //    用户很难凑齐"工具能跑"的前置条件。现在设置里新增「权限中心」：
        //    集中展示每一项的状态与用途，一个按钮就把未授予的项按顺序申请一遍
        //    （运行时弹窗 + 跳系统设置交替进行，跳转返回后自动续下一项）。
        // ② 联网搜索 web_search —— 此前只有 web_fetch（必须已知网址）。
        //    新增多引擎结果页解析（Bing / 360 / 百度 / DuckDuckGo），免 API Key、
        //    一个引擎拿不到结果自动换下一个；专属解析失败还有通用锚点兜底。
        // ③ MT 管理器自动化 —— mt_open 把 MT 拉起来停到指定路径；
        //    更有用的是新增的无障碍 GUI 自动化（ui_dump / ui_tap / ui_input /
        //    ui_swipe / ui_key / ui_wait）：MT 没有对外开放反编译、改包等接口，
        //    只有"读屏 + 模拟点击"这条路能让 AI 真的替用户把那些多步界面操作做完。
        //    ui_* 全部默认关闭，且需要用户在系统设置里显式开启无障碍服务。
        //
        // 1.9.2 三项（后台不中断 + 长内容不刷屏）：
        // ① 后台运行 —— 会话状态（消息/运行标志/进度）从 ViewModel 提升到全局单例
        //    ChatSession，生成任务改跑应用级作用域：此前 ViewModel 随 Activity
        //    销毁即取消，转屏或切后台就等于"生成到一半没了"。
        // ② 前台服务 + 通知栏进度 —— ChatForegroundService 让系统知道"正在为用户干活"，
        //    切后台也能跑完；通知实时显示"正在执行工具 xxx / 正在生成回复…"，
        //    并按 Android 14 要求声明 specialUse 类型、按 Android 13 要求申请通知权限。
        // ③ 流式折叠 —— 有些模型不返回 reasoning_content，而是把大段"过程叙述"
        //    直接写进正文（思考卡收不到东西）。现在正在生成的消息超过 900 字
        //    也会自动收起为卡片，只留末尾预览 + 字数，结论不再被刷出屏幕。
        //
        // 1.9.1 补齐「改包」能力 + 对话折叠：
        // ① 改包链路（4 个新工具）—— 此前 AI 只能"看"不能"改"：
        //    apk_replace 替换包内文件并重建签名（一步产出可安装的包）、
        //    apk_unpack  完整解包（二进制 XML 自动解码）、
        //    apk_pack    从目录重新打包、apk_sign 仅签名。
        //    底座：自研 ApkZipWriter（按 zipalign 规则对齐，arsc/so 不压缩）、
        //    RepackEngine（剔除旧签名、保留原压缩方式）、
        //    引入 Google 官方 apksig 做 v1/v2/v3 签名。
        // ② 没有 keystore 也能签名 —— SelfSignedCert 用纯 Kotlin 拼 DER 生成
        //    自签名 X.509 证书；密钥持久复用，否则每次改包签名都变、无法互相覆盖安装。
        // ③ 补上「AI 写不出二进制」的空洞：
        //    file_write_binary（base64 或复制）、image_convert（缩放/转格式）。
        // ④ 对话折叠：历史长回复收起为一行摘要（一屏扫过更多轮，便于找回旧内容）、
        //    思考卡折叠态精简为单行、翻离底部时出现「回到最新」按钮。
        //
        // 1.9.0 全新能力：**内置 APK 逆向工具集**（9 个工具，交给 AI 调用）
        //
        // 为何是「内置解析」而不是 jadx/Ghidra：那些是桌面 JVM 程序，手机上跑不起来。
        // 所以在 App 内实现了一套纯 Kotlin 的二进制解析引擎，零外部依赖、开箱即用。
        //
        // 解析层覆盖：资源字符串池（UTF-8/UTF-16）、二进制 XML（AXML）、
        // resources.arsc 资源表、DEX（含 MUTF-8 解码与 ULEB128）、APK Signing Block。
        //
        // 工具清单：
        // ① apk_info       总览：包名/版本/SDK/权限/导出组件/签名/加固特征
        // ② apk_manifest   把二进制 AndroidManifest.xml 解码成可读 XML
        // ③ apk_list       列出包内条目（可过滤、按大小或名字排序）
        // ④ apk_read       读条目：AXML 自动解码、dex/arsc 给概览、二进制给 hex 头
        // ⑤ apk_dex        代码结构：统计 / 类列表 / 方法列表 / 字符串池
        // ⑥ apk_resources  资源表查询（按类型或关键字，含资源 id）
        // ⑦ apk_search     跨 DEX 字符串池 / 资源 / manifest / assets 搜索
        // ⑧ apk_signature  签名方案 v1/v2/v3 + 证书指纹、有效期、是否调试证书
        // ⑨ apk_extract    把包内文件提取到用户已授权的目录
        //
        // 另记两个踩过的解析坑（都有测试兜住）：
        // · ResXMLTree_node 的 headerSize 已含 lineNumber/comment，多读 8 字节会让
        //   元素名与属性名整体错位；
        // · 字符串池偏移 0 是合法值（指向数据区首项），只有 0xFFFFFFFF 才表示「无」。
        //
        // 1.8.7 三项（修「聊几次之后这个对话就废了」）：
        // ① 多模态历史压平 —— 发过图片后，那条 content 为数组的消息会永久留在
        //    历史里，而只接受字符串的服务端（如报 ZodError 的那类网关）每轮都
        //    返回 400，于是该会话此后彻底不可用、重开 App 也好不了。
        //    现在发送前只保留本轮 user 消息的富文本形态，历史里的图片一律压成
        //    文字占位（同时省掉每轮重传 base64 的巨大 token 开销）；
        // ② content 类型自愈 —— 识别 expected string / received array /
        //    invalid_union 等报文，命中则关掉富文本重试一次，并给出准确提示；
        // ③ 历史超长裁剪 —— 超过 120 条时从 user 边界裁掉最早的若干轮
        //    （不会切开 tool 调用与响应），避免聊久后撞上下文上限导致整段会话不可用
        versionCode = 30
        versionName = "1.12.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        // 供 App 内读取 versionName / versionCode（设置页展示用）
        buildConfig = true
    }
}

dependencies {
    // ---- UI / Compose ----
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // ---- AndroidX core ----
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    // ---- 协程 ----
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // ---- 网络 + JSON ----
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // ---- 持久化 ----
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // ---- SAF 目录遍历 ----
    implementation("androidx.documentfile:documentfile:1.0.1")

    // ---- APK 签名（Google 官方 apksig，纯 Java，手机端改包工具通用的实现）----
    // 支持 JAR 签名(v1) 与 APK Signature Scheme v2/v3；Android 11+ 对
    // targetSdk>=30 的包强制要求 v2+，自己实现风险太高，直接用官方库。
    implementation("com.android.tools.build:apksig:8.13.0")

    // ---- 单元测试（纯 JVM，不依赖 Android 运行时）----
    testImplementation("junit:junit:4.13.2")
    // 端到端验证网页桥接链路（无 Key 直连本地服务）
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")
}
