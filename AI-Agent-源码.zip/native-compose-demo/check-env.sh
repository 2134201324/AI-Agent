#!/usr/bin/env bash
# 环境与能力自检：新会话接手本项目时先跑这个脚本。
# 只做检测与报告，不修改任何东西。
#
#   用法：bash native-compose-demo/check-env.sh
#
# 为什么需要它：本沙盒的完整工具链配置写在校验性的 profile 脚本里，而助手的
# 命令行是「非登录 shell」，读不到那些变量 —— 于是 `java` 可能解析到旧版本、
# `ANDROID_HOME` 看起来是空的，让人误判成「工具链没装」。
# 本脚本用**绝对路径**核实真实状态，把这些假象排除掉。

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_DIR="$(dirname "$PROJECT_DIR")"
JDK=/usr/lib/jvm/java-21-openjdk-amd64
SDK=/opt/android-sdk
BT=$SDK/build-tools/36.0.0
KEYSTORE="$HOME/.android/debug.keystore"
MCP_CONF="/root/.codebuddy/.mcp.json"

ok=0; bad=0; warn=0
pass() { printf '  \033[32m✓\033[0m %s\n' "$1"; ok=$((ok+1)); }
fail() { printf '  \033[31m✗\033[0m %s\n' "$1"; bad=$((bad+1)); }
warn() { printf '  \033[33m!\033[0m %s\n' "$1"; warn=$((warn+1)); }
note() { printf '      %s\n' "$1"; }

echo "=============================================="
echo " 环境与能力自检   $(date '+%Y-%m-%d %H:%M:%S')"
echo "=============================================="

# ── 0. 两个最容易被误判的点 ─────────────────────────────
echo
echo "【0】易误判项（先看这里）"

# 默认 java 的版本：>=21 才算过。注意这里检测的是「助手实际拿到的 java」。
if command -v java >/dev/null 2>&1; then
    raw=$(java -version 2>&1 | head -1)
    major=$(printf '%s' "$raw" | sed -n 's/.*"\([0-9][0-9]*\)\..*/\1/p')
    [ -z "$major" ] && major=0
    if [ "$major" -ge 21 ]; then
        pass "默认 java 版本可用（$raw）"
    else
        fail "默认 java 是 $major，低于构建所需的 21（$raw）"
        note "修复：ln -sfn $JDK /root/.sdkman/candidates/java/current"
        note "或每次构建显式指定：export JAVA_HOME=$JDK"
    fi
else
    fail "PATH 里找不到 java 命令"
fi

# ANDROID_HOME 为空是常态：Gradle 通过工程内 local.properties 的 sdk.dir 找 SDK
if [ -n "$ANDROID_HOME" ] || [ -n "$ANDROID_SDK_ROOT" ]; then
    pass "ANDROID_HOME 已设置（${ANDROID_HOME:-$ANDROID_SDK_ROOT}）"
else
    warn "ANDROID_HOME / ANDROID_SDK_ROOT 为空 —— 这不代表 SDK 缺失"
    note "SDK 实际在 $SDK，由工程内 local.properties 的 sdk.dir 指定，构建不受影响"
fi

# 构建工具能否「按名」直接调用（助手常用这种写法）
for t in aapt2 apksigner zipalign adb; do
    if command -v $t >/dev/null 2>&1; then
        pass "$t 可按名调用"
    else
        fail "$t 不在 PATH 中"
        note "修复：ln -sfn $BT/$t /usr/local/bin/$t"
    fi
done

# ── 1. 逆向分析 ─────────────────────────────────────────
echo
echo "【1】逆向分析（REA）"
if [ -f "$MCP_CONF" ] && grep -q '"rea"' "$MCP_CONF"; then
    pass "MCP 配置已注册 rea 服务"
else
    fail "MCP 配置缺少 rea 服务（$MCP_CONF）"
    note "修复：执行 rea setup"
fi

REA_BIN=""
for cand in /root/.nvm/versions/node/v22.23.3/bin/rea /root/.nvm/versions/node/*/bin/rea; do
    [ -x "$cand" ] && REA_BIN="$cand" && break
done
if [ -n "$REA_BIN" ]; then
    ver=$(timeout 20 "$REA_BIN" --version 2>/dev/null | head -1)
    pass "rea 命令可用（${ver:-版本未知}）"
    note "路径：$REA_BIN"
else
    fail "找不到 rea 命令"
    note "修复：npm i -g rea-agents 后执行 rea setup"
fi

for dep in "/opt/ghidra:Ghidra（反编译引擎）" \
           "/opt/jadx:JADX（APK/Java 反编译）" \
           "/opt/apktool:apktool（APK 资源解码）"; do
    path="${dep%%:*}"; label="${dep##*:}"
    if [ -e "$path" ]; then pass "$label 已安装"; else fail "$label 缺失（$path）"; fi
done

if [ -e /root/.codebuddy/skills/reverse-engineer-anything/SKILL.md ]; then
    pass "技能 reverse-engineer-anything 可用"
else
    fail "技能 reverse-engineer-anything 缺失（修复：rea setup）"
fi

# ── 2. Android 打包 ────────────────────────────────────
echo
echo "【2】Android 打包"
if [ -x "$JDK/bin/java" ]; then
    pass "JDK 21 存在（$($JDK/bin/java -version 2>&1 | head -1 | tr -d '\"')）"
else
    fail "JDK 21 缺失（$JDK）"
fi
if [ -d "$SDK" ]; then pass "Android SDK：$SDK"; else fail "Android SDK 缺失（$SDK）"; fi
if [ -d "$BT" ]; then pass "build-tools 36.0.0 存在"; else fail "build-tools 36.0.0 缺失（$BT）"; fi
if [ -f "$KEYSTORE" ]; then pass "签名密钥存在"; else fail "签名密钥缺失（$KEYSTORE）"; fi
if [ -f "$PROJECT_DIR/gradlew" ]; then pass "Gradle wrapper 就绪"; else fail "Gradle wrapper 缺失"; fi

if grep -q '^org.gradle.java.home' "$PROJECT_DIR/gradle.properties" 2>/dev/null; then
    pinned=$(grep -m1 '^org.gradle.java.home' "$PROJECT_DIR/gradle.properties" | cut -d= -f2)
    if [ -x "$pinned/bin/java" ]; then
        pass "构建 JDK 已在工程内固化：$pinned"
    else
        fail "固化的 JDK 路径不存在：$pinned"
        note "请修改 gradle.properties 的 org.gradle.java.home 为本机 JDK 21 路径"
    fi
else
    warn "gradle.properties 未固化 org.gradle.java.home，构建依赖 shell 默认 java"
fi

if [ -f "$PROJECT_DIR/app/build.gradle.kts" ]; then
    vc=$(grep -m1 'versionName' "$PROJECT_DIR/app/build.gradle.kts" | tr -d ' "')
    pass "工程配置就绪（$vc）"
else
    fail "工程配置缺失（app/build.gradle.kts）"
fi

# ── 3. 发布与文档 ──────────────────────────────────────
echo
echo "【3】发布与文档能力"
for s in "sites:发布为应用" "library:library（资料库）"; do
    dir="${s%%:*}"; label="${s##*:}"
    if [ -f "/root/.codebuddy/skills/$dir/SKILL.md" ]; then pass "技能 $label 可用"; else fail "技能 $label 缺失"; fi
done

# ── 4. 项目资源 ────────────────────────────────────────
echo
echo "【4】项目资源"
for f in "$PROJECT_DIR/ENVIRONMENT.md"; do
    if [ -f "$f" ]; then pass "存在：${f#$WORKSPACE_DIR/}"; else fail "缺失：${f#$WORKSPACE_DIR/}"; fi
done
# 交付产物：不写死版本号 —— 否则每次发版这里都会误报「缺失」
apk_count=$(ls "$WORKSPACE_DIR"/AI-Agent-v*.apk 2>/dev/null | wc -l)
if [ "$apk_count" -gt 0 ]; then
    apk_latest=$(ls -t "$WORKSPACE_DIR"/AI-Agent-v*.apk 2>/dev/null | head -1)
    pass "交付产物存在（共 ${apk_count} 个，最新：$(basename "$apk_latest")）"
else
    fail "缺失：/workspace/AI-Agent-v*.apk（尚未构建过 release 包）"
fi
kt=$(find "$PROJECT_DIR/app/src/main" -name '*.kt' 2>/dev/null | wc -l)
tkt=$(find "$PROJECT_DIR/app/src/test" -name '*.kt' 2>/dev/null | wc -l)
echo "      源码：主 $kt 个 .kt / 测试 $tkt 个 .kt"

# ── 结论 ───────────────────────────────────────────────
echo
echo "=============================================="
printf ' 结果：通过 %d 项' "$ok"
[ "$warn" -gt 0 ] && printf '，提示 %d 项' "$warn"
[ "$bad" -gt 0 ] && printf '，缺失 %d 项' "$bad"
echo
echo "=============================================="

if [ "$bad" -gt 0 ]; then
    echo
    echo "若【1】整组报缺失，很可能是当前会话落在了一个干净沙盒"
    echo "（与工作区未绑定），重跑 rea setup 即可恢复。"
fi
echo
echo "提醒：REA 的 170 个逆向工具是延迟加载的，不在助手的直接工具表里。"
echo "      调用方式：先用工具检索（ToolSearch）查找，再用 DeferExecuteTool 执行。"
