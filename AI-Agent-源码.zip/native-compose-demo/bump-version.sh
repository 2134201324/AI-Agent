#!/usr/bin/env bash
#
# 版本迭代脚本 —— 每次交付前运行一次，自动推进版本号。
#
#   versionCode:  +1（整数，必须严格递增，应用商店据此判断升级）
#   versionName:  补丁位 +1（1.1.0 -> 1.1.1）
#
# 若要发大版本，手动把 build.gradle.kts 里的 versionName 改成 1.2.0 / 2.0.0
# 即可，本脚本只负责补丁位递增。
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GRADLE="$SCRIPT_DIR/app/build.gradle.kts"

if [ ! -f "$GRADLE" ]; then
  echo "✗ 找不到 $GRADLE" >&2
  exit 1
fi

current_code="$(grep -oE 'versionCode = [0-9]+' "$GRADLE" | head -1 | grep -oE '[0-9]+')"
current_name="$(grep -oE 'versionName = "[^"]+"' "$GRADLE" | head -1 | sed 's/versionName = "//; s/"$//')"

if [ -z "$current_code" ] || [ -z "$current_name" ]; then
  echo "✗ 无法从 build.gradle.kts 解析当前版本号" >&2
  exit 1
fi

IFS='.' read -r major minor patch <<< "$current_name"
major="${major:-1}"; minor="${minor:-0}"; patch="${patch:-0}"

next_name="${major}.${minor}.$((patch + 1))"
next_code=$((current_code + 1))

# macOS / Linux 的 sed -i 语法不同，这里用临时文件避免差异
tmp="$(mktemp)"
sed "s/versionCode = ${current_code}/versionCode = ${next_code}/" "$GRADLE" \
  | sed "s/versionName = \"${current_name}\"/versionName = \"${next_name}\"/" > "$tmp"
mv "$tmp" "$GRADLE"

echo "✓ 版本已推进：${current_name} (${current_code})  ->  ${next_name} (${next_code})"
echo "  下一步：./gradlew assembleRelease，并对产物签名"
