# 配置文档：让本工作区具备「逆向分析」与「Android 打包」两套能力

> ⚠ **权威版本**：`/workspace/AI-Agent-项目交接文档.txt`（第 1 节）。
> 该文件是唯一权威交接文档，新会话优先全文阅读它；本文件只讲工具链配置原理，
> 是该文档第 1 节的详细展开，内容以该 txt 为准，两处冲突时听 txt 的。

> **使用方式**：把本文档整份发给助手（或让它读取本文件）。按第 0～3 步执行即可。
> **前提**：工作区 `native-compose-demo/` 内有本工程源码与本文件附带的两个脚本。

---

## 你要做什么（一句话）

沙盒镜像是干净的，**不含**逆向分析与 Android 打包工具链 —— 这两套能力需要在本会话的沙盒里装一次。
工作区已备好一键脚本，**先跑自检，再按需安装，最后按本文档的方式调用**。

---

## 第 0 步：先自检，判断到底缺什么

```bash
bash native-compose-demo/check-env.sh
```

- 输出里**全是 ✓** → 环境已就绪，直接跳到第 2 步
- 有 **✗** → 执行第 1 步安装

> 看结果时请注意：`ANDROID_HOME 为空`这一条是**提示**不是错误，不影响构建（原因见第 4 步）。

---

## 第 1 步：一键安装（幂等，可反复执行）

```bash
bash native-compose-demo/setup-toolchain.sh
```

**务必在后台运行**：Ghidra 压缩包约 570MB，沙盒到 GitHub 的带宽可能只有 0.1～0.5 MB/s，
完整安装可能需要 10～30 分钟。脚本做了**断点续传**，中断后重新执行会从中断处继续。

若你有更快的下载渠道：把 Ghidra 的 zip 预先放到 `/tmp/ghidra.zip`，脚本会直接使用它，不再下载。

脚本会安装以下内容（幂等：已存在的自动跳过）：

- **JDK 21** → `/usr/lib/jvm/java-21-openjdk-amd64`（apt 安装），并把默认 `java` 指向它
- **Android SDK** → `/opt/android-sdk`
  （cmdline-tools 19.0、platform-tools、platforms;android-36、build-tools;36.0.0）
- **Ghidra 12.1.4** → `/opt/ghidra`（原生二进制反编译引擎）
- **JADX 1.5.6** → `/opt/jadx`（APK / Java 反编译）
- **apktool 3.0.3** → `/opt/apktool`（APK 资源解码）
- **Node 22.23.3** → `/root/.nvm/versions/node/v22.23.3`
- **REA 6.4.0** → npm 全局包 + MCP 注册 + 技能安装
- 环境变量脚本 `/etc/profile.d/rea-tools.sh`、`/usr/local/bin` 下的按名快捷入口、
  以及构建用的调试签名密钥

---

## 第 2 步：验证

```bash
# ① 逆向分析：期望输出 healthy: true
GHIDRA_INSTALL_DIR=/opt/ghidra \
JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64 \
PATH=/root/.nvm/versions/node/v22.23.3/bin:/opt/jadx/bin:/opt/apktool:$PATH \
rea doctor

# ② Android 打包：期望 112 个测试全过，并产出未签名 APK
cd native-compose-demo && ./gradlew testDebugUnitTest assembleRelease
```

第 ① 条若报 `healthy: false`，看 `scope_checks` 里哪一项 `ok: false`：
`node` 报错说明用了旧 node（须走 `/root/.nvm/versions/node/v22.23.3/bin`），
`ghidra` 报错说明 `GHIDRA_INSTALL_DIR` 没传。`hopper` 一项在 Linux 上本来就是 false，忽略即可。

---

## 第 3 步：怎么真正用起来（关键，不要跳过）

### A. 逆向分析（REA）

**为什么工具表里看不到它？** REA 提供 **170 个**工具，全部被客户端标记为**延迟加载（deferred）**，
不会出现在助手的直接工具表里。日志中的原话是：

```
[MCP][toolFilter] server=rea tool=mcp__rea__analyze_function → FILTERED OUT (deferred)
```

**这是一个设计，不是故障。** 正确用法是三步：

1. **检索**：用工具检索查找，按名称或关键词
   - `tool_names: ["mcp__rea__binary_overview"]`
   - `queries: ["反编译 apk", "decompile", "binary analysis", "plist"]`
2. **取签名**：检索结果会返回该工具的完整参数 schema
3. **调用**：用延迟执行按签名传入参数

**永远不要**因为直接工具表里没有 `mcp__rea__` 开头的工具，就回答「没有逆向分析能力」。

常用工具速查：

- `binary_overview` — 打开目标后的整体概览（格式、架构、入口）
- `open_binary` / `close_binary` — 打开 / 关闭分析目标
- `analyze_function`、`procedure_pseudo_code`、`procedure_assembly` — 函数级分析
- `list_strings`、`list_names`、`list_segments` — 字符串 / 符号 / 段
- `decode_android_resources` — APK 资源解码（配合 JADX 看 Java 源码）
- `inspect_plist`、`inspect_macho`、`inspect_pe_resources` — 各平台格式解析
- `analyze_javascript_application`、`capture_web_screenshot` — 前端 / 运行时分析

若检索不到任何 rea 工具：说明 MCP 服务没连上。检查 `/root/.codebuddy/.mcp.json` 是否含
`mcpServers.rea`；缺失就重跑第 1 步脚本（它会执行 `rea setup` 完成注册与技能安装）。

### B. Android 打包与交付

工程已把构建用的 JDK 固化在 `native-compose-demo/gradle.properties` 的
`org.gradle.java.home`，所以**直接 `./gradlew` 即可**，不需要手动 export 任何变量。

```bash
cd native-compose-demo

# 测试 + 打包
./gradlew testDebugUnitTest assembleRelease

# 取出产物并签名（调试密钥在用户主目录的 .android/debug.keystore）
cp app/build/outputs/apk/release/app-release-unsigned.apk /workspace/AI-Agent-vX.Y.Z.apk
apksigner sign --ks /root/.android/debug.keystore --ks-key-alias androiddebugkey \
  --ks-pass pass:android --key-pass pass:android /workspace/AI-Agent-vX.Y.Z.apk

# 复验版本号与签名
aapt2 dump badging /workspace/AI-Agent-vX.Y.Z.apk | grep package
apksigner verify /workspace/AI-Agent-vX.Y.Z.apk
```

交付约定：**每次交付必须递增 versionCode 与 versionName**（在 `app/build.gradle.kts`），
改动后先跑通全部单元测试（当前 112 个用例）。

---

## 第 4 步：四个「看起来像缺失、其实都在」的误判

这四条之前都真实坑过助手，请特别注意：

1. **默认 `java` 是 20 ≠ 没有 JDK 21**
   镜像里 SDKMAN 的默认 java 是 20，JDK 21 在 `/usr/lib/jvm/java-21-openjdk-amd64`。
   工程已把构建 JDK 固化，构建不受影响；`./gradlew --version` 出现
   `Daemon JVM: … (from org.gradle.java.home)` 即正常。

2. **`ANDROID_HOME` 为空 ≠ Android SDK 缺失**
   SDK 在 `/opt/android-sdk`，由工程内 `local.properties` 的 `sdk.dir` 指定。
   Gradle 构建**不读** `ANDROID_HOME`，变量为空完全不影响打包。

3. **环境变量读不到 ≠ 工具没装**
   完整配置写在 `/etc/profile.d/rea-tools.sh`，只对**登录 shell** 生效；
   助手的命令行是**非登录 shell**，读不到。判断工具是否可用，请以**绝对路径**或
   **按名调用是否成功**为准（`aapt2`、`apksigner`、`adb`、`jadx`、`apktool` 都已建按名入口）。

4. **工具表里没有 `mcp__rea__` ≠ 没有逆向能力**
   见第 3 步 A：它们是延迟加载的，检索后即可调用。

---

## 附：脚本全文

若助手无法直接读取工作区文件（例如把本文档贴在别处使用），可用下面的全文在沙盒里重建脚本。

### setup-toolchain.sh

```bash
#!/usr/bin/env bash
# ============================================================================
#  一键配置「逆向分析」+「Android 打包」两套能力（幂等，可反复执行）
#
#  用法：  bash native-compose-demo/setup-toolchain.sh
#
#  为什么需要它：沙盒镜像本身不含这两套工具链，只有在装过一次的沙盒里才存在。
#  新会话如果落在全新沙盒，就会「看起来什么都没有」——本脚本把两套能力装回来。
#
#  安装内容与落点：
#    JDK 21        → /usr/lib/jvm/java-21-openjdk-amd64（apt）
#    Android SDK   → /opt/android-sdk（cmdline-tools / platform-tools /
#                    platforms;android-36 / build-tools;36.0.0）
#    Ghidra 12.1.4 → /opt/ghidra（反编译引擎）
#    JADX 1.5.6    → /opt/jadx（APK / Java 反编译）
#    apktool 3.0.3 → /opt/apktool（APK 资源解码）
#    Node 22.23.3  → /root/.nvm/versions/node/v22.23.3（nvm）
#    REA 6.4.0     → npm 全局包 + MCP 注册 + 技能软链
# ============================================================================

JAVA_HOME_21=/usr/lib/jvm/java-21-openjdk-amd64
ANDROID_SDK=/opt/android-sdk
BT_VERSION=36.0.0
NODE_VERSION=22.23.3
# 注意：nvm 的目录名带 v 前缀（/root/.nvm/versions/node/v22.23.3）
NODE_DIR=/root/.nvm/versions/node/v$NODE_VERSION

FAILED=0
log()  { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }
ok()   { printf '  \033[32m✓\033[0m %s\n' "$1"; }
skip() { printf '  \033[2m·\033[0m %s\n' "$1"; }
bad()  { printf '  \033[31m✗\033[0m %s\n' "$1"; FAILED=$((FAILED+1)); }

# 下载：断点续传 + 慢速自动重试。
# 沙盒到 GitHub 的带宽可能只有 0.1~0.5 MB/s，Ghidra 有 570MB，
# 所以必须允许「慢」和「中断后续传」，不能设短的硬超时。
dl() {
    curl -fL --retry 6 --retry-delay 5 --retry-all-errors \
         --connect-timeout 30 --speed-limit 1024 --speed-time 180 \
         -C - -o "$1" "$2"
}

echo "=============================================="
echo "  工具链配置脚本    $(date '+%Y-%m-%d %H:%M:%S')"
echo "=============================================="

# ── 1. JDK 21 ───────────────────────────────────────────────────────────────
log "1/6  JDK 21"
if [ -x "$JAVA_HOME_21/bin/java" ]; then
    skip "JDK 21 已存在（$JAVA_HOME_21）"
else
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq && apt-get install -y -qq openjdk-21-jdk-headless \
        && ok "已安装 JDK 21" || bad "JDK 21 安装失败"
fi
if [ -x "$JAVA_HOME_21/bin/java" ]; then
    # 让默认 java 也指向 21（沙盒镜像默认是 20，会让构建失败）
    if [ -d /root/.sdkman/candidates/java ]; then
        ln -sfn "$JAVA_HOME_21" /root/.sdkman/candidates/java/current
        ok "默认 java 已指向 JDK 21"
    fi
fi

# ── 2. Android SDK ──────────────────────────────────────────────────────────
log "2/6  Android SDK"
export JAVA_HOME="$JAVA_HOME_21"
SDKMANAGER="$ANDROID_SDK/cmdline-tools/latest/bin/sdkmanager"
if [ -x "$SDKMANAGER" ]; then
    skip "cmdline-tools 已存在"
else
    mkdir -p "$ANDROID_SDK/cmdline-tools"
    if dl /tmp/clt.zip "https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip"; then
        rm -rf /tmp/clt && mkdir -p /tmp/clt && unzip -q /tmp/clt.zip -d /tmp/clt
        rm -rf "$ANDROID_SDK/cmdline-tools/latest"
        mv /tmp/clt/cmdline-tools "$ANDROID_SDK/cmdline-tools/latest"
        ok "cmdline-tools 已安装"
    else
        bad "cmdline-tools 下载失败"
    fi
fi

if [ -x "$SDKMANAGER" ]; then
    mkdir -p "$ANDROID_SDK/licenses"
    for f in android-sdk-license android-sdk-preview-license android-googletv-license \
             android-googlexr-license android-sdk-arm-dbt-license google-gdk-license \
             microxr-sysimage-license mips-android-sysimage-license; do
        printf '\n24333f8a63b6825ea9c5514f83c2829b004d1fee\n84831b9409646a918e30573bab4c9c91346d8abd\n' \
            > "$ANDROID_SDK/licenses/$f"
    done
    yes 2>/dev/null | "$SDKMANAGER" --sdk_root="$ANDROID_SDK" --licenses >/dev/null 2>&1
    "$SDKMANAGER" --sdk_root="$ANDROID_SDK" \
        "platform-tools" "platforms;android-36" "build-tools;$BT_VERSION" 2>&1 \
        | tail -3
    if [ -x "$ANDROID_SDK/build-tools/$BT_VERSION/aapt2" ]; then
        ok "platform-tools / android-36 / build-tools $BT_VERSION 就绪"
    else
        bad "SDK 组件安装不完整"
    fi
fi

# ── 3. 逆向分析引擎 ─────────────────────────────────────────────────────────
log "3/6  Ghidra / JADX / apktool"

if [ -d /opt/ghidra/Ghidra ]; then
    skip "Ghidra 已存在（/opt/ghidra）"
else
    GHIDRA_URL="https://github.com/NationalSecurityAgency/ghidra/releases/download/Ghidra_12.1.4_build/ghidra_12.1.4_PUBLIC_20260921.zip"
    if [ -f /tmp/ghidra.zip ] && unzip -tq /tmp/ghidra.zip >/dev/null 2>&1; then
        ok "使用已就绪的 /tmp/ghidra.zip"
    else
        echo "      下载中（约 570MB，视带宽可能需要 10~30 分钟；中断后重跑本脚本会断点续传）"
        dl /tmp/ghidra.zip "$GHIDRA_URL" || bad "Ghidra 下载未完成（重新执行本脚本会继续下载）"
    fi
    if unzip -tq /tmp/ghidra.zip >/dev/null 2>&1; then
        rm -rf /tmp/gh && mkdir -p /tmp/gh && unzip -q /tmp/ghidra.zip -d /tmp/gh
        src=$(find /tmp/gh -maxdepth 1 -type d -name 'ghidra_*' | head -1)
        rm -rf /opt/ghidra
        if [ -n "$src" ]; then mv "$src" /opt/ghidra && ok "Ghidra 已安装"; else bad "Ghidra 解压结构异常"; fi
        rm -rf /tmp/gh
    fi
fi

if [ -x /opt/jadx/bin/jadx ]; then
    skip "JADX 已存在（/opt/jadx）"
else
    if dl /tmp/jadx.zip "https://github.com/skylot/jadx/releases/download/v1.5.6/jadx-1.5.6.zip"; then
        rm -rf /opt/jadx && mkdir -p /opt/jadx && unzip -q /tmp/jadx.zip -d /opt/jadx
        chmod +x /opt/jadx/bin/* 2>/dev/null
        ok "JADX 已安装"
    else
        bad "JADX 下载失败"
    fi
fi

if [ -f /opt/apktool/apktool_3.0.3.jar ]; then
    skip "apktool 已存在（/opt/apktool）"
else
    mkdir -p /opt/apktool
    if dl /opt/apktool/apktool_3.0.3.jar "https://github.com/iBotPeaches/Apktool/releases/download/v3.0.3/apktool_3.0.3.jar"; then
        ok "apktool 已安装"
    else
        bad "apktool 下载失败"
    fi
fi
printf '#!/bin/bash\nexec java -jar /opt/apktool/apktool_3.0.3.jar "$@"\n' > /usr/local/bin/apktool
chmod +x /usr/local/bin/apktool

# ── 4. Node + REA ───────────────────────────────────────────────────────────
log "4/6  Node $NODE_VERSION + REA"
export NVM_DIR=/root/.nvm
if [ ! -s "$NVM_DIR/nvm.sh" ]; then
    curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash >/dev/null 2>&1
fi
if [ -s "$NVM_DIR/nvm.sh" ]; then
    # shellcheck disable=SC1091
    . "$NVM_DIR/nvm.sh" >/dev/null 2>&1
    if [ -x "$NODE_DIR/bin/node" ]; then
        skip "Node $NODE_VERSION 已存在"
    else
        nvm install "$NODE_VERSION" >/dev/null 2>&1 && ok "Node $NODE_VERSION 已安装" || bad "Node 安装失败"
    fi
else
    bad "nvm 不可用"
fi

if [ -x "$NODE_DIR/bin/rea" ]; then
    skip "REA 已安装（$("$NODE_DIR/bin/rea" --version 2>/dev/null | head -1)）"
else
    "$NODE_DIR/bin/npm" i -g rea-agents@6.4.0 >/dev/null 2>&1 \
        && ok "rea-agents 已安装" || bad "rea-agents 安装失败"
fi

# ── 5. 环境变量、MCP 注册、快捷入口 ─────────────────────────────────────────
log "5/6  环境变量 / MCP 注册 / 快捷入口"

cat > /etc/profile.d/rea-tools.sh <<'EOS'
# 逆向分析与 Android 打包工具链配置
export GHIDRA_INSTALL_DIR=/opt/ghidra
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
case ":$PATH:" in *":$JAVA_HOME/bin:"*) ;; *) export PATH="$JAVA_HOME/bin:$PATH" ;; esac
export PATH="/opt/jadx/bin:/opt/apktool:$PATH"
export ANDROID_HOME=/opt/android-sdk
export ANDROID_SDK_ROOT=/opt/android-sdk
case ":$PATH:" in
  *":$ANDROID_HOME/platform-tools:"*) ;;
  *) export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH" ;;
esac
export NVM_DIR=/root/.nvm
[ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh" >/dev/null 2>&1 && nvm use 22.23.3 >/dev/null 2>&1
EOS
ok "已写入 /etc/profile.d/rea-tools.sh（登录 shell 生效）"

# 助手的命令行是非登录 shell，读不到上面的变量 —— 所以再建一层按名可调的入口
for pair in "aapt2:$ANDROID_SDK/build-tools/$BT_VERSION/aapt2" \
            "apksigner:$ANDROID_SDK/build-tools/$BT_VERSION/apksigner" \
            "zipalign:$ANDROID_SDK/build-tools/$BT_VERSION/zipalign" \
            "adb:$ANDROID_SDK/platform-tools/adb" \
            "jadx:/opt/jadx/bin/jadx"; do
    name="${pair%%:*}"; target="${pair##*:}"
    [ -x "$target" ] && ln -sfn "$target" "/usr/local/bin/$name"
done
ok "已建快捷入口：aapt2 / apksigner / zipalign / adb / jadx / apktool"

if [ -x "$NODE_DIR/bin/rea" ]; then
    if grep -q '"rea"' /root/.codebuddy/.mcp.json 2>/dev/null; then
        skip "MCP 已注册 rea 服务"
    else
        "$NODE_DIR/bin/rea" setup --yes --all-detected >/dev/null 2>&1 \
            && ok "已执行 rea setup（注册 MCP + 安装技能）" || bad "rea setup 失败"
    fi
fi

# ── 6. 校验 ─────────────────────────────────────────────────────────────────
log "6/6  校验"
export GHIDRA_INSTALL_DIR=/opt/ghidra
export PATH="$NODE_DIR/bin:$JAVA_HOME_21/bin:/opt/jadx/bin:/opt/apktool:$PATH"

if [ -x "$NODE_DIR/bin/rea" ]; then
    if "$NODE_DIR/bin/rea" doctor 2>/dev/null | grep -q "^healthy: true"; then
        ok "rea doctor：healthy"
    else
        "$NODE_DIR/bin/rea" doctor 2>/dev/null | grep -E "^(healthy|environment_healthy)" | sed 's/^/    /'
    fi
fi

echo
if [ -f "$ANDROID_SDK/build-tools/$BT_VERSION/aapt2" ]; then ok "aapt2 就绪"; else bad "aapt2 缺失"; fi
if [ -f /root/.android/debug.keystore ]; then
    ok "签名密钥存在"
else
    mkdir -p /root/.android
    keytool -genkeypair -v -keystore /root/.android/debug.keystore \
        -alias androiddebugkey -storepass android -keypass android \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -dname "CN=Android Debug,O=Android,C=US" >/dev/null 2>&1 \
        && ok "已生成调试签名密钥" || bad "签名密钥生成失败"
fi

echo
echo "=============================================="
if [ "$FAILED" -eq 0 ]; then
    printf ' \033[32m配置完成：全部就绪\033[0m\n'
else
    printf ' \033[31m配置结束：%d 项失败\033[0m（详见上面 ✗ 行，可重跑本脚本补齐）\n' "$FAILED"
fi
echo "=============================================="
echo
echo "下一步："
echo "  1) 体检：bash native-compose-demo/check-env.sh"
echo "  2) 构建：cd native-compose-demo && ./gradlew testDebugUnitTest assembleRelease"
echo
echo "注意：REA 的逆向工具是「延迟加载」的 MCP 工具，不在助手的直接工具表里；"
echo "      必须先用工具检索（ToolSearch）按关键词查找，再用 DeferExecuteTool 调用。"
```
